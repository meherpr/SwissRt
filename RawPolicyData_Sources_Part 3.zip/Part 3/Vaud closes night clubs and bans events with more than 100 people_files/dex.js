/**
 * Cookies Library: /npm/js-cookie@2.2.0/src/js.cookie.js
 */
!function(e){var n=!1;if("function"==typeof define&&define.amd&&(define(e),n=!0),"object"==typeof exports&&(module.exports=e(),n=!0),!n){var o=window.Cookies,t=window.Cookies=e();t.noConflict=function(){return window.Cookies=o,t}}}(function(){function e(){for(var e=0,n={};e<arguments.length;e++){var o=arguments[e];for(var t in o)n[t]=o[t]}return n}function n(o){function t(n,r,i){var c;if("undefined"!=typeof document){if(arguments.length>1){if("number"==typeof(i=e({path:"/"},t.defaults,i)).expires){var a=new Date;a.setMilliseconds(a.getMilliseconds()+864e5*i.expires),i.expires=a}i.expires=i.expires?i.expires.toUTCString():"";try{c=JSON.stringify(r),/^[\{\[]/.test(c)&&(r=c)}catch(e){}r=o.write?o.write(r,n):encodeURIComponent(String(r)).replace(/%(23|24|26|2B|3A|3C|3E|3D|2F|3F|40|5B|5D|5E|60|7B|7D|7C)/g,decodeURIComponent),n=(n=(n=encodeURIComponent(String(n))).replace(/%(23|24|26|2B|5E|60|7C)/g,decodeURIComponent)).replace(/[\(\)]/g,escape);var s="";for(var f in i)i[f]&&(s+="; "+f,!0!==i[f]&&(s+="="+i[f]));return document.cookie=n+"="+r+s}n||(c={});for(var p=document.cookie?document.cookie.split("; "):[],d=/(%[0-9A-Z]{2})+/g,u=0;u<p.length;u++){var l=p[u].split("="),C=l.slice(1).join("=");this.json||'"'!==C.charAt(0)||(C=C.slice(1,-1));try{var g=l[0].replace(d,decodeURIComponent);if(C=o.read?o.read(C,g):o(C,g)||C.replace(d,decodeURIComponent),this.json)try{C=JSON.parse(C)}catch(e){}if(n===g){c=C;break}n||(c[g]=C)}catch(e){}}return c}}return t.set=t,t.get=function(e){return t.call(t,e)},t.getJSON=function(){return t.apply({json:!0},[].slice.call(arguments))},t.defaults={},t.remove=function(n,o){t(n,"",e(o,{expires:-1}))},t.withConverter=n,t}return n(function(){})});


/** UUID Library **/
function uuidv4() {return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) { var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8); return v.toString(16);});}

/**
 * Detect if is a search engine
 * @returns {boolean}
 */
function isCrawler(userAgent){
    var botPattern = "(googlebot\/|Googlebot-Mobile|Googlebot-Image|Google favicon|Mediapartners-Google|bingbot|slurp|java|wget|curl|Commons-HttpClient|Python-urllib|libwww|httpunit|nutch|phpcrawl|msnbot|jyxobot|FAST-WebCrawler|FAST Enterprise Crawler|biglotron|teoma|convera|seekbot|gigablast|exabot|ngbot|ia_archiver|GingerCrawler|webmon |httrack|webcrawler|grub.org|UsineNouvelleCrawler|antibot|netresearchserver|speedy|fluffy|bibnum.bnf|findlink|msrbot|panscient|yacybot|AISearchBot|IOI|ips-agent|tagoobot|MJ12bot|dotbot|woriobot|yanga|buzzbot|mlbot|yandexbot|purebot|Linguee Bot|Voyager|CyberPatrol|voilabot|baiduspider|citeseerxbot|spbot|twengabot|postrank|turnitinbot|scribdbot|page2rss|sitebot|linkdex|Adidxbot|blekkobot|ezooms|dotbot|Mail.RU_Bot|discobot|heritrix|findthatfile|europarchive.org|NerdByNature.Bot|sistrix crawler|ahrefsbot|Aboundex|domaincrawler|wbsearchbot|summify|ccbot|edisterbot|seznambot|ec2linkfinder|gslfbot|aihitbot|intelium_bot|facebookexternalhit|yeti|RetrevoPageAnalyzer|lb-spider|sogou|lssbot|careerbot|wotbox|wocbot|ichiro|DuckDuckBot|lssrocketcrawler|drupact|webcompanycrawler|acoonbot|openindexspider|gnam gnam spider|web-archive-net.com.bot|backlinkcrawler|coccoc|integromedb|content crawler spider|toplistbot|seokicks-robot|it2media-domain-crawler|ip-web-crawler.com|siteexplorer.info|elisabot|proximic|changedetection|blexbot|arabot|WeSEE:Search|niki-bot|CrystalSemanticsBot|rogerbot|360Spider|psbot|InterfaxScanBot|Lipperhey SEO Service|CC Metadata Scaper|g00g1e.net|GrapeshotCrawler|urlappendbot|brainobot|fr-crawler|binlar|SimpleCrawler|Livelapbot|Twitterbot|cXensebot|smtbot|bnf.fr_bot|A6-Indexer|ADmantX|Facebot|Twitterbot|OrangeBot|memorybot|AdvBot|MegaIndex|SemanticScholarBot|ltx71|nerdybot|xovibot|BUbiNG|Qwantify|archive.org_bot|Applebot|TweetmemeBot|crawler4j|findxbot|SemrushBot|yoozBot|lipperhey|y!j-asr|Domain Re-Animator Bot|AddThis)";
    var re = new RegExp(botPattern, 'i');
    if (re.test(userAgent)) { return true;  }
    else{return false;}
}

/**
 * Extract URL from domain
 * @param data
 * @returns {string}
 * @constructor
 */
function extractHostname(url) {
    var hostname;
    if (url.indexOf("//") > -1) { hostname = url.split('/')[2]; }
    else { hostname = url.split('/')[0]; }
    hostname = hostname.split(':')[0];
    hostname = hostname.split('?')[0];
    return hostname;
}


/**
 * Check if element in array
 * @param needle
 * @param haystack
 * @returns {boolean}
 */
function inArray(needle, haystack) {
    var length = haystack.length;
    for (var i = 0; i < length; i++) {
        if (haystack[i] == needle)
            return true;
    }
    return false;
}



/**
 * App
 */
var dex = {

    /**
     * Configuration
     */
    config: {
        cookie: {
            name: 'dx',
            validity: 365 * 10
        },
        ws: {
            capture: dexdata.capture,
            persistence: dexdata.persistence
        },
        debug: dexdata.debug,
        persist: {
            timer: 5000
        },
        domains:[ 'cdt.ch', 'www.cdt.ch']
    },



    /**
     * Init procedure
     */
    init: function(){
        if(this.config.debug) { console.log("DEX: Init Has been Call [48]"); }

        if( (!isCrawler(this.getUserAgent()))  &&  (this.hasRequiredData()) &&  (this.isValidRun()) ){
            if(this.isNewUser()){ this.createNewTracer();}

            //Verify that user has the identifier set (new or already existing) - may cookie not allowed (undefined)
            if(typeof this.getUserIdentifier() !== 'undefined'){
                this.traceActivity();
            }
        }
        else{
            if(this.config.debug) { console.log("DEX: isCrawler or Not Has Required Data [58]"); }
        }

    },


    /**
     * Verify that all the mandatory data has been set
     */
    hasRequiredData: function(){
        if(this.getUniqueKey() === null){
            if(this.config.debug){ console.log("DEX: No unique KEY, SKIP [65]"); }
            return false;
        }

        if(this.getProperty() === null){
            if(this.config.debug) { console.log("DEX: No property id, SKIP [72]"); }
            return false;
        }

        return true;
    },



    /**
     * Verify that the execution is valid
     */
    isValidRun: function(){
        var URL = this.getCurrrentURL();
        var domain = extractHostname(URL);

        if(!inArray(domain, this.config.domains) ){
            console.log("DEX: KO, the domain is not valid one SKIP [73]");
            return false;
        }

        return true;
    },


    /**
     * Check if user has already a cookie with informations
     */
    isNewUser: function(){
        if(typeof Cookies.get(this.config.cookie.name) === 'undefined'){
            if(this.config.debug){ console.log("DEX: Is New User [82]"); }
            return true;
        }
        else{
            if(this.config.debug){ console.log("DEX: Not A new User [86]"); }
            return false;
        }
    },



    /**
     * Get User Identifier
     * @returns {*}
     */
    getUserIdentifier: function(){
        if(this.config.debug) { console.log("DEX: Get User Identifier [98]"); }
        return Cookies.get(this.config.cookie.name);
    },



    /**
     * Get the navigation referrer
     * @returns {string}
     */
    getReferrer: function(){
        if(this.config.debug) { console.log("DEX: Get User Referrer [109]"); }
        return document.referrer;
    },



    /**
     * Send User Information
     */
    traceActivity: function(){
        if(this.config.debug) { console.log("DEX: Trace Activity [119]"); }
        var xhttp = new XMLHttpRequest();
        xhttp.open("POST", this.config.ws.capture, true);
        xhttp.onreadystatechange = function() {
            if(this.readyState == XMLHttpRequest.DONE && this.status == 200) {
                if(dex.config.debug) { console.log("DEX: Trace Activity OK Status [131]"); }
                var response = JSON.parse(this.responseText);
                window.dexnid = response.nid;
                dex.startPersistence(response.nid, dex.config.persist.timer);
            }
        }

        xhttp.send(this.dataCollect());
    },


    /**
     * XHR Call for Persistence time
     */
    startPersistence: function(nid, interval){
        if(this.config.debug) { console.log("DEX: Starting Persistence [145]"); }
        setInterval(function(){ dex.pingPersistence(nid) }, interval);
    },


    /**
     * Ping Percentage
     * @param nid
     */
    pingPersistence: function(nid){
        if(this.config.debug) { console.log("DEX: Persistence Call Executed [151]"); }

        var dataObj = new FormData();
        dataObj.append('nid', nid);
        dataObj.append('scroll', this.getMaxScrollPercentage());

        var xhttp = new XMLHttpRequest();
        xhttp.open("POST", this.config.ws.persistence, true);
        xhttp.send(dataObj);
    },


    /**
     * Get Scroll Percentage
     * @returns {number}
     */
    getMaxScrollPercentage: function(){
        if(this.config.debug) { console.log("DEX: Getting Current Scroll Percentage [151]"); }

        if(typeof this.maxScroll === 'undefined'){ this.maxScroll = 0;}

        var h = document.documentElement, b = document.body, st = 'scrollTop', sh = 'scrollHeight';
        var currentScroll = Math.floor( (h[st]||b[st]) / ((h[sh]||b[sh]) - h.clientHeight) * 100 );

        if(currentScroll > this.maxScroll){
            this.maxScroll = currentScroll;
        }

        return this.maxScroll;

    },


    /**
     * Return the size of the screen of the client
     */
    getScreenSize: function(){
        if(this.config.debug) { console.log("DEX: Getting Screen Size [195]"); }
        var w = window, d = document,
            e = d.documentElement,
            g = d.getElementsByTagName('body')[0],
            x = w.innerWidth || e.clientWidth || g.clientWidth,
            y = w.innerHeight|| e.clientHeight|| g.clientHeight;

        return x + " x " + y;
    },





    /**
     * Return the number of caracthers in the article
     * @returns {string}
     */
    getArticleSize: function(){
        if(this.config.debug) { console.log("DEX: Getting Article Size [214]"); }

        if(document.getElementsByClassName('article-content').length === 0){
            return null;
        }

        if(typeof document.getElementsByClassName('article-content')[0] === "undefined"){
            return null;
        }

        return document.getElementsByClassName('article-content')[0].scrollHeight;
    },


    /**
     * Collect data for the user
     */
    dataCollect: function(){
        if(this.config.debug) { console.log("DEX: Collecting Data [131]"); }

        var dataObj = new FormData();
        dataObj.append('uuid', this.getUserIdentifier());

        dataObj.append('url', this.getCurrrentURL());
        dataObj.append('property', this.getProperty());
        dataObj.append('unique_key', this.getUniqueKey());

        dataObj.append('unique_key', this.getUniqueKey());
        dataObj.append('has_paywall', this.getHasPayWall());
        dataObj.append('is_subscriber', this.isSubscriber());

        dataObj.append('referrer', this.getReferrer());
        dataObj.append('user_agent', this.getUserAgent());

        dataObj.append('screen', this.getScreenSize());
        dataObj.append('arsize', this.getArticleSize());

        return dataObj;
    },


    /**
     * Create new tracing system
     */
    createNewTracer: function(){
        if(this.config.debug) { console.log("DEX: Creating new Cookie [151]"); }
        Cookies.set(this.config.cookie.name, uuidv4(), { expires: dex.config.cookie.validity });
    },



    /**
     * Get Current Domain
     * @returns {string}
     */
    getCurrrentURL: function(){
        if(this.config.debug) { console.log("DEX: Getting Current URL [162]"); }
        return window.location.href;
    },



    /**
     * Get the Unique Key id if exist
     */
    getUniqueKey:function(){
        if(this.config.debug) { console.log("DEX: Getting Unique KEY [172]"); }
        if( ((typeof dexdata !== 'undefined') && (typeof dexdata.unique_key !== 'undefined')) ){
            return dexdata.unique_key;
        }else{
            return null;
        }
    },





    /**
     * Get the Unique Key id if exist
     */
    getHasPayWall:function(){
        if(this.config.debug) { console.log("DEX: Getting IsPayWall KEY [182]"); }
        if( ((typeof dexdata !== 'undefined') && (typeof dexdata.has_paywall !== 'undefined')) ){
            return dexdata.has_paywall;
        }else{
            return false;
        }
    },



    /**
     * Get the Unique Key id if exist
     */
    isSubscriber:function(){
        if(this.config.debug) { console.log("DEX: Getting IsSubscriber KEY [192]"); }
        if( ((typeof dexdata !== 'undefined') && (typeof dexdata.is_subscriber !== 'undefined')) ){
            return dexdata.is_subscriber;
        }else{
            return null;
        }
    },



    /**
     * Get the Propriety id if exist
     */
    getProperty:function(){
        if(this.config.debug) { console.log("DEX: Getting Property KEY [186]"); }
        if( ((typeof dexdata !== 'undefined') && (typeof dexdata.property !== 'undefined')) ){
            return dexdata.property;
        }else{
            return null;
        }
    },



    /**
     * Get the User Agent
     * @returns {string}
     */
    getUserAgent: function(){
        if(this.config.debug) { console.log("DEX: Getting User Agent [201]"); }
        return navigator.userAgent;
    }


}

document.addEventListener("DOMContentLoaded", function(){
    dex.init();
});