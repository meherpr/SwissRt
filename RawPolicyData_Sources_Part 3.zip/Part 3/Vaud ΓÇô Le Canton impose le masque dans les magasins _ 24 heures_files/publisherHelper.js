"use strict";

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

var MESSAGE_API = {
  AUTHORITY: {
    IN: 'codevelop',
    OUT: 'codevelop'
  },
  ORIGIN: {
    IN: 'brokenSun',
    OUT: 'publisherHelper'
  }
};
var publisherQuery2;

var PublisherHelper =
/*#__PURE__*/
function () {
  function PublisherHelper() {
    _classCallCheck(this, PublisherHelper);

    this.$bannerIframeElement = null;
    this.alreadyLoaded = false;
    this.codev_ignoreScrollEvent = false;
    this.codev_videoHidden = false;
    this.bannerInitialised = false;
    this.sticky_timer = null;
    this.bannerFixed = false;
    this.bannerOuterContainer = null;
    this.bannerStartPosition = null;
    this.init();
  }

  _createClass(PublisherHelper, [{
    key: "normalize",
    value: function normalize(val, min, max) {
      var result = Math.min((val - min) / (max - min), 1);
      return result < 0 ? 0 : result;
    }
  }, {
    key: "sendMessageToBanner",
    value: function sendMessageToBanner(action, message) {
      if (typeof message === 'undefined') {
        message = null;
      }

      if (this.$bannerIframeElement) {
        this.$bannerIframeElement.contentWindow.postMessage(JSON.stringify({
          authority: MESSAGE_API.AUTHORITY.OUT,
          origin: MESSAGE_API.ORIGIN.OUT,
          action: action,
          message: message
        }), '*');
      }
    }
  }, {
    key: "getFrameByEvent",
    value: function getFrameByEvent(event) {
      // this is the IFRAME which send the postMessage
      var sourceFrame = null;
      var myFrames = document.getElementsByTagName('IFRAME'); // event is the event raised by the postMessage

      var eventSource = event.source; // origin domain, e.g. http://example.com

      var eventOrigin = event.origin; // detect the source for IFRAMEs with same-origin URL

      for (var i = 0; i < myFrames.length; ++i) {
        var f = myFrames[i];

        if (f.contentWindow === eventSource || // for absolute URLs
        f.contentWindow === eventSource.parent) {
          // for relative URLs
          sourceFrame = f;
          break;
        }
      } // detect the source for IFRAMEs with cross-origin URL (because accessing/comparing event.source properties is not allowed for cross-origin URL)


      if (sourceFrame === null) {
        for (var _i = 0; _i < myFrames.length; ++_i) {
          if (myFrames[_i].src.indexOf(eventOrigin) === 0) {
            sourceFrame = myFrames[_i];
            break;
          }
        }
      }

      return sourceFrame;
    }
  }, {
    key: "saveBannerStartPosition",
    value: function saveBannerStartPosition() {
      this.bannerStartPosition = this.$codevelopIframeContainer.getBoundingClientRect().top + window.scrollY;
    }
  }, {
    key: "getStickPositionOnScreen",
    value: function getStickPositionOnScreen() {
      var _this = this;

      var sum = [];

      if (!this.watchForStick) {
        return 0;
      }

      if (this.watchForStick.top) {
        sum.push(0);
      }

      if (this.watchForStick.items) {
        this.watchForStick.items.forEach(function (item, i) {
          sum.push((item ? item.getBoundingClientRect().bottom : 0) + _this.watchForStick.offset); // TODO: check how it changes when ad tranlates up
        });
      }

      return Math.max.apply(null, sum);
    }
  }, {
    key: "revertBannerPosition",
    value: function revertBannerPosition() {
      var stickyElt = this.$stickyElement,
          currentPos = stickyElt.getBoundingClientRect().top + window.scrollY - this.bannerStartPosition,
          targetPos = this.$staticContainer.getBoundingClientRect().top + window.scrollY - this.bannerStartPosition;
      stickyElt.style.position = 'absolute';
      stickyElt.style.top = currentPos + this.ignoreStick + this.offset.y + 'px';
      stickyElt.style.left = this.offset.x ? this.offset.x + 'px' : null;
      publisherQuery2(stickyElt).animate({
        top: 0 + this.ignoreStick + this.offset.y + 'px'
      }, 500, function () {});
    }
  }, {
    key: "updateBannerOnScroll",
    value: function updateBannerOnScroll() {
      var _this2 = this;

      if (this.codev_ignoreScrollEvent || !this.$staticContainer) {
        return;
      }

      var scroll = window.scrollY;
      this.sendMessageToBanner('PositionIcons', {
        status: 'scroll'
      });

      if (!this.initialized) {
        return;
      }

      if (this.codev_videoHidden) {
        if (scroll > this.bannerStartPosition + 250) {
          this.sendMessageToBanner('VideoPause', {});
        } else {
          this.sendMessageToBanner('VideoContinue', {});
        }

        return;
      }

      var stickPosition = this.getStickPositionOnScreen(),
          staticContainerBounds = this.$staticContainer.getBoundingClientRect();

      if (staticContainerBounds.top + this.ignoreStick <= stickPosition - this.offset.y) {
        this.$staticContainer.classList.add('is-fixed');
        this.$stickyElement.style.top = stickPosition + 'px';
        this.$stickyElement.style.left = staticContainerBounds.left + this.offset.x + 'px';
      } else {
        this.$staticContainer.classList.remove('is-fixed');
        this.$stickyElement.style.top = 0 + this.ignoreStick + this.offset.y + 'px';
        this.$stickyElement.style.left = 0 + this.offset.x + 'px';
      }

      var height = this.normalize(scroll, this.resizeStartPoints[0], this.resizeStartPoints[1]) * this.videoHeadVideoHeight;
      var scrolldownIconVisible = true;

      if (scroll > 100 && scrolldownIconVisible) {
        scrolldownIconVisible = false;
        this.sendMessageToBanner('ScrollDownIconVisible');
      }

      var heightBreakpoint = 250;

      if (height > heightBreakpoint) {
        if (typeof this.brokenSunPublisherSettings !== 'undefined') {
          this.actionMinHeightClassElements({
            minHeightClassElements: this.brokenSunPublisherSettings.minHeightClassElements
          });
        }

        this.setBannerSize({
          height: height
        });
        this.sendMessageToBanner('AudioIconDown', {
          down: true
        });

        if (this.sticky_timer != null) {
          clearTimeout(this.sticky_timer);
          this.sticky_timer = null;
          console.log('reset timer');
        }
      } else {
        // Analytics
        if (!this.adf_scrolldownto250px_tracker) {
          this.sendMessageToBanner('ScrollDownTo250px', {});
          this.adf_scrolldownto250px_tracker = true;
        }

        if (typeof this.brokenSunPublisherSettings !== 'undefined') {
          this.actionMinHeightClassElements({
            minHeightClassElements: this.brokenSunPublisherSettings.minHeightClassElements
          });
        }

        this.setBannerSize({
          height: heightBreakpoint
        });
        this.sendMessageToBanner('AudioIconDown', {
          down: false
        });

        if (this.sticky_timer == null) {
          if (typeof this.brokenSunPublisherSettings !== 'undefined' && this.brokenSunPublisherSettings.maxStickyTimeInSec && this.brokenSunPublisherSettings.maxStickyTimeInSec > 0) {
            console.log('start timer');
            this.sticky_timer = setTimeout(function () {
              _this2.sendMessageToBanner('StickyTimeCompleted', {});
            }, this.brokenSunPublisherSettings.maxStickyTimeInSec * 1000);
          }
        }
      } // console.timeEnd("scroll")

    }
  }, {
    key: "initEventListeners",
    value: function initEventListeners() {
      var _this3 = this;

      console.log('initEventListeners');
      window.addEventListener('message', function (e) {
        var eventDataObject = null;

        try {
          eventDataObject = JSON.parse(e.data);

          if (!eventDataObject) {
            return;
          }

          if (eventDataObject.authority !== MESSAGE_API.AUTHORITY.IN || eventDataObject.origin !== MESSAGE_API.ORIGIN.IN) {
            return;
          }
        } catch (err) {
          return;
        }

        if (eventDataObject.action === 'InitConnection' && !_this3.alreadyLoaded) {
          _this3.$bannerIframeElement = _this3.getFrameByEvent(e);
          _this3.$codevelopIframeContainer = _this3.$bannerIframeElement.parentNode;
          _this3.alreadyLoaded = true;
        }

        var functionToExecute = "action".concat(eventDataObject.action);

        if (typeof _this3[functionToExecute] === 'function') {
          _this3[functionToExecute].call(_this3, eventDataObject.message);
        }
      });
      window.addEventListener('scroll', function (e) {
        return _this3.updateBannerOnScroll();
      });
    }
  }, {
    key: "initFormat",
    value: function initFormat(originContext) {
      // Virtual Dom Injection Fix (Handelszeitung / Bilanz)
      this.resizeElt = this.$bannerIframeElement.parentElement.parentElement;
      publisherQuery(this.resizeElt).classList.add('adf_outer_div');
    }
  }, {
    key: "getResizeStartPoints",
    value: function getResizeStartPoints(data) {
      if (!data) {
        return;
      }

      return data.map(function (item, i) {
        var res;

        if (typeof item === 'string') {
          res = document.querySelector(item).getBoundingClientRect().top;
        }

        if (typeof item === 'number') {
          res = item;
        }

        return res;
      });
    }
  }, {
    key: "actionApplyPublisherSettings",
    value: function actionApplyPublisherSettings(settings) {
      // Get the creative and publisher settings
      this.brokenSunPublisherSettings = settings.publisherSettings;
      this.brokenSunCreativeSettings = settings.creativeSettings;
      this.videoHeadVideoHeight = settings.videoHeadVideoHeight;
      this.microNaviAdditionalHeight = settings.microNaviAdditionalHeight;
      this.borderbottomvalue = settings.borderbottomvalue;
      this.resizeStartPoints = this.getResizeStartPoints(this.brokenSunPublisherSettings.resizeStartPoints || [400, 0]);
      this.bannerOuterContainer = document.querySelector(this.brokenSunPublisherSettings.bannerOuterContainer);
      this.bannerOuterContainerExtraHeight = this.brokenSunPublisherSettings.bannerOuterContainerExtraHeight || 0; // this.navSettings = this.brokenSunPublisherSettings.navContainer;
      // this.navContainer = document.querySelector(this.navSettings.query);

      if (this.brokenSunPublisherSettings.watchForStick) {
        this.watchForStick = {
          items: this.brokenSunPublisherSettings.watchForStick && this.brokenSunPublisherSettings.watchForStick.items && this.brokenSunPublisherSettings.watchForStick.items.map(function (item) {
            return document.querySelector(item);
          }),
          offset: this.brokenSunPublisherSettings.watchForStick && this.brokenSunPublisherSettings.watchForStick.offset || 0,
          top: this.brokenSunPublisherSettings.watchForStick !== undefined && this.brokenSunPublisherSettings.watchForStick.top || false
        };
      }

      this.$staticContainer = publisherQuery(this.brokenSunPublisherSettings.staticContainer);
      this.$staticContainer.dataset.codevName = 'staticContainer';
      this.$stickyElement = publisherQuery(this.brokenSunPublisherSettings.stickyElement);
      this.$stickyElement.dataset.codevName = 'stickyElement';
      this.bannerTopOffset = this.brokenSunPublisherSettings.bannerTopOffset;
      this.ignoreStick = this.brokenSunPublisherSettings.ignoreStick ? document.querySelector(this.brokenSunPublisherSettings.ignoreStick).getBoundingClientRect().height : 0;
      this.offset = this.brokenSunPublisherSettings.offset || {
        x: 0,
        y: 0
      };

      if (this.brokenSunPublisherSettings.maxVideoHeadWidth) {
        this.setBannerSize({
          height: this.videoHeadVideoHeight + this.microNaviAdditionalHeight + this.borderbottomvalue,
          maxWidth: this.brokenSunPublisherSettings.maxVideoHeadWidth,
          width: 994
        });
      } else {
        this.setBannerSize({
          height: this.videoHeadVideoHeight + this.microNaviAdditionalHeight + this.borderbottomvalue,
          width: 994
        });
      }

      this.saveBannerStartPosition();
      this.sendMessageToBanner('PositionIcons', {
        status: 'initialised'
      });
    }
  }, {
    key: "setBannerSize",
    value: function setBannerSize(opts) {
      if (opts.transition) {
        this.$codevelopIframeContainer.parentNode.style.transition = 'height .5s';
        this.$codevelopIframeContainer.parentNode.parentNode.style.transition = 'height .5s';
      } else {
        this.$codevelopIframeContainer.parentNode.style.transition = null;
        this.$codevelopIframeContainer.parentNode.parentNode.style.transition = null;
      }

      if (opts.height) {
        this.$bannerIframeElement.style.height = '100%';
        this.$codevelopIframeContainer.style.height = '100%';
        this.$stickyElement.style.height = opts.height + 'px';
        this.$staticContainer.style.height = opts.height + this.bannerOuterContainerExtraHeight + 'px';
      }

      if (opts.width) {
        this.$codevelopIframeContainer.style.width = opts.width + 'px';
        this.$bannerIframeElement.style.width = opts.width + 'px';
      }

      if (opts.maxWidth) {
        this.$codevelopIframeContainer.style.maxWidth = opts.maxWidth + 'px';
        this.$bannerIframeElement.style.maxWidth = opts.maxWidth + 'px';
      }
    }
  }, {
    key: "actionApplyPublisherCSS",
    value: function actionApplyPublisherCSS(message) {
      this.$styleElement = document.createElement('style'); // this.$styleElement.innerHTML = message.css.replace('#BNWIDTH#', this.bannerBoundingClientRect.width + 'px')

      this.$styleElement.innerHTML = message.css.replace('#BNWIDTH#', this.brokenSunPublisherSettings.maxVideoHeadWidth + 'px').replace(/#BNHEIGHT#/g, this.brokenSunPublisherSettings.maxVideoHeadWidth / this.brokenSunCreativeSettings.videoDimensionRatio + 'px');
      this.$codevelopIframeContainer.appendChild(this.$styleElement);
    }
  }, {
    key: "actionSkipBanner",
    value: function actionSkipBanner(message) {
      publisherQuery2(document.documentElement).animate({
        scrollTop: window.scrollY + message.videoHeight
      }, 800);
    }
  }, {
    key: "actionCloseBanner",
    value: function actionCloseBanner(message) {
      var _this4 = this;

      this.codev_ignoreScrollEvent = true;
      this.$staticContainer.classList.add('is-closed');

      if (this.sticky_timer != null) {
        clearTimeout(this.sticky_timer);
        this.sticky_timer = null;
        console.log('reset timer');
      }

      setTimeout(function () {
        _this4.sendMessageToBanner('PositionIcons', {
          status: 'closed'
        }); // Needed?


        _this4.codev_ignoreScrollEvent = false;
      }, 500);

      if (window.scrollY > this.bannerStartPosition + 250) {
        this.sendMessageToBanner('VideoPause', {});
      } else {
        this.sendMessageToBanner('VideoContinue', {});
      }

      this.revertBannerPosition();
      this.setBannerSize({
        height: 250,
        transition: true
      });
    }
  }, {
    key: "actionVideoHidden",
    value: function actionVideoHidden(message) {
      this.codev_videoHidden = true;
    }
  }, {
    key: "actionMinHeightClassElements",
    value: function actionMinHeightClassElements(message) {
      message.minHeightClassElements.forEach(function (element) {
        element = publisherQuery(element);

        if (!element) {
          return;
        }

        element.classList.remove('min_height');
      });
    }
  }, {
    key: "actionInitConnection",
    value: function actionInitConnection(message) {
      if (this.bannerInitialised) {
        return;
      }

      this.bannerInitialised = true;
      this.sendMessageToBanner('InitBanner', {
        hostname: window.location.hostname,
        innerWidth: window.innerWidth
      });
      this.initFormat();
      this.initialized = true;
    }
  }, {
    key: "init",
    value: function init() {
      this.initEventListeners();
    }
  }]);

  return PublisherHelper;
}();

if (typeof jQuery == 'undefined') {
  var getScript = function getScript(url, success) {
    var script = document.createElement('script');
    script.src = url;
    var head = document.getElementsByTagName('head')[0],
        done = false;

    script.onload = script.onreadystatechange = function () {
      if (!done && (!this.readyState || this.readyState == 'loaded' || this.readyState == 'complete')) {
        done = true;
        success();
        script.onload = script.onreadystatechange = null;
        head.removeChild(script);
      }

      ;
    };

    head.appendChild(script);
  };

  ;
  getScript('https://cdnjs.cloudflare.com/ajax/libs/jquery/1.12.4/jquery.min.js', function () {
    publisherQuery2 = jQuery;
    console.log('cdnjsquery');
    var publisherHelper = new PublisherHelper();
  });
} else {
  publisherQuery2 = jQuery;
  console.log('publisherquery');
  var publisherHelper = new PublisherHelper();
}

;

var publisherQuery = function publisherQuery(sel) {
  if (typeof sel === 'string') {
    return document.querySelector(sel);
  }

  return sel;
};
//# sourceMappingURL=publisherHelper.js.map
