initFilter = function() {
    jQuery('.filterbar a:not(.directlink)').click(function(e) {
        e.preventDefault();
        jQuery('.filterbar a').removeClass('active');
        jQuery(this).addClass('active');
        loadMore('.ressortoverview .items', '.item', 14, 1);
        loadMore('.dossieroverview .items', '.item', 14, 1);
        loadMore('.epaperoverview .items', '.item', 14, 1);

        //Show/Hide Topstory
        if (jQuery('.ressorttopstory .item').hasClass(jQuery(this).attr('data-filter'))) {
            jQuery('.ressorttopstory .item').show();
        } else {
            jQuery('.ressorttopstory .item').hide();
        }
        
        ga('send', 'pageview');
        jQuery('.element.videos .item:visible').matchHeight();
    });

}

jQuery(document).ready(function() {

    if (jQuery('.filterbar a').length > 0) initFilter();

    //ePaper
    jQuery('.epaperFilter .select-wrap select').change(function() {
        loadMore('.epaperoverview .items', '.item', 14, 1);
    });

});
