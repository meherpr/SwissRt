jQuery(document).ready(function() {
	//Position Images
	jQuery('.timetable .item .detail p').each(function() {
		//Images
		if (jQuery(this).closest('.detail').find('figure').length > 0) {
        	varText = jQuery(this).html();
	        arrReg = /\[IMG\s.{0,7}\]/.exec(varText);
    	    if (arrReg) {
        	    addClass = "pull-left";
            	arrReg2 = [];
	            arrReg2 = arrReg[0].match(/(\d\d\d|\d\d|\d)/gi);
    	        startIMG = arrReg2[0];
        	    varText = varText.replace(arrReg[0], '');
            	jQuery(this).html(jQuery(this).closest('.detail').find('figure[data-image="timetable-img-' + startIMG + '"]')[0].outerHTML + varText).after('<div class="clear"></div>');
	        }
    	}
	});

    //Init Timetable
    jQuery('.timetable .item .accordion').click(function() {
        jQuery(this).parent().toggleClass('active');
    });

    //Init
    jQuery('.timetable .items .item').hide();
    jQuery('.timetable .items .item.' + jQuery('.timetable .filter a.active').attr('data-filter')).show();

    jQuery('.timetable .filter a').click(function(e) {
        e.preventDefault();

        jQuery('.timetable .filter a').removeClass('active');
        jQuery(this).addClass('active');

        //Filter
        jQuery('.timetable .items .item').hide();
        jQuery('.timetable .items .item.' + jQuery('.timetable .filter a.active').attr('data-filter')).show();
    });

    jQuery("#btncampusprogramm").click(function(e) {
        e.preventDefault();
        jQuery([document.documentElement, document.body]).animate({
            scrollTop: jQuery("#campus-programm").offset().top - 100
        }, 2000);
    });

});