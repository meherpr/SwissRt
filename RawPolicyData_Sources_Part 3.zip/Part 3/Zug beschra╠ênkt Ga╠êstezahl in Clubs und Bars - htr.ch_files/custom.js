var getUrlParameter = function getUrlParameter(sParam) {
    var sPageURL = window.location.search.substring(1),
    sURLVariables = sPageURL.split('&'),
    sParameterName,
    i;

    for (i = 0; i < sURLVariables.length; i++) {
        sParameterName = sURLVariables[i].split('=');

        if (sParameterName[0] === sParam) {
            return sParameterName[1] === undefined ? true : decodeURIComponent(sParameterName[1]);
        }
    }
};

repositionPartnerImMarkt = function() {
    //Screenwidth
    sWidth = jQuery(document).width();
    if ((sWidth < 1420) && (!jQuery('body').hasClass('repositioned'))) {
        //console.log('Do it');
        portrait = jQuery('div.portrait').detach();
        jQuery('.innerwrap .right').prepend(portrait);
        jQuery('body').addClass('repositioned');
    }

    if (sWidth > 1420 && jQuery('body').hasClass('repositioned')) {
        //console.log('Do it back');
        portrait = jQuery('div.portrait').detach();
        portrait.insertBefore('.innerwrap .content');
        jQuery('body').removeClass('repositioned');
    }
    
    jQuery('.partnerimmarkt .items .item').matchHeight();
}

initSlick = function() {
    jQuery('.element.singleitem .items, .element.topstory .items').on('init', function(event, slick){
        jQuery(this).find('.item').show();
    });

    jQuery('.col .element.singleitem .items').each(function() {
        tmpSlider = jQuery(this).next('.slider-nav');
        jQuery(this).slick({
            appendArrows: tmpSlider,
            prevArrow: tmpSlider.find('.prev-arrow'),
            nextArrow: tmpSlider.find('.next-arrow'),
            fade: true,
            cssEase: 'linear',
            autoplay: true,
            autoplaySpeed: 5000
        });

    });

    //Karussell-Elemente
    jQuery('.ressort .element.singleitem .items').on('init', function(event, slick){
        jQuery('.ressort .element.singleitem .items .slick-eqheight').matchHeight();
    });
    jQuery('.ressort .element.singleitem .items').each(function() {
        tmpSlider = jQuery(this).next('.slider-nav');
        jQuery(this).slick({
            appendArrows: tmpSlider,
            prevArrow: tmpSlider.find('.prev-arrow'),
            nextArrow: tmpSlider.find('.next-arrow'),
            fade: true,
            cssEase: 'linear',
            adaptiveHeight: true,
            autoplay: true,
            autoplaySpeed: 5000
        });
    });

    //Topstories
    jQuery('.element.topstory .items').each(function() {
        tmpSlider = jQuery(this).next('.slider-nav');
        jQuery(this).slick({
            appendArrows: tmpSlider,
            prevArrow: tmpSlider.find('.prev-arrow'),
            nextArrow: tmpSlider.find('.next-arrow'),
            fade: true,
            cssEase: 'linear',
            autoplay: true,
            autoplaySpeed: 5000
        });
        jQuery(this).on('afterChange', function(event, slick, direction){
            updateSlideCount(tmpSlider.find('.slidecount'), slick.currentSlide + 1);
        });

        //Add count
        slideCount = jQuery(this).find('.item').length;
        tmpSlider.find('.slidecount').attr('data-maxslides', slideCount);
        updateSlideCount(tmpSlider.find('.slidecount'), 1);
    });


    //Artikel-Bilder
    jQuery('.mainimages .items, .moreimages .items').each(function() {
    	if (!jQuery(this).hasClass('slidersync')) {
    	    tmpSlider = jQuery(this).next('.slider-nav');
	        jQuery(this).slick({
            	appendArrows: tmpSlider,
        	    prevArrow: tmpSlider.find('.prev-arrow'),
    	        nextArrow: tmpSlider.find('.next-arrow'),
	            fade: true,
        	    cssEase: 'linear'
    	    });

	        jQuery(this).on('afterChange', function(event, slick, direction){
            	updateSlideCount(jQuery(this).next('.slider-nav').find('.slidecount'), slick.currentSlide + 1);
        	    ga('send', 'pageview');
    	    });

	        //Add count
        	slideCount = jQuery(this).find('.item').length;
    	    tmpSlider.find('.slidecount').attr('data-maxslides', slideCount);
	        updateSlideCount(jQuery(this).next('.slider-nav').find('.slidecount'), 1);
        } 
    });
    
    //Single Multimedia-Element
   jQuery('.element.singlemultimedia .sliderfor').each(function() {
   		tmpSlider = jQuery(this).next('.slider-nav');
	    jQuery(this).slick({
    		appendArrows: tmpSlider,
    		slidesToShow: 1,
			slidesToScroll: 1,
        	prevArrow: tmpSlider.find('.prev-arrow'),
	    	nextArrow: tmpSlider.find('.next-arrow'),
		    fade: true,
		    infinite: true,
        	cssEase: 'linear',
	        asNavFor: '.slidernav'
    	});
	    jQuery('.element.singlemultimedia .slidernav').slick({
  			slidesToShow: 6,
  			slidesToScroll: 1,
	  		asNavFor: '.sliderfor',
  			dots: false,
  			infinite: true,
  			centerMode: false,
	  		focusOnSelect: true,
	  		responsive: [
    			{
      				breakpoint: 600,
      				settings: {
        				slidesToShow: 3,
        				slidesToScroll: 1,
        				dots: false,
        				asNavFor: '.sliderfor',
        				infinite: true,
  						centerMode: false,
	  					focusOnSelect: true,
	  					arrows: false
				   	}
    			}
    		]
		});
		
		jQuery(this).on('afterChange', function(event, slick, direction){
            updateSlideCount(jQuery(this).next('.slider-nav').find('.slidecount'), slick.currentSlide + 1);
        	ga('send', 'pageview');
    	});
		
		//Add count
        slideCount = jQuery(this).find('.item').length;
    	tmpSlider.find('.slidecount').attr('data-maxslides', slideCount);
	    updateSlideCount(jQuery(this).next('.slider-nav').find('.slidecount'), 1);
	});
    

    //Karussell-Elemente
    jQuery('.homeressort.rot .items').on('init', function(event, slick){
        jQuery('.homeressort.rot .items .slick-eqheight').matchHeight();
    });
    jQuery('.homeressort.rot .items').each(function() {
        jQuery(this).slick({
            prevArrow: '<div class="prev-arrow"></div>',
            nextArrow: '<div class="next-arrow"></div>',
            variableWidth: true,
            adaptiveHeight: true,
            slidesToShow: 4,
            slidesToScroll: 2,
            responsive: [{
                breakpoint: 1200,
                settings: {
                    slidesToScroll: 1
                }
            }]
        });
    });

    //Weitere Artikel
    jQuery('.articlerelated .wrap .items').on('init', function(event, slick){
        jQuery('.articlerelated .wrap .items .slick-eqheight').matchHeight();
    });
    jQuery('.articlerelated .wrap .items').each(function() {
        tmpSlider = jQuery(this).next('.slider-nav');
        jQuery(this).slick({
            appendArrows: tmpSlider,
            prevArrow: tmpSlider.find('.prev-arrow'),
            nextArrow: tmpSlider.find('.next-arrow'),
            adaptiveHeight: true,
            slidesToShow: 4,
            slidesToScroll: 1,
            responsive: [{
                breakpoint: 970,
                settings: {
                    slidesToShow: 2
                }
            },
            {
                breakpoint: 525,
                settings: {
                    slidesToShow: 1,
                    centerMode: true
                }
            }
            ]
        });
    });


}

updateSlideCount = function(obj, currentSlide) {
    //Get Max
    maxSlides = obj.attr('data-maxslides');
    obj.html(currentSlide + '/' + maxSlides);
    if (maxSlides == 1) obj.hide();
}

clearTeaser = function() {
	jQuery('.item .wrap .bodytext').each(function() {
		varText = jQuery(this).html();
        arrReg = /\[IMG\s.{0,7}\]/.exec(varText);
        if (arrReg) {
        	jQuery(this).html(varText.replace(arrReg[0], ''));
        }
	});
}

initArticle = function() {
    //Search image insertion
    jQuery('.articlebody p').each(function(i) {

        //artikelUID
        var artikelID = jQuery(this).parent().attr('data-artikel-id');

        //Images
        varText = jQuery(this).html();
        arrReg = /\[IMG\s.{0,7}\]/.exec(varText);
        if (arrReg) {
            addClass = "pull-left";
            if (arrReg['index'] > 20) addClass = "pull-right";
            if (arrReg['input'] == arrReg[0]) addClass = "full";
            arrReg2 = [];
            arrReg2 = arrReg[0].match(/(\d\d\d|\d\d|\d)/gi);
            startIMG = arrReg2[0];
            endIMG = startIMG;
            if (arrReg2.length > 1) endIMG = arrReg2[1];
            varText = varText.replace(arrReg[0], '');
            jQuery(this).html('<div class="moreimages ' + addClass + '" data-nr="' + i + '" data-start="' + startIMG + '" data-end="' + endIMG + '" data-artikel-id="' + artikelID + '"><div class="items"></div><div class="slider-nav"><div class="prev-arrow"></div><div class="slidecount"></div><div class="next-arrow"></div></div></div>' + varText);
        }

        //Files
        varText = jQuery(this).html();
        arrReg = /\[DOWNLOADS]/.exec(varText);

        if (arrReg) {
            addClass = "pull-left";
            if (arrReg['index'] > 20) addClass = "pull-right";
            if (arrReg['input'] == arrReg[0]) addClass = "full";
            jQuery('#articlefiles').addClass(addClass);
            jQuery(this).html(varText.replace(arrReg[0], ''));
            jQuery(this).prepend(jQuery('#articlefiles'));
        }
        
        //Dossier
        varText = jQuery(this).html();
        arrReg = /\[DOSSIER]/.exec(varText);

        if (arrReg) {
            addClass = "pull-left";
            if (arrReg['index'] > 20) addClass = "pull-right";
            if (arrReg['input'] == arrReg[0]) addClass = "full";
            jQuery('#maindossier-box').addClass(addClass);
            jQuery(this).html(varText.replace(arrReg[0], ''));
            jQuery(this).prepend(jQuery('#maindossier-box'));
            jQuery('#maindossier-box').show();
        }

        //Verwandte Artikel
        varText = jQuery(this).html();
        arrReg = /\[RELATED]/.exec(varText);

        if (arrReg) {
            addClass = "pull-left";
            if (arrReg['index'] > 20) addClass = "pull-right";
            if (arrReg['input'] == arrReg[0]) addClass = "full";
            jQuery('#related-box').addClass(addClass);
            jQuery(this).html(varText.replace(arrReg[0], ''));
            jQuery(this).prepend(jQuery('#related-box'));
            jQuery('#related-box').show();
        }

        //Externe Ressourcen
        varText = jQuery(this).html();
        arrReg = /\[EXT]/.exec(varText);

        if (arrReg) {
            addClass = "pull-left";
            if (arrReg['index'] > 20) addClass = "pull-right";
            if (arrReg['input'] == arrReg[0]) addClass = "full";
            jQuery('#externalressource-box').addClass(addClass);
            jQuery(this).html(varText.replace(arrReg[0], ''));
            jQuery(this).prepend(jQuery('#externalressource-box'));
            jQuery('#externalressource-box').show();
        }
    });

    jQuery('.moreimages').each(function() {
        artikelID = jQuery(this).attr('data-artikel-id');
        for (i = parseInt(jQuery(this).attr('data-start')); i <= parseInt(jQuery(this).attr('data-end')); i++ ) {
            jQuery(this).find('.items').append(jQuery('.mainimages[data-artikel-id="' +  artikelID + '"] #img-' + i));
        }
    });

    //Alternativer Autor setzen
    jQuery('.articlebody').each(function() {
        if (jQuery(this).find('.autor_alt').length > 0) {
            jQuery(this).find('p').last().append(jQuery(this).find('.autor_alt'));
        }
    });
}

cropText = function() {
    //Ressort Topstories
    jQuery('.ressorttopstory .item').each(function() {
        if (jQuery(this).find('p.lead').height() + jQuery(this).find('h2').height() > 240) jQuery(this).find('p.body').hide();
    });
}

initJumpURLs = function() {
    jQuery('a.jumpurl').click(function(e) {
        e.preventDefault();
        jumpto(jQuery(this).attr('href'), 500);
    });
}

jumpto = function(section, speed) {
    //Read Hash
    if (window.location.hash != '' && section == '') {section = window.location.hash;}

    if (section != '') {
        addOffset = 100;
        var offset = jQuery(section).offset().top - addOffset;
        jQuery('html, body').animate({scrollTop: offset}, speed);
    }
}

var lastScrollTop = 0;

checkSticky = function() {
    //Scrollpos
    scrollPosition = jQuery(document).scrollTop();


    if (scrollPosition > lastScrollTop){
        // downscroll code
        jQuery('header div, section.content .header, body').removeClass('goup');
    } else {
        // upscroll code
        jQuery('header div, section.content .header, body').addClass('goup');
    }
    lastScrollTop = scrollPosition;

    //Header out of viewport
    if (scrollPosition > jQuery('.header-top').height()) {
        jQuery('.header-top').addClass('outofvp');
    } else {
        jQuery('.header-top').removeClass('outofvp');
    }

    jQuery('.sticky').each(function(){
        if (!isNaN(jQuery(this).attr('data-sticky-scrollpos')) && jQuery(this).attr('data-sticky-scrollpos') < scrollPosition) {
            jQuery(this).addClass('is-sticky');
        }
        if (!isNaN(jQuery(this).attr('data-sticky-scrollpos')) && jQuery(this).attr('data-sticky-scrollpos') > scrollPosition) {
            jQuery(this).removeClass('is-sticky');
        }

        if (isNaN(jQuery(this).attr('data-sticky-scrollpos')) && jQuery(this).attr('data-sticky-trigger') != '') {
            if (jQuery(jQuery(this).attr('data-sticky-trigger')).hasClass('is-sticky')) {
                jQuery(this).addClass('is-sticky');
            } else {
                jQuery(this).removeClass('is-sticky');
            }
        }

        if (jQuery(this).attr('data-bottom-trigger') != '' && !isNaN(jQuery(this).attr('data-bottom-offset'))) {
            bottomPos = jQuery(jQuery(this).attr('data-bottom-trigger')).offset().top  + jQuery(jQuery(this).attr('data-bottom-trigger')).height();
            //console.log('BottomPos: ' + bottomPos);
            //console.log('ScrollBottom: ' + (scrollPosition + jQuery(this).height() + parseInt(jQuery(this).attr('data-bottom-offset'))));
            //console.log('Offset: ' + jQuery(this).attr('data-bottom-offset'));
            //console.log('Doc-Height: ' + jQuery(document).height());
            if ((scrollPosition + jQuery(this).height() + parseInt(jQuery(this).attr('data-bottom-offset'))) > bottomPos) {
                jQuery(this).addClass('is-bottom');
            } else {
                jQuery(this).removeClass('is-bottom');
            }
        }

    });
}

checkDossierNav = function() {
    //Scrollpos
    scrollPosition = jQuery(document).scrollTop();
    winHeight = jQuery(window).height();
    docHeight = jQuery('html').height();
    scrollPositionTophalf = scrollPosition + (winHeight /3);
    var currentSlide = 0;
    jQuery('.dossierContent').each(function(i){
        if (jQuery(this).position().top < scrollPositionTophalf) {
            jQuery('.dossiercontents .items .item').removeClass('active');
            jQuery('a[href="#' + jQuery(this).attr('id') + '"] .item').addClass('active');
            currentSlide = i;
        }
    });

    currentSlide = currentSlide -2;
    if (currentSlide < 0) currentSlide = 0;

    if (jQuery('.dossiercontents .items').slick('slickCurrentSlide') != currentSlide) {
        jQuery('.dossiercontents .items').slick('slickGoTo', currentSlide);
    }

    //Update progress
    progressCalc = parseInt((scrollPosition / docHeight) * 100 + 10);
    if (progressCalc > 100) progressCalc = 100;
    jQuery('.header.dossier .progress .fill').width(progressCalc + '%');
}

initDossier = function() {
    jQuery('.dossiercontents .items').slick({
        vertical: true,
        infinite: false,
        slidesToScroll: 1,
        verticalSwiping: true,
        adaptiveHeight: true,
        prevArrow: '<div class="slick-prev"></div>',
        nextArrow: '<div class="slick-next"></div>'
    });
}

clearFigCaptions = function() {
    jQuery('.moreimages, .mainimages').each(function() {
        if (jQuery(this).find('.item').length == 1) {
            if (jQuery(this).find('figcaption').html().trim() == '') jQuery(this).find('figcaption').remove();
        }
    });
}

initRessortNav = function() {
    if (jQuery('.ressortnav .current').length > 0) {
        jQuery('.header-top .wrap .ressort').empty();
        jQuery('.header-top .wrap .ressort').append(jQuery('.ressortnav .current'));

        //Get Left Offset
        jQuery('.tx-gi-redaktion .ressortnav').css('left', jQuery('.header-top .wrap .ressort').offset().left + 'px');

        jQuery('.header-top .wrap .ressort .current').click(function() {
            jQuery(this).toggleClass('active');

            if (jQuery(this).hasClass('active')) {
                jQuery('.tx-gi-redaktion .ressortnav').addClass('active');
            } else {
                jQuery('.tx-gi-redaktion .ressortnav').removeClass('active');
            }
        });
    }
}

initMostread = function() {

    jQuery('.last-mostread a, .last-newest a').click(function(e) {
        e.preventDefault();
        jQuery('.last-mostread, .last-newest').toggleClass('active');
        if (jQuery('.last-mostread').hasClass('active')) {
            //Meistgelesen
            jQuery('.items.items-newest').hide();
            jQuery('.items.items-mostread').show();
            jQuery(this).parent().parent().parent().find('.header').html(jQuery('.last-mostread a').html());
            jQuery('.items.items-mostread figure').imagefill();
        } else {
            //Neuste
            jQuery('.items.items-mostread').hide();
            jQuery('.items.items-newest').show();
            jQuery(this).parent().parent().parent().find('.header').html(jQuery('.last-newest a').html());
        }
    });
}

initNewsletterForm = function() {
    jQuery('.tx-registeraddress input[type="text"]').each(function() {
        jQuery(this).attr('placeholder', jQuery(this).parent().find('label').html().trim());
    });

    if (getUrlParameter('email') != '' && jQuery('#email').length > 0) {
        jQuery('#email').val(getUrlParameter('email'));
    }
}

initMobilenav = function() {
    jQuery('.hamburger-wrap').click(function() {
        //Open Menu
        jQuery('body').addClass('mm-open');
    });

    jQuery('#mobilemenu .close-wrap .closer').click(function() {
        //close Menu
        jQuery('body').removeClass('mm-open');
    });
}

initSearch = function() {
    jQuery('.header-top .search').click(function() {
        //Open Overlay
        jQuery('body').addClass('search-open');
        jQuery('#txtsearchkw').focus();
    });

    jQuery('#searchoverlay .close-wrap .closer').click(function() {
        //close overlay
        jQuery('body').removeClass('search-open');
    });
}

setContentMinHeight = function() {
    //Layout 3 - Static Content
    if (jQuery('body.layout_3').length > 0) {
        minContentHeight = jQuery(window).height() - jQuery('body.layout_3 header').outerHeight(true) - jQuery('body.layout_3 footer').outerHeight(true);
        jQuery('body.layout_3 .contentwrap').attr('style', 'min-height: ' + minContentHeight + 'px;');
    }
}
  
initPosterAd = function() {
  jQuery(".posterad").each(function() {
    var thisPosterAd = jQuery(this);
    var outerPosterAd = thisPosterAd.find('.posterad-outer');
    var posterAdElement = thisPosterAd.find('.posterad-element');
  
    posterAdElement.css( 'max-width', outerPosterAd.width());
  });  
}

initIgehoPartners = function() {
	jQuery('.element.partner .items .linebreak4').remove();
	
	//Shuffle
	jQuery('.element.partner .items .item').shuffle();
	jQuery('.element.partner .items .item .eqheight figure').imagefill();
	jQuery('.element.partner .items .item .eqheight').matchHeight();
	
	jQuery('.element.partner .item').each(function(i) {
    	
    	if ((i+1)%4 == 0) {
    		jQuery(this).after('<div class="linebreak-4"></div>');
    	}
    	
    	if (i+1 > 8) {
    		//jQuery(this).hide();
    	}
    });
    jQuery('.element.partner .item .showmore').click(function() {
        jQuery('.element.partner .item').removeClass('active');
        jQuery('.element.partner .item .showmore').html('Mehr anzeigen');

        jQuery(this).toggleClass('active');
        if (jQuery(this).hasClass('active')) {
            jQuery(this).parent().addClass('active');
            jQuery(this).html('Weniger anzeigen');
        } else {
            jQuery(this).html('Mehr anzeigen');
        }
    });
    
    loadMore('.element.partner .items', '.item', 8, 1) ;
}

initIgehoVideos = function() {
	if (window.location.hash != '') {
		tVideoID = window.location.hash;
		tVideoID = tVideoID.replace("#", "#video-");
		
		if (jQuery(tVideoID).length == 1) {
			//Copy video to Top-Container
			jQuery('#videolargecontainer').html(jQuery(tVideoID).html());
			jQuery('#videolargecontainer').addClass('active');
		}
	}
}

jQuery(document).ready(function() {
    //Hyphenation
    Hyphenator.config({
        defaultlanguage: 'de',
        leftmin: 6,
        rightmin: 4,
        minwordlength : 12
    });

    Hyphenator.run();

    //HomeLink
    jQuery('html[lang=de] .logo').click(function(){document.location.href = '/';});
    jQuery('html[lang=fr] .logo').click(function(){document.location.href = '/edition-francaise/home.html';});


    //Imagefill
    jQuery('.imagefill').imagefill();

    //Crop text
    cropText();

    //Init Meistgelesen
    initMostread();

    //Init Ressort-Nav
    initRessortNav();

    //Init Article
    if (jQuery('.articlebody').length > 0) initArticle();

    //Init Slick-Sliders
    initSlick();

    //Jumpurls
    initJumpURLs();

    //Backlinks
    jQuery('.backlink').click(function(e) {
        e.preventDefault();
        window.history.back();
    });

    //Nice-Selects
    jQuery('.frame-type-form_formframework select, .tx-registeraddress select, .epaperFilter select').niceSelect();

    //Clear empty Figure-Captions
    clearFigCaptions();

    //Check sticky objects
    checkSticky();

    //Init Dossier-Navigation
    initDossier();

    //Init Newsletter-Form
    initNewsletterForm();

    //Dossier Navigation + Progress
    checkDossierNav();

    //initMobilenav
    initMobilenav();

    //initSearch
    initSearch();

    //Adjust height to row height
    jQuery('.rowheight').each(function() {
        jQuery(this).height(jQuery(this).closest('.row').height());
    });

    //Matchheigt, by row
    jQuery('.row, .articlerelated').each(function(){
        jQuery(this).find('.eqheight').matchHeight();
    });

    //Matchheigt Layout Meinungen
    jQuery('.ressortoverview .items.ressort-layout-1 .item').matchHeight();
    jQuery('.ressortoverview .items.ressort-layout-1 .item h2').matchHeight();

    //Matchheight left/main/right
    jQuery('.body .left, .body .right, .body .main').matchHeight();
    
    //Matchheight Videos
    jQuery('.element.videos .item').matchHeight();
    initIgehoVideos();

    //Set min-height on Content-Section
    setContentMinHeight();

    //Lightbox
    jQuery('.mainimages, .moreimages').each(function() {
        jQuery(this).magnificPopup({
            delegate: 'a',
            type: 'image',
            titleSrc: 'title',
            gallery: {
                // options for gallery
                enabled: true,
                tCounter: '<span class="mfp-counter">%curr% / %total%</span>'
            }
        });
    });
    
    //Clear Teasers
    clearTeaser();

    //Reposition Content-Elements
    repositionPartnerImMarkt();

    //Igeho Partner
    initIgehoPartners();

    //ePaper
    jQuery('a.epaper.read, img.epaper.thumbnail').click(function(e) {
        e.preventDefault();
        //jQuery('iframe.ePaperGuruFrame').attr('src', 'https://l9fwllg3ke7y.reader.epaper.guru/de-CH/embed/list?publicOnly=false&filterLanguage=de&thumbnailWidth=160&pageSize=1&embedStyle=default&objectId=819c1574b1ff4d25b11baf21efc4372b-ePaperGuru&sessionId=&showToolbar=false&showQuickSelect=false&directOpen=' + jQuery(this).attr('data-guid') + '&directOpenPage=');
        epaperGuruOpenIssue(jQuery(this).attr('data-guid'));
    });

    jQuery('a.epaper.download').click(function(e) {
        e.preventDefault();
        epaperGuruDownloadIssue(jQuery(this).attr('data-guid'));
    });
    
});

jQuery(document).scroll(function() {
    //Check sticky objects
    checkSticky();

    //Dossier Navigation + Progress
    checkDossierNav();
});

jQuery(window).on('resize', function(){
    //Reposition Ressort-Nav
    if (jQuery('.tx-gi-redaktion .ressortnav').length > 0) jQuery('.tx-gi-redaktion .ressortnav').css('left', jQuery('.header-top .wrap .ressort').offset().left + 'px');
    if (jQuery('.posterad').length > 0) initPosterAd();

    //Set min-height on Content-Section
    setContentMinHeight();

    //Reposition Content-Elements
    repositionPartnerImMarkt();

    //Matchheight left/main/right
    jQuery('.body .left, .body .right, .body .main').matchHeight();
});

jQuery(document).keyup(function(e) {
    if (e.keyCode == 27) {
        jQuery('body').removeClass('mm-open');
        jQuery('body').removeClass('search-open');
    }
});


jQuery(window).on('load', function() {
  jQuery.stellar('_handleScrollEvent');
});
