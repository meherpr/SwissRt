initTimeline = function() {
	counter = false;
  	actQ = '';
  	
  	jQuery('.year').remove();
  	
  	jQuery('.element.timeline .items > .item:visible').each(function() {
  		jQuery(this).removeClass('onright')
  		
    	currQ = Math.ceil(jQuery(this).attr('data-month') / 3) + ' / ' + jQuery(this).attr('data-year');
	    if (actQ != currQ) {
    	  jQuery('<div class="year">Q' + currQ + '</div>').insertBefore(this);
      		actQ = currQ;
    	}
    	if (counter) jQuery(this).addClass('onright');
    	counter = !counter;
  	});

  	jQuery('.element.timeline .showmore').click(function() {
    	if (jQuery(this).hasClass('open')) {
      		jQuery(this).removeClass('open');
      		jQuery(this).prev().hide();
    	} else {
      		jQuery(this).addClass('open');
      		jQuery(this).prev().show();
    	}
  	});
  
  	//Check for #
  	if (jQuery(location).attr('hash') != '') {
		thash = jQuery(location).attr('hash');
    	jQuery("html, body").animate({ scrollTop: jQuery(thash).offset().top - 200 }, 500);
  	}
}


jQuery(document).ready(function() {
    //Init Timeline
    initTimeline();
    
    //Filter
    jQuery('.header.timeline .filter a').click(function() {
    	tFilter = jQuery(this).attr('data-filter');
    	jQuery('.header.timeline .filter a').removeClass('active');
        jQuery(this).addClass('active');
        
        jQuery('.timeline .items .item').each(function() {
        	if (!jQuery(this).hasClass(tFilter)) {
        		jQuery(this).hide();
        	} else {
        		jQuery(this).show();
        	}
        });
        
        initTimeline();
        return false;
    });

});