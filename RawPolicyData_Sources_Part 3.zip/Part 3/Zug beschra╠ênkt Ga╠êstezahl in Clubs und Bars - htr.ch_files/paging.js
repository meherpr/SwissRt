var arrLang = {};
arrLang['de'] = {};
arrLang['fr'] = {};
arrLang['de']['showmore'] = 'Mehr anzeigen';
arrLang['fr']['showmore'] = 'voir plus';

var currentLang = 'de';

initPageing = function(parentsel, childsel, pagesize) {
    itemC = jQuery(parentsel + ' ' + childsel).length;
    anzPages = Math.ceil(itemC / pagesize);

    paginator = '';
    activeClass = '';
    currentpage = 1;

    for (i=1;i<=anzPages;i++) {
        activeClass = '';
        if (currentpage == i) activeClass = 'active';
        paginator += '<a href="" class="' + activeClass + '" data-page="' + i + '" onclick="return pageingClick(' + i + ');">' + i + '</a>';

    }

    //pageingClick(parentsel, childsel, pagesize, currentpage);
    jQuery(parentsel + ' ' + childsel).each(function(index) {
        if (index >= 0 && index < pagesize) {
            jQuery(this).show();
        } else {
            jQuery(this).hide();
        }
    });

    jQuery(parentsel).append('<div class="paging">' + paginator + '</div>');

    jQuery('.paging a').click(function() {
        selPage = jQuery(this).attr('data-page');
        pageingClick(parentsel, childsel, pagesize, selPage);
        ga('send', 'pageview');
        return false;
    });
}

pageingClick = function(parentsel, childsel, pagesize, currentpage) {
	
    jQuery('html').animate({
        scrollTop: jQuery(parentsel).offset().top
    }, 500);

    jQuery(parentsel + ' .paging a').removeClass('active');
    jQuery(parentsel + ' .paging a').each(function() {
        if (jQuery(this).attr('data-page') == currentpage) jQuery(this).addClass("active");
    });

    itemStart = (currentpage * pagesize) - pagesize;
    itemEnd = itemStart + pagesize - 1;

    jQuery(parentsel + ' ' + childsel).each(function(index) {
        if (index >= itemStart && index <= itemEnd) {
            jQuery(this).show();
        } else {
            jQuery(this).hide();
        }
    });

    jQuery('html').animate({
        scrollTop: (jQuery(parentsel).parent().offset().top - 20)
    }, 100);
}

loadMore = function(parentsel, childsel, pagesize, currentPage) {

    actFilter = '.filter-0';
    if (jQuery('.filterbar a.active').length > 0) actFilter = '.' + jQuery('.filterbar a.active').attr('data-filter');

    //ePaper
    if (jQuery('select#epaperMonth').length > 0) {
        if (jQuery('select#epaperMonth').val() != '') actFilter = actFilter + '.' + jQuery('select#epaperMonth').val();
        if (jQuery('select#epaperYear').val() != '') actFilter = actFilter + '.' + jQuery('select#epaperYear').val();
    }

    itemC = jQuery(parentsel + ' ' + childsel + '' + actFilter).length;

    paginator = '';
    nextPage = parseInt(currentPage) + 1;

    paginator = '<a href="#" class="" data-page="' + nextPage + '">' + arrLang[currentLang]['showmore'] + '</a>';

    i = 0;

    jQuery(parentsel + ' ' + childsel).each(function(index) {
        if (jQuery(this).is(actFilter)) {
            if (i >= 0 && i < (currentPage * pagesize)) {
                jQuery(this).show();
                if (jQuery(this).find('img').not('.portrait').attr('data-src') != '') {
                    jQuery(this).find('img').not('.portrait').attr('src', jQuery(this).find('img').not('.portrait').attr('data-src'));
                }
            } else {
                jQuery(this).hide();
            }

            i++;
        } else {
            jQuery(this).hide();
        }
    });

    if (jQuery(parentsel).find('.paging').length > 0) {
        jQuery(parentsel).find('.paging').html(paginator);
    } else {
        jQuery(parentsel).append('<div class="paging">' + paginator + '</div>');
    }

    if (itemC < (currentPage * pagesize)) jQuery(parentsel).find('.paging').remove();

    jQuery('.paging a').click(function(e) {
        e.preventDefault();
        selPage = jQuery(this).attr('data-page');
        loadMore(parentsel, childsel, pagesize, selPage);
		ga('send', 'pageview');
        return false;
    });

}



jQuery(document).ready(function() {
    currentLang = jQuery('html').attr('lang');

    //if (jQuery('.ressortoverview .items .item').length > 0) initPageing('.ressortoverview .items', '.item', 20);
    if (jQuery('.ressortoverview .items .item').length > 0) loadMore('.ressortoverview .items', '.item', 14, 1);
    if (jQuery('.dossieroverview .items .item').length > 0) loadMore('.dossieroverview .items', '.item', 14, 1);

    if (jQuery('.epaperoverview .items .item').length > 0) loadMore('.epaperoverview .items', '.item', 20, 1);

});
