jQuery(document).ready(function() {
	console.log('twitter readdy');
	if (jQuery('#tweet-container').length > 0) {
		var tweetUsers = ['hotelrevue'],
		container = jQuery('#tweet-container');

		jQuery('#twitter-ticker').slideDown('slow');

		jQuery.post('/typo3conf/ext/gi_redaktion/Resources/Public/twitter/twitter-proxy.php', {handles:tweetUsers}, function(response){

			// Empty the container
			container.html('');

			jQuery.each(response.statuses, function(){
				//console.log('url: '+this.user.profile_image_url_https);
				var str = '	<div class="tweet">\
								<div class="headline">\
									<div class="avatar"><a href="https://twitter.com/'+this.user.screen_name+'" target="_blank"><img src="'+this.user.profile_image_url_https+'" alt="'+this.from_user+'" /></a></div>\
									<div class="user"><a href="https://twitter.com/'+this.user.screen_name+'" target="_blank">'+this.user.screen_name+'</a><br><span class="time">'+relativeTime(this.created_at)+'</span></div>\
									<div class="twitter-icon"></div>\
								</div>\
								<div class="clear"></div>\
								<div class="txt">'+formatTwitString(this.text)+'</div>\
							</div>';

				container.append(str);

			});

			
        		tmpSlider = jQuery('.twitter-wrapper .slider-nav');
        		jQuery('#tweet-container').slick({
            		appendArrows: tmpSlider,
            		prevArrow: tmpSlider.find('.prev-arrow'),
            		nextArrow: tmpSlider.find('.next-arrow'),
            		
            		autoplay: false,
            		infinite: true,
				  	slidesToShow: 4,
  					slidesToScroll: 1,
  					responsive: [
    				{
      					breakpoint: 1130,
      					settings: {
        					centerMode: true,
        					centerPadding: '20px',
        					slidesToShow: 1
    	  				}
    				},
    				{
      					breakpoint: 1070,
      					settings: {
        					centerMode: false,
        					slidesToShow: 2
    	  				}
    				},
    				{
      					breakpoint: 750,
      					settings: {
        					centerMode: true,
        					centerPadding: '20px',
        					slidesToShow: 1
    	  				}
    				}
  					]
        		});
        		
			

		});
	}
	
	// Helper functions

	function formatTwitString(str){
		str=' '+str;
		str = str.replace(/((ftp|https?):\/\/([-\w\.]+)+(:\d+)?(\/([\w/_\.]*(\?\S+)?)?)?)/gm,'<a href="$1" target="_blank">$1</a>');
		str = str.replace(/([^\w])\@([\w\-]+)/gm,'$1@<a href="https://twitter.com/$2" target="_blank">$2</a>');
		//str = str.replace(/([^\w])\#([\w\-]+)/gm,'$1<a href="http://twitter.com/search?q=%23$2" target="_blank">#$2</a>');
		str = str.replace(/([^\w])\#([\w\u00c4\u00df\u00e4\u00d6\u00f6\u00dc\u00fc\u00df\-]+)/gm,'$1<a href="https://twitter.com/search?q=%23$2" target="_blank">#$2</a>');
		return str;
	}

	function relativeTime(pastTime){
		pastTime = pastTime.replace("+0000 ", ""); 
		var origStamp = Date.parse(pastTime);
		var curDate = new Date();
		var currentStamp = curDate.getTime();

		var difference = parseInt((currentStamp - origStamp)/1000);

		if(difference < 0) return false;

		if(difference <= 5)				return "Jetzt";
		if(difference <= 20)			return "Vor ein paar Sekunden";
		if(difference <= 60)			return "Vor 1 Minute";
		if(difference < 3600)			return "Vor "+parseInt(difference/60)+" Minuten";
		if(difference <= 1.5*3600) 		return "Vor 1 Stunde";
		if(difference < 23.5*3600)		return "Vor "+Math.round(difference/3600)+" Stunden";
		if(difference < 1.5*24*3600)	return "Vor 1 Tag";
		if(difference > 1.5*24*3600)	return "Vor mehr als 1 Tag";

		var dateArr = pastTime.split(' ');
		return dateArr[4].replace(/\:\d+$/,'')+' '+dateArr[2]+' '+dateArr[1]+(dateArr[3]!=curDate.getFullYear()?' '+dateArr[3]:'');
	}	

});