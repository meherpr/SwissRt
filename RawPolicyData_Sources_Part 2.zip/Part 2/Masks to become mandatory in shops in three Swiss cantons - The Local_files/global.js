
// Used, for example, on the Noticeboard for "Staying safe" links etc.
function openWindow(url, name, width, height, toolbar, scroll) {
	var screenWidth = (screen.width - width) / 2;
	var screenHeight = (screen.height - height) / 2;
	newWindow = window.open(url,name,'width=' + width + ',height=' + height + ',toolbar=' + toolbar + ',scrollbars=' + scroll + ',resize=no,left=' + screenWidth + ',top=' + screenHeight + '');
	newWindow.focus();
}

// Used by the social sharing buttons on each article (Facebook, Twitter, Google+)
function popupShareWindow(url, w, h) {
  var left = (screen.width/2)-(w/2);
  var top = (screen.height/2)-(h/2);
  return window.open(url, '_blank', 'toolbar=no, location=yes, directories=no, status=no, menubar=no, scrollbars=yes, resizable=yes, copyhistory=yes, width='+w+', height='+h+', top='+top+', left='+left);
}

// Is this used as of December 2016, and if so, where?
function switchtab(newtab, oldtab) {
	if (document.getElementById)
	{
		document.getElementById(newtab).style.display = "inline";
		document.getElementById(oldtab).style.display = "none";
		return false;
	}
	else if (document.all)
	{
		document.all[oldtab].style.display = "none";
		document.all[newtab].style.display = "inline";
		return false;
	}
	else {
		return true;
	}
}
