const bannerWidth = 300;
const bannerHeight = 250;

const loopDuration = 10;
const pauseLastLoopAfter = 10;

const loopNumber = 0;

const whiteoutSpeed = 0.5;

const enableTerms = false;

const enableCtaPause = false;
const ctaPauseAfter = 30000;

const ctaSolid = false;



const preloadImages = ["cta_1.png", "cta_2.png", "logo.png"];


const images = ["bg.jpg", "copy_1a.png", "copy_1b.png", "copy_1c.png", "copy_2.png","mask.png"];


var tl_Frame = [];

tl_Frame[1] = function() {    
    var tl = new TimelineMax();
    
    
    var f1 = 0,
	    f2 = 1,
	    f3 = 6;
    var fadeTime = 1;

    // start parameters
    tl.set([copy_1a, copy_1b, copy_1c, copy_2, cta_all], {opacity: 0}, 0);
    //tl.set(terms_btn, {display:"none"}, 0);
    
    
   
    
    // frame 1
    tl.to(copy_1a, fadeTime, {opacity: 1}, f1);
    tl.to(copy_1b, fadeTime, {opacity: 1}, f1 + 0.5);
    tl.to(copy_1c, fadeTime, {opacity: 1}, f1 + 1);
    
    // frame 2
    //tl.to(copy_1, fadeTime, {opacity: 0}, f2);
    tl.to(copy_2, fadeTime, {opacity: 1}, f2 + fadeTime);

    // frame 3
    //tl.to(copy_2, 1, {opacity:0}, f3);
    tl.to(cta_all, fadeTime, {opacity: 1}, f2 + 1);
    //tl.set(terms_btn, {display:"block"}, f2+2);
    

    return tl;
}






// ============================== clicktag, cta, terms (mouse events) ============================== //

function clicktag_Click(e) {
    if (dcSelect) {
        Enabler.exit("Exit Click");
//        Enabler.exitOverride("Exit Click", "https://www.google.com");
    } else {
        window.open(window.clickTag);
    }
}

function mouseEnter() {
    if (!ctaStop) {
        var cta_2_bg = document.getElementById("cta_2_bg");
        cta_2_bg.style.opacity= 1;
           
        if (!ctaSolid) {
            var cta_1 = document.getElementById("cta_1");
            cta_1.style.opacity = 0;

            var cta_2 = document.getElementById("cta_2");
            cta_2.style.opacity = 1;
        }
    }
}
        
function mouseLeave() {
    var cta_2_bg = document.getElementById("cta_2_bg");
    cta_2_bg.style.opacity = 0;
            
    if (!ctaSolid) {
        var cta_1 = document.getElementById("cta_1");
        cta_1.style.opacity = 1;

        var cta_2 = document.getElementById("cta_2");
        cta_2.style.opacity = 0;
    }
}

function termsEnter() {
    terms_overlay.style.animation = undefined;
    terms_overlay.style.animation = "terms_overlay_animation_over 0.3s 0s linear forwards";
    
    mouseEnter(); // cta on state
    animationsPause();
}

function termsLeave() {
    terms_overlay.style.animation = undefined;
    terms_overlay.style.animation = "terms_overlay_animation_out 0.3s 0s linear forwards";
    
    if (!stopAnimations) { animationsPlay() }
}

// ============================== others ============================== //










// ============================== Do not edit ============================== //

var mTL,content,loopCount=1,stopAnimations=false,ctaStop=false;

// --- preloading images
if (enableTerms) preloadImages.push("terms_overlay.png");
// --- end preloading images



// ---------- special functions ---------- //

function ctaInit() {
    const cta_all = document.getElementById("cta_all");
    const cta_1 = document.getElementById("cta_1");

    cta_1.src="cta_1.png";
    cta_1.onload = function() {
        cta_all.style.height = cta_1.naturalHeight + "px";
        cta_all.style.width = cta_1.naturalWidth + "px";
    }

    if (!ctaSolid) {
        const cta_2 = document.createElement("img");
        cta_2.setAttribute("src","cta_2.png");
        cta_2.setAttribute("id","cta_2");
        cta_2.setAttribute("class","cta_position");
        cta_all.appendChild(cta_2);
    }
}

function ctaPause() {
    if (enableCtaPause) {
        setTimeout(function() {
            mouseLeave();
            ctaStop = true;
        }, ctaPauseAfter);   
    }
}



// ---------- (05) - main animation ---------- //

function startMainTimeLine() {
    for (var i = 1; i < tl_Frame.length; i++) {
        mTL.add(tl_Frame[i]());   
    }

    mTL.to(whiteout, whiteoutSpeed, {opacity: 0, onComplete: runWhiteout}, 0);
    mTL.to(whiteout, whiteoutSpeed, {opacity: 1}, loopDuration - whiteoutSpeed);

    mTL.set({}, {onComplete: pauseMainTimeLine}, pauseLastLoopAfter);
    mTL.set({}, {onComplete: resetMainTimeLine}, loopDuration);
}

function runWhiteout() {
    if (loopCount == loopNumber) { TweenMax.killTweensOf(whiteout) }
}

function pauseMainTimeLine() {
    if (loopCount == loopNumber) {
        console.log("animation stop");
        stopAnimations = true;
        animationsPause();
    }
}

function resetMainTimeLine() {
    if (loopCount != loopNumber) {
        loopCount++;
        mTL.restart();
    }
}

function animationsPause() {
    mTL.pause();
}

function animationsPlay() {
    mTL.play();
}



// ---------- (04) - init ---------- //

function init() {
    content = document.getElementById("content");
    
    TweenMax.set([content, main, clicktag], {width: bannerWidth, height: bannerHeight});
    TweenMax.set(border, {width: bannerWidth-2, height: bannerHeight-2});
    
    logo.style.backgroundImage = "url(logo.png)";
    
    if (enableTerms) {
        terms_overlay.style.backgroundImage = "url(terms_overlay.png)";
        terms_btn.style.display = "block";
    }
    
    TweenMax.set(".ad_size", {width: bannerWidth, height: bannerHeight});
    
    mTL = new TimelineMax();
    
    
    ctaInit(); ctaPause();

    content.style.opacity = 1;
    startMainTimeLine();
}



// ---------- (03) - images/styles load ---------- //
function initStage() {
    init();
}

function loadStyles() {
    var extCSS = document.createElement("link");
    extCSS.setAttribute("rel", "stylesheet");
    extCSS.setAttribute("type", "text/css");
    extCSS.setAttribute("href", "style.css");
    document.getElementsByTagName("head")[0].appendChild(extCSS);

    extCSS.onerror = initStage; extCSS.onload = initStage; // callback
}

function preLoadImages() {
    // preload images inside array preloadImages
    var newImages = [], l = preloadImages.length;
    for (var i = 0; i < preloadImages.length; i++) {
        newImages[i] = new Image();
        newImages[i].src = preloadImages[i];
        newImages[i].onerror = function() { l-- }
        newImages[i].onload = function() { if(!--l) {
            loadStyles(); // <- callback
        }}
    } if (!l) loadStyles(); // <- callback if array empty
}

function createImages(){
    function initImage(id, src) {
        if (type) {
            var image = document.createElement("img");
            image.setAttribute("id", id);
            image.setAttribute("class", "image");
            image.setAttribute("src", src);
            main.appendChild(image);
        } else {
            var elm = document.createElement(imageId[1]);
            elm.setAttribute("id", id);
            main.appendChild(elm);
        }
    }
    var newImages = [], l = images.length, type;
    for (var i = 0; i < images.length; i++) {
        var imageId = images[i].split(".");
        
//        console.log(['jpg','png'].indexOf(imageId[1]), imageId[1]); // just log type check
        if (['jpg','png'].indexOf(imageId[1]) !== -1) { type = true } else { type = false }
        initImage(imageId[0], images[i]);
        
        // preload images inside array images
        if (type) {
            newImages[i] = new Image();
            newImages[i].src = images[i];
            newImages[i].onerror = function() { l--; document.getElementById(this.attributes.src.value.slice(0, -4)).style.display = "none"}
            newImages[i].onload = function() { if(!--l) {
                preLoadImages(); // <- callback
            }}
        } else { l-- }
    } if (!l) preLoadImages(); // <- callback if array empty
}



// ---------- (02) - DC/ST/polite load ---------- //
function preloadingStage() {
    createImages();
//    preLoadImages(); // if skip createImages
}

function stLoad() {
    console.log("ready-Standalone");
    
    preloadingStage();
}

function dcLoad() {
    if (Enabler.isInitialized()) {
        enablerInitHandler();
    } else {
        Enabler.addEventListener(studio.events.StudioEvent.INIT, enablerInitHandler);
    }
}

function enablerInitHandler() {
    console.log("ready-DoubleClick");
    
    if (politeLoad) {
        if (Enabler.isPageLoaded()) {
            pageLoadedHandler();
        } else {
            Enabler.addEventListener(studio.events.StudioEvent.PAGE_LOADED, pageLoadedHandler);
        }
    } else {
        preloadingStage();
    }
}

function pageLoadedHandler() {
    console.log("ready-polite");
    
    preloadingStage();
}



// ---------- (01) - first stage ---------- //
window.onload = function start() {
    if (typeof TimelineMax !== 'undefined') {

        if (dcSelect) {
            dcLoad();
        } else {
            stLoad();
        }   

    } else {
        console.log("TimelineMax is not defined, trying to reload");
        setTimeout(function(){
            start();
        }, 200);
    }
}