try {
	var sitebarhostname = window.top.location.hostname.split(".").slice(-2).join(".");
} catch(err){
	var sitebarhostname = "standard";
}

try {
	var sitebarhostnamefull = window.top.location.hostname;
} catch(err){
	var sitebarhostnamefull = "standard";
}

console.log(sitebarhostname+' '+sitebarhostnamefull);
if (sitebarhostname=='standard' && sitebarhostnamefull=='standard') {
    document.getElementById('vf_sitebar').style.width='100%';
    document.getElementById('vf_sitebar').style.height='100%';
} else {
    console.log(window.top.location);
}


if (sitebarhostname.length<3 || sitebarhostname=="undefined") {
	sitebarhostname="standard";
}

var sitebarpages = {
	"standard" : { 
		showsite: "#vf_sitebar { left: 0px; width: 100%; height: 100%;}"
	},
	"omdmedia.ch" : { 
		showsite: "#vf_sitebar { right: 0px; width: 50%; height: 100%;}"
	},
	"blick.ch" : { 
		showsite: "@media screen and (min-width: 1270px) {#vf_sitebar { left: 1000px;}} @media screen and (min-width: 1315px) {#vf_sitebar { left: calc(50% + 350px);}} @media screen and (max-width: 1271px) { #vf_sitebar {display: none;}}"
	},
	"bluewin.ch" : { 
		showsite: "@media screen and (min-width: 1329px) { #vf_sitebar { top: 44px; z-index: 100000; left: calc(50% + 350px); padding-top: 0px; padding-bottom: 0px; padding-right: 0px;} .container {/*margin:0 0 0 10px; left: 0px;*/} .adcontainer-leaderboard {margin: 0 10px;} .wide-content, .modFooter{ margin-left:10px;} #sitebar_container {top: 0px;} div.nav {margin-left: 10px;} .nav__level0 {margin-left: -10px; width: 1010px;} .nav__subnav {left: 0px !important; right: 0px !important; width: 100% !important; margin-left: 0px !important; margin-right: 0px !important;} .nav-body.is-open {-webkit-transform: translateX(-0px) !important; transform: translateX(-0px) !important;} nav .container { margin-left: 0px !important;} div.nav { max-width: 1000px;}} @media screen and (max-width: 1329px) { #vf_sitebar {display: none;}} "
	},
	"nzz.ch" : { 
		showsite: "@media screen and (min-width: 1024px) {#vf_sitebar { left: 814px;}} @media screen and (min-width: 1136px) {#vf_sitebar { left: calc(100% - 300px);}} @media screen and (min-width: 1562px) {#vf_sitebar { left: calc(50% + 474px);}} @media screen and (min-width: 1848px) {#vf_sitebar { left: calc(50% + 622px);}} @media screen and (max-width: 1025px) { #vf_sitebar {display: none;}}"
	},	
	"aargauerzeitung.ch" : { 
		showsite: "@media screen and (min-width: 1401px) {#vf_sitebar { left: calc(100% - 340px);}} @media screen and (min-width: 1750px) {#vf_sitebar { left: calc(50% + 520px);}} @media screen and (max-width: 1400px) { #vf_sitebar {display: none;}}"
	},
	"suedostschweiz.ch" : { 
		showsite: "@media screen and (min-width: 1300px) {.container {margin-left: 20px; } #vf_sitebar { left: 1035px; } #content_outer { margin: 0; } #footer { margin: 0; } #footer-teaser_outer { margin: 0; }} @media screen and (max-width: 1300px) { #vf_sitebar {display: none;}}"
	},
	"moneyhouse.ch" : { 
		showsite: "@media screen and (min-width: 1240px) {#vf_sitebar { left: 1040px;}} @media screen and (min-width: 1380px) {#vf_sitebar { left: calc(50% + 360px);}} @media screen and (min-width: 1640px) {#vf_sitebar { left: 1340px;}} @media screen and (min-width: 1980px) {#vf_sitebar { left: calc(50% + 360px);}} @media screen and (max-width: 1241px) { #vf_sitebar {display: none;}}"
	},	
	"bote.ch" : { 
		showsite: "#vf_sitebar { left: 350px; margin-top: 208px; margin-bottom: 0px; margin-right: 0px; margin-left: calc(50% + 0px);} @media screen and (max-width: 1200px) { #vf_sitebar {display: none;}} @media screen and (max-width: 1350px) { #vf_sitebar {left: 0px !important; min-width: 0px !important; margin-left: 1024px}} @media screen and (max-width: 1626px) { #vf_sitebar {left: 350px; min-width: 300px; margin-left: calc(50%-300px)}}"
	},
	"20min.ch" : { 
		showsite: "@media screen and (max-width: 1260px) { #vf_sitebar {left: 10px; min-width: 0px !important; margin-left: 1004px}} .slideshow {z-index: 200000 !important;} #vf_sitebar { left: 390px; margin-top: 0px; margin-bottom: 0px; margin-right: 0px; margin-left: 50%;} @media all and (min-width: 0px) { #vf_sitebar {display: none;}} @media all and (-ms-high-contrast: active), (-ms-high-contrast: none) {#vf_sitebar {display: block;}} @media all and (min-width: 1200px) {#vf_sitebar {display: block;}}"
	},
	"tutti.ch" : { 
		showsite: "@media screen and (max-width: 1260px) { #vf_sitebar {left: 10px; min-width: 0px !important; margin-left: 1004px}} .slideshow {z-index: 200000 !important;} #vf_sitebar { left: 390px; margin-top: 70px; margin-bottom: 0px; margin-right: 0px; margin-left: 50%;} @media all and (min-width: 0px) { #vf_sitebar {display: none;}} @media all and (-ms-high-contrast: active), (-ms-high-contrast: none) {#vf_sitebar {display: block;}} @media all and (min-width: 1200px) {#vf_sitebar {display: block;}}"
	},
	"tagesanzeiger.ch" : { 
		showsite: "@media screen and (min-width: 1626px) {#vf_sitebar { left: calc(50% + 515px);}} @media screen and (min-width: 1324px) and (max-width: 1625px) {#vf_sitebar { left: calc(100% - 300px);}} @media screen and (min-width: 1250px) and (max-width: 1324px) {#vf_sitebar { left: 1030px;}} @media screen and (max-width: 1251px) { #vf_sitebar {display: none;}}"
	},
	"derbund.ch" : { 
		showsite: "#vf_sitebar { left: 1004px; } @media screen and (max-width: 1626px){body {margin: 0!important; float: none;} .sitebar-container{left: 1024px;}}"
	},
	"lematin.ch" : { 
		showsite: "#vf_sitebar { left: 980px; } @media screen and (max-width: 1626px){body {margin: 0!important; float: none;} .sitebar-container{left: 1024px;}}"
	},
	"24heures.ch" : { 
		showsite: "#vf_sitebar { left: 980px; } @media screen and (max-width: 1626px){body {margin: 0!important; float: none;} .sitebar-container{left: 1024px;}}"
	},
	"tio.ch" : { 
		showsite: "#vf_sitebar { left: 400px; margin-top: 0px; margin-bottom: 0px; margin-right: 0px; margin-left: calc(50% + 120px);} @media screen and (max-width: 1484px) { #vf_sitebar {left: 0px !important; min-width: 0px !important; margin-left: 994px !important;}} @media screen and (max-width: 1240px) { #vf_sitebar {display: none;}}"
	},
	"adform.com" : { 
		showsite: "#vf_sitebar { width: 100%; heigth: 100%; }"
	},
	"cash.ch" : { 
		showsite: "#vf_sitebar { z-index: 100 !important; left: 500px; margin-top: 140px; margin-bottom: 0px; margin-right: 0px; margin-left: calc(50% - 120px);} @media screen and (max-width: 1240px) { #vf_sitebar {display: none;}} @media screen and (max-width: 1460px) { #vf_sitebar {left: 0px !important; min-width: 0px !important; margin-left: calc(75% + 30px);}}"
	},
	"finanzen.ch" : { 
		showsite: ".container { margin-left: 0px; } #vf_sitebar { left: 500px; margin-top: 0px; margin-bottom: 0px; margin-right: 0px; margin-left: calc(50% - 120px);} @media screen and (max-width: 1240px) { #vf_sitebar {display: none;}} @media screen and (max-width: 1460px) { #vf_sitebar {left: 0px !important; min-width: 0px !important; margin-left: calc(75% + 30px);}}"
	},
	"telem1.ch" : {
		showsite: "#vf_sitebar { left: 1190px; } body{max-width: 1175px; margin-left: 10px;} .container{margin:0;} main{margin-right: 0px;} @media screen and (max-width: 1380px) { #vf_sitebar {display: none;}}"
	},
	"monetas.ch" : {
		showsite: "#vf_sitebar { left: 1162px; } body{max-width: 1162px;} @media screen and (max-width: 1350px) { #vf_sitebar {display: none;}}"
	},
	"cineman.ch" : {
		showsite: "#vf_sitebar { left: 1184px; } body{max-width: 1184px;} @media screen and (max-width: 1384px) { #vf_sitebar {display: none;}}"
	},
	"hockeyfans.ch" : {
		showsite: "@media screen and (min-width: 1500px) {#vf_sitebar { left: 1260px;} body{max-width: 1420px;}} @media screen and (max-width: 1500px) { #vf_sitebar {display: none;}}"
	},
	"swisshockeynews.ch" : {
		showsite: "#vf_sitebar { left: 1030px; } .container{margin-left:0;} @media screen and (max-width: 1210px) { #vf_sitebar {display: none;}}"
	},
	"gutekueche.ch" : {
		showsite: "#vf_sitebar { left: 980px; } #container {margin: 0;} #cookieBar, .cc_banner{max-width:980px;} @media screen and (max-width: 1170px) { #vf_sitebar {display: none;}}"
	},
	"gutekueche.at" : {
		showsite: "#vf_sitebar { left: 980px; } #container {margin: 0;} #cookieBar, .cc_banner{max-width:980px;} @media screen and (max-width: 1170px) { #vf_sitebar {display: none;}}"
	},
	"prosieben.ch" : {
		showsite: "#vf_sitebar { left: 1200px; } #sitebar_container{z-index: 12000;} @media screen and (min-width: 1220px) {body, .cookie-banner{max-width:1200px;} .narrow-wrapper{width:1180px; margin: 0 10px;} .topbar-container-static .topbar-container{width: 1200px;}} @media screen and (min-width: 1220px) and (max-width: 1449px) { body, .cookie-banner{max-width: 100%;} .narrow-wrapper{width:940px;} .topbar-container-static .topbar-container{width: 100%;}} @media screen and (max-width: 1220px) { #vf_sitebar {display: none;}} @media screen and (min-width: 1220px) and (max-width: 1449px) { #vf_sitebar {left: 1010px;} .cookie-banner{max-width: 1010px;}}"
	},
	"meteonews.ch" : {
		showsite: "#vf_sitebar { left: 1130px; } .site{margin-left:0;} @media screen and (max-width: 1370px) { #vf_sitebar {display: none;} .site{margin-left:100px;}}"
	},
	"teleboy.ch" : {
		showsite: "#vf_sitebar { left: calc(50% + 340px); top: 56px;} @media screen and (max-width: 1325px) {#vf_sitebar { left: 1000px; top: 56px;}} @media screen and (max-width: 1250px) { #vf_sitebar {display: none;}}"
	},
	"boerse.de" : {
		showsite: "#vf_sitebar { left: calc(50% + 395px);} @media screen and (max-width: 1224px) { #vf_sitebar {display: none;}}"
	},
	"n-tv.de" : {
		showsite: "#vf_sitebar { left: calc(50% + 420px);} @media screen and (max-width: 1224px) { #vf_sitebar {display: none;}}"
	},
	"santemedia.ch" : {
		showsite: "#vf_sitebar { left: calc(50% + 520px); top: 117px;} #prox_footer_newsletter,#footer-bottom .container{width:1004px;} .et_primary_nav_dropdown_animation_slideInY #main-header #et-menu .menu-item-has-children > ul {max-width: 1146px;} @media screen and (max-width: 1430px) { #vf_sitebar {display: none;}}"
	},
	"wildeisen.ch" : {
		showsite: "#vf_sitebar { left: 1016px;} .container, .ad-container, .main-header__inner {margin: 0 10px;} @media screen and (max-width: 1260px) { #vf_sitebar {display: none;}}"
	},
	"geo.de" : {
		showsite: "#vf_sitebar { left: calc(50% + 400px);} @media screen and (max-width: 1224px) { #vf_sitebar {display: none;}}"
	},
	"chefkoch.de" : {
		showsite: "#vf_sitebar { left: calc(50% + 400px); top: 60px;} @media screen and (max-width: 1224px) { #vf_sitebar {display: none;}}"
	},
	"meteo.ch" : {
		showsite: "#vf_sitebar { left: 1020px;} @media screen and (max-width: 1224px) { #vf_sitebar {display: none;}}"
	},
	"gala.de" : {
		showsite: "#vf_sitebar { left: calc(50% + 500px);} @media screen and (max-width: 1440px) { #vf_sitebar {display: none;}}"
	},
	"wanderungen.ch" : {
		showsite: "#vf_sitebar { left: calc(50% + 410px);} .backToTop {display: none!important;} footer .container{max-width: 970px; position:relative; left:-100px;} @media screen and (max-width: 1260px) { #vf_sitebar {display: none;}}"
	},
	"southpark.de" : {
		showsite: "#vf_sitebar { left: 1442px;} @media screen and (min-width: 1740px) {#vf_sitebar { left: 1442px;}} @media screen and (min-width: 1523px) and (max-width: 1739px) {#vf_sitebar { left: 1225px;}} @media screen and (min-width: 1306px) and (max-width: 1522px) {#vf_sitebar { left: 1010px;}} @media screen and (max-width: 1305px) {#vf_sitebar { left: 982px;}} body,div#container,section,.shadows {margin:0;} @media screen and (max-width: 1160px) { #vf_sitebar {display: none;}}"
	},
	"stern.de" : {
		showsite: "#vf_sitebar { left: calc(50% + 400px);} @media screen and (max-width: 1240px) { #vf_sitebar {display: none;}}"
	},
	"motorsport-magazin.com" : {
		showsite: "#vf_sitebar { left: 1017px;} .cc-window.cc-banner {max-width: 1017px;} @media screen and (max-width: 1250px) { #vf_sitebar {display: none;}}"
	},
	"songtexte.com" : {
		showsite: "#vf_sitebar { left: calc(50% + 425px);} .cookieBanner{max-width: calc(50% + 425px);} @media screen and (max-width: 1250px) { #vf_sitebar {display: none;} .cookieBanner{max-width: 100%}}"
	},
	"familienleben.ch" : {
		showsite: "#vf_sitebar { left: calc(50% + 450px);} @media screen and (max-width: 1370px) { #vf_sitebar {display: none;}"
	},
	"urbia.de" : {
		showsite: "@media screen and (min-width: 1220px) {.layer.banner.sticky.bottom.slidein-right{left: 2em;}} @media screen and (min-width: 1220px) and (max-width: 1280px) {#vf_sitebar { left: 984px;}} @media screen and (min-width: 1281px) and (max-width: 1344px) {#vf_sitebar { left: 1036px;}} @media screen and (min-width: 1345px) and (max-width: 1440px) {#vf_sitebar { left: 1050px;}} @media screen and (min-width: 1441px) {#vf_sitebar { left: calc(50% + 408px);}} @media screen and (max-width: 1220px) { #vf_sitebar {display: none;}}"
	},
	"testedich.ch" : {
		showsite: "#vf_sitebar { left: 1025px;} body { max-width: 1010px;} @media screen and (max-width: 1250px) { #vf_sitebar {display: none;} body { max-width: 100%;}}"
	},
	"swissmilk.ch" : {
		showsite: "#vf_sitebar { left: 1030px;} body {max-width: 1030px;} .l-constrained.wide,#sticky-wrapper container {width: 64em;} .mainnav .items .itemwrap {border-spacing: .625em .1875em;} .mainnav .items .itemwrap .item {padding: 0 .625em;} .mainnav .items .itemwrap .item>a {font-size: 1.125em;} .mainnav .logo {width: 24%;} .mainnav .logo img {padding-left: 2em; padding-bottom: .3125em;} .mainnav .items .itemwrap .item.claim>a:after {left: 100%;} #footer-additional, body.footerbar-fixed #footerbar {left: 515px;} @media screen and (max-width: 1250px) { #vf_sitebar {display: none;} body {max-width: 100%;}}"
	},
	"wetter.com" : {
		showsite: "#vf_sitebar { left: 1170px;} body,.cookie-banner{max-width: 1145px;} body .footer{min-width: 1145px; max-width: 1145px;} body .footer-nav__item {width: auto;} .smaller-desk-fit-screen-ph{padding:15px;} @media screen and (max-width: 1400px) { #vf_sitebar {display: none;} body,.cookie-banner {max-width: 100%;}}"
	},
	"nachhaltigleben.ch" : {
		showsite: "#vf_sitebar { left: 1070px;} .ct, .mainsize {margin: 0;} .mainsize{max-width:1070px!important;} .nav-sticky{padding-left: 30px;} @media screen and (max-width: 1280px) { #vf_sitebar {display: none;}"
	},
	"wireltern.ch" : {
		showsite: "#vf_sitebar { left: 1050px;} body{max-width: 1050px;} @media screen and (max-width: 1280px) { #vf_sitebar {display: none;} body{max-width: 100%;}"
	},
	"brigitte.de" : {
		showsite: "#vf_sitebar { left: calc(50% + 480px);} @media screen and (max-width: 1400px) { #vf_sitebar {display: none;}}"
	},
	"ronorp.net" : {
		showsite: "#vf_sitebar { left: calc(50% + 490px);} @media screen and (max-width: 1400px) { #vf_sitebar {display: none;}}"
	},
	"linternaute.com" : {
		showsite: "#vf_sitebar { left: 1302px;} body{max-width: 1302px;} @media screen and (min-width: 1560px) {.ccmcss_oic{left: 1050px;}} @media screen and (max-width: 1560px) { #vf_sitebar {display: none;} body{max-width: 100%;} .ccmcss_oic{bottom: 20px; right: 20px;}}"
	},
	"sports.fr" : {
		showsite: "@media screen and (min-width: 1250px) {#vf_sitebar { left: 1020px;} #footer_tc_privacy { max-width: 1020px;} #content, #footer, #header, #top .trunk, #main-nav, .sub-nav {margin: 0 20px;} body #banner-full {margin: 0 5px;} .wbtz-embed-main-sticky{display: none!important;}} @media screen and (max-width: 1250px) { #vf_sitebar {display: none;}}"
	},
	"doctissimo.fr" : {
		showsite: "@media screen and (min-width: 1260px) {#vf_sitebar { left: 1020px;} div#doc-menu-mobile-wrapper{margin: 0 10px;} #footer_tc_privacy {max-width:1020px;}} @media screen and (max-width: 1260px) { #vf_sitebar {display: none;}}"
	},
	"magicmaman.com" : {
		showsite: "@media screen and (min-width: 1250px) {#vf_sitebar { left: 1020px;} body{max-width: 1010px;}.CookieNotification{z-index:15000;}.SiteHeader-content{width:1000px; margin:0;}.MagazineSubscription{display:none;}} @media screen and (max-width: 1250px) { #vf_sitebar {display: none;}}"
	},
	"public.fr" : {
		showsite: "@media screen and (min-width: 1250px) {#vf_sitebar { left: 1010px;} body,#tools,#header,#footer_tc_privacy{max-width:1010px}} @media screen and (max-width: 1250px) { #vf_sitebar {display: none;}}"
	},
	"journaldesfemmes.com" : {
		showsite: "@media screen and (min-width: 1340px) {#vf_sitebar { left: 1122px;} body{max-width: 1120px;}} @media screen and (min-width: 1340px) {.ccmcss_oic{left: 875px;}} @media screen and (max-width: 1340px) { #vf_sitebar {display: none;}}"
	},
	"marieclaire.fr" : {
		showsite: "@media screen and (min-width: 1250px) {#vf_sitebar { left: 1030px;} body{max-width: 1010px;margin-left: 10px;} .SiteHeader--minimal .SiteHeader-contentContainer{max-width:1030px;}} @media screen and (max-width: 1250px) { #vf_sitebar {display: none;}}"
	},
	"cuisineaz.com" : {
		showsite: "@media screen and (min-width: 1470px) {#vf_sitebar { left: calc(50% + 520px); top: 50px;} .m6Cookies_bar {max-width: calc(50% + 520px);} .siteheader_logo .logo{line-height: 54px;} .siteheader{height:50px;} .siteheader.small .foxmenu>ul>li{line-height:51px;}} @media screen and (max-width: 1470px) { #vf_sitebar {display: none;}}"
	},
	"hausinfo.ch" : {
		showsite: "@media screen and (min-width: 1500px) {#vf_sitebar { left: 1345px;}} @media screen and (max-width: 1500px) { #vf_sitebar {display: none;}}"
	},
	"galileo.tv" : {
		showsite: "@media screen and (min-width: 1380px) {#vf_sitebar { left: 1100px; top: 60px;} body {max-width: 1100px;} #cookieBannerGTV{max-width:1100px;}.aa-dropdown-menu {overflow:hidden;}} @media screen and (max-width: 1380px) { #vf_sitebar {display: none;}}"
	},
	"staragora.com" : {
		showsite: "@media screen and (min-width: 1440px) {#vf_sitebar { left: 1160px; } body {max-width: 1160px;} .Menu .Menu-link{padding: 0 8px; font-size: 17px;} .Menu .Menu-moreLinks{margin-right:0;} .SiteHeader-magazineSubscription{left: 1015px; right: auto; width: 130px;} .SiteHeader-searchButton{left:1110px;} .SiteHeader-searchContent{margin: 0 50px;} .SiteHeader{margin:0;}.CookieNotification{width:1160px;} body.is-scrolled .SiteHeader-magazineSubscription:not(.is-static){left:900px;} .is-scrolled .SiteHeader-searchButton{left:1055px;} .SiteHeader-logo{left:30%;}} @media screen and (max-width: 1440px) { #vf_sitebar {display: none;}}"
	},
	"gentside.com" : {
		showsite: "@media screen and (min-width: 1200px) {#vf_sitebar { left: 1000px; top: 64px;} body, div.filter.filter--up {max-width: 1000px;} } @media screen and (max-width: 1200px) { #vf_sitebar {display: none;}}"
	},
	"arcor.de" : {
		showsite: "@media screen and (min-width: 1560px) {#vf_sitebar { left: calc(50% + 565px);} .gdpr-cookie-notice {max-width: calc(50% + 565px);}} @media screen and (max-width: 1560px) { #vf_sitebar {display: none;}}"
	},
	"11freunde.de" : {
		showsite: "@media screen and (min-width: 1320px) {#vf_sitebar { left: calc(50% + 410px);} #gujems-cookie-banner {max-width: calc(50% + 410px);}} @media screen and (max-width: 1320px) { #vf_sitebar {display: none;}}"
	},
	"gofeminin.ch" : {
		showsite: "@media screen and (min-width: 1260px) {#vf_sitebar { left: 1030px; } #content, .af-banner, header #header-content {margin: 0px;} footer, #header{max-width: 1020px;} } @media screen and (max-width: 1260px) { #vf_sitebar {display: none;}}"
	},
	"yelp.com" : {
		showsite: "@media screen and (min-width: 1260px) {#vf_sitebar { left: 1020px; } body {max-width: 1000px;} } @media screen and (max-width: 1260px) { #vf_sitebar {display: none;}}"
	},
	"tv8.ch" : {
		showsite: "@media screen and (min-width: 1460px) {#vf_sitebar { left: 1220px; } .wrapper {margin:0 10px;} } @media screen and (max-width: 1460px) { #vf_sitebar {display: none;}}"
	},
	"adnxs.com" : { 
		showsite: "#vf_sitebar { left: 0px; width: 100%; height: 100%;}"
	},
	"creative-preview-an.com" : { 
		showsite: "#vf_sitebar { left: 0px; width: 100%; height: 100%;}"
	},
	"letsfamily.ch" : {
		showsite: "@media screen and (min-width: 1460px) {#vf_sitebar { left: 1230px; } .inside.container {max-width: 1160px;} .cc-window.cc-banner, #header {max-width:1230px;} body {max-width: 1200px;} } @media screen and (max-width: 1460px) { #vf_sitebar {display: none;}}"
	},
	"lacote.ch" : {
		showsite: "@media screen and (min-width: 1730px) {#vf_sitebar { left: calc(50% + 640px);}} @media screen and (max-width: 1730px) { #vf_sitebar {display: none;}}"
	},
	"sprechzimmer.ch" : {
		showsite: "#vf_sitebar { left: 1000px;} @media screen and (max-width: 1220px) { #vf_sitebar {display: none;}}"
	},
	"dmax.de" : {
		showsite: "@media screen and (min-width: 1730px) {#vf_sitebar { left: calc(50% + 640px);} #dni-notifications{left:15px;}} @media screen and (max-width: 1730px) { #vf_sitebar {display: none;}}"
	},
	"vox.de" : {
		showsite: "@media screen and (min-width: 1400px) {#vf_sitebar { left: 1200px;} #header,body {max-width: 1200px;}} @media screen and (max-width: 1401px) { #vf_sitebar {display: none;}}"
	},
	"vip.de" : {
		showsite: "@media screen and (min-width: 1260px) {#vf_sitebar { left: calc(50% + 410px);}} @media screen and (max-width: 1261px) { #vf_sitebar {display: none;}}"
	},
	"stilpalast.ch" : {
		showsite: "@media screen and (min-width: 1450px) {#vf_sitebar { left: 1180px;} body {max-width: 1180px;} .newsletter-bar .container{margin: 0 20px;}} @media screen and (max-width: 1451px) { #vf_sitebar {display: none;}}"
	},
	"comedycentral.tv" : {
		showsite: "@media screen and (min-width: 1300px) {#vf_sitebar { left: calc(50% + 400px);} #_evidon_banner{ max-width: calc(50% + 400px);}} @media screen and (max-width: 1301px) { #vf_sitebar {display: none;}}"
	},
	"engadiner-wochenzeitung.ch" : {
		showsite: "@media screen and (min-width: 1500px) {#vf_sitebar { left: calc(50% + 510px);} .so-cookie-wrapper{ max-width: calc(50% + 510px);}} @media screen and (max-width: 1501px) { #vf_sitebar {display: none;}}"
	},
	"fm1today.ch" : {
		showsite: "@media screen and (min-width: 1280px) {#vf_sitebar { left: 1030px;} #page {margin: 0;}} @media screen and (max-width: 1281px) { #vf_sitebar {display: none;}}"
	},
	"reddit.com" : {
		showsite: "@media screen and (min-width: 1500px) {#vf_sitebar { left: calc(50% + 510px); top: 49px; z-index:49;}} @media screen and (max-width: 1501px) { #vf_sitebar {display: none;}}"
	},
	"radio24.ch" : {
		showsite: "@media screen and (min-width: 1440px) {body, .audio-player, .audio-player--collapsed {width: 1200px !important;} #vf_sitebar { z-index: 10000000; left: 1200px;}} @media screen and (max-width: 1441px) { #vf_sitebar {display: none;}}"
	},
	"ehow.com" : {
		showsite: "@media screen and (min-width: 1500px) {#vf_sitebar { left: calc(50% + 510px); z-index: 9000011;} .component-article-jwplayer .jwplayer__container-outer .jwplayer__container.jwplayer__container--sticky, a.qc-cmp-persistent-link{ right: calc(50% - 490px) !important;}} @media screen and (max-width: 1501px) { #vf_sitebar {display: none;}}"
	},
	"over-blog.com" : {
		showsite: "@media screen and (min-width: 1520px) {#vf_sitebar { left: 1240px;} body {max-width:1240px;}} @media screen and (max-width: 1521px) { #vf_sitebar {display: none;}}"
	},
	"pflegeportal.ch" : {
		showsite: "@media screen and (min-width: 1270px) {#vf_sitebar { left: 1024px;}} @media screen and (max-width: 1271px) { #vf_sitebar {display: none;}}"
	},
	"ricardo.ch" : {
		showsite: "@media screen and (min-width: 1500px) {#vf_sitebar { left: calc(50% + 450px);}} @media screen and (max-width: 1501px) { #vf_sitebar {display: none;}}"
	},
	"style-magazin.ch" : {
		showsite: "@media screen and (min-width: 1470px) {#vf_sitebar { left: 1210px;}} @media screen and (max-width: 1471px) { #vf_sitebar {display: none;}}"
	},
	"friday-magazine.ch" : {
		showsite: "@media screen and (min-width: 1500px) {#vf_sitebar { left: calc(50% + 520px);} .footer__additional-info{margin-right:130px;}} @media screen and (max-width: 1501px) { #vf_sitebar {display: none;}}"
	},
	"annabelle.ch" : {
		showsite: "@media screen and (min-width: 1850px) {#vf_sitebar { left: calc(50% + 475px);} #newsletterflyin{right: calc(50% - 457px);}} @media screen and (min-width: 1500px) and (max-width: 1849px)  {#vf_sitebar { left: 1250px;} #newsletterflyin{left: 947px;}} @media screen and (max-width: 1501px) { #vf_sitebar {display: none;}}"
	},
	"tilllate.com" : {
		showsite: "@media screen and (min-width: 1260px) {#vf_sitebar { left: calc(50% + 375px);} #wrapper{margin: 0 auto!important;}} @media screen and (max-width: 1261px) { #vf_sitebar {display: none;}}"
	},
	"romandie.com" : {
		showsite: "@media screen and (min-width: 1240px) {#vf_sitebar { left: 1000px;} body {max-width:1000px;}} @media screen and (max-width: 1241px) { #vf_sitebar {display: none;}}"
	},
	"livejournal.com" : {
		showsite: "@media screen and (min-width: 1680px) {#vf_sitebar { left: calc(50% + 625px);} header{max-width: calc(50% + 625px);}} @media screen and (max-width: 1681px) { #vf_sitebar {display: none;}}"
	},
	"femina.ch" : {
		showsite: "@media screen and (min-width: 1595px) {#vf_sitebar { left: calc(50% + 497px);}} @media screen and (min-width: 1240px) and (max-width: 1594px) {#vf_sitebar { left: 994px;} body {max-width: 1020px;}} @media screen and (max-width: 1241px) { #vf_sitebar {display: none;}}"
	},
	"bilanz.ch" : {
		showsite: "@media screen and (min-width: 1250px) {body {padding-left: 25px; padding-right: 25px;} #vf_sitebar { left: 1000px;} #main *, .header-inner, body, ._3xef3Q1V, ._1rHcpTDM, ._1yU2ujCb {max-width: 1000px;}} @media screen and (min-width: 1600px) {body {padding-left: 25px; padding-right: 25px;} #vf_sitebar { left: 1220px;} #main *, .header-inner, body, ._3xef3Q1V, ._1rHcpTDM, ._1yU2ujCb {max-width: 1220px;}} @media screen and (max-width: 1251px) { #vf_sitebar {display: none;}}"
	},
	"beobachter.ch" : {
		showsite: "@media screen and (min-width: 1200px) {#vf_sitebar { left: calc(40% + 420px);}} @media screen and (min-width: 1680px) {#vf_sitebar { left: calc(40% + 700px);}} @media screen and (max-width: 1199px) { #vf_sitebar {display: none;}}"
	},
	"handelszeitung.ch" : {
		showsite: "#apn-ad-slot-hpa-1-sba {border: 0px;} #vf_sitebar {margin-right: 1px;} @media screen and (min-width: 1200px) { #vf_sitebar {left: calc(50% + 250px); top: 332px;}} @media screen and (min-width: 1680px) { #vf_sitebar { left: calc(50% + 500px); top: 0px;}} @media screen and (max-width: 1199px) { #vf_sitebar {display: none;}}"
	},
	"schweizerfamilie.ch" : {
		showsite: "@media screen and (min-width: 1480px) {#vf_sitebar { left: calc(50% + 520px);}} @media screen and (max-width: 1481px) { #vf_sitebar {display: none;}}"
	},
	"bilan.ch" : {
		showsite: "@media screen and (min-width: 1595px) {#vf_sitebar { left: calc(50% + 507px);}} @media screen and (min-width: 1240px) and (max-width: 1304px) {#vf_sitebar { left: 1008px;}} @media screen and (min-width: 1305px) and (max-width: 1594px) {#vf_sitebar { left: calc(100% - 296px);}} @media screen and (max-width: 1241px) { #vf_sitebar {display: none;}}"
	},
	"blickamabend.ch" : {
		showsite: "@media screen and (min-width: 1240px) {#vf_sitebar { left: 994px;} body, #header_outer.sticky {max-width: 994px;}} @media screen and (max-width: 1241px) { #vf_sitebar {display: none;}}"
	},
	"viva.tv" : {
		showsite: "@media screen and (min-width: 1240px) {#vf_sitebar { left: 1000px;} section, .viacomcookiebar, #_evidon_banner {max-width:1000px;} #top-ad{margin-left: 0px !important;}} @media screen and (max-width: 1241px) { #vf_sitebar {display: none;}}"
	},
	"aol.de" : {
		showsite: "@media screen and (min-width: 1850px) {#vf_sitebar { left: calc(50% + 700px);}} @media screen and (max-width: 1851px) { #vf_sitebar {display: none;}}"
	},
	"tvdigital.de" : {
		showsite: "@media screen and (min-width: 1680px) {#vf_sitebar { left: calc(50% + 575px);} #pc-cookie-notice { width: calc(50% + 575px);}} @media screen and (max-width: 1681px) { #vf_sitebar {display: none;}}"
	},
	"fitbook.de" : {
		showsite: "@media screen and (min-width: 1680px) {#vf_sitebar { left: calc(50% + 520px);} #footer-bar { width: calc(50% + 520px);}} @media screen and (max-width: 1681px) { #vf_sitebar {display: none;}}"
	},
	"swisshabs.ch" : {
		showsite: "@media screen and (min-width: 1390px) {#vf_sitebar { left: 1170px; top: 66px;} body {max-width: 1080px;}} @media screen and (max-width: 1391px) { #vf_sitebar {display: none;}}"
	},
	"energy.ch" : {
		showsite: "@media screen and (min-width: 1300px) {#vf_sitebar { left: 1020px; top: 60px;} body, #w .background-image, .playerbar-wrapper #player .main-player, #headerbar .navbar, .playerbar-wrapper #player {max-width: 1020px;}} @media screen and (max-width: 1301px) { #vf_sitebar {display: none;}}"
	},
	"kochbar.de" : {
		showsite: "@media screen and (min-width: 1480px) {#vf_sitebar { left: calc(50% + 500px);}} @media screen and (max-width: 1481px) { #vf_sitebar {display: none;}}"
	},
	"rtl.de" : {
		showsite: "@media screen and (min-width: 1480px) {#vf_sitebar { left: calc(50% + 510px);}} @media screen and (max-width: 1481px) { #vf_sitebar {display: none;}}"
	},
	"derstandard.at" : {
		showsite: "@media screen and (min-width: 1280px) {#vf_sitebar { left: 980px; }} @media screen and (max-width: 1281px) { #vf_sitebar {display: none;}}"
	},
	"icepop.com" : {
		showsite: "@media screen and (min-width: 1640px) {#vf_sitebar { left: calc(50% + 580px);}} @media screen and (max-width: 1641px) { #vf_sitebar {display: none;}}"
	},
	"voetbalzone.nl" : {
		showsite: "@media screen and (min-width: 1440px) {#vf_sitebar { left: calc(50% + 500px);}} @media screen and (max-width: 1441px) { #vf_sitebar {display: none;}}"
	},
	"meinbezirk.at" : {
		showsite: "@media screen and (min-width: 1440px) {#vf_sitebar { left: calc(50% + 500px);}} @media screen and (max-width: 1441px) { #vf_sitebar {display: none;}}"
	},
	"dcmepgnord.de" : {
		showsite: "@media screen and (min-width: 1590px) {#vf_sitebar { left: calc(50% + 575px);} #pc-cookie-notice { width: calc(50% + 575px); }} @media screen and (max-width: 1591px) { #vf_sitebar {display: none;}}"
	},
	"sport.de" : {
		showsite: "@media screen and (min-width: 1320px) {body, .cc-window.cc-banner {width: 1040px;} #vf_sitebar { left: 1040px;}} @media screen and (max-width: 1321px) { #vf_sitebar {display: none;}}"
	},
	"radiofm1.ch" : { 
		showsite: "@media screen and (min-width: 1240px) {#vf_sitebar { left: 1028px;}} @media screen and (min-width: 1340px) {#vf_sitebar { left: calc(50% + 365px);}} @media screen and (max-width: 1261px) { #vf_sitebar {display: none;}}"
	},
	"swissmom.ch" : {
		showsite: "@media screen and (min-width: 1370px) {body {width: 1140px;} #vf_sitebar { left: 1140px;}} @media screen and (max-width: 1371px) { #vf_sitebar {display: none;}}"
	},
	"swissmomforum.ch" : {
		showsite: "@media screen and (min-width: 1620px) {body {width: 1410px;} #vf_sitebar { left: 1410px;}} @media screen and (max-width: 1621px) { #vf_sitebar {display: none;}}"
	},
	"netdoktor.ch" : {
		showsite: "@media screen and (min-width: 1200px) {body {width: 1110px;} #vf_sitebar { left: 980px;}} @media screen and (min-width: 1400px) {body {width: 1410px;} #vf_sitebar { left: 1100px;}} @media screen and (max-width: 1201px) { #vf_sitebar {display: none;}}"
	},
	"mamiweb.de" : {
		showsite: "@media screen and (min-width: 1100px) {body {width: 940px;} #vf_sitebar { left: 900px;}} @media screen and (min-width: 1400px) {body {width: 1410px;} #vf_sitebar { left: 1070px;}} @media screen and (max-width: 1101px) { #vf_sitebar {display: none;}}"
	},
	"mtv.de" : {
		showsite: "@media screen and (min-width: 1650px) {#vf_sitebar { left: calc(50% + 630px);}} @media screen and (max-width: 1651px) { #vf_sitebar {display: none;}}"
	},
	"letemps.ch" : {
		showsite: "@media screen and (min-width: 1460px) {body {width: 1260px;} .picture-cover {margin: 0 0 0 115px;} .container, .container-fluid {margin:0;} .ad .adtech{width: auto;} .adtech{max-width: 1230px;} .picture-cover{max-width:1140px;} .alert-paywall,.navbar-not-top, .navbar.affix{max-width: 1255px;} #vf_sitebar { left: 1260px;}} @media screen and (max-width: 1461px) { #vf_sitebar {display: none;}}"
	},
	"businessinsider.de" : {
		showsite: "@media screen and (min-width: 1440px) {body {width: 1200px;} #vf_sitebar { left: 1200px;}} @media screen and (max-width: 1441px) { #vf_sitebar {display: none;}}"
	},
	"bildderfrau.de" : {
		showsite: "@media screen and (min-width: 1440px) {body {width: 1200px;} #vf_sitebar { z-index: 10000000; left: 1200px;}} @media screen and (max-width: 1441px) { #vf_sitebar {display: none;}}"
	},
	"motorsport.com" : {
		showsite: "@media screen and (min-width: 1440px) {body {width: 1200px;} #vf_sitebar { top: 120px; z-index: 10000000; left: 1200px;}} @media screen and (max-width: 1441px) { #vf_sitebar {display: none;}}"
	},
	"watson.ch" : {
		showsite: "@media screen and (min-width: 1440px) {body {width: 1200px;} #vf_sitebar { top: 87px; z-index: 10000000; left: 1026px;}} @media screen and (max-width: 1441px) { #vf_sitebar {display: none;}}"
	},
	"telezueri.ch" : {
		showsite: "@media screen and (min-width: 1396px) {#vf_sitebar { left: 900px;} body { width: 1200px;}} @media screen and (min-width: 1760px) {#vf_sitebar { left: 1200px;} body { width: 1200px;}} @media screen and (max-width: 1395px) { #vf_sitebar {display: none;}}"
	},
	"ok-magazin.de" : {
		showsite: "@media screen and (min-width: 1260px) {body {width: 1200px;} #vf_sitebar { z-index: 10000000; left: 1030px;}} @media screen and (min-width: 1600px) {body {width: 1200px;} #vf_sitebar { z-index: 10000000; left: 1330px;}} @media screen and (max-width: 1261px) { #vf_sitebar {display: none;}}"
	},
	"bz-berlin.de" : {
		showsite: "@media screen and (min-width: 1440px) {body {width: 1200px;} div.brand-container {left: 600px !important;} #vf_sitebar { z-index: 10000000; left: 1200px;}} @media screen and (max-width: 1441px) { #vf_sitebar {display: none;}}"
	},
	"rtv.de" : {
		showsite: "@media screen and (min-width: 1440px) {body {width: 1200px;} #vf_sitebar { z-index: 10000000; left: 1200px;}} @media screen and (max-width: 1441px) { #vf_sitebar {display: none;}}"
	},
	"jolie.de" : {
		showsite: "@media screen and (min-width: 1440px) {body, .header.header--fixed {width: 1200px !important;} #vf_sitebar { z-index: 10000000; left: 1020px;}} @media screen and (max-width: 1441px) { #vf_sitebar {display: none;}}"
	},
	"gmx.net" : {
		showsite: "@media screen and (min-width: 1440px) {body {width: 1200px !important;} #vf_sitebar { z-index: 10000000; left: 1321px;}} @media screen and (max-width: 1441px) { #vf_sitebar {display: none;}}"
	},
	"weltfussball.com" : {
		showsite: "@media screen and (min-width: 1440px) {#vf_sitebar { z-index: 10000000; left: 1020px;}} @media screen and (max-width: 1441px) { #vf_sitebar {display: none;}}"
	},
	"suissebook.ch" : {
		showsite: "@media screen and (min-width: 1440px) {.header, body {width: 1200px !important;} #vf_sitebar { z-index: 10000000; left: 1200px;}} @media screen and (max-width: 1441px) { #vf_sitebar {display: none;}}"
	},
	"comparis.ch" : {
		showsite: "@media screen and (min-width: 1550px) {#vf_sitebar { z-index: 10000000; left: 1320px;}} @media screen and (max-width: 1319px) { #vf_sitebar {display: none;}}"
	},
	"corriere.it" : {
		showsite: "@media screen and (min-width: 1460px) {#vf_sitebar { top: 40px; left: calc(50% + 512px);}} @media screen and (max-width: 1461px) { #vf_sitebar {display: none;}}"
	},
	"tagesspiegel.de" : {
		showsite: "@media screen and (min-width: 1440px) {#vf_sitebar { z-index: 1600000000; left: calc(50% + 525px);}} @media screen and (max-width: 1441px) { #vf_sitebar {display: none;}}"
	},
	"tvtv.ch" : {
		showsite: "@media screen and (min-width: 1240px) {body {width: 1000px !important;} #vf_sitebar { z-index: 10000000; left: 1000px;}} @media screen and (min-width: 1440px) {body {width: 1000px !important;} #vf_sitebar { z-index: 10000000; left: 1200px;}} @media screen and (min-width: 1620px) {body {width: 1000px !important;} #vf_sitebar { z-index: 10000000; left: 1400px;}} @media screen and (max-width: 1241px) { #vf_sitebar {display: none;}}"
	},
	"krone.at" : {
		showsite: "@media screen and (min-width: 1200px) {#vf_sitebar { left: 960px;}} @media screen and (min-width: 1440px) {#vf_sitebar { left: 1120px;}} @media screen and (min-width: 1680px) {#vf_sitebar { left: 1260px;}} @media screen and (max-width: 1201px) { #vf_sitebar {display: none;}}"
	},
	"bergfex.ch" : {
		showsite: "@media screen and (min-width: 1260px) {#vf_sitebar { left: 1070px;}} @media screen and (min-width: 1400px) {#vf_sitebar { left: 1090px;}} @media screen and (min-width: 1600px) {#vf_sitebar { left: 1140px;}} @media screen and (max-width: 1261px) { #vf_sitebar {display: none;}}"
	},
	"stickermanager.com" : {
		showsite: "@media screen and (min-width: 1550px) {body {width: 1300px !important;} #vf_sitebar { z-index: 10000000; left: 1100px; top: 70px;}} @media screen and (max-width: 1551px) { #vf_sitebar {display: none;}}"
	},
	"spiegel.de" : {
		showsite: "@media screen and (min-width: 1200px) {#vf_sitebar { left: 1010px;}} @media screen and (min-width: 1330px) {#vf_sitebar { left: calc(100% - 300px);}} @media screen and (min-width: 1620px) {#vf_sitebar { left: calc(50% + 505px);}} @media screen and (max-width: 1201px) { #vf_sitebar {display: none;}}"
	},
	"rfj.ch" : {
		showsite: "@media screen and (min-width: 993px) {#vf_sitebar { left: calc(50% + 275px); top: 50px; bottom: 82px;}} @media screen and (min-width: 1200px) {#vf_sitebar { left: calc(50% + 382px); top: 50px; bottom: 82px;}} @media screen and (min-width: 1600px) {#vf_sitebar { left: calc(50% + 582px); top: 50px; bottom: 82px;}} @media screen and (max-width: 992px) { #vf_sitebar {display: none;}}"
	},
	"rtn.ch" : {
		showsite: "@media screen and (min-width: 993px) {#vf_sitebar { left: calc(50% + 215px); top: 50px; bottom: 82px;}} @media screen and (min-width: 1200px) {#vf_sitebar { left: calc(50% + 322px); top: 50px; bottom: 82px;}} @media screen and (min-width: 1600px) {#vf_sitebar { left: calc(50% + 522px); top: 50px; bottom: 82px;}} @media screen and (max-width: 992px) { #vf_sitebar {display: none;}}"
	},
	"duden.de" : {
		showsite: "@media screen and (min-width: 1161px) {#vf_sitebar{ left: calc(100% - 210px);}} @media screen and (min-width: 1640px) {#vf_sitebar{ left: calc(100% - 360px);}} @media screen and (max-width: 1160px) { #vf_sitebar {display: none;}}"
	},
	"sueddeutsche.de" : {
		showsite: "@media screen and (min-width: 1300px) {#vf_sitebar {top: 50px; z-index: 160000000000; left: calc(50% + 510px);}} @media screen and (max-width: 1301px) { #vf_sitebar {display: none;}}"
	},
	"gipfelbuch.ch" : {
		showsite: "@media screen and (min-width: 971px) {#vf_sitebar { position: absolute; top: 170px; left: calc(100% - 330px);}} @media screen and (min-width: 1451px) {#vf_sitebar { position: fixed; top: 0px; left: calc(50% + 410px);}} @media screen and (max-width: 970px) { #vf_sitebar {display: none;}}"
	},
	"finanznachrichten.de" : {
		showsite: "@media screen and (min-width: 1271px) {#vf_sitebar { left: 1050px;}} @media screen and (min-width: 1551px) {#vf_sitebar { left: calc(50% + 520px);}} @media screen and (max-width: 1270px) { #vf_sitebar {display: none;}}"
	},
	"bfmtv.com" : {
		showsite: "@media screen and (min-width: 1550px) {body {width: 1300px !important;} header[class^='nx-'] {width: 1300px;} #vf_sitebar { z-index: 10000000; left: 1300px;}} @media screen and (max-width: 1551px) { #vf_sitebar {display: none;}}"
	},
	"zonebourse.com" : {
		showsite: "@media screen and (min-width: 1550px) {body {width: 1300px !important;} .htFLine, .htMLine {min-width: 1300px;} #vf_sitebar { z-index: 10000000; left: 1300px;}} @media screen and (max-width: 1551px) { #vf_sitebar {display: none;}}"
	},
	"babywelten.ch" : {
		showsite: "@media screen and (min-width: 1300px) {body {margin: 0 0 0 0 !important;} #vf_sitebar { z-index: 10000000; left: 1010px;}} @media screen and (max-width: 1300px) { #vf_sitebar {display: none;}}"
	},
	"schweizer-illustrierte.ch" : {
		showsite: "@media screen and (min-width: 1440px) {#vf_sitebar { left: calc(50% + 490px); z-index: 9000;}} @media screen and (max-width: 1441px) { #vf_sitebar {display: none;}}"
	},
	"1300left.ch" : {
		showsite: "@media screen and (min-width: 1550px) {body {width: 1300px !important;} #vf_sitebar { z-index: 10000000; left: 1300px;}} @media screen and (max-width: 1551px) { #vf_sitebar {display: none;}}"
	},
	"1200left.ch" : {
		showsite: "@media screen and (min-width: 1440px) {body {width: 1200px !important;} #vf_sitebar { z-index: 10000000; left: 1200px;}} @media screen and (max-width: 1441px) { #vf_sitebar {display: none;}}"
	},
	"1236left.ch" : {
		showsite: "@media screen and (min-width: 1440px) {body {width: 1236px !important;} #vf_sitebar { z-index: 10000000; left: 1236px;}} @media screen and (max-width: 1441px) { #vf_sitebar {display: none;}}"
	},
	"1110left.ch" : {
		showsite: "@media screen and (min-width: 1440px) {body {width: 1110px !important;} #vf_sitebar { z-index: 10000000; left: 1110px;}} @media screen and (max-width: 1441px) { #vf_sitebar {display: none;}}"
	},
	"1060left.ch" : {
		showsite: "@media screen and (min-width: 1340px) {body {width: 1060px !important;} #vf_sitebar { z-index: 10000000; left: 1060px;}} @media screen and (max-width: 1341px) { #vf_sitebar {display: none;}}"
	},
	"1010left.ch" : {
		showsite: "@media screen and (min-width: 1240px) {body {width: 1010px !important;} #vf_sitebar { z-index: 10000000; left: 1010px;}} @media screen and (max-width: 1241px) { #vf_sitebar {display: none;}}"
	},
	"1000left.ch" : {
		showsite: "@media screen and (min-width: 1340px) {body {width: 1000px !important;} #vf_sitebar { z-index: 10000000; left: 1000px;}} @media screen and (max-width: 1341px) { #vf_sitebar {display: none;}}"
	},
	"1440center.ch" : {
		showsite: "@media screen and (min-width: 1440px) {#vf_sitebar { left: calc(50% + 500px);}} @media screen and (max-width: 1441px) { #vf_sitebar {display: none;}}"
	},
	"1440center650.ch" : {
		showsite: "@media screen and (min-width: 1440px) {#vf_sitebar { left: calc(50% + 650px);}} @media screen and (max-width: 1441px) { #vf_sitebar {display: none;}}"
	},
	"1440center610.ch" : {
		showsite: "@media screen and (min-width: 1440px) {#vf_sitebar { left: calc(50% + 610px);}} @media screen and (max-width: 1441px) { #vf_sitebar {display: none;}}"
	},
	"1440center590.ch" : {
		showsite: "@media screen and (min-width: 1440px) {#vf_sitebar { left: calc(50% + 590px);}} @media screen and (max-width: 1441px) { #vf_sitebar {display: none;}}"
	},
	"1440center540.ch" : {
		showsite: "@media screen and (min-width: 1440px) {#vf_sitebar { left: calc(50% + 540px);}} @media screen and (max-width: 1441px) { #vf_sitebar {display: none;}}"
	},
	"1440center520.ch" : {
		showsite: "@media screen and (min-width: 1440px) {#vf_sitebar { left: calc(50% + 520px);}} @media screen and (max-width: 1441px) { #vf_sitebar {display: none;}}"
	},
	"1440center490.ch" : {
		showsite: "@media screen and (min-width: 1440px) {#vf_sitebar { left: calc(50% + 490px);}} @media screen and (max-width: 1441px) { #vf_sitebar {display: none;}}"
	},
	"1440center470.ch" : {
		showsite: "@media screen and (min-width: 1440px) {#vf_sitebar { left: calc(50% + 470px);}} @media screen and (max-width: 1441px) { #vf_sitebar {display: none;}}"
	},
	"1440center450.ch" : {
		showsite: "@media screen and (min-width: 1440px) {#vf_sitebar { left: calc(50% + 450px);}} @media screen and (max-width: 1441px) { #vf_sitebar {display: none;}}"
	},
	"1440center440.ch" : {
		showsite: "@media screen and (min-width: 1440px) {#vf_sitebar { left: calc(50% + 440px);}} @media screen and (max-width: 1441px) { #vf_sitebar {display: none;}}"
	},
	"1300center.ch" : {
		showsite: "@media screen and (min-width: 1300px) {#vf_sitebar { left: calc(50% + 430px);}} @media screen and (max-width: 1301px) { #vf_sitebar {display: none;}}"
	},
	"1300center420.ch" : {
		showsite: "@media screen and (min-width: 1300px) {#vf_sitebar { left: calc(50% + 400px);}} @media screen and (max-width: 1301px) { #vf_sitebar {display: none;}}"
	},
	"1300center400.ch" : {
		showsite: "@media screen and (min-width: 1300px) {#vf_sitebar { left: calc(50% + 400px);}} @media screen and (max-width: 1301px) { #vf_sitebar {display: none;}}"
	},
	"1300center380.ch" : {
		showsite: "@media screen and (min-width: 1300px) {#vf_sitebar { left: calc(50% + 380px);}} @media screen and (max-width: 1301px) { #vf_sitebar {display: none;}}"
	},
	"1200center360.ch" : {
		showsite: "@media screen and (min-width: 1200px) {#vf_sitebar { left: calc(50% + 360px);}} @media screen and (max-width: 1201px) { #vf_sitebar {display: none;}}"
	}
}

var sitebarcss = document.createElement('style');
sitebarcss.type = 'text/css';

if (sitebarhostname=='standard') {
	var sitebarstyles = '#vf_sitebar { position: absolute; right: 0; bottom: 0; top: 0;  text-align: center; } ';
} else {
	var sitebarstyles = '#vf_sitebar { position: fixed; right: 0; bottom: 0; top: 0;  z-index: 1600000; text-align: center; } ';
}

// Samestyles
if (sitebarhostname=='01net.com' || sitebarhostname=='hausgartenleben.ch' || sitebarhostname=='radiobern1.ch') {sitebarhostname='1300left.ch';}

if (sitebarhostname=='search.ch') {sitebarhostname='1236left.ch';}

if (sitebarhostname=='sarganserlaender.ch' || sitebarhostname=='parents.at' || sitebarhostname=='kleinezeitung.at' || sitebarhostname=='websingles.at' || sitebarhostname=='kronehit.at' || sitebarhostname=='local.ch' || sitebarhostname=='liewo.li' || sitebarhostname=='teteamodeler.com' || sitebarhostname=='femina.fr' || sitebarhostname=='cosmopolitan.fr' || sitebarhostname=='swissflirt.ch' || sitebarhostname=='vaterland.li' || sitebarhostname=='apotheken-umschau.de' || sitebarhostname=='baby-und-familie.de' || sitebarhostname=='pme.ch' || sitebarhostname=='radio.ch' || sitebarhostname=='illustre.ch' || sitebarhostname=='manager-magazin.de' || sitebarhostname=='manager-magazin.de' || sitebarhostname=='tvtv.de' || sitebarhostname=='alpenverein.de' || sitebarhostname=='neon.de' || sitebarhostname=='business-punk.com' || sitebarhostname=='livingathome.de') {sitebarhostname='1200left.ch';}

if (sitebarhostname=='harvardbusinessmanager.de' || sitebarhostname=='sunny.at' || sitebarhostname=='meteocentrale.ch' || sitebarhostname=='4-4-2.com' || sitebarhostname=='polizei-schweiz.ch' || sitebarhostname=='swisswebcams.ch') {sitebarhostname='1060left.ch';}

if (sitebarhostname=='burnout-info.ch' || sitebarhostname=='swisscharts.com' || sitebarhostname=='hitparade.ch') {sitebarhostname='1010left.ch';}

if (sitebarhostname=='planetehockey.com') {sitebarhostname='1110left.ch';}

if (sitebarhostname=='aktien-portal.at' || sitebarhostname=='sms.at' || sitebarhostname=='wetteronline.at' || sitebarhostname=='wetteronline.ch' || sitebarhostname=='ze.tt' || sitebarhostname=='spektrum.de' || sitebarhostname=='eishockeyticker.ch' || sitebarhostname=='eyeblaster.com' || sitebarhostname=='diepresse.com') {sitebarhostname='1000left.ch';}

if (sitebarhostname=='handelsblatt.com' || sitebarhostname=='zeit.de' || sitebarhostname=='capital.de' || sitebarhostname=='ticinonews.ch' || sitebarhostname=='welt.de') {sitebarhostname='1440center.ch';}

if (sitebarhostname=='kul-magazin.li' || sitebarhostname=='tvdirekt.de' || sitebarhostname=='klack.de' || sitebarhostname=='wieistmeineip.ch' || sitebarhostname=='zurich-airport.com' || sitebarhostname=='flughafen-zuerich.ch' || sitebarhostname=='femelle.ch' || sitebarhostname=='usgang.ch' || sitebarhostname=='transfermarkt.ch') {sitebarhostname='1440center440.ch';}

if (sitebarhostname=='vaterlandmagazin.li') {sitebarhostname='1440center450.ch';}

if (sitebarhostname=='classicdriver.com' || sitebarhostname=='bento.de' || sitebarhostname=='wirtschaftregional.li' || sitebarhostname=='students.ch') {sitebarhostname='1440center470.ch';}

if (sitebarhostname=='rollingstone.de' || sitebarhostname=='e-puzzles.fr' || sitebarhostname=='lefigaro.fr' || sitebarhostname=='fitundgesund.at' || sitebarhostname=='gazzetta.it' || sitebarhostname=='gruenderszene.de' || sitebarhostname=='couchstyle.de' || sitebarhostname=='gesund-vital.de' || sitebarhostname=='vorname.com' || sitebarhostname=='hoerzu.de') {sitebarhostname='1440center490.ch';}

if (sitebarhostname=='blueray-disc.ch' || sitebarhostname=='psychologies.com' || sitebarhostname=='ariva.de' || sitebarhostname=='hockeymanager.ch' || sitebarhostname=='fussballinfos.ch' || sitebarhostname=='appenzell24.ch' || sitebarhostname=='haustech-magazin.ch' || sitebarhostname=='zueriost.ch' || sitebarhostname=='ingenieur.de' || sitebarhostname=='hk-gebaeudetechnik.ch' || sitebarhostname=='elektrotechnik.ch' || sitebarhostname=='polizeiticker.ch' || sitebarhostname=='schweizamwochenende.ch' || sitebarhostname=='famili.fr' || sitebarhostname=='wiwo.de' || sitebarhostname=='cdt.ch' || sitebarhostname=='fuw.ch' || sitebarhostname=='oltnertagblatt.ch' || sitebarhostname=='badenertagblatt.ch' || sitebarhostname=='limmattalerzeitung.ch' || sitebarhostname=='weltwoche.ch' || sitebarhostname=='radio3i.ch' || sitebarhostname=='netdoktor.de' || sitebarhostname=='onvista.de' || sitebarhostname=='myhomebook.de' || sitebarhostname=='stylebook.de' || sitebarhostname=='techbook.de' || sitebarhostname=='formel1.de' || sitebarhostname=='motorsport-total.com' || sitebarhostname=='sport1.de' || sitebarhostname=='travelbook.de') {sitebarhostname='1440center520.ch';}

if (sitebarhostname=='digitalfernsehen.de') {sitebarhostname='1440center540.ch';}

if (sitebarhostname=='keinhochglanzmagazin.com' || sitebarhostname=='myself.de' || sitebarhostname=='schoenesleben.ch' || sitebarhostname=='20minutes.fr' || sitebarhostname=='dietagespresse.com' || sitebarhostname=='s1tv.ch' || sitebarhostname=='terrenature.ch') {sitebarhostname='1440center590.ch';}

if (sitebarhostname=='laliberte.ch' || sitebarhostname=='jobtome.com') {sitebarhostname='1440center610.ch';}

if (sitebarhostname=='brandeins.de' || sitebarhostname=='journaldunet.fr' || sitebarhostname=='commentcamarche.net' || sitebarhostname=='noizz.de') {sitebarhostname='1440center650.ch';}

if (sitebarhostname=='rro.ch' || sitebarhostname=='journaldujura.ch' || sitebarhostname=='9monate.de' || sitebarhostname=='teletext.ch' || sitebarhostname=='maedchen.de' || sitebarhostname=='wieistmeineip.de' || sitebarhostname=='autobild.de' || sitebarhostname=='computerbild.de' || sitebarhostname=='finanzen.net' || sitebarhostname=='bild.de' || sitebarhostname=='transfermarkt.de' || sitebarhostname=='doodle.ch' || sitebarhostname=='50plus.ch') {sitebarhostname='1300center.ch';}

if (sitebarhostname=='areamobile.de' || sitebarhostname=='finya.ch' || sitebarhostname=='hockeyinfo.ch' || sitebarhostname=='wetter.de' || sitebarhostname=='heute.at') {sitebarhostname='1300center380.ch';}

if (sitebarhostname=='schweizersee.ch') {sitebarhostname='1300center420.ch';}

if (sitebarhostname=='ekitchen.de' || sitebarhostname=='vital.de' || sitebarhostname=='fuersie.de' || sitebarhostname=='petra.de' || sitebarhostname=='eltern.de' || sitebarhostname=='grazia-magazin.de' || sitebarhostname=='essen-und-trinken.de' || sitebarhostname=='schoener-wohnen.de') {sitebarhostname='1300center400.ch';}

if (sitebarhostname=='bergfex.pl' || sitebarhostname=='bergfex.si' || sitebarhostname=='bergfex.si' || sitebarhostname=='bergfex.fr' || sitebarhostname=='bergfex.at' || sitebarhostname=='bergfex.de' || sitebarhostname=='bergfex.it' || sitebarhostname=='bergfex.es' || sitebarhostname=='bergfex.com') {sitebarhostname='bergfex.ch';}

if (sitebarhostname=='lifeline.de' || sitebarhostname=='bildspielt.de') {sitebarhostname='1200center360.ch';}

if (sitebarhostname=='argovia.ch') {sitebarhostname='radio24.ch';}

if (sitebarhostname=='nitro-tv.de') {sitebarhostname='vox.de';}

if (sitebarhostname=='netdoktor.at') {sitebarhostname='netdoktor.ch';}

if (sitebarhostname=='grenchnertagblatt.ch' || sitebarhostname=='basellandschaftlichezeitung.ch' || sitebarhostname=='bzbasel.ch' || sitebarhostname=='solothurnerzeitung.ch') {sitebarhostname='aargauerzeitung.ch';}

if (sitebarhostname=='tagblatt.ch' || sitebarhostname=='luzernerzeitung.ch') {sitebarhostname='nzz.ch';}

if (sitebarhostname=='langenthalertagblatt.ch' || sitebarhostname=='berneroberlaender.ch' || sitebarhostname=='thunertagblatt.ch' || sitebarhostname=='bazonline.ch' || sitebarhostname=='bernerzeitung.ch' || sitebarhostname=='derbund.ch' || sitebarhostname=='tdg.ch' || sitebarhostname=='lematin.ch' || sitebarhostname=='24heures.ch') {sitebarhostname='tagesanzeiger.ch';}

if (sitebarhostname=='the-voice-of-germany.ch' || sitebarhostname=='kabeleinsdoku.ch' || sitebarhostname=='puls8.ch' || sitebarhostname=='sixx.ch' || sitebarhostname=='sat1.ch' || sitebarhostname=='prosiebenmaxx.ch' || sitebarhostname=='kabeleins.ch' || sitebarhostname=='sat1gold.ch') {sitebarhostname='prosieben.ch';}

if (sitebarhostname=='rtl2.de') {sitebarhostname='rtl.de';}

if (sitebarhostname=='wetter.li' || sitebarhostname=='meteonews.fr' || sitebarhostname=='meteonews.at' || sitebarhostname=='meteonews.be' || sitebarhostname=='meteonews.de') {sitebarhostname='meteonews.ch';}

if (sitebarhostname=='bym.de') {sitebarhostname='brigitte.de';}

if (sitebarhostname=='journaldesfemmes.fr') {sitebarhostname='journaldesfemmes.com';}

if (sitebarhostname=='20minuti.ch') {sitebarhostname='tio.ch';}

if (sitebarhostname=='linternaute.fr') {sitebarhostname='linternaute.com';}

if (sitebarhostname=='hldlg.com') {sitebarhostname='hausinfo.ch';}

if (sitebarhostname=='gofeminin.de') {sitebarhostname='gofeminin.ch';}

if (sitebarhostname=='cdnarcinfo.ch' || sitebarhostname=='arcinfo.ch' || sitebarhostname=='lenouvelliste.ch') {sitebarhostname='lacote.ch';}

if (sitebarhostname=='ronorp.test') {sitebarhostname='ronorp.net';}

if (sitebarhostname=='teleboerse.de') {sitebarhostname='n-tv.de';}

if (sitebarhostname=='feglufficialsurselva.ch') {sitebarhostname='engadiner-wochenzeitung.ch';}

if (sitebarhostname=='meteo.aero') {sitebarhostname='meteo.ch';}

if (sitebarhostname=='lessentiel.lu') {sitebarhostname='20min.ch';}

if (sitebarhostname=='tv24.ch' || sitebarhostname=='telebaern.tv') {sitebarhostname='telezueri.ch';}

if (sitebarhostname=='rjb.ch') {sitebarhostname='rtn.ch';}

if (sitebarhostname=='rmcsport.bfmtv.com' || sitebarhostname=='rmc.bfmtv.com' || sitebarhostname=='grrif.ch') {sitebarhostname='bfmtv.com';}


if (sitebarhostname=='doubleclick.net' || sitebarhostname=='googleadservices.com') {sitebarhostname='standard';}

// Check styles and send a notification
if (!(sitebarhostname in sitebarpages)) {
	sitebarstyles += '#vf_sitebar {display: none;}';
	if (sitebarhostname!='googleadservices.com' || sitebarhostname!='themediatrust.com' || sitebarhostname!='sogoucdn.com' || sitebarhostname!='localhost' || sitebarhostname!='azmedien.ch') {
		var vf_sitebar_pixel = document.createElement("IMG");
		vf_sitebar_pixel.setAttribute("src", "https://dynamicad.ch/sitebar/sitebarcreate.php?domain="+sitebarhostname);
		vf_sitebar_pixel.setAttribute("height", "1");
		vf_sitebar_pixel.setAttribute("width", "1");
		document.body.appendChild(vf_sitebar_pixel);
	}
} else {
	sitebarstyles += sitebarpages[sitebarhostname]["showsite"];
}




if (sitebarcss.styleSheet) sitebarcss.styleSheet.cssText = sitebarstyles;
else sitebarcss.appendChild(document.createTextNode(sitebarstyles));

document.getElementById('vf_sitebar').appendChild(sitebarcss);

var vf_sitebar_current=document.createElement('script');

var vf_sitebar_cs="var sitebarhostname='"+sitebarhostname+"'; if (typeof vf_sitebar_active === 'undefined' || vf_sitebar_active === null) {vf_sitebar_tscurrent=Date.now();}; if (typeof vf_sitebar_active === 'undefined' || vf_sitebar_active === null) {window.top.addEventListener('message', function(e) {if (e.data=='sitebarup') {vf_sitebar_active=1;vf_sitebar_tscurrent=Date.now();}}, false);console.log('sitebartickerup'); vf_sitebar_active=true; setInterval(function(){ if (vf_sitebar_active==1) {if (vf_sitebar_tscurrent+3000>Date.now() || sitebarhostname=='blick.ch' || sitebarhostname=='20min.ch') {/*console.log('active');*/} else {if (document.getElementById('vf_sitebar')!=null) { document.getElementById('vf_sitebar').remove();	};}; }}, 500);}; setInterval(function(){ var sitebarScrollPos = window.scrollY || window.scrollTop || document.getElementsByTagName('html')[0].scrollTop; if(document.getElementById('vf_sitebarcontent')){document.getElementById('vf_sitebarcontent').contentWindow.postMessage('sitebarScroll_'+sitebarScrollPos, '*');} /*console.log(sitebarScrollPos);*/ }, 10);";

try {
	vf_sitebar_current.appendChild(document.createTextNode(vf_sitebar_cs));      
} catch(e) {
    vf_sitebar_current.text = vf_sitebar_cs;
}

function sitebarTop() {
    var sitebarScrollPos = window.top.scrollY || window.top.scrollTop;

    if (sitebarScrollPos == undefined) {
        sitebarScrollPos=0;
    }
    if (sitebarhostname=='bluewin.ch') {
        if (sitebarScrollPos <= 119) {
            window.parent.document.getElementById('vf_sitebar').style.marginTop=(119-sitebarScrollPos)+'px';
        } else {
            window.parent.document.getElementById('vf_sitebar').style.marginTop='0px';
        }
    }
}

if (sitebarhostname=='bluewin.ch') {
    setInterval(function(){ sitebarTop(); }, 100);
}

function sitebarhide(event) {
	if (event.data=='sitebarclose') {
		console.log('sitebarclose');
		document.getElementById('vf_sitebar').parentNode.removeChild(document.getElementById('vf_sitebar'));
	}
}
addEventListener("message", sitebarhide, false);



var vf_eventlistener='enabled';

	if(window!=top) {
		try {
			if (window.parent.document.getElementById("vf_sitebar")!=null) {
				console.log('sitebarclose');
				window.parent.document.getElementById("vf_sitebar").remove();				
			};
		} catch (err) {
			vf_eventlistener='disabled';
		}
		try {
			window.parent.document.getElementsByTagName('body')[0].appendChild(document.getElementById("vf_sitebar"));
			window.parent.document.getElementById('vf_sitebarcontainer').appendChild(vf_sitebar_current);
			setInterval(function(){ parent.postMessage('sitebarup', '*'); }, 500);
		} catch(err){
			document.getElementsByTagName('body')[0].appendChild(document.getElementById("vf_sitebar"));
			if (vf_eventlistener=='enabled') { 
				document.getElementById('vf_sitebarcontainer').appendChild(vf_sitebar_current);
				setInterval(function(){ document.postMessage('sitebarup', '*'); }, 500);
			}
		}
	} else {
		console.log('primary');
	}
	var vfsitebareventlistener='level1';

	if(window.parent!=top && window.top.location.hostname!='studio.adform.com') {
		try {
			window.parent.parent.document.getElementsByTagName('body')[0].appendChild(window.parent.document.getElementById("vf_sitebar"));
			vfsitebareventlistener='level2';
		} catch(err){

		}
	}


	if (typeof vf_sitebar_listener === 'undefined' || vf_sitebar_listener === null) {
		if (vf_eventlistener=='enabled') {
			window.top.addEventListener('message', function(e) {
				if (e.origin.indexOf(".appenzell.net")>0 || e.origin.indexOf(".sitebarad.com")>0) {
					if (e.data=='sitebarclose') {
						if (window.parent.document.getElementById("vf_sitebar")!=null) {
							console.log('sitebarclose');
							window.parent.document.getElementById("vf_sitebar").remove();				
						};
					} else if (e.data=='sitebarup') {

					} else {
						try {
							eval(e.data);
						} catch(err) {

						}
					}
				} else {

				}
			}, false);
		}
	}

  



window.sitebarhide = function () {
	console.log('sitebarclose');
	document.getElementById('vf_sitebar').parentNode.removeChild(document.getElementById('vf_sitebar'));
	console.log('hidetest');
}
