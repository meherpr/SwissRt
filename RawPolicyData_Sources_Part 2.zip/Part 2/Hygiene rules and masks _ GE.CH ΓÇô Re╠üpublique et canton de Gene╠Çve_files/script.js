/**
 * @file
 * A JavaScript file for the theme.
 *
 * In order for this JavaScript to be loaded on pages, see the instructions in
 * the README.txt next to this file.
 */

/* Fonction générique à tous les thèmes */
(function ($) {
    $(document).ready(function () {

        $('.content .col-md-8 a:has(img)').addClass('imgInto');
        $('.content .col-md-9 a:has(img)').addClass('imgInto');

        // // Vérifie la présence du cookie ETATRAD
        // if ($.cookie('ETATRAD')) {
        //     // have cookie
        //     $("#menu-toggle").addClass("active");
        //
        // } else {
        //     //no cookie
        //     $("#menu-toggle").removeClass("active");
        // }
    });
}(jQuery));
