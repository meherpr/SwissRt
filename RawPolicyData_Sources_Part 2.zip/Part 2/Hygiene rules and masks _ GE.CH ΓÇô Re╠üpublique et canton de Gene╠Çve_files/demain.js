/**
 * @file
 * A JavaScript file for the theme.
 *
 * In order for this JavaScript to be loaded on pages, see the instructions in
 * the README.txt next to this file.
 */

// JavaScript should be made compatible with libraries other than jQuery by
// wrapping it with an "anonymous closure". See:
// - https://drupal.org/node/1446420
// - http://www.adequatelygood.com/2010/3/JavaScript-Module-Pattern-In-Depth
(function ($, Drupal, window, document, undefined) {

    //LISTES
    Drupal.behaviors.Listes = {
        attach: function (context, settings) {
            $('body').ready(function () {
                $("ol").each(function () {
                    var val = 1;
                    if ($(this).attr("start")) {
                        val = $(this).attr("start");
                        val = val - 1;
                        val = 'list-body ' + val;
                        $(this).css('counter-increment', val);
                    }

                });
            });
        }
    };

    Drupal.behaviors.smoothScrollingEvent = {
        attach: function (context, settings) {
            $('.node-type-evenement a[href^="#"]').click(function () {
                $('html, body').animate({
                    scrollTop: $('[id="' + $.attr(this, 'href').substr(1) + '"]').offset().top - 30
                }, 500, 'swing');

                return false;
            });
        }
    };


    //RESPONSIVE TABLE
    Drupal.behaviors.Table = {
        attach: function (context, settings) {
            $('body').ready(function () {
                $('table').each(function () {
                    if ($(this).not('.datatables').find('thead').length) {
                        $(this).cardtable();
                    } else {
                        $(this).addClass('table-responsive');
                    }
                });
            });
        }
    };

    //cf CHARTEDRUPAL-323
    Drupal.behaviors.LinkImage = {
        attach: function (context, settings) {
            $('body').ready(function () {
                $("a img").each(function () {
                    $(this).parent().addClass('liens-images-externes');
                });
            });
        }
    };


    Drupal.behaviors.accordeon = {
        attach: function (context, settings) {
            $('body').ready(function () {
                $(".edg-cke-collapsible-item-title a").click(function (e) {
                    $(this).find('span').toggleClass('fa-plus-square-o');
                    $(this).find('span').toggleClass('fa-minus-square-o');
                });
            });
        }
    };

    Drupal.behaviors.cleanSubmit = {
        attach: function (context, settings) {
            $("form").not('#suggestion_form').submit(function () {
                $(this).find(":input").filter(function () {
                    return !this.value;
                }).attr("disabled", "disabled");
                return true;
            });
        }
    };

    //OWL CAROUSEL
    Drupal.behaviors.Carousel = {
        attach: function (context, settings) {

            var non_shuffled = (typeof Drupal.settings.carrousel !== "undefined") ? Drupal.settings.carrousel.non_shuffled_prestations_carrousel : 0;
            if( typeof non_shuffled !== 'undefined' ) {
                var carrousel = '.carousel-prestations';
                var carrousel_el = '.carousel-prestations .carousel-prestations-item';

                for (var i = $(carrousel_el).length; i > non_shuffled; i--) {
                    random = Math.floor(Math.random() * ($(carrousel_el).length - non_shuffled+ 1) + non_shuffled);

                    var item_tmp = $(carrousel_el+':eq('+ (i - 1 ) +')');

                    $(carrousel_el+':eq('+random+')').after(item_tmp);
                }
            }


            $('.field-type-image:not(.field-name-field-illustration) .field-items, .views-field-field-images .field-content ul').owlCarousel({
                loop: true,
                nav: true,
                navSpeed: 300,
                singleItem: true,
                items: 1
            });
            $('.field-type-edg-video .field-items').not('.field-name-field-p-video .field-items').owlCarousel({
                loop: true,
                nav: true,
                navSpeed: 300,
                singleItem: true,
                items: 1
            });

            $('.view-prestations-front .carousel-prestations').owlCarousel({
                loop: true,
                nav: true,
                navSpeed: 300,
                responsiveClass: true,
                responsive: {
                    0: {
                        items: 1,
                    },
                    600: {
                        items: 2,
                    },
                    1000: {
                        items: 4,
                    }
                }
            });

            $('.field-type-edg-video .field-items').each(function () {
                $this = $(this);
                $this.find('.owl-nav').click(function () {
                    $this.find('video').each(function () {
                        $(this).get(0).pause();
                    });
                });

                $this.find('video').click(function () {
                    if ($(this).get(0).paused) {
                        $this.find('.caption').show();
                    }
                    else {
                        $this.find('.caption').hide();
                    }
                });
            });
        }
    };

    Drupal.behaviors.changeHash = {
        attach: function (context, settings) {
            $(window).on('hashchange', function (e) {
                e.preventDefault();
                return false;
            });
        }
    };

    // REMARQUE SUR LES PRESTATIONS
    /*Drupal.behaviors.sidebar = {
     attach: function(context, settings) {
     $("#menu-toggle").click(function(e) {
     e.preventDefault();
     $("#wrapper").toggleClass("toggled");
     });
     $("#close_sidebar").click(function(e) {
     e.preventDefault();
     $("#wrapper").removeClass("toggled");
     });

     }
     }*/

    //IMAGE CAPTION
    /*
     Drupal.behaviors.caption = {
     attach: function(context, settings) {
     $('body').ready(function() {
     $(".owl-theme").hover(function() {
     $(this).find('figure').trigger('mouseover');
     }, function() {
     $(this).find('figure').trigger('mouseout');
     });
     });

     $('figure').hover(function(event) {
     $('figure figcaption').css({"opacity":"0.5", "bottom": "0"});
     event.stopPropagation();
     }, function(event) {
     $('figure figcaption').css({"opacity":"0", "bottom": "-25px"});
     event.stopPropagation();
     });
     }
     };
     */

    // REMARQUE SUR LES PRESTATIONS
    Drupal.behaviors.edgNotice = {
        attach: function (context, settings) {
            $(".pane-edg-2016-base-comment-pane .pane-title").click(function () {
                $(this).siblings().children('form').slideToggle(300);
            });
        }
    };

    //MENU
    Drupal.behaviors.Menu = {
        attach: function (context, settings) {
            if ($('body').hasClass('page-parcourir')) {
                var MenuItem = function (menu) {
                    var self = this;
                    self.menu = menu;
                    if (self.menu.attr("class") == 'active') {
                        activeMenu = self;
                    }
                    self.name = self.menu.attr("href").substring(1);
                    self.items = [];
                    self.submenu = level2.find(".menu-category" + self.menu.attr("href"));
                    self.submenu.find("li a").each(function () {
                        self.items.push(this);
                        if ($(this).attr("class") == 'active') {
                            activeSubMenu = $(this);
                        }
                    });

                    self.menu.click(function (e) {
                        e.preventDefault();
                        replaceActiveMenu(self, null);
                        if (history.pushState) {
                            history.pushState(null, null, "#" + self.name);
                        } else {
                            window.location.hash = "#" + self.name;
                        }
                        return false;
                    });
                    if (typeof self.items == "object") {
                        self.items.map(function (item) {
                            $(item).click(function (e) {
                                e.preventDefault();
                                replaceActiveSubMenu($(this));
                                var stateName = self.name + "-" + $(this).attr("href").substring(1);
                                if (history.pushState) {
                                    history.pushState(null, null, "#" + stateName);
                                } else {
                                    window.location.hash = "#" + stateName;
                                }
                                return false;
                            });
                        });
                    }
                };
            }

            var MenuStorage = [];

            var activeMenu = null;
            var activeSubMenu = null;

            function replaceActiveSubMenu(submenu) {
                if (activeSubMenu !== null) {
                    activeSubMenu.removeClass("active");
                    level3.find(".menu-category" + activeSubMenu.attr("href")).removeClass("active");
                }
                if (submenu !== null) {
                    submenu.addClass("active");
                    level3.find(".menu-category" + submenu.attr("href")).addClass("active");
                    setBrowseStep("browse-step-2");
                    $("#browse-back").html(submenu.find("h3").html());
                }
                activeSubMenu = submenu;
                setTimeout(function () {
                    window.scrollTo(0, 0);
                }, 50);
            }

            function replaceActiveMenu(menu, submenu) {
                if (activeMenu !== null) {
                    activeMenu.menu.removeClass("active");
                    activeMenu.submenu.removeClass("active");
                }
                if (menu !== null) {
                    menu.menu.addClass("active");
                    menu.submenu.addClass("active");
                    setBrowseStep("browse-step-1");
                    $("#browse-back").html(menu.menu.html());
                }
                else {
                    setBrowseStep(null);
                }
                activeMenu = menu;
                replaceActiveSubMenu(submenu);
            }

            function initHash(hash) {
                if (hash.length > 1) {
                    var names = hash.split("-");
                    MenuStorage.map(function (item) {
                        if (item.name == names[0]) {
                            submenu = null;
                            if (typeof names[1] !== "undefined") {
                                submenu = $('a[href="#' + names[1] + '"]');
                            }
                            replaceActiveMenu(item, submenu);
                        }
                    });
                    $('html, body').animate({scrollTop: 0}, 0);
                }
                else {
                    replaceActiveMenu(null, null);
                }
            }

            function setBrowseStep(step) {
                $('.browse-page').removeClass('browse-step-1');
                $('.browse-page').removeClass('browse-step-2');
                $('.browse-level').removeClass('active');
                if (step !== null) {
                    $('.browse-page').addClass(step);
                    $('.browse-page').removeClass('browse-level-1');

                    if (step == 'browse-step-1') {
                        level2.addClass('active');
                    }
                    if (step == 'browse-step-2') {
                        level3.addClass('active');
                    }
                }
                else {
                    level1.addClass('active');
                    $('.browse-page').addClass('browse-level-1');
                }
            }

            var level1 = $(".browse-page .browse-level-1");
            var level2 = $(".browse-page .browse-level-2");
            var level3 = $(".browse-page .browse-level-3");

            level1.find("li a").each(function () {
                MenuStorage.push(new MenuItem($(this)));
            });

            initHash(History.getHash());

            $("#browse-back").click(function (e) {
                if (activeSubMenu !== null) {
                    replaceActiveMenu(activeMenu, null);
                    var stateName = activeMenu.name;
                }
                else {
                    replaceActiveMenu(null, null);
                    var stateName = '';
                }
                e.preventDefault();
                if (history.pushState) {
                    history.pushState(null, null, "#" + stateName);
                }
                else {
                    window.location.hash = "#" + stateName;
                }
                //$('html, body').animate({ scrollTop: 0 }, 0);
                return false;
            });
        }
    };

    // CHARTEDRUPAL-417 goto top feuillet en affichage mobile

    function findBootstrapEnvironment() {
        var envs = ['xs', 'sm', 'md', 'lg'];

        var $el = $('<div>');
        $el.appendTo($('body'));

        for (var i = envs.length - 1; i >= 0; i--) {
            var env = envs[i];

            $el.addClass('hidden-' + env);
            if ($el.is(':hidden')) {
                $el.remove();
                return env;
            }
        }
    }

    Drupal.behaviors.edgTopFeuillet = {
        attach: function (context, settings) {
            $(document).ready(function () {
                var env = findBootstrapEnvironment();
                if (env == 'xs' || env == 'sm') {
                    // uniquement en mobile / tablette ...
                    /* v1 sur $(window).load
                     var position = $("#top-feuillet").offset().top;
                     window.scrollTo(0, position - 30 );
                     */
                    if ($("#top-feuillet").offset()) { //
                        $('html, body').animate({
                            scrollTop: $("#top-feuillet").offset().top - 100
                        }, 500);
                    }
                }
            });
        }
    };

    // Fin CHARTEDRUPAL-417

    /* CHARTEDRUPAL-351
     * Supprime les tooltips restants affiché après rechargement ajax lors du filtre de publications
     */
    Drupal.behaviors.tooltipReset = {
        attach: function (context, settings) {
            $('#views-exposed-form-publication-publications').ready(function () {
                $(".tooltip").remove();
            });
        }
    };


    // CHARTEDRUPAL-359 : Modifie le comportement du Bouton Effacer car bug avec Ajax
    // cf https://www.drupal.org/node/1109980#comment-11500041
    Drupal.behaviors.actionBoutonEffacer = {
        attach: function (context, settings) {
            $('#views-exposed-form-publication-publications,#views-exposed-form-evenement-liste-evenement-liste-pane,#views-exposed-form-liste-bpv-panel-offres-emploi').ready(function () {
                $(document).delegate('#edit-reset', 'click', function (event) {
                    event.preventDefault();
                    $('form').each(function () {
                        $('form select option').removeAttr('selected');
                        $('form input').attr('value', '');
                        this.reset();
                    });
                    $('#edit-submit-publication,#edit-submit-evenement-liste,#edit-submit-liste-bpv').click();
                    return false;
                });
            });
        }
    };

    Drupal.behaviors.ajaxRefreshNumberOfElements = {
        attach: function (context, settings) {
            $(document).ajaxStop(function() {
                var size = $( ".view-display-id-liste_dossiers .views-row, .view-display-id-liste_blogs .views-row" ).size();
                $(".liste-dossiers-count .total, .liste-blogs-count .total").html(size);

                if (size > 1) {
                    $(".liste-dossiers-count, .liste-blogs-count").show();
                }
                else {
                    $(".liste-dossiers-count, .liste-blogs-count").hide();
                }
            });
        }
    };

    Drupal.behaviors.ajaxScrollToViewsFilter = {
        attach: function (context, settings) {
            $(document).ready(function() {
                //console.log($('#edit-titre , #edit-name').val());
                if ($('.view-id-liste_termes #edit-titre, .view-id-liste_termes #edit-name').val()) {
                    $('html, body').animate({
                        scrollTop: $(".liste-dossiers-count, .liste-blogs-count").offset().top - 50
                    }, 500);
                }
            });
        }
    };

    // CHARTEDRUPAL-509 : Se positionne sur l'ancre si présente dans l'url 
    Drupal.behaviors.ancres = {
        attach: function (context, settings) {
            $(document).ready(function () {
                var anchor_id = window.location.hash;
                if (anchor_id != "" && $(anchor_id).length > 0) {
                    // DOM fonction pour scroller vers l'element
                    $(anchor_id)[0].scrollIntoView(true);
                }
            });
        }
    };

    if (Drupal.jsAC != undefined) {
        Drupal.jsAC.prototype.select = function (node) {
            this.input.value = $(node).data('autocompleteValue');
            if (jQuery(this.input).hasClass('auto_submit')) {
                this.input.form.submit();
            }
        };
    }

    //CHARTEDRUPAL-601 Affiche les sous options du select en décalé au lieu d'un ou plusieurs '-'
    $.fn.changeOptionSelectTaxonomy = function () {
        $(this).children("option").each(function (index, op) {
            if ($(this).val() != 'All') {
                var regExp = /^(-+)(.*)/;
                var matches = regExp.exec($(this).text());
                if (matches) {
                    var nbDash = matches[1].length;
                    $(this).addClass('niv-' + nbDash);
                    var indent = '';
                    for (i = 0; i < nbDash; i++) {
                        indent += '\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0';
                    }
                    $(this).text(indent + matches[2]);
                }
                else {
                    $(this).addClass('niv-0');
                }

            }
        });
    };
    Drupal.behaviors.refactorOptionsOutput = {
        attach: function (context, settings) {
            $(document).ready(function () {
                $('.view-id-publication #edit-type').changeOptionSelectTaxonomy();
                $('.view-id-publication #edit-organisation').changeOptionSelectTaxonomy();
                $('.view-id-publication #edit-departement').changeOptionSelectTaxonomy();
            });
        }
    };

    Drupal.behaviors.edgCkeCollapseExpandAll = {
        attach: function (context, settings) {
            $(document).ready(function () {

                var view = $('.view-display-id-liste_organisations_depth');
                if (view.length == 0) {
                    return true;
                }

                //Add/Remove classes to parents elements
                $('.collapse').on('show.bs.collapse', function(event) {
                    if ($(this).is(event.target)) {
                        var li = $(this).closest('li');
                        li.addClass('expanded');
                        li.next('li').addClass('next-expanded');
                    }
                }).on('hide.bs.collapse', function(event) {
                    if ($(this).is(event.target)) {
                        var li = $(this).closest('li');
                        li.removeClass('expanded');
                        li.next('li').removeClass('next-expanded');
                    }
                });

                //Expand or collapse all elements
                var element = $('.edg-cke-collapse-expand-all');
                if (element.length === 0) {
                    return true;
                }
                element.find('a').click(function (e) {
                    e.preventDefault();
                    var action = $(this).data('collapse-action');
                    $("[data-toggle=collapse]").each(function () {
                        var collapsor = $(this);
                        if (collapsor.prop('tagName') !== 'A') {
                            return true;
                        }
                        var collapsible = $(collapsor.data('collapsing'));
                        if (collapsible.length == 1) {
                            if ((action == 'open' && collapsible.attr('aria-expanded') == 'false')
                                || (action == 'close' && collapsible.attr('aria-expanded') == 'true')) {
                                collapsor.click();
                            }
                        }
                    });
                })
            });
        }
    };

    Drupal.behaviors.nodeEvenement = {
        attach: function (context, settings) {
            var event_infos = 'event_infos';
            var event_infos_copy = 'event_infos_copy';
            var destination_copy = '.field-name-field-illustration:first';
            var node_type_evenement_class = 'node-type-evenement'

            $(document).ready(function () {
                if ($('body').hasClass(node_type_evenement_class)) {
                    var $el_copy_event_infos = $('#' + event_infos).clone().attr('id', event_infos_copy);
                    $(destination_copy).before($el_copy_event_infos);
                    resizeEvenement();
                    $(window).resize(function () {
                        resizeEvenement();
                    });
                }
            });

            function resizeEvenement() {
                var env = getTypeDeviceUsingBootstrap();

                var smallDevice = $.inArray(env, ['xs', 'sm']);

                if (smallDevice == -1) {
                    $('#' + event_infos).show();
                    $('#' + event_infos_copy).hide();
                } else {
                    $('#' + event_infos).hide();
                    $('#' + event_infos_copy).show();
                }
            }

            function getTypeDeviceUsingBootstrap() {
                var envs = ['xs', 'sm', 'md', 'lg'];
                var $el = $('<div>');
                $el.appendTo($('body'));
                for (var i = envs.length - 1; i >= 0; i--) {
                    var env = envs[i];
                    $el.addClass('hidden-' + env);
                    if ($el.is(':hidden')) {
                        $el.remove();
                        return env;
                    }
                }
            }
        }
    };

    Drupal.behaviors.whoAmI = {
        attach: function (context, settings) {
            $('body').ready(function () {
                function getCookie(name) {
                    var value = "; " + document.cookie;
                    var parts = value.split("; " + name + "=");
                    if (parts.length == 2) return parts.pop().split(";").shift();
                }

                function whoAmIShow() {
                    if (getCookie('whoami') == 1 || getCookie('whoami') === 'true') {
                        $("#whoami").addClass('active');
                        $("#popover-content-whoami .logged").show();
                        $("#popover-content-whoami .signin").hide();
                        $("#popover-content-whoami .email").show();
                        $("#popover-content-whoami .nom").show();
                        $("#popover-content-whoami .email").html(sessionStorage.getItem('mail'));
                        $("#popover-content-whoami .nom").html(sessionStorage.getItem('fullname'));
                    } else {
                        $("#popover-content-whoami .logged").hide();
                        $("#popover-content-whoami .signin").show();
                        $("#popover-content-whoami .email").hide();
                        $("#popover-content-whoami .nom").hide();
                        $("#whoami").removeClass('active');
                        sessionStorage.removeItem('mail');
                        sessionStorage.removeItem('fullname');
                    }
                }

                if (settings.whoAmI.active == 1) {

                    whoAmIShow();

                    $("#whoami").on("click", function(){
                        $('#whoami').popover('toggle');
                    });

                    $('#whoami').popover({
                        placement:"bottom",
                        html: true,
                        content: function () {
                            return $("#popover-content-whoami").html();
                        },
                    });

                    if(typeof getCookie('whoami') === 'undefined') {
                        var date = new Date();
                        var cache_cookie = parseInt(settings.whoAmI.cache);
                        date.setTime(date.getTime()+(cache_cookie*1000));
                        var expires = "; expires="+date.toGMTString();
                        $.ajax({
                            type: 'GET',
                            url: settings.whoAmI.whoami,
                            xhrFields: {
                                withCredentials: true
                            },
                            setCookies: document.cookie,
                            crossDomain: true,
                            dataType: 'json',
                            /*beforeSend: function(jqXHR) {
                                jqXHR.overrideMimeType('text/html;charset=iso-8859-1');
                            },*/
                            success: function (data) {
                                if (settings.whoAmI.log == 1) {
                                    console.log(data);
                                }
                                if (data['code'] == '200') {
                                    document.cookie = "whoami=" + data['properties']['isLogged'] +expires+"; path=/";
                                    sessionStorage.setItem('mail', data['properties']['mail']);
                                    sessionStorage.setItem('fullname', data['properties']['fullname']);
                                }
                                whoAmIShow();
                            },
                            timeout: 2000,
                        }).fail(function (jqXHR, textStatus, error) {
                            if (settings.whoAmI.log == 1) {
                                console.log(data);
                            }
                            document.cookie = "whoami=0;" +expires+"; path=/";
                            whoAmIShow();
                        });
                    }
                    else {
                        whoAmIShow();
                    }
                }
            });
        }
    };

})(jQuery, Drupal, this, this.document);
