/**
 * Created by MOUTAWEF on 21.10.2015.
 */
(function ($, Drupal, window) {
    Drupal.behaviors.socialurl = {
        attach: function (context, settings) {
            var shared_ids = Drupal.settings.socialurl.shared_ids || [];

            for (var i in shared_ids) {
                $('#' + shared_ids[i]).click(function (e) {
                    var h = $(this).attr("data-popup-height"),
                        w = $(this).data("popup-width");

                    if (h && w) {
                        e.preventDefault();

                        window.open(
                            $(this).attr("href"),
                            "share",
                            "top=" + ((screen.height - h) / 2) + ",left=" + ((screen.width - w) / 2) + ",width=" + w + ",height=" + h
                        );
                    }
                });
            }
        }
    };
})(jQuery, Drupal, window);