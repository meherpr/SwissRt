(function ($) {

  /** ********************************************************************
   * INIT
   ** ***************************************************************** */
  Drupal.edg_mail = Drupal.edg_mail || {};

  Drupal.behaviors.edg_mail = {
    attach: function(context, settings) {
      $('.page-node-edit #edit-edg-mail-send').click(function() {
        if ($(this).is(":checked")) {
          $('#edit-submit').val('Enregistrer et notifier');
          Drupal.edg_mail.selectAddressbook();
          $('#edg-mail-addressbooks-wrapper').show();
        }
        else {
          $('#edit-submit').val('Enregistrer');
          $('#edg-mail-addressbooks-wrapper').hide();
        }
      });

      $('.edg-mail-nl-subscription button[id^=edit-subscribe]').click(function(e) {
        e.preventDefault();

        $.ajax({
          url: '/callback/edg/mail/subscription',
          type: 'get',
          dataType: 'json',
          data: { email: $('#edit-email').val(), name: $('#nl-name').val(), tid: $('#nl-tid').val() },
          async: false,
          success: function(data) {
            $('#edg-mail-subscribe-message').removeClass().addClass(data.class).html(data.message);
            $('#edg-mail-subscription div:first-child').children().not($('#edg-mail-subscribe-message')).hide();
          }
        });

        return false;
      });

      $('.form-on-click').hide();
      $('.show-form-on-click').click(function() {
        $(this).siblings('.form-on-click').toggle();
        return false;
      });

      $('#edit-field-blog-erac-und').bind("change", function() {
        Drupal.edg_mail.selectAddressbook();
      });

      Drupal.edg_mail.confirmNotification();
      Drupal.edg_mail.confirmCancellation();

    }
  }; // Drupal.behaviors.edg_mail

  Drupal.edg_mail.selectAddressbook = function() {
    if ($('#edit-edg-mail-addressbooks').size()) {
      var value = $('#edit-field-blog-erac-und option:selected').text(),
        valueLowerCase = value.toLowerCase(),
        valid = false;
      $('#edit-edg-mail-addressbooks .form-item label').each(function() {
        if ($(this).text().trim().toLowerCase() === valueLowerCase) {
          $('#edit-edg-mail-addressbooks input.form-checkbox').prop('checked', false);
          $('#' + $(this).attr('for')).prop('checked', true);
          return false;
        }
      });
    }
  }; // Drupal.edg_mail.selectAddressbook

  Drupal.edg_mail.confirmNotification = function() {
    var confirmed = false;
    if ($('#edg-mail-node-notify').size()) {
      $('#edg-mail-node-notify #edit-submit').click(function(e) {
        if(confirmed === true){
          return true;
        }
        e.preventDefault();
        $( "<div>" ).attr('title', Drupal.t("Confirmation")).html(Drupal.t("Êtes-vous sûr de vouloir notifier ces carnets d'adresses ?")).dialog({
          resizable: false,
          height: "auto",
          width: 400,
          modal: true,
          buttons: {
            "Confirmer la notification": function() {
              $( this ).dialog( "close" );
              confirmed = true;
              $('#edit-submit[name="send_notify"]').click();
            },
            "Annuler": function() {
              $( this ).dialog( "close" );
            }
          }
        });
      });
    }
  }; // Drupal.edg_mail.confirmNotification

  Drupal.edg_mail.confirmCancellation = function() {
    if ($('#edg-mail-node-notify').size()) {
      $('#edg-mail-node-notify .confirm-cancellation').click(function(e) {
        var $link = $(this).attr('href');
        e.preventDefault();
        $( "<div>" ).attr('title', Drupal.t("Confirmation")).html(Drupal.t("Êtes-vous sûr de vouloir annuler l'envoi ?")).dialog({
          resizable: false,
          height: "auto",
          width: 400,
          modal: true,
          buttons: {
            "Confirmer l'annulation": function() {
              $( this ).dialog( "close" );
              window.location.href = $link;
            },
            "Annuler": function() {
              $( this ).dialog( "close" );
              return false;
            }
          }
        });
      });
    }
  }; // Drupal.edg_mail.confirmCancelation

// END jQuery
})(jQuery);