var is_chrome = navigator.userAgent.indexOf('Chrome') > -1;
var is_explorer = navigator.userAgent.indexOf('MSIE') > -1 || navigator.userAgent.indexOf('Trident') > -1;
var is_firefox = navigator.userAgent.indexOf('Firefox') > -1;
var is_safari = navigator.userAgent.indexOf("Safari") > -1;
var is_opera = navigator.userAgent.toLowerCase().indexOf("op") > -1;
if ((is_chrome) && (is_safari)) { is_safari = false; }
if ((is_chrome) && (is_opera)) { is_chrome = false; }

jQuery(document).ready(function () {
    $('.nodesktop').remove();


    if (is_safari) $('body').addClass('safari');

    initNav();
    IEPlaceholderFix();
    initBootstrapLightbox();
    initFooter();
    initOpenerOrganigramma();
    ApriChiudi();
    initWfqbe();
    initPageSearch();
    initIrfaq();
    initListTransformation();
    initVivereInTicino();
    // initHeadingLinks();
    initSaiperche();
    initClearField();
    initCarouselLinks();
   // initTichSlider();
    if($('body:not(.agenda-culturale)').length == 1) initTichSlider();

    if($('#contact-form').length) initModuloContattatoPage();
    else initModuloContattato();

    if ($('.scuola-parallax').length) initParallaxPage();
    else if ($('#ricercaFilm').length) initInfoGiovani();
    else if (document.getElementById('mappa-traffico')) initMap();
    else if (document.getElementById('mappa-radar')) initMap2();
    else if (document.getElementById('dt-mappa-ticino')) initDTMappaTicino();
    else if (document.getElementById('aste')) initAste();
    else if ($('.map').length && $('map').length) initMap3();
    else if ($('body.gc-home').length) initGCHome();
    else if (document.getElementById('ticino2020')) initTicino2020();
    else if (document.getElementById('pca')) initPCA();
    else if ($('.user-cpa-pi1').length) initCPA();
    else if ($('.cpa_page').length) initCPANew();
    else if (document.getElementById('ricercaSalaStampa')) initSelectSalaStampa();
    else if (document.getElementById('ODG')) initODG();
    else if (document.getElementById('dfe-inner-form')) initDFEInnerForm();
    else if ($('.home-menu').length) {
        initHomeMenu();
        initTematicaBox();
        initGC();
        //initSondaggio();
    }
    else if ($('body.pagina-depressione').length) initDepressione();
    else if ($('.sviluppo-economico').length) initSviluppoEconomico();
    else if ($('#uefmap').length) initUEFMap();
    else if ($('#dispop').length) initSPOPMap();
    else if (document.getElementById('di_svg_schema')) initDISVGSchema();// Schema della procedura - DI
    else if ($('#pinacoteca').length) initPinacoteca();
    else if ($('#RtiD').length) initLegislazione();
    else if ($('#altrePubb').length) initLegislazione();
    else if ($('#deputatiHome').length) initDTCF();
    else if ($('#listaArticoli').length) initDTCF();
    else if(document.getElementById('antibiotici_quiz')) initAntibioticiQuiz();
    else if ($('#tich_pubblicazioni').length) initTichPubblicazioni();
    else if ($('.boxWebcams').length) initWebcamPage();
    else if(document.getElementById('formulario_use')) initFormularioUSE();
    else if(document.getElementById('formulario_use2')) initFormularioUSE2();
    else if(document.getElementById('formulario_use_uac')) initFormularioUSEUAC();
    else if(document.getElementById('formulario_uosp_workshop')) initFormularioUOSPWorkshop();
    else if(document.getElementById('contatore_uosp_workshop')) initContatoreUOSPWorkshop();
    else if(document.getElementById('formulario_ias')) initFormularioIAS();
    else if(document.getElementById('formulario_ias2')) initFormularioIAS2();
	else if(document.getElementById('formulario_ias_adeguamento_1')) initFormularioIASAdeguamento1();
    else if(document.getElementById('formulario_ias_adeguamento_2')) initFormularioIASAdeguamento2();
    else if(document.getElementById('formulario_ias_adeguamento_3')) initFormularioIASAdeguamento3();
    else if($('.ias-parallax').length) initIAS();
    else if($('.rassegna-stampa').length) initRassegnaStampa();
    else if ($('.impiantiSportivi-parallax').length) initImpiantiSportivi();
    else if($('.tx-tich-areamedia').length || $('.tx-tich-attualita').length) initAreaMedia();
    else if(document.getElementById('formulario_tlet')) initFormularioTLET();
    else if(document.getElementById('formulario_sel')) initFormularioSEL();
    else if($('.schedario_utpg').length) initSchedarioUTPG();
    else if($('.agenda-culturale').length) initAgendaCulturale();
    else if($('.laboratorio-cantonale').length) initLaboratorioCantonale();
    else if($('.portaleComuni').length) initComuni();
    else if($('.tx-tich-dssfrancointasca').length) initFrancoInTasca();

    if(document.getElementById('canicola_map')) initCanicolaMap();

    if($('.video_lightbox').length) initVideoLightboxes();

    if(document.getElementById('assegni_parentali'))
    {
        initIASAssegniParentali();
    }

    //if(location.href == 'https://www4.ti.ch/dss/dsp/covid19/home/') initSondaggio();

    if (typeof tiporicerca !== 'undefined' && tiporicerca != '') {
        initRicerca();
    }

    // Fix menu sinistra
    $('.noitem span:contains(\'Menu\')').each(function () {
        $(this).parent().addClass('no-text');
    });
    $('.noitem:contains(\'Menu\')').each(function () {
        $(this).text('').css('padding', '0').css('border-bottom', '0');
    });

    // Fix user contatti address
    $('#contenitore .col-xs-4 .user-contatti-pi1 address > p').filter(function () { return $.trim(this.innerHTML) == "" }).remove();
    $('#contenitore .col-xs-6 .user-contatti-pi1 address > p').filter(function () { return $.trim(this.innerHTML) == "" }).remove();

    // Fix
    jQuery(document.body).on('click', '.dropdown-menu li', function (event) {
        var jQuerytarget = jQuery(event.currentTarget);

        jQuerytarget.closest('.btn-group')
            .find('[data-bind="label"]').text(jQuerytarget.text())
            .end()
            .children('.dropdown-toggle').dropdown('toggle');
        return false;
    });

    // Timeline
    if ($('.timeline-container2').length) initSpecialTimeline();

    // Popover
    if ($('[data-toggle="popover"]').length) $('[data-toggle="popover"]').popover();

    // Torna in cima
    initBackToTop();

    // Se la pagina ha il cambio lingua, lo script mette in bold la lingua attuale

    // Read more
    if ($('.readmore').length) {
        $('.readmore').readmore({
            speed: 75,
            moreLink: '<a href="#">...<i class="fa fa-angle-down"></i></a>',
            lessLink: '<a href="#"><i class="fa fa-angle-up"></i></a>'
        });
    }

    // Datepicker
    if ($('.datepicker').length) initDatepicker();

    // Selectpicker
    if ($('select:not(.default)').length){
        jQuery('select:not(.default)').selectpicker({
            'selectedText': 'cat',
            noneSelectedText: 'Selezionare',
            noneResultsText: 'Nessun risultato',
            countSelectedText: '{0} di {1} selezionato'
        });

        // GC parlamento
        if($('.user-gcparlamento-pi9').length){
            $('button.selectpicker').attr('aria-describedby', 'testo-nascosto').after('<span id="testo-nascosto" class="hidden">Selezionare anno. Attenzione, la ricerca inizia quando un valore è selezionato</span>');

            $('button.selectpicker').attr('aria-expanded', false)
            $('html').click(function (e){
                setTimeout(function (){
                    $('button.selectpicker').attr('aria-expanded', $('button.selectpicker').parent().hasClass('open'));
                }, 50);
            }).keyup(function (e){
                setTimeout(function (){
                    $('button.selectpicker').attr('aria-expanded', $('button.selectpicker').parent().hasClass('open'));
                }, 50);
            });
        }
    }

    setTimeout(function (){
        $('.bootstrap-select').show();
    },1);

    //Lightbox for Bootstrap
    $(document).on('click', '[data-toggle="lightbox"]', function (event) {
        event.preventDefault();
        $(this).ekkoLightbox({
            alwaysShowClose: true
        });
    });


    $('#skiplink1, #skiplink2').focus(function (){
        $('body').css('padding-top', '38px');
    }).blur(function (){
        $('body').css('padding-top', '0');
    });


    // Bootstrap collapse fix
    $('.panel-group').on('hidden.bs.collapse', function (e) {
        $(this).find('[data-toggle=collapse]').attr('aria-expanded', 'false');
    }).on('shown.bs.collapse', function (e) {
        $(this).find('[data-toggle=collapse]').attr('aria-expanded', 'true');
    });


    if($('.foldable-list').length){
        $('.fold').click(function (e){
            e.preventDefault();
            if($(this).next().hasClass('hidden')) $(this).children('i').removeClass('fa-plus-circle').addClass('fa-minus-circle');
            else $(this).children('i').removeClass('fa-minus-circle').addClass('fa-plus-circle');
            $(this).next().toggleClass('hidden');
        });
    }

    if(typeof gmaps != 'undefined' && gmaps.length) showGMaps()
});

function initFormularioUSE(){
    var uploadFile = {};
    var url = '/fileadmin/DFE/DE-USE/formulario/';
    function init(){
        $('#legge').change(changeFields);
        $('#formulario_use button').click(send);
        initMultiUpload();
    }
    function changeFields(){
        var v = $(this).val();

        $('.variante').addClass('hidden')
        if(v == 'a' || v == 'b'){
            $('#variante_'+v).removeClass('hidden');
            $('#legge').siblings('.error-messages').addClass('hidden');
        }
    }
    function send(e){
        e.preventDefault();

        var error = false;

        if($('#ragione_sociale').val() == ''){
            $('#ragione_sociale').siblings('.error-messages').removeClass('hidden');
            error = true;
        }
        else $('#ragione_sociale').siblings('.error-messages').addClass('hidden');

        if($('#numero_idi').val() == ''){
            $('#numero_idi').siblings('.error-messages').removeClass('hidden');
            error = true;
        }
        else $('#numero_idi').siblings('.error-messages').addClass('hidden');

        if($('#numero_iva').val() == ''){
            $('#numero_iva').siblings('.error-messages').removeClass('hidden');
            error = true;
        }
        else $('#numero_iva').siblings('.error-messages').addClass('hidden');

        if($('#numero_noga').val() == ''){
            $('#numero_noga').siblings('.error-messages').removeClass('hidden');
            error = true;
        }
        else $('#numero_noga').siblings('.error-messages').addClass('hidden');

        if($('#legge').val() == ''){
            $('#legge').siblings('.error-messages').removeClass('hidden');
            error = true;
        }
        else $('#legge').siblings('.error-messages').addClass('hidden');


        if($('#legge').val() == 'a'){

            if($('[name=misura_richiesta]:checked').length == 0){
                $('[name=misura_richiesta]:first').parent().parent().siblings('.error-messages').removeClass('hidden');
                error = true;
            }
            else $('[name=misura_richiesta]:first').parent().parent().siblings('.error-messages').addClass('hidden');
        }
        else if($('#legge').val() == 'b'){

            if($('[name=misura_richiesta2]:checked').length == 0){
                $('[name=misura_richiesta2]:first').parent().parent().siblings('.error-messages').removeClass('hidden');
                error = true;
            }
            else $('[name=misura_richiesta2]:first').parent().parent().siblings('.error-messages').addClass('hidden');


            if($('[name=otr]:checked').length == 0){
                $('[name=otr]:first').parent().parent().siblings('.error-messages').removeClass('hidden');
                error = true;
            }
            else $('[name=otr]:first').parent().parent().siblings('.error-messages').addClass('hidden');
        }

        if(!error){
            var data = {
                ragione_sociale: $('#ragione_sociale').val(),
                numero_idi: $('#numero_idi').val(),
                numero_iva: $('#numero_iva').val(),
                numero_noga: $('#numero_noga').val(),
                dimensione: $('#dimensione').val(),
                progetto: $('#progetto').val(),
                comune: $('#comune').val(),
                legge: $('#legge').val()
            };

            if(data.legge == 'a'){
                data.data_richiesta = $('#data_richiesta').val();
                data.numero_etp = $('#numero_etp').val();
                data.assoggettamento_lavoro = $('#assoggettamento_lavoro').val();
                data.stato_richiesta = $('#stato_richiesta').val();
                data.misura_richiesta = $('[name=misura_richiesta]:checked').val();

                if($('.allegati .allegato:not(.hidden)').length){
                    data.files = [];
                    $('.allegati .allegato:not(.hidden) input').each(function (){
                        data.files.push($(this).attr('data-file'))
                    });
                }
            }
            else{
                data.otr = $('[name=otr]:checked').val();
                data.misura_richiesta = $('[name=misura_richiesta2]:checked').val();
            }

            $.post(url+'save.php', data, function (r){
                // console.log(r)
            });
        }
    }
    function initMultiUpload(){
        var attachments_n = 1;
        var max_weight = 10;
        var used_weight = 0;
        var working = false;
        var uploadButtonContent = '';
        function init(){
            uploadButtonContent = $('#formulario_use .allegati .add').html();

            $('#formulario_use').on('click', '.allegati .add', addAttachemnt);
            $('#formulario_use').on('click', '.allegati .remove', clearAttachemnt);

            $('#formulario_use').on('change', '.inputfile', change);
        }
        function addAttachemnt(e){
            e.preventDefault();

            if(!working){
                $(this).siblings('.allegato.hidden.new').remove();

                if($('#attachments-error').length) $('#attachments-error').remove();

                $(this).prev().before($(this).siblings('.allegato.hidden').clone().addClass('new'));
                $('#formulario_use .allegato.new label').attr('for', 'file'+attachments_n);
                $('#formulario_use .allegato.new input').attr('id', 'file'+attachments_n).attr('name', 'file'+attachments_n);

                $('#formulario_use .allegato.new input:last').trigger('click');

                attachments_n++;
            }
        }
        function clearAttachemnt(e){
            e.preventDefault();

            var id = $(this).parents('.allegato').find('input[type=file]').attr('id');
            uploadFile[id] = false;

            var p = $(this).parents('.allegato');
            used_weight -= parseInt(p.find('input').attr('data-weight'));
            // updateWeights();

            p.find('input[type=file]').val('');
            p.find('input[type=file]').next().children('span').text('Allega un file');
            p.remove();
        }
        function change(event){
            var id = $(this).attr('id');

            tmp = $(this).val().split("\\");
            var v = tmp[tmp.length - 1];

            if(v){
                tmp2 = v.split('.');
                var ext = tmp2[(tmp2.length - 1)];

                if(ext == 'exe' || ext == 'bat' || ext == 'com'){
                    if($('#attachments-error').length) $('#attachments-error').remove();
                    $('.allegato.hidden:not(.new)').after('<div id="attachments-error"><p style="color:#c33;position: relative; top: -10px;">Formato non consentito.</p></div>');

                    $('label[for='+id+'] span').text('Allega un file (10Mb massimo)');
                }
                else{
                    $('label[for='+id+'] span').text(v);

                    if($('#attachments-error').length) $('#attachments-error').remove();


                    uploadFile[id] = event.target.files;

                    upload(id, event.target.files);
                }
            }
        }
        function upload(x, value){
            var data = new FormData();

            // if(value.length > 1){
            //     var upd = {};
            //     n = 1;
            //     console.log(value[0]);
            //     for(y in value){
            //         upd[n] = value[y];
            //         n++;
            //     }
            // }
            // else{
                var upd = {
                    x: value
                };
            // }

            // console.log(upd);
            // console.log(value)
            // console.log(x)

            $('body').append('<div id="sending-form" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; z-index: 10002;"></div>');
            $('#formulario_use .allegati .add').html('<i class="fa fa-spinner fa-spin"></i>');
            working = true;

            for(x in upd){
                if(upd[x]){
                    n = 1;
                    $.each(upd[x], function(key, value){
                        data.append('file'+n, value);
                        n++;
                    });
                }
            }


            $.ajax({
                // url: url+'upload.php?max='+(max_weight - used_weight), // point to server-side PHP script
                url: url+'upload.php', // point to server-side PHP script
                dataType: 'text',  // what to expect back from the PHP script, if anything
                cache: false,
                contentType: false,
                processData: false,
                data: data,
                type: 'post',
                success: function(php_script_response){

                    if(php_script_response == 'filesize'){
                        if($('#attachments-error').length) $('#attachments-error').remove();
                        $('.allegato.hidden:not(.new)').after('<div id="attachments-error"><ul style="color:#c33;position: relative; top: -10px;"><ul>L\'allegato supera il limite consentito di 10MB.</li></ul></div>');
                    }
                    else if(php_script_response == 'error'){
                        if($('#attachments-error').length) $('#attachments-error').remove();
                        $('.allegato.hidden:not(.new)').after('<div id="attachments-error"><ul style="color:#c33;position: relative; top: -10px;"><ul>Errore durante il caricamento degli allegati.</li></ul></div>');
                    }
                    else{
                        if(php_script_response.indexOf(';') > -1){
                            var tmp = php_script_response.split(';');
                        }
                        else var tmp = [php_script_response];
                        // var tmp = php_script_response.split('|');
                        // used_weight += parseInt(tmp[1]);

                        $('.allegato.new.hidden input').attr('data-file', php_script_response);
                        // $('.allegato.new.hidden input').attr('data-weight', tmp[1]);

                        // updateWeights()
                        $('.allegato.new.hidden').removeClass('new hidden');
                    }

                    $('#formulario_use .allegati .add').html(uploadButtonContent);
                    $('#sending-form').remove();
                    // $('.allegati .add').removeClass('disabled');
                    working = false;
                }
            });
        }
        function updateWeights(){
            if(contactData.lang == 'en') $('.allegati h4').html('Attachments '+(used_weight)+' MB(maximum size allowed 10 MB)');
            else $('.allegati h4').html('Allegati '+(used_weight)+' MB(dimensione massima consentita 10 MB)');

            if(used_weight == max_weight) $('.allegati .add').hide();
            else $('.allegati .add').show();
        }
        init();
    }
    init();
}
function initVideoLightboxes(){
    // <link rel="stylesheet" type="text/css" href="typo3conf/ext/tich_wowza/css/StyleSheet.css" media="screen" />
    $('head').append('<script type="text/javascript" src="//player.wowza.com/player/latest/wowzaplayer.min.js"></script>');

    var myWowzaPlayer;x
    $('.video_lightbox').click(function (e){
        e.preventDefault();

        var r = 'playerElement' + Math.floor((Math.random() * 100) + 1);

        $('body').prepend('<div id="lightbox_video"><div id="'+r+'" style="width:100%; height:0; padding:0 0 56.25% 0"></div><a href="#" id="close_lightbox_video" style="position: absolute; top: 0; right: 0; padding: 0 10px; font-size: 30px; color: #FFF"><i class="fa fa-times"></i></a></div>');

        myWowzaPlayer = WowzaPlayer.create(r,
            {
            "license":"PLAY1-mWhxJ-Gh3GN-vcn6m-JWJhQ-G9PXe",
            "title":"",
            "description":"",
            "posterFrameURL": $(this).attr('data-cover') ? $(this).attr('data-cover') : '',
            "sourceURL": $(this).attr('href'),
            "autoPlay":false,
            "volume":"75",
            "mute":false,
            "loop":false,
            "audioOnly":false,
            "uiShowQuickRewind":true,
            "uiQuickRewindSeconds":"30"
            }
        );

        $('#close_lightbox_video').click(function (e){
            e.preventDefault();
            if(myWowzaPlayer != null) myWowzaPlayer.destroy();
            $('#lightbox_video').remove();
        });
    });
}
function initSondaggio(){
    function init(){
        $('body').append('<div id="sondaggio"><a href="#" class="close"><i class="fa fa-times"></i></a><h1>COVID-19: sondaggio sulla comunicazione</h1><p>Come pensi sia stata gestita la comunicazione ufficiale delle autorità cantonali durante la crisi sanitaria? Vogliamo sapere la tua opinione!<a href="https://www.wssphinx.ti.ch/SurveyServer/s/fust043/TI_Covid19/questionnaire.htm" class="btn btn-primary" role="button" aria-pressed="true">Partecipa al sondaggio</a></p></div>');

        setTimeout(function (){
            $('#sondaggio').addClass('show');
        }, 500);

        $('#sondaggio .close').click(close);
    }
    function close(e){
        e.preventDefault();
        $('#sondaggio').removeClass('show');
    }
    init();
}

function showGMaps(){
    $.getScript('https://maps.googleapis.com/maps/api/js?key=AIzaSyCRMOl4GMPjzzCWJwjeysPeMum9uskXM5A', function (){
        showGMap(0)
    })
}
function showGMap(n){
    if(gmaps[n]){
        var data = gmaps[n]
        var map = new google.maps.Map(document.getElementById(data.id), {
            zoom: data.zoom,
            panControl: false,
            mapTypeControl: false,
            scaleControl: false,
            streetViewControl: false,
            overviewMapControl: false,
            mapTypeId: google.maps.MapTypeId[data.map_type],
            disableDefaultUI: true
        });

        var infowindow = new google.maps.InfoWindow({
            content: data.description
        });

        geocoder = new google.maps.Geocoder();
        geocoder.geocode( { 'address': data.address}, function(results, status) {
            if (status == google.maps.GeocoderStatus.OK){
                map.setCenter(results[0].geometry.location);

                var marker = new google.maps.Marker({
                    map: map,
                    position: results[0].geometry.location
                });

                google.maps.event.addListener(marker, 'click', function() {
                    infowindow.open(map,marker);
                });
            }
            n++
            setTimeout(function (){
                showGMap(n)
            }, 350)
        })
    }
}
/* Carousel links */
function initCarouselLinks() {
    var e = $('.carousel a[href=\'\']');
    if (e.length) {
        e.css({ cursor: 'default' }).click(function (e) { e.preventDefault(); }).children('.carousel-caption').css({ cursor: 'default' });
    }
}
/* Footer */
function initFooter() {
    var pathname = window.location.href.split('#')[0];
    jQuery('a[href^="#"]').each(function () {
        jQuery(this).attr('href', pathname + jQuery(this).attr('href'));
    });

    //attiva i menù se ho il javascript
    jQuery("#navPrimoLivello1 a, #navPrimoLivello2 a").attr("href", "#");
    jQuery("#navPrimoLivello1 a, #navPrimoLivello2 a").attr("onclick", "javascript:return false;");

    setTimeout(function () {


        var o = $('.footer .bar').offset();
        $('.sliding-content').each(function () {
            var h = $(this).outerHeight();
            $(this).css({ top: (o.top - h) + 'px' }).hide();
        });

    }, 1000);


    var footer_hover = { 'apps': false, 'social': false };
    var footer_opened = false;
    $('.footer .bar li a:not(.info-legali)').click(function (e) {
        e.preventDefault();

        var h = $(this).attr('href');
        footer_opened = true;
        $('.footer .bar .selected').removeClass('selected');
        $(this).addClass('selected');
        if (h.indexOf('#') && (h.indexOf('#') + 1) < h.length) {
            tmp = h.split('#');
            if (tmp[1] && $('.sliding-content.' + tmp[1]).length) {
                // footer_hover[tmp[1]] = true;

                $('.sliding-content.visible').removeClass('visible').hide();


                $('.sliding-content.' + tmp[1]).show()
                $('.sliding-content.' + tmp[1]).addClass('visible');
                // setTimeout(function (){
                //     $('.sliding-content.'+tmp[1]).addClass('visible');
                // }, 200);
            }
        }
    });

    $('html, body').click(function (e) {
        if (footer_opened) {
            if (!$(e.target).parents('.footer').length && !$(e.target).parents('.sliding-content').length) {
                $('.sliding-content.visible').removeClass('visible').hide();
                $('.footer .bar .selected').removeClass('selected');
            }
        }
    })



    $('.sliding-content').each(function () {
        $(this).append('<i class="fa fa-times"></i>');
    });

    $('.fa.fa-times').click(function () {
        $('.sliding-content.visible').removeClass('visible').hide();
        $('.footer .bar .selected').removeClass('selected');
    })


    $('.sliding-content a.social-link').click(function (e) {
        e.preventDefault();
        $('html, body').animate({ scrollTop: 0 }, 500);
        // apriContatti2();
    })
}
/* Functions */
function windowHeight() {
    return window.innerHeight
         || document.documentElement.clientHeight
         || document.body.clientHeight;
}
function initClearField() {
    function init() {
        if(!is_explorer){
            $('input.clear-field').wrap('<span class="clear-field"></span>');
            $('input.clear-field').after('<a href="#" class="hidden"><i class="fa fa-times" aria-label="Cancella contenuto"></i></a>');
            $('input.clear-field').keyup(keyup);
            $('span.clear-field a').click(click);

            if ($('input.clear-field').val()) {
                $('input.clear-field').next().removeClass('hidden');
            }
        }
    }
    function keyup(e) {
        if ($(this).val()) {
            $(this).next().removeClass('hidden');
        }
        else if (!$(this).next().hasClass('hidden')) $(this).next().addClass('hidden');
    }
    function click(e) {
        e.preventDefault();
        $(this).prev().val('');
        $(this).addClass('hidden');
    }
    init();
}
function initDatepicker() {
    $.fn.datepicker.dates['it'] = {
        days: ["Domenica", "Lunedì", "Martedì", "Mercoledì", "Giovedì", "Venerdì", "Sabato", "Domenica"],
        daysShort: ["Dom", "Lun", "Mar", "Mer", "Gio", "Ven", "Sab", "Dom"],
        daysMin: ["Do", "Lu", "Ma", "Me", "Gi", "Ve", "Sa", "Do"],
        months: ["Gennaio", "Febbraio", "Marzo", "Aprile", "Maggio", "Giugno", "Luglio", "Agosto", "Settembre", "Ottobre", "Novembre", "Dicembre"],
        monthsShort: ["Gen", "Feb", "Mar", "Apr", "Mag", "Giu", "Lug", "Ago", "Set", "Ott", "Nov", "Dic"],
        today: "Oggi",
        clear: "Svuota"
    };

    $('.datepicker').datepicker({
        format: "dd.mm.yyyy",
        todayHighlight: true,
        language: 'it',
    });
}
function IEPlaceholderFix() {
    var ua = window.navigator.userAgent;
    var msie = ua.indexOf("MSIE ");
    if (msie > 0 && parseInt(ua.substring(msie + 5, ua.indexOf(".", msie))) < 10) {
        jQuery('[placeholder]').focus(function () {
            var input = jQuery(this);
            if (input.val() == input.attr('placeholder')) {
                input.val('');
                input.removeClass('placeholder');
            }
        }).blur(function () {
            var input = jQuery(this);
            if (input.val() == '' || input.val() == input.attr('placeholder')) {
                input.addClass('placeholder');
                input.val(input.attr('placeholder'));
            }
        }).blur();
    }
}
function createWindowWithRemotingUrl() {
    jQuery.window({
        title: "Prova",
        url: "https://www.ti.ch"
    });
}
function initBackToTop(){
    $('body').append('<a href="#" id="backtotop" tabindex="-1" aria-label="Torna in cima alla pagina"><i class="fa fa-angle-up" aria-hidden="true"></i></a>');
    $('#backtotop').click(function (e){
        e.preventDefault();
        $('html, body').animate({'scrollTop': 0}, 500);
    });
    $(window).scroll(function (e){
        if($(this).scrollTop() > 100) $('#backtotop').addClass('shown');
        else $('#backtotop').removeClass('shown');
    });
}
function initHeadingLinks() {
    // $('h3 > a').append(' <i class="fa fa-angle-right"></i>');

    $('h3 > a').each(function () {
        if ($(this).parents('.lista-comunicati').length == 0 && $(this).parents('#numeroComuni').length == 0 && $(this).parents('.rss-title').length == 0) $(this).append(' <i class="fa fa-angle-right"></i>');
    });
}
function Popup(sURL) {
    var w = window.open(sURL, '', 'width=800,height=600');
}
function PopupPrimoPiano(sURL) {
    var w = window.open(sURL, '', 'width=800,height=600,resizable=1');
}
function nuovafinestra(str, w, h) {

    var efficientString = 'scrollbars=yes,resizable=yes,width=';
    efficientString += w;
    efficientString += ',height=';
    efficientString += h;
    efficientString += ',status=no,location=no,toolbar=no';

    searchWin = window.open(str, 'nuovafinestra', efficientString);
    // searchWin.refer = self;
}
function TargetBlank() {
    if (document.getElementsByTagName) {
        var msg = ' (Collegamento in nuova finestra)';
        var links = document.getElementsByTagName('a');
        for (i = 0; i < links.length; i++) {
            var link = links[i];
            if (link.className.indexOf('targetblank') != -1) {
                link.title += msg;
                var fn = function () {
                    window.open(this.href);
                    return false;
                }
                link.onclick = link.onkeypress = fn;
            }
        }
    }
}
function setPointer(theRow, thePointerColor) {
    if (thePointerColor == '' || typeof (theRow.style) == 'undefined') {
        return false;
    }
    if (typeof (document.getElementsByTagName) != 'undefined') {
        var theCells = theRow.getElementsByTagName('td');
    } else if (typeof (theRow.cells) != 'undefined') {
        var theCells = theRow.cells;
    } else {
        return false;
    }
    var rowCellsCnt = theCells.length;
    for (var c = 0; c < rowCellsCnt; c++) {
        theCells[c].style.backgroundColor = thePointerColor;
    }
    return true;
}
function URLEncode(strToEnc, sep) {
    arrOfStr = strToEnc.split(sep);
    strToEnc = arrOfStr[0];
    for (i = 1; i < arrOfStr.length; i++) {
        strToEnc += '%20' + arrOfStr[i];
    }
    return strToEnc;
}
function getParameterByName(name) {
    name = name.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");
    var regexS = "[\\?&]" + name + "=([^&#]*)";
    var regex = new RegExp(regexS);
    var results = regex.exec(window.location.href);
    if (results == null)
        return "";
    else
        return decodeURIComponent(results[1].replace(/\+/g, " "));
}
var myWin;
function openWin(pagina, nome, parametri) {
    // Apre una pagina in una nuova finestra in base ai parametri passati
    // PARAMETRI
    // pagina : URI della pagina da caricare
    // nome : nome della nuova finestra (da non confondere con il titolo)
    // parametri : parametri di visualizzazione della nuova finestra
    if (!myWin || myWin.closed) {
        myWin = window.open(URLEncode(pagina), nome, parametri);
    } else {
        // myWin.close();
        myWin = window.open(URLEncode(pagina), nome, parametri);
        myWin.focus();
    }
}
function openURL(url) {
    location.href = url;
}
function mouseTrap(first, last){
        first.keydown(function (e){
                if(e.keyCode == 9 && e.shiftKey){
                        e.preventDefault();
                        last.focus();
                }
        });
        last.keydown(function (e){
                if(e.keyCode == 9 && !e.shiftKey){
                        e.preventDefault();
                        first.focus();
                }
        });
}

function initPhraseSlider(t){

    var sp_index = 1;
    var sp_count;

    sp_count =  t.children().length

    t.children(':eq('+(sp_index - 1)+')').css({left: 0});

    var next = (sp_index + 1 > sp_count) ? 1 : sp_index + 1;
    t.children(':eq('+(next)+')').css({left: -1000});



    // t.children(':first').css({left: 0});
    setInterval(function (){
        t.children(':eq('+(sp_index - 1)+')').css({left: 1000});

        sp_index = ((sp_index + 1) > sp_count) ? 1 : sp_index + 1;

        t.children(':eq('+(sp_index - 1)+')').css({left: 0});

        var next = (sp_index + 1 > sp_count) ? 1 : sp_index + 1;
        t.children(':eq('+(next-1)+')').addClass('flip').css({left: -1000});
        setTimeout(function (){
            t.children(':eq('+(next-1)+')').removeClass('flip');
        }, 1500)

    //     t.children(':eq('+(sp_index - 1)+')').css({left: 1000});

    //     console.log(sp_count)
    //     console.log(sp_index)
    //     index = ((sp_index + 1) > sp_count) ? 1 : sp_index + 1;
    //     console.log(sp_index)

    //     t.children(':eq('+(sp_index - 1)+')').css({left: 0});

    //     var next = (sp_index + 1 > sp_count) ? 1 : sp_index + 1;
    //     t.children(':eq('+(next)+')').css({left: -1000});

    }, 8000)
}

function capitalizeFirstLetter(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
}

$.urlParam = function(name){
    var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);
    return results[1] || 0;
}
/* Home */
function initHomeMenu() {

    $('.home-tab a').click(function (e) {
        // e.preventDefault();
        var i = $(this).parent().index();
        $('.home-tab a.selected').removeClass('selected');
        $(this).addClass('selected')
        if (i == 0) {

        }
        else {
            $('.home-icon-menu .items').hide();
            // $('.home-icon-menu .sub-page').hide();
            $('.home-icon-menu .sub-page').css('height', 0).html('');
            $('.home-icon-menu, .home-icon-menu .items:eq(' + (i - 1) + ')').show();
            openOverlayMenu();
        }
        // $('.home-tab a')
    });

    // aria-expanded
    $('.home-menu .menu > li > a').each(function (){
        $(this).attr('aria-expanded', false);
    });

    // fix tab navigation
    $('.sub-items').each(function (i){
        if(i > 0) $(this).attr('data-n', i - 1);
    })

    var str = new Array();
    for(x=0;x<$('.home-menu .menu li').length;x++) str.push('.home-menu .sub-items:eq('+x+') ul a:first');
    $(str.join(',')).keydown(function (e){
        if(e.keyCode == 9 && e.shiftKey){
            e.preventDefault();
            $('.home-menu .menu li:eq('+$(this).parents('.sub-items').attr('data-n')+') a').focus();
        }
    });

    var str = new Array();
    for(x=0;x<$('.home-menu .menu li').length;x++) str.push('.home-menu .sub-items:eq('+x+') ul a:last');
    $(str.join(',')).keydown(function (e){
        if(e.keyCode == 9 && !e.shiftKey){
            e.preventDefault();
            $('.home-menu .menu li:eq('+$(this).parents('.sub-items').attr('data-n')+') a').focus();
        }
    });

    $('.home-menu .menu > li:last a').keydown(function (e){
        if(e.keyCode == 9 && !e.shiftKey){
            e.preventDefault();
            $('.tx-user-slider a').focus()
            // console.log($('.tx-user-slider a:first'))
            // $('.lista-icons.small-incons a:first').focus();
            // $('.home-menu .menu li:eq('+$(this).parents('.sub-items').attr('data-n')+') a').focus();
        }
    });


    $('.home-menu ul.menu a').click(function (e) {
        e.preventDefault();
        var i = $(this).parent().index() + 1;
        $('.home-menu .sub-items').hide();
        $('.home-menu a.selected').removeClass('selected');

        $('.home-menu .sub-items:eq(' + i + ')').show();
        $(this).addClass('selected')

        $('.home-menu .sub-items:eq(' + i + ') ul a:first').focus();

        $('.home-menu .menu > li > a').attr('aria-expanded', false);
        $(this).attr('aria-expanded', true);
    });

    $('#overlay').click(function () {
        if (location.href.indexOf('#') > -1) {
            var tmp = location.href.split('#');
            location.href = tmp[0] + '#';
        }
        else {
            location.href = location.href + '#';
        }
    });

    $('.home-icon-menu .item a').click(function (e) {
        // e.preventDefault();
        var o = $(this).parent().parent().next('.sub-page');

        if ($(this).attr('href') == '#tematiche/circolazione-trasporti') {
            $.get('templates/pages/sala-stampa.html', function (r) {
                // o.html(r).show().css('height','auto');
                o.html(r);
                o.css('height', o.children().outerHeight());
                // $('#overlay').hide();
                $('#overlay').removeClass('shown');
            });
        }
        else {
            $.get('templates/pages/vivere-ticino.html', function (r) {
                o.html(r);
                setTimeout(function () {
                    o.css('height', o.children().outerHeight());
                }, 500)
                // o.css('height', o.children().outerHeight());
                $('#overlay').removeClass('shown');
            });
        }
    });

    // serve per gestire la scomparsa dell'overlay quando é stata cambiata pagina
    if ($('#overlay.shown.autohide').length) setTimeout(function () { $('#overlay').removeClass('shown'); }, 100);



    $('.consigliere img').hover(function () {
        $(this).next('a').addClass('shown');
    }, function () {
        $(this).next('a').removeClass('shown');
    });
}
/* Liste icone */
var icone = {
    'elencoFILE': 'file-text-o',
    'elencoPDF': 'file-pdf-o',
    'elencoDOC': 'file-word-o',
    'elencoDOCX': 'file-word-o',
    'elencoXLS': 'file-excel-o',
    'elencoPPT': 'file-powerpoint-o',
    'elencoIMG': 'file-image-o',
    'elencoLinkInterno': 'angle-right',
    'elencoLinkEsterno': 'external-link',
    'elencoAudio': 'file-audio-o',
    'elencoRSS': 'rss-square',
    'elencoGoogleEarth': 'globe',
    'elencoDataPicker': 'calendar',
    'elencoHTML': 'code',
    'elencoZIP': 'file-archive-o',
    // 'elencozip': 'file-archive-o',
    'elencoDXF': 'pencil-square-o',
    'elencoDWG': 'pencil-square',
    'elencoGeoRSS': 'rss',
    'elencoSWF': 'star',
    'elencoVideo': 'file-video-o',
    'elencoQuadrato': 'square',
    'elencoCartella': 'folder-open',
    'elencoMappa': 'map-o'
}
function initListTransformation() {

    for(x=0;x<4;x++){
        if($('li[class*=elenco] dfn').length){
            $('li[class*=elenco] dfn').each(function (){
                $(this).replaceWith('<span>'+$(this).html()+'</span>');
            });
        }
        else break;
    }

    $('li[class*=elenco]').each(function () {
        var c = $(this).attr('class');
        if (icone[c]) {
            if (
                !$(this).parents('.big-icon').length
                // !$(this).parents('.risultatiTutti').length
            ) {

                // var text = $(this).clone()    //clone the element
                //             .children() //select all the children
                //             .remove()   //remove all the children
                //             .end()  //again go back to selected element
                //             .text();
                // if(text){
                //     var tmp = $(this).children('a').append('<span>'+text+'</span>').clone();
                //     $(this).html(tmp);
                // }


                // var html = $(this).html();
                // var end = (html.indexOf('</a>') + 4);
                // if(end < html.length){

                //     var str = html.substring(end);
                //     if(str.indexOf('<br>') == 0) str = str.substring(4);
                //     else if(str.indexOf('<br/>') == 0) str = str.substring(5);
                //     else if(str.indexOf('<br />') == 0) str = str.substring(6);

                //     var a = $(this).children('a').clone().append('<span>'+str+'</span>')//.prepend('|');
                //     $(this).html(a);
                // }

                // small
                if ($(this).children().is('a')) {
                    $(this).children('a').addClass('small-icon-link').prepend('<i class="fa fa-' + icone[c] + '"></i>');
                    $(this).parent('ul').addClass('lista-icone');
                    // $(this).parents('ul').addClass('lista-icone');
                }
                else {
                    $(this).prepend('<i class="fa fa-' + icone[c] + '"></i>');
                }
                $(this).parent('ul').addClass('lista-icons small-incons');

                //console.log('here')
            }
                // else if($(this).parents('.box-default').length || (!$(this).parents('.box-default').length && $(this).parents('.big-icon').length)){
            else {
                // big
                if ($(this).children().is('a')) {
                    // var text = $(this).children('a').text();
                    // $(this).children('a').text('');
                    // $(this).children('a').append('<span>'+text+'</span>');

                    // console.log('asdf')

                    var text = $(this).children('a')
                        .clone()    //clone the element
                        .children() //select all the children
                        .remove()   //remove all the children
                        .end()  //again go back to selected element
                        .text();
                    if ($(this).children('a').children('span').length) {
                        text += '<span class="text">' + $(this).children('a').children('span').text() + '</span>';
                    }

                    var width = $(this).outerWidth() - 70;
                    if (width < 0) {
                        width = $(this).parents('.box-default').outerWidth() - 70 - 30;
                        // width = $(this).parents('.frame-box-default').outerWidth() - 70 - 30;
                    }
                    var icon_type = ($(this).hasClass('elencoLinkEsterno') || $(this).hasClass('elencoLinkInterno')) ? 'link' : 'file';

                    $(this).children('a').addClass('big-icon-link').html('<span class="i"><i class="fontac-' + icon_type + '"></i><i class="fa fa-' + icone[c] + ' appendice"></i></span><span class="t" style="width: ' + width + 'px">' + text + '</span><span class="c"></span>');

                    $(this).parents('ul').addClass('lista-icone big-list')
                }
                else {
                    var icon_type = ($(this).hasClass('elencoLinkEsterno') || $(this).hasClass('elencoLinkInterno')) ? 'link' : 'file';
                    // $(this).prepend('<i class="'+c+'-big"></i>');
                    $(this).prepend('<span class="big-icon-link"><i class="fontac-' + icon_type + '"></i><i class="fa fa-' + icone[c] + ' appendice"></i></span>');
                }
                $(this).parent('ul').attr('class', '').addClass('lista-icons big-incons');
            }
            $(this).attr('class', '');
        }
        $(this).addClass('no-list');

    });

    $('ul[class*=elenco][class!=elenco_scheda][class!=elencoQuadratoNero][class!=elencoGlossario][class!=\'elenco 1x\']').each(function () {
        var c = $(this).attr('class');
        if (icone[c]) {
            if (
                !$(this).parents('.big-icon').length
            ) {


                // var text = $(this).children('a')
                //     .clone()    //clone the element
                //     .children() //select all the children
                //     .remove()   //remove all the children
                //     .end()  //again go back to selected element
                //     .text();
                // if($(this).children('a').children('span').length){
                //     text += '<span class="text">'+$(this).children('a').children('span').text()+'</span>';
                // }

                $(this).children('li').each(function () {
                    var html = $(this).html();
                    var end = (html.indexOf('</a>') + 4);
                    if (end < html.length) {

                        var str = html.substring(end);
                        if (str.indexOf('<br>') == 0) str = str.substring(4);
                        else if (str.indexOf('<br/>') == 0) str = str.substring(5);
                        else if (str.indexOf('<br />') == 0) str = str.substring(6);

                        var a = $(this).children('a').clone().append('<span>' + str + '</span>');
                        $(this).html(a);
                    }
                });

                // small
                if ($(this).children('li:eq(0)').children().is('a')) {
                    $(this).children('li').each(function () {
                        $(this).children('a').addClass('small-icon-link').prepend('<i class="fa fa-' + icone[c] + '"></i>');

                        if ($(this).find('ul').length) {
                            $(this).find('ul').children('li').each(function () {
                                if ($(this).children().is('a')) {
                                    $(this).children('a').addClass('small-icon-link').prepend('<i class="fa fa-' + icone[c] + '"></i>');
                                }
                                else {
                                    $(this).prepend('<i class="fa fa-' + icone[c] + '"></i>');
                                }
                                $(this).addClass('no-list');
                            })
                        }

                    });
                    $(this).addClass('lista-icone');
                }
                else {
                    $(this).children('li').each(function () {
                        $(this).prepend('<i class="fa fa-' + icone[c] + '"></i>');


                        if ($(this).find('ul').length) {
                            $(this).find('ul').children('li').each(function () {
                                if ($(this).children().is('a')) {
                                    $(this).children('a').addClass('small-icon-link').prepend('<i class="fa fa-' + icone[c] + '"></i>');
                                }
                                else {
                                    $(this).prepend('<i class="fa fa-' + icone[c] + '"></i>');
                                }
                                $(this).addClass('no-list');
                            })
                        }
                    });
                }
                $(this).attr('class', '').addClass('lista-icons small-incons');
            }
                // else if($(this).parents('.box-default').length || (!$(this).parents('.box-default').length && $(this).parents('.big-icon').length)){
            else {
                // big

                if ($(this).children('li:eq(0)').children().is('a')) {
                    var icon_type = ($(this).hasClass('elencoLinkEsterno') || $(this).hasClass('elencoLinkInterno')) ? 'link' : 'file';
                    $(this).children('li').each(function () {

                        var text = $(this).children('a')
                            .clone()    //clone the element
                            .children() //select all the children
                            .remove()   //remove all the children
                            .end()  //again go back to selected element
                            .text();
                        if ($(this).children('a').children('span').length) {
                            text += '<span class="text">' + $(this).children('a').children('span').text() + '</span>';
                        }

                        $(this).children('a').addClass('big-icon-link').prepend('<i class="fontac-' + icon_type + '"></i><i class="fa fa-' + icone[c] + ' appendice"></i>');

                        var i1 = $(this).children('a').children('.fontac-' + icon_type + '');
                        var i2 = $(this).children('a').children('.appendice');





                        var width = $(this).outerWidth() - 70;
                        if (width < 0) {
                            width = $(this).parents('.box-default').outerWidth() - 70 - 30;
                            // width = $(this).parents('.frame-box-default').outerWidth() - 70 - 30;
                        }
                        $(this).children('a').text('');
                        $(this).children('a').append('<span class="i"></span>');
                        $(this).children('a').children('span').append(i1).append(i2);
                        $(this).children('a').append('<span class="t" style="width: ' + width + 'px">' + text + '</span><span class="c"></span>');


                    });
                    $(this).addClass('lista-icone big-list')
                }
                else {
                    // $(this).prepend('<i class="'+c+'-big"></i>');
                    var icon_type = ($(this).hasClass('elencoLinkEsterno') || $(this).hasClass('elencoLinkInterno')) ? 'link' : 'file';
                    $(this).children('li').each(function () {
                        $(this).prepend('<span class="big-icon-link"><i class="fontac-' + icon_type + '"></i><i class="fa fa-' + icone[c] + ' appendice"></i></span>');
                    });
                }
                $(this).attr('class', '').addClass('lista-icons big-incons');
            }
            // $(this).attr('class', '');
        }
        $(this).children('li').each(function () {
            $(this).addClass('no-list');

            if ($(this).children('a').hasClass('internal-link')) {
                $(this).children('a').removeClass('internal-link');
            }
        });
    });

    $('ul[class*=elenco][class!=elenco_scheda][class!=elencoQuadratoNero][class!=elencoGlossario][class!=\'elenco 1x\']').each(function () {
        var c = $(this).attr('class');
        if (icone[c]) {
            if (
                !$(this).parents('.big-icon').length
            ) {


                // var text = $(this).children('a')
                //     .clone()    //clone the element
                //     .children() //select all the children
                //     .remove()   //remove all the children
                //     .end()  //again go back to selected element
                //     .text();
                // if($(this).children('a').children('span').length){
                //     text += '<span class="text">'+$(this).children('a').children('span').text()+'</span>';
                // }

                $(this).children('li').each(function () {
                    var html = $(this).html();
                    var end = (html.indexOf('</a>') + 4);
                    if (end < html.length) {

                        var str = html.substring(end);
                        if (str.indexOf('<br>') == 0) str = str.substring(4);
                        else if (str.indexOf('<br/>') == 0) str = str.substring(5);
                        else if (str.indexOf('<br />') == 0) str = str.substring(6);

                        var a = $(this).children('a').clone().append('<span>' + str + '</span>');
                        $(this).html(a);
                    }
                });

                // console.log($(this))

                // small
                if ($(this).children('li:eq(0)').children().is('a')) {
                    $(this).children('li').each(function () {
                        $(this).children('a').addClass('small-icon-link').prepend('<i class="fa fa-' + icone[c] + '"></i>');

                    });
                    $(this).addClass('lista-icone');
                }
                else {
                    $(this).children('li').each(function () {
                        $(this).prepend('<i class="fa fa-' + icone[c] + '"></i>');
                    });
                }
                $(this).attr('class', '').addClass('lista-icons small-incons');



            }
                // else if($(this).parents('.box-default').length || (!$(this).parents('.box-default').length && $(this).parents('.big-icon').length)){
            else {
                // big

                if ($(this).children('li:eq(0)').children().is('a')) {
                    var icon_type = ($(this).hasClass('elencoLinkEsterno') || $(this).hasClass('elencoLinkInterno')) ? 'link' : 'file';
                    $(this).children('li').each(function () {

                        var text = $(this).children('a')
                            .clone()    //clone the element
                            .children() //select all the children
                            .remove()   //remove all the children
                            .end()  //again go back to selected element
                            .text();
                        if ($(this).children('a').children('span').length) {
                            text += '<span class="text">' + $(this).children('a').children('span').text() + '</span>';
                        }

                        $(this).children('a').addClass('big-icon-link').prepend('<i class="fontac-' + icon_type + '"></i><i class="fa fa-' + icone[c] + ' appendice"></i>');

                        var i1 = $(this).children('a').children('.fontac-' + icon_type + '');
                        var i2 = $(this).children('a').children('.appendice');





                        var width = $(this).outerWidth() - 70;
                        if (width < 0) {
                            width = $(this).parents('.box-default').outerWidth() - 70 - 30;
                            // width = $(this).parents('.frame-box-default').outerWidth() - 70 - 30;
                        }
                        $(this).children('a').text('');
                        $(this).children('a').append('<span class="i"></span>');
                        $(this).children('a').children('span').append(i1).append(i2);
                        $(this).children('a').append('<span class="t" style="width: ' + width + 'px">' + text + '</span><span class="c"></span>');


                    });
                    $(this).addClass('lista-icone big-list')
                }
                else {
                    // $(this).prepend('<i class="'+c+'-big"></i>');
                    var icon_type = ($(this).hasClass('elencoLinkEsterno') || $(this).hasClass('elencoLinkInterno')) ? 'link' : 'file';
                    $(this).children('li').each(function () {
                        $(this).prepend('<span class="big-icon-link"><i class="fontac-' + icon_type + '"></i><i class="fa fa-' + icone[c] + ' appendice"></i></span>');
                    });
                }
                $(this).attr('class', '').addClass('lista-icons big-incons');
            }
            // $(this).attr('class', '');
        }
        $(this).children('li').each(function () {
            $(this).addClass('no-list');

            if ($(this).children('a').hasClass('internal-link')) {
                $(this).children('a').removeClass('internal-link');
            }
        });
    });
}
/* Irfaq */
function initIrfaq() {
    function irfaqOpen(e) {
        e.preventDefault();

        if ($(this).parent().parent().is('[class*=irfaq]')) {
            $(this).parent().parent().find('.panel-heading > a.collapsed').trigger('click').removeClass('collapsed');
        }
        else {
            $('.panel-heading > a.collapsed').trigger('click').removeClass('collapsed');
        }
    }
    function irfaqClose(e) {
        e.preventDefault();

        if ($(this).parent().parent().is('[class*=irfaq]')) {
            $(this).parent().parent().find('.panel-heading > a[class=""]').trigger('click');
        }
        else {
            $('.panel-heading > a[class=""]').trigger('click');
        }

    }
    $('.irfaq-open').click(irfaqOpen);
    $('.irfa-close').click(irfaqClose);
}
/* Lightbox */
function initBootstrapLightbox(){
    function init(){

        var html = '';
        var n = 1;
        $('a.cboxElement').each(function (){
            var id = 'myModal'+n;
            $(this).attr('data-toggle', 'modal').attr('data-target', '#'+id);

            // if($(this).hasClass('iframe')){
                var href = $(this).attr('href');
                $(this).attr('href', '#').attr('data-src', href);
                content = '';
                title = $(this).text();
            // }

            html += generateModal(id, title, content);
            $(this).click(open);
	    n++;
        });
        $('body').append(html);
    }
    function generateModal(id, title, content){
        var html = '<div class="modal fade" id="'+id+'" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">';
        html += '<div class="modal-dialog modal-lg" role="document">';
        html += '<div class="modal-content">';
        html += '<div class="modal-header"><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button><h4 class="modal-title" id="myModalLabel">'+title+'</h4></div>';
        html += '<div class="modal-body">'+content+'</div>';
        html += '</div></div></div>';
        return html;
    }
    function open(e){
        // e.preventDefault();

        var href = $(this).attr('href');
        if($(this).hasClass('iframe')){
            href = $(this).attr('data-src');
            $(''+$(this).attr('data-target')+' .modal-body').html('<iframe src="'+href+'" style="display: 1none; width: 100%; height: 480px; border: 0"></iframe>');
        }
    }
    init();
}
/* Maps */
function initMap() {
    $('map area').hover(function () {
        var p = $(this).attr('coords').split(',');
        var base_p = $('#mappa-traffico').position();
        $('.map-tooltip').css({ top: base_p.top + parseInt(p[1]) + 'px', left: base_p.left + parseInt(p[0]) + 20 + 'px' }).show();
        $('.map-tooltip .' + $(this).attr('id')).show();

    }, function () {
        $('.map-tooltip, .map-tooltip .inner').hide();
    });
}
function initMap2() {

    var hover_color = '#C33';
    var positions = {};

    function init() {
        $('#mappa-radar').css('position', 'relative');
        initCantieri();
        initRadar();
        initFancybox();
    }

    function initCantieri() {
        function mouseover() {
            d3.select(this).select('.st19').transition().attr('r', 12).style('fill', hover_color);
            d3.select(this).select('.st20').transition().attr('r', 12).style('stroke', hover_color);

            showTooltip($(this));
        }
        function mouseout() {
            d3.select(this).select('.st19').transition().attr('r', 11).style('fill', '#2F4699');
            d3.select(this).select('.st20').transition().attr('r', 11).style('stroke', '#2F4699');

            hideTooltip();
        }
        function click() {
            var id = $(this).attr('id').substring(1);
            var link = $('.map-tooltip2 .e' + id + '').attr('data-link');
            window.open(link);
        }

        d3.select('svg').selectAll('#Cantieri > g').on('mouseover', mouseover);
        d3.select('svg').selectAll('#Cantieri > g').on('mouseout', mouseout);
        d3.select('svg').selectAll('#Cantieri > g').on('click', click);
    }

    function initRadar() {
        function mouseover() {
            d3.select(this).select('circle').transition().attr('r', 10).style('fill', hover_color);
            d3.select(this).select('text').transition().style('fill', hover_color);

            showTooltip($(this));
        }
        function mouseout() {
            d3.select(this).select('circle').transition().attr('r', 6.9).style('fill', '#2F4699');
            d3.select(this).select('text').transition().style('fill', '#2F4699');

            hideTooltip();
        }
        function click() {
            var id = $(this).attr('id').substring(1);
            $('.map-tooltip2 .e' + id + ' a').trigger('click');
        }

        d3.select('svg').selectAll('#Radar > g').on('mouseover', mouseover);
        d3.select('svg').selectAll('#Radar > g').on('mouseout', mouseout);
        d3.select('svg').selectAll('#Radar > g').on('click', click);
    }

    function showTooltip(o) {
        var d = o.attr('data-p');
        var id = o.attr('id').substring(1);

        // if(!positions[id]){
        //     var p = o.children('circle').position();
        //     positions[id] = {
        //         top: p.top + 20,
        //         left: ((d == 'r') ? (p.left + 20) : (p.left - 250))
        //     };
        // }

        // if (!positions[id]) {
            var p = o.children('circle').offset();
            var mp = $('#mappa-radar').offset();
            positions[id] = {
                top: p.top + 20 - mp.top,
                left: ((d == 'r') ? (p.left + 20 - mp.left) : (p.left - 250 - mp.left))
            };
        // }


         var pp = o.children('circle').offset();

        // console.log(positions[id]);
        //  console.log(pp)
        //  console.log($('#mappa-radar').position())
        //  console.log($('#mappa-radar').offset())

        $('.map-tooltip').css({ top: p.top + 40, left: p.left + 10 }).show();
        $('.map-tooltip2').css({ top: positions[id].top, left: positions[id].left }).show();
        $('.map-tooltip2 .e' + id).show();
    }

    function hideTooltip() {
        $('.map-tooltip2, .map-tooltip2 > div').hide();
    }

    function initFancybox() {
        $('.fancybox').fancybox({
            helpers: {
                title: {
                    type: 'inside'
                },
                overlay: {
                    speedOut: 0
                }
            }
        });
    }

    init();
}
function initMap3() {
    $.getScript('https://www3.ti.ch/DT/dc/uca/temi/corsi_acqua/jquery.maphilight.js', function () {
        $('.map').maphilight();
    });
}
/* Nav */
function initNav() {
    var timeoutId1;
    var timeoutId2;
    /*var timeoutId3;*/
    jQuery("#navPrimoLivello1").hover(function () {
        jQuery("#navPrimoLivello1").css('background-color', '#ffffff');

        if (jQuery('#visualizza1').css("display") == 'none') {
            if (!timeoutId1) {

                timeoutId1 = window.setTimeout(function () {
                    if (timeoutId1 > 0) {
                        timeoutId1 = null; // EDIT: added this line
                        //jQuery("#visualizza1").slideDown('fast');
                        jQuery('#visualizza1').css("display", "block");
                    }
                }, 500);
            }
        }
    }, function () {
        timeoutId1 = 0;

        jQuery('#visualizza1').css("display", "none");
        jQuery("#navPrimoLivello1").css('background-color', '#eeeeee');

    });


    jQuery("#navPrimoLivello2").hover(function () {
        jQuery("#navPrimoLivello2").css('background-color', '#ffffff');
        if (!timeoutId2) {

            timeoutId2 = window.setTimeout(function () {
                if (timeoutId2 > 0) {
                    timeoutId2 = null; // EDIT: added this line
                    //jQuery("#visualizza2").slideDown('fast');
                    jQuery('#visualizza2').css("display", "block");
                }
            }, 500);

        }
    }, function () {
        timeoutId2 = 0;

        jQuery('#visualizza2').css("display", "none");
        jQuery("#navPrimoLivello2").css('background-color', '#eeeeee');

    });
}
/* Overlay */
function showOverlay(o) {
    $('body').append('<div class="overlay-close"><div class="inner"><a href="#" title="Chiudi" aria-label="Chiudi"><i class="fa fa-times" aria-hidden="true"></i></a></div></div><div class="overlay"></div>');
    $('.overlay-close').click(function (e) {
        e.preventDefault();
        hideOverlay();
    });
    $(window).on('keydown', function (e){
        if(e.keyCode == 27){
            $('.overlay-close a').trigger('click');
        }
    })
}
function hideOverlay() {
    $('.overlay-close, .overlay, #organigramma, .overlay-content').remove();
    $('header .right a.opened').removeClass('opened');
    if(overlayOpener){
        overlayOpener.focus();
        overlayOpener = false;
    }

    if($('.tx-tichwowza-pi2 object').length){
        $('.tx-tichwowza-pi2 object').css('visibility', 'visible');
    }
}
function resizeOverlay() {
    if($(".background").outerHeight() > 50) var h = $(".background").outerHeight() + $(".footer").outerHeight();
    else var h = $("#maincontent").outerHeight() + $(".footer").outerHeight() + 136;

    if ($('body.parallax-template').length) {
        h += $('body > .co-n1, body > .box-default, body > .frame-box-default').outerHeight();
    }
    else if(windowHeight() - $('header.new').outerHeight() > h){
        h = windowHeight() - $('header.new').outerHeight();
    }

    $('.overlay').css({ height: h }).show();
}
/* Parallax */
function initParallaxPage() {

    var items = [];
    var h = 0;
    function init() {
        h = windowHeight();

        setTimeout(function () {
            items.push({
                from: 0,
                to: $('.box-default .scuola-parallax .box-1, .frame-box-default .scuola-parallax .box-1').outerHeight()
            });
            items.push({
                from: $('.box-4').offset().top - h,
                to: $('.box-4').offset().top + $('.box-4').outerHeight() - h
            });

            items.push({
                // from: $('.box-3').offset().top - h,
                from: 0,
                to: $('.box-3').offset().top + $('.box-3').outerHeight() - h
            });



            $(window).scroll(scroll);

        }, 200);

        initSlider();

        setTimeout(function () { $('.box-1 .img1').addClass('shown'); }, 300);
        setTimeout(function () { $('.box-1 .triangle').addClass('opened'); }, 500);
        setTimeout(function () { $('.box-1 .bar').addClass('opened'); }, 1000);
    }
    function scroll(e) {
        var v = $(window).scrollTop();

        if (v >= 0 && v <= 500) {
            $('.box-default .scuola-parallax .box-1 .img1').css({ 'background-position': '0px ' + (items[0].from - (v / 4)) + 'px' })
            $('.frame-box-default .scuola-parallax .box-1 .img1').css({ 'background-position': '0px ' + (items[0].from - (v / 4)) + 'px' })
        }
        else if (v >= items[1].from) {
            var val = (items[1].from - v) / 8;
            $('.box-default .scuola-parallax .box-4').css({ 'background-position': '0px ' + val + 'px' })
            $('.frame-box-default .scuola-parallax .box-4').css({ 'background-position': '0px ' + val + 'px' })
        }


        if (v >= items[2].from <= items[2].to) {
            var val = (items[2].from - v) / 14;
            $('.box-default .scuola-parallax .box-3 .circle').css({ 'background-position': 'center ' + val + 'px' })
            $('.frame-box-default .scuola-parallax .box-3 .circle').css({ 'background-position': 'center ' + val + 'px' })
        }
    }
    function initSlider() {
        var owl = $("#owl-demo")

        owl.owlCarousel({
            navigation: false,
            mouseDrag: false,
            touchDrag: false,
            responsiveClass: true,
            responsive: {
                0: {
                    items: 1,
                    // nav:true
                },
                600: {
                    items: 4,
                    // nav:false
                },
                1400: {
                    items: 5,
                    // nav:true,
                    // loop:false
                }
            }
        });

        $(".box-2 .next").click(function (e) {
            e.preventDefault();
            owl.trigger('next.owl.carousel');
        });

        $(".box-2 .prev").click(function (e) {
            e.preventDefault();
            owl.trigger('prev.owl.carousel');
        });

        // $("#owl-demo a.fancybox").fancybox();
    }
    init();
}
/* Timeline */
// function initSpecialTimeline() {
//     $('.timeline-container > .frame-box-default > .row > .col-xs-12 > a').remove();
//     var html = '';
//     var first = true;
//     $('.timeline-container > .frame-box-default > .row > .col-xs-12 .frame-box-default').each(function () {
//         if (first) {
//             html += $(this).html();
//             html = html.replace('</ul>', '');
//             first = false;
//         }
//         else html += $(this).html();
//     });
//     $('.timeline-container > .frame-box-default > .row > .col-xs-12').html(html);

//     $('.timeline-container > .frame-box-default > .row > .col-xs-12 .frame-box-default').each(function () {
//         if (first) {
//             html += $(this).html();
//             html = html.replace('</ul>', '');
//             first = false;
//         }
//         else html += $(this).html();
//     });
//     $('.timeline-container > .frame-box-default > .row > .col-xs-12').html(html);

//     $('.timeline-container').addClass('shown');


//     /* V2 */

//     var start = '<ul class="timeline-new"><li class="timeline-title">::title::</li>';
//     var entryA = '<li><div class="timeline-badge primary"><a><img src="/typo3conf/ext/user_archivio_votazioni/images/circle.png"></a></div><div class="timeline-panel"><div class="timeline-body"><h3 class="bar">::title::</h3>::text::</div></div></li>';
//     var entryB = '<li class="timeline-inverted"><div class="timeline-badge primary"><a><img src="/typo3conf/ext/user_archivio_votazioni/images/circle.png"></a></div><div class="timeline-panel"><div class="timeline-body"><h3 class="bar">::title::</h3>::text::</div></div></li>';
//     var end = '<li class="clearfix" style="float: none;"></li></ul>';


//     // $('.timeline-container2')
//     $('.timeline-container2 a:not([href])').remove();
//     $('.timeline-container2 > .frame-box-default > .csc-header').remove();
//     $('.timeline-container2 > .frame-box-default > .csc-header').remove();

//     $('.timeline-container2').each(function () {
//         var first = true;
//         var html = '';
//         var n = 0;
//         $(this).find('> .frame-box-default > .row > .col-xs-12 > .frame-box-default').each(function () {
//             if (first) {
//                 html += start.replace('::title::', $(this).text());
//                 first = false;
//             }
//             else {
//                 // console.log($(this).find('.csc-header').text());
//                 // console.log($(this).find('.rte').html());

//                 var entry = (n % 2 == 0) ? entryA : entryB;
//                 entry = entry.replace('::title::', $(this).find('h3').text());
//                 entry = entry.replace('::text::', $(this).find('.ce-bodytext').html());

//                 html += entry;
//                 n++;
//             }
//         });
//         $(this).find('> .frame-box-default > .row > .col-xs-12 > .frame-box-default').each(function () {
//             if (first) {
//                 html += start.replace('::title::', $(this).text());
//                 first = false;
//             }
//             else {
//                 // console.log($(this).find('.csc-header').text());
//                 // console.log($(this).find('.rte').html());

//                 var entry = (n % 2 == 0) ? entryA : entryB;
//                 entry = entry.replace('::title::', $(this).find('h3').text());
//                 entry = entry.replace('::text::', $(this).find('.ce-bodytext').html());

//                 html += entry;
//                 n++;
//             }
//         });
//         html += end;
//         $(this).find('> .frame-box-default > .row > .col-xs-12').html(html);
//         $(this).find('> .frame-box-default > .row > .col-xs-12').html(html);
//     });


//     // var first = true;
//     // var html = '';
//     // var n = 0;

//     // $('.timeline-container2 > .frame-box-default > .row > .col-xs-12 > .frame-box-default').each(function (){
//     //     if(first){
//     //         html += start.replace('::title::', $(this).text());
//     //         first = false;
//     //     }
//     //     else{
//     //         // console.log($(this).find('.csc-header').text());
//     //         // console.log($(this).find('.rte').html());

//     //         var entry = (n % 2 == 0) ? entryA : entryB;
//     //         entry = entry.replace('::title::', $(this).find('.csc-header').text());
//     //         entry = entry.replace('::text::', $(this).find('.rte').html());

//     //         html += entry;
//     //         n++;
//     //     }
//     // });

//     // html += end;
//     // $('.timeline-container2 > .frame-box-default > .row > .col-xs-12').html(html);
// }
function initSpecialTimeline() {
    $('.timeline-container > .frame-box-default > .row > .col-xs-12 > a').remove();
    var html = '';
    var first = true;
    $('.timeline-container > .frame-box-default > .row > .col-xs-12 .frame-box-default').each(function () {
        if (first) {
            html += $(this).html();
            html = html.replace('</ul>', '');
            first = false;
        }
        else html += $(this).html();
    });
    $('.timeline-container > .frame-box-default > .row > .col-xs-12').html(html);
    $('.timeline-container').addClass('shown');


    /* V2 */

    var start = '<ul class="timeline-new"><li class="timeline-title">::title::</li>';
    var entryA = '<li><div class="timeline-badge primary"><a><img src="/typo3conf/ext/user_archivio_votazioni/images/circle.png" alt=""></a></div><div class="timeline-panel"><div class="timeline-body"><h3 class="bar">::title::</h3>::text::</div></div></li>';
    var entryB = '<li class="timeline-inverted"><div class="timeline-badge primary"><a><img src="/typo3conf/ext/user_archivio_votazioni/images/circle.png" alt=""></a></div><div class="timeline-panel"><div class="timeline-body"><h3 class="bar">::title::</h3>::text::</div></div></li>';
    var end = '<li class="clearfix" style="float: none;"></li></ul>';


    // $('.timeline-container2')
    $('.timeline-container2 a:not([href])').remove();
    $('.timeline-container2 > .frame-box-default > .csc-header').remove();

    $('.timeline-container2').each(function () {
        var first = true;
        var html = '';
        var n = 0;
        $(this).find('> .frame-box-default > .row > .col-xs-12 > .frame-box-default').each(function () {
            if (first) {
                html += start.replace('::title::', $(this).text());
                first = false;
            }
            else {
                var entry = (n % 2 == 0) ? entryA : entryB;
                var t = $(this).find('h3').text() ? $(this).find('h3').text() : '&nbsp;';
                entry = entry.replace('::title::', t);
                entry = entry.replace('::text::', $(this).find('.ce-bodytext').html());

                html += entry;
                n++;
            }
        });
        html += end;
        $(this).find('> .frame-box-default > .row > .col-xs-12').html(html);
    });


    // var first = true;
    // var html = '';
    // var n = 0;

    // $('.timeline-container2 > .frame-box-default > .row > .col-xs-12 > .frame-box-default').each(function (){
    //     if(first){
    //         html += start.replace('::title::', $(this).text());
    //         first = false;
    //     }
    //     else{
    //         // console.log($(this).find('.csc-header').text());
    //         // console.log($(this).find('.rte').html());

    //         var entry = (n % 2 == 0) ? entryA : entryB;
    //         entry = entry.replace('::title::', $(this).find('.csc-header').text());
    //         entry = entry.replace('::text::', $(this).find('.rte').html());

    //         html += entry;
    //         n++;
    //     }
    // });

    // html += end;
    // $('.timeline-container2 > .frame-box-default > .row > .col-xs-12').html(html);
}
/* Wfqbe */
function initWfqbe() {
    function click(e) {
        e.preventDefault();
        $('.wfqbe-form input[type=text]').val('');
        $('.wfqbe-form select option:first-child').prop('selected', true).trigger('change')
    }

    $('.wfqbe-reset').click(click);
}
function initAgendaCulturale(){
    function init(){
        if($('.big_dropdown').length) initDaterange()
        else if($('#formulario_osservatorio').length) initFormularioAgenda()

        if($('.loop').length) initHomeCarousel()
    }
    function initHomeCarousel(){

        $('.loop').owlCarousel({
            center: true,
            autoWidth: true,
            loop: true,
            margin: 0
        }).on('changed.owl.carousel', function(event) {
            setTimeout(function (){
                $('.owl-item .inner-caption:not(.hidden)').addClass('hidden')
                $('.owl-item.active .inner-caption').removeClass('hidden')
            }, 100)
        })
        $('.owl-item:not(.center) .inner-caption').addClass('hidden')

        $('.owl-carousel .owl-stage-outer').append('<a href="#" class="prev"><i class="fa fa-angle-left"></i></a><a href="#" class="next"><i class="fa fa-angle-right"></i></a>')


        $('.owl-carousel .prev').click(function(e){
            e.preventDefault();
            $('.loop').trigger('prev.owl.carousel');
        });
        $('.owl-carousel .next').click(function(e){
            e.preventDefault();
            $('.loop').trigger('next.owl.carousel');
        });

       
    }
    function initDaterange(){
        var startDate = false;
        var endDate = false;

        if($('.big_dropdown').text().indexOf('Oggi') == -1){
            var text = $('#periodo').text();
            var tmp = text.split('-');
            startDate = tmp[0];
            endDate = tmp[1];
        }

        $('.big_dropdown').daterangepicker({
            autoUpdateInput: false,
            startDate: startDate,
            endDate: endDate,
            showDropdowns: true,
            minDate: '01.01.1992',
            locale: {
              format: 'DD.MM.YYYY',
              firstDay: 1,
              cancelLabel: 'Cancella',
              applyLabel: 'Applica',
              customRangeLabel: "Custom",
              daysOfWeek: ["Do","Lu","Ma","Me","Gi","Ve", "Sa"],
              monthNames: ["Gennaio","Febbraio","Marzo","Aprile","Maggio","Giugno","Luglio","Agosto","Settembre","Ottobre","Novembre","Dicembre"]
            }
        },
        function(start, end) {
            var startDate = start;
            var endDate = end;

            var val=startDate.format('DD.MM.YYYY') + '-' + endDate.format('DD.MM.YYYY');
            $("#periodo").val(val);
            $('#formRicerca').submit();
           }
        );
    }
    init();

    $('.big_dropdown').on('apply.daterangepicker', function(ev, picker) {
         $(this).html('<i class="fa fa-calendar"></i> '+picker.startDate.format('DD.MM.YYYY') + ' - ' + picker.endDate.format('DD.MM.YYYY')+' <i class="fa fa-caret-down"></i>');
    });

    $('.big_dropdown').on('cancel.daterangepicker', function(ev, picker) {
        $(this).html('<i class="fa fa-calendar"></i> Oggi <i class="fa fa-caret-down"></i>');
        $("#periodo").val('');
    });

    $('.agenda-culturale #formRicerca select').change(function (){
        $('#formRicerca').submit();

    });

    $('#ricercaButton').click(function (){
        $('#formRicerca').submit();
    });

}

function initFormularioAgenda(){
    var uploadFile = {};
    var url = '/fileadmin/DECS/DCSU/AC/OSSERVATORIO/segnaliazioni/';
    var loading = false;
    var prestazioniUpload = false;
    var date_n = 1
    var max_date_n = 4
    function init(){


        $('.add-date').click(addDate)
        $('#formulario_osservatorio').on('click', '.remove-date', removeDate)

        $('.send-form').click(send);

        $.getScript(url+'securimage/securimage.js', function (){
            captcha_image_audioObj = new SecurimageAudio({ audioElement: 'captcha_image_audio', controlsElement: 'captcha_image_audio_controls' });
        });

        $.fn.datepicker.dates['it'] = {
            days: ["Domenica", "Lunedì", "Martedì", "Mercoledì", "Giovedì", "Venerdì", "Sabato", "Domenica"],
            daysShort: ["Dom", "Lun", "Mar", "Mer", "Gio", "Ven", "Sab", "Dom"],
            daysMin: ["Do", "Lu", "Ma", "Me", "Gi", "Ve", "Sa", "Do"],
            months: ["Gennaio", "Febbraio", "Marzo", "Aprile", "Maggio", "Giugno", "Luglio", "Agosto", "Settembre", "Ottobre", "Novembre", "Dicembre"],
            monthsShort: ["Gen", "Feb", "Mar", "Apr", "Mag", "Giu", "Lug", "Ago", "Set", "Ott", "Nov", "Dic"],
            today: "Oggi",
            clear: "Svuota"
        };

        $('#inizio, #fine').datepicker({
            format: "dd.mm.yyyy",
            language: 'it',
        });

        initMultiUpload1();
        initMultiUpload2();
    }
    
    function addDate(e){
        e.preventDefault()

        var c = $(this).prev().clone()
        c.attr('class', 'new-date')

        $(this).prev().before(c)

        $('.new-date:eq('+(date_n-1)+') input[name*=inizio], .new-date:eq('+(date_n-1)+') input[name*=fine]').datepicker({
            format: "dd.mm.yyyy",
            language: 'it',
        });

        date_n++
        if(date_n == max_date_n){
            $('.add-date').addClass('hidden')
        }
    }
    function removeDate(e){
        e.preventDefault()

        $(this).parents('.new-date').remove()
        date_n--
        $('.add-date').removeClass('hidden')
    }
    function send(e){
        e.preventDefault();

        if(!loading){
            loading = true;

            var error = false;

            if(!checkField('#titolo')) error = true;
            if(!checkField('#nomeLuogo')) error = true;
            if(!checkField('#citta')) error = true;
            if(!checkField('#inizio')) error = true;


            if($('#fine').val()){
                var from = moment($('#inizio').val(), 'DD.MM.YYYY')
                var to = moment($('#fine').val(), 'DD.MM.YYYY')
                if(!to.isAfter(from) && !to.isSame(from)){
                    $('#fine').siblings('.error-messages').removeClass('hidden')
                    error = true
                }
                else $('#fine').siblings('.error-messages').addClass('hidden')
            }
            else $('#fine').siblings('.error-messages').addClass('hidden')

            if($('.new-date').length){
                for(x=0;x<$('.new-date').length;x++){
                    var o = $('.new-date:eq('+x+')')
                    var inizio = o.find('input[name*=inizio]')
                    if(!inizio.val()){
                        inizio.siblings('.error-messages').removeClass('hidden')
                        error = true
                    }
                    else{
                        inizio.siblings('.error-messages').addClass('hidden')
                        var fine = o.find('input[name*=fine]')
                        if(fine.val()){
                            var from = moment(inizio.val(), 'DD.MM.YYYY')
                            var to = moment(fine.val(), 'DD.MM.YYYY')
                            if(!to.isAfter(from) && !to.isSame(from)){
                                fine.siblings('.error-messages').removeClass('hidden')
                                error = true
                            }
                            else fine.siblings('.error-messages').addClass('hidden')
                        }
                        else fine.siblings('.error-messages').addClass('hidden')
                    }
                }
            }

            if($('#organizzatore').val() == '' && $('#nomeOrganizzatore').val() == ''){
                checkField('#organizzatore')
                checkField('#nomeOrganizzatore')
                error = true
            }
            else {
                $('#organizzatore').siblings('.error-messages').addClass('hidden')
                $('#nomeOrganizzatore').siblings('.error-messages').addClass('hidden')
            }
           
            if(!checkField('#email', 'email')) error = true;
            
            if(!error){
                if(!checkCaptchaField()) error = true;
            }

            if(!error){

                $('form').submit()
               
            }
            else{
                $('html, body').animate({scrollTop: $('.error-messages:first').offset().top - 70}, 500)
                loading = false;
            }
        }
    }
    function checkField(s, type){
        if(typeof type == 'undefined'){
            if($(s).val() == ''){
                $(s).siblings('.error-messages').removeClass('hidden');
                return false;
            }
            else{
                $(s).siblings('.error-messages').addClass('hidden');
                return true;
            }
        }
        else if(type == 'radio' || type == 'checkbox'){
            if($(s+':checked').length == 0){
                $(s+':first').parent().parent().siblings('.error-messages').removeClass('hidden');
                return false;
            }
            else{
                $(s+':first').parent().parent().siblings('.error-messages').addClass('hidden');
                return true;
            }
        }
        else if(type == 'email'){
            if($(s).val() == '' || !checkEmail($(s).val())){
                $(s).siblings('.error-messages').removeClass('hidden');
                return false;
            }
            else{
                $(s).siblings('.error-messages').addClass('hidden');
                return true;
            }
        }
        else if(type == 'date'){
            if($(s).val() == '' || !checkDate($(s).val())){
                $(s).siblings('.error-messages').removeClass('hidden');
                return false;
            }
            else{
                $(s).siblings('.error-messages').addClass('hidden');
                return true;
            }
        }
    }
    function checkEmail(email) {
        var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(String(email).toLowerCase());
    }
    function checkDate(value){
        if(new RegExp("[0-9]{2}\.[0-9]{2}\.[0-9]{4}").test(value)) return true;
        else return false;
    }
    function checkCaptchaField(){
        var field = $('input[name=captcha]');
        var error = false;

        if(field.val()){
            var r = checkCaptcha(field.val());
            if(r.responseText == 'ok'){
                field.removeClass('error');
                $('.captcha .error-messages').addClass('hidden');
            }
            else{
                field.addClass('error').val('');
                $('.refresh-button').trigger('click');
                $('.captcha .error-messages').removeClass('hidden');
                error = true;
            }
        }
        else{
            field.addClass('error');
            $('.refresh-button').trigger('click');
            $('.captcha .error-messages').removeClass('hidden');
            error = true;
        }

        if(!error) return true;
        return false;
    }
    function checkCaptcha(value){
        var rand = Math.floor((Math.random() * 100000) + 1);
        return $.ajax({
            url: url+'securimage/check.php?r='+rand,
            data: {
                value: value
            },
            async: false,
            method: 'post'
        });
    }
    function initMultiUpload1(){
        var attachments_n = 1;
        var max_uploads = 1;
        var max_weight = 10;
        var working = false;
        var uploadButtonContent = '';
        function init(){

            $('#formulario_osservatorio').on('click', '.allegati1 button', addAttachemnt);
            $('#formulario_osservatorio').on('change', '.allegati1 input', change);
        }
        function addAttachemnt(e){
            e.preventDefault();

            if(!working){
                
                $('#formulario_osservatorio .allegati1 input').trigger('click');
            }
        }
        
        function change(event){
            var id = $(this).attr('id');

            tmp = $(this).val().split("\\");
            var v = tmp[tmp.length - 1];

            if(v){
                tmp2 = v.split('.');
                var ext = tmp2[(tmp2.length - 1)];


                $('.allegati1 .error-messages, .allegati1 .error-messages-type, .allegati1 .error-messages-size').addClass('hidden');

                if(ext != 'jpg' && ext != 'jpeg' && ext != 'png' && ext != 'PNG' && ext != 'JPG'){
                    // Type error
                    $('.allegati1 .error-messages-type').removeClass('hidden');
                   
                }
                else{
                    if(Math.round(event.target.files[0].size / 1048576) > max_weight){
                        // Size error
                        $('.allegati1 .error-messages-size').removeClass('hidden');
                        
                    }
                    else{
                        $('.allegati1 .filename').text(v);

                        uploadFile[id] = event.target.files;
                      
                    }
                }
            }
        }
        init();
    }
    function initMultiUpload2(){
        var attachments_n = 1;
        var max_uploads = 1;
        var max_weight = 10;
        var working = false;
        var uploadButtonContent = '';
        function init(){

            $('#formulario_osservatorio').on('click', '.allegati2 button', addAttachemnt);
            $('#formulario_osservatorio').on('change', '.allegati2 input', change);
        }
        function addAttachemnt(e){
            e.preventDefault();

            if(!working){
                $('#formulario_osservatorio .allegati2 input').trigger('click');
            }
        }
        
        function change(event){
            var id = $(this).attr('id');

            tmp = $(this).val().split("\\");
            var v = tmp[tmp.length - 1];

            if(v){
                tmp2 = v.split('.');
                var ext = tmp2[(tmp2.length - 1)];


                $('.allegati2 .error-messages, .allegati2 .error-messages-type, .allegati2 .error-messages-size').addClass('hidden');

                if(ext != 'pdf'){
                    // Type error
                    $('.allegati2 .error-messages-type').removeClass('hidden');
                   
                }
                else{
                    if(Math.round(event.target.files[0].size / 1048576) > max_weight){
                        // Size error
                        $('.allegati2 .error-messages-size').removeClass('hidden');
                     
                    }
                    else{
                        $('.allegati2 .filename').text(v);

                        uploadFile[id] = event.target.files;
                       
                    }
                }
            }
        }
        init();
    }
    init();
}
/* ApriChiudi */
function ApriChiudi() {
    try {
        jQuery(".msg_body").hide();
        jQuery(".msg_body.aperto").slideToggle(500);
        // jQuery(".msg_head").toggleClass("SimboloMeno");

        jQuery(".msg_head").click(function () {
            jQuery(this).next(".msg_body").slideToggle(500);
            jQuery(this).toggleClass("SimboloMeno");
        });
    } catch (e) { }
}

/* ApriChiudiSingolo */
function ApriChiudiSingolo() {
    try {
        jQuery(".msg_body").hide(500);
        jQuery(".msg_body.aperto").slideToggle(500);
        jQuery(".msg_head.SimboloMeno").toggleClass("nosimbolo"); // test

        jQuery(".msg_head").click(function () {
            // jQuery(".msg_body").hide();
            jQuery(".msg_body").hide(500);
            jQuery(".msg_head").toggleClass("SimboloMeno", false);
            jQuery(".msg_head").toggleClass("nosimbolo", false); // test
            jQuery(this).next(".msg_body").slideToggle(500);
            jQuery(this).toggleClass("SimboloMeno");
            jQuery(this).toggleClass("nosimbolo"); // test
        });
    } catch (e) { }
}
function initAreaMedia(){

    $('head').append('<link href="https://fonts.googleapis.com/css?family=IBM+Plex+Serif:400,700" rel="stylesheet">');



    $("#areaMediaPrint").click(function() {
        $("#showComunicato").show();
        window.print();

    });


    $('.downloadAreaMedia').click(function(e) {


        $.ajaxTransport("+binary", function(options, originalOptions, jqXHR){
            // check for conditions and support for blob / arraybuffer response type
            if (window.FormData && ((options.dataType && (options.dataType == 'binary')) || (options.data && ((window.ArrayBuffer && options.data instanceof ArrayBuffer) || (window.Blob && options.data instanceof Blob)))))
            {
                return {
                    // create new XMLHttpRequest
                    send: function(_, callback){
                // setup all variables
                        var xhr = new XMLHttpRequest(),
                            url = options.url,
                            type = options.type,
                // blob or arraybuffer. Default is blob
                            dataType = options.responseType || "blob",
                            data = options.data || null;

                        xhr.addEventListener('load', function(){
                            var data = {};
                            data[options.dataType] = xhr.response;
                // make callback and send data
                            callback(xhr.status, xhr.statusText, data, xhr.getAllResponseHeaders());
                        });

                        xhr.open(type, url, true);
                        xhr.responseType = dataType;
                        xhr.send(data);
                    },
                    abort: function(){
                        jqXHR.abort();
                    }
                };
            }
        });


        var splitterA = $(this).attr('id').split(',');
        var urlMio = splitterA[0];
        console.log(urlMio);
        $.ajax({
              url: urlMio,
              type: "GET",
              dataType: 'binary',
              success: function(result) {
                var url = URL.createObjectURL(result);
                var $a = $('<a />', {
                  'href': url,
                  'download': splitterA[1],
                  'text': "click"
                }).hide().appendTo("body")[0].click();
                setTimeout(function() {
                  URL.revokeObjectURL(url);
                }, 10000);
              }
            });



    });


    if($('.daterange').length){
        var startDate = false;
        var endDate = false;

        if($('.btn.btn-default.daterange .filter-option').text().indexOf('Periodo') == -1){
            var text = $('.btn.btn-default.daterange .filter-option').text();
            // $("#periodo").val(text);
            var tmp = text.split('-');
            startDate = tmp[0];
            endDate = tmp[1];
        }

        $('.daterange').daterangepicker({
            autoUpdateInput: false,
            startDate: startDate,
            endDate: endDate,
            locale: {
              format: 'DD.MM.YYYY',
              firstDay: 1,
              cancelLabel: 'Cancella',
              applyLabel: 'Applica',
              customRangeLabel: "Custom",
              daysOfWeek: ["Do","Lu","Ma","Me","Gi","Ve", "Sa"],
              monthNames: ["Gennaio","Febbraio","Marzo","Aprile","Maggio","Giugno","Luglio","Agosto","Settembre","Ottobre","Novembre","Dicembre"]
            }
        },
        function(start, end) {
            var startDate = start;
            var endDate = end;

            var val=startDate.format('D.MM.YYYY') + '-' + endDate.format('D.MM.YYYY');
            $("#periodo").val(val);
            $('#ricerca').submit();
           }
        );

        $('.daterange').on('apply.daterangepicker', function(ev, picker) {
            $(this).html('<span class="filter-option pull-left">'+picker.startDate.format('DD.MM.YYYY') + ' - ' + picker.endDate.format('DD.MM.YYYY')+'</span> <span class="calendar"></span>');
        });

        $('.daterange').on('cancel.daterangepicker', function(ev, picker) {
            $(this).html('<span class="filter-option pull-left">Periodo</span>&nbsp;<span class="calendar"></span>');
        });
    }


}
/* Aste */
function initAste(){
    var url = '/typo3conf/ext/user_diasteonline/';
    var pagination_n = 9;
    var items_n = 0;
    var selectedCategory = 'all';
    var link = '';
    var fadeTimeout = 150;
    function init(){
        $('.nav button').click(changeCategory);

        if($('#aste .list a:eq(0)').length) link = $('#aste .list a:eq(0)').attr('href').split('?')[0];

        // init list
        $('#aste .list').after('<div class="hidden list_all"></div>')
        $('#aste .list_all').html($('#aste .list').html());
        pagination2();


    }
    function changeCategory(e) {
        e.preventDefault();

        if(!$(this).hasClass('btn-primary')){
            $('.nav .btn-primary').addClass('btn-default').removeClass('btn-primary');
            $(this).addClass('btn-primary').removeClass('btn-default');

            var data = {
                type: $(this).attr('data-type'),
                link: link
            };

            if(data.type != selectedCategory){
                selectedCategory = data.type;

                $('#aste .divSpagina').hide();
                if(data.type == 'all'){
                    $('#aste .list').html($('#aste .list_all').html());
                    pagination2();
                }
                else{
                    $.getJSON(url+'request.php', data, function (r){

                        if(r.length){
                            var n = 1;
                            var nn = 1;
                            var html = '';
                            for(x in r){
                                if(nn == 1) html += '<div class="page">';
                                if(n == 1) html += '<div class="row">';

                                html += r[x];

                                if(n == 3){
                                    html += '</div>';
                                    n = 1;
                                }
                                else n++;

                                if(nn == pagination_n){
                                    html += '</div>';
                                    nn = 1;
                                }
                                else nn++;
                            }

                            if(n < 3 && n > 1) html += '</div>';
                            if(nn < pagination_n && nn > 1) html += '</div>';

                            $('#aste .list').html(html);

                            if(r.length > pagination_n){
                                pagination(r);
                            }
                            else{
                                $('#aste .page:eq(0)').show();
                                setTimeout(function (){
                                    $('#aste .page:eq(0)').addClass('show');
                                }, fadeTimeout);
                            }
                        }
                        else{
                            $('#aste .list').html('<p class="bodytext">Nessun asta in questa categoria</p>')
                        }
                    });
                }
            }
        }
    }
    var lastPage;
    function pagination(items){

        lastPage = 0;

        $('.divSpagina').remove();

        items_n = items.length;

        html = '<div class="divSpagina"><span>Risultati 1 - '+pagination_n+' di '+items_n+'</span><ul class="pagination"><li class=""><a href="#" class="first">«</a></li><li class=""><a href="#" class="prev">‹</a></li>';

        var n = 0;
        var nn = 1;
        for(x=0;x<items.length;x++){
            n++;
            if(n == pagination_n) {
                html += '<li><a href="#" data-n="'+nn+'">'+nn+'</a></li>';
                nn++;
                n = 0;
            }
        }
        if(n > 0){
            n++;
            html += '<li><a href="#" data-n="'+nn+'">'+nn+'</a></li>';
        }


        html += '<li><a href="#" class="next">›</a></li><li><a href="#" class="last">»</a></li></ul></div>';
        $('#aste .list').after(html);

        $('.pagination [data-n=1]').parent().addClass('active');
        $('#aste .page:eq(0)').show();
        setTimeout(function (){
            $('#aste .page:eq(0)').addClass('show');
        }, fadeTimeout);


        updatePagination();

        $('.pagination a').click(function (e){
            e.preventDefault();

            if(!$(this).parent().hasClass('disabled')){
                $('.pagination .active').removeClass('active');
                if($(this).is('[data-n]')){

                    $(this).parent().addClass('active');

                    var n = $(this).attr('data-n') - 1;

                    $('#aste .page:eq('+lastPage+')').removeClass('show');
                    setTimeout(function (){
                        $('#aste .page:eq('+lastPage+')').hide();
                        $('#aste .page:eq('+n+')').show();
                        setTimeout(function (){
                            $('#aste .page:eq('+n+')').addClass('show');lastPage = n;
                        updatePagination();
                        }, fadeTimeout);

                    }, 700);
                }
                else if($(this).hasClass('first')){
                    n = 0
                    $('.pagination li a[data-n='+(n+1)+']').parent().addClass('active');

                    $('#aste .page:eq('+lastPage+')').removeClass('show');
                    setTimeout(function (){
                        $('#aste .page:eq('+lastPage+')').hide();
                        $('#aste .page:eq('+n+')').show();
                        setTimeout(function (){
                            $('#aste .page:eq('+n+')').addClass('show');lastPage = 0;
                        updatePagination();
                        }, fadeTimeout);

                    }, 700);
                }
                else if($(this).hasClass('prev')){
                    n = lastPage - 1;
                    $('.pagination li a[data-n='+(n+1)+']').parent().addClass('active');

                    $('#aste .page:eq('+lastPage+')').removeClass('show');
                    setTimeout(function (){
                        $('#aste .page:eq('+lastPage+')').hide();
                        $('#aste .page:eq('+n+')').show();
                        setTimeout(function (){
                            $('#aste .page:eq('+n+')').addClass('show');lastPage = n;
                        updatePagination();
                        }, fadeTimeout);

                    }, 700);
                }
                else if($(this).hasClass('last')){
                    // n = $('.pagination li').length - 4;

                    // $('.pagination li a[data-n='+(n)+']').parent().addClass('active');

                    // $('#aste .page:eq('+lastPage+')').removeClass('show');
                    // setTimeout(function (){
                    //     $('#aste .page:eq('+lastPage+')').hide();
                    //     $('#aste .page:eq('+n+')').show();
                    //     setTimeout(function (){
                    //         $('#aste .page:eq('+n+')').addClass('show');
                    //     }, fadeTimeout);
                    //     lastPage = n - 1;
                    //     updatePagination();
                    // }, 700);


                    n = $('.pagination li').length - 4;

                    $('.pagination li a[data-n='+(n)+']').parent().addClass('active');

                    $('#aste .page:eq('+lastPage+')').removeClass('show');
                    setTimeout(function (){
                        $('#aste .page:eq('+lastPage+')').hide();
                        $('#aste .page:eq('+(n-1)+')').show();
                        setTimeout(function (){
                            $('#aste .page:eq('+(n-1)+')').addClass('show');lastPage = n-1;
                        updatePagination();
                        }, fadeTimeout);

                    }, 700);
                }
                else if($(this).hasClass('next')){
                    n = lastPage + 1;
                    $('.pagination li a[data-n='+(n+1)+']').parent().addClass('active');

                    $('#aste .page:eq('+lastPage+')').removeClass('show');
                    setTimeout(function (){
                        $('#aste .page:eq('+lastPage+')').hide();
                        $('#aste .page:eq('+n+')').show();
                        setTimeout(function (){
                            $('#aste .page:eq('+n+')').addClass('show');lastPage = n;
                        updatePagination();
                        }, fadeTimeout);

                    }, 700);
                }

                $('body').animate({ scrollTop: 0 }, 600);
            }
        })
    }
    function pagination2(){

        lastPage = 0;

        $('.divSpagina').remove();

        items_n = $('#aste .list_all .page .col-xs-4').length;

        html = '<div class="divSpagina"><span>Risultati 1 - '+pagination_n+' di '+items_n+'</span><ul class="pagination"><li class=""><a href="#" class="first">«</a></li><li class=""><a href="#" class="prev">‹</a></li>';

        var n = 0;
        var nn = 1;
        for(x=0;x<$('#aste .list_all .page').length;x++){
            // n++;
            // if(n == pagination_n) {
                html += '<li><a href="#" data-n="'+(x+1)+'">'+(x+1)+'</a></li>';
                // nn++;
                // n = 0;
            // }
        }

        html += '<li><a href="#" class="next">›</a></li><li><a href="#" class="last">»</a></li></ul></div>';
        $('#aste .list').after(html);

        $('.pagination [data-n=1]').parent().addClass('active');
        // $('#aste .page:eq(0)').show();
        // setTimeout(function (){
        //     $('#aste .page:eq(0)').addClass('show');
        // }, fadeTimeout);


        updatePagination();

        $('.pagination a').click(function (e){
            e.preventDefault();

            if(!$(this).parent().hasClass('disabled')){
                $('.pagination .active').removeClass('active');
                if($(this).is('[data-n]')){

                    $(this).parent().addClass('active');

                    var n = $(this).attr('data-n') - 1;

                    $('#aste .page:eq('+lastPage+')').removeClass('show');
                    setTimeout(function (){
                        $('#aste .page:eq('+lastPage+')').hide();
                        $('#aste .page:eq('+n+')').show();
                        setTimeout(function (){
                            $('#aste .page:eq('+n+')').addClass('show');lastPage = n;
                        updatePagination();
                        }, fadeTimeout);

                    }, 700);
                }
                else if($(this).hasClass('first')){
                    n = 0
                    $('.pagination li a[data-n='+(n+1)+']').parent().addClass('active');

                    $('#aste .page:eq('+lastPage+')').removeClass('show');
                    setTimeout(function (){
                        $('#aste .page:eq('+lastPage+')').hide();
                        $('#aste .page:eq('+n+')').show();
                        setTimeout(function (){
                            $('#aste .page:eq('+n+')').addClass('show');lastPage = 0;
                        updatePagination();
                        }, fadeTimeout);

                    }, 700);
                }
                else if($(this).hasClass('prev')){
                    n = lastPage - 1;
                    $('.pagination li a[data-n='+(n+1)+']').parent().addClass('active');

                    $('#aste .page:eq('+lastPage+')').removeClass('show');
                    setTimeout(function (){
                        $('#aste .page:eq('+lastPage+')').hide();
                        $('#aste .page:eq('+n+')').show();
                        setTimeout(function (){
                            $('#aste .page:eq('+n+')').addClass('show');lastPage = n;
                        updatePagination();
                        }, fadeTimeout);

                    }, 700);
                }
                else if($(this).hasClass('last')){
                    n = $('.pagination li').length - 4;

                    $('.pagination li a[data-n='+(n)+']').parent().addClass('active');

                    $('#aste .page:eq('+lastPage+')').removeClass('show');
                    setTimeout(function (){
                        $('#aste .page:eq('+lastPage+')').hide();
                        $('#aste .page:eq('+(n-1)+')').show();
                        setTimeout(function (){
                            $('#aste .page:eq('+(n-1)+')').addClass('show');lastPage = n-1;
                        updatePagination();
                        }, fadeTimeout);

                    }, 700);
                }
                else if($(this).hasClass('next')){
                    n = lastPage + 1;
                    $('.pagination li a[data-n='+(n+1)+']').parent().addClass('active');

                    $('#aste .page:eq('+lastPage+')').removeClass('show');
                    setTimeout(function (){
                        $('#aste .page:eq('+lastPage+')').hide();
                        $('#aste .page:eq('+n+')').show();
                        setTimeout(function (){
                            $('#aste .page:eq('+n+')').addClass('show');lastPage = n;
                        updatePagination();
                        }, fadeTimeout);

                    }, 700);
                }

                $('body').animate({ scrollTop: 0 }, 600);
            }
        })
    }
    function showPage(){
        $('#aste .page:eq('+lastPage+')').removeClass('show');
        setTimeout(function (){
            $('#aste .page:eq('+lastPage+')').hide();
            $('#aste .page:eq('+n+')').show();
            setTimeout(function (){
                $('#aste .page:eq('+n+')').addClass('show');
            }, fadeTimeout);
        }, 700);
    }
    function updatePagination(){

        var i = $('.pagination .active').index();
        var n = $('.pagination li').length;

        if(i == 2){
            $('.pagination li:eq(0)').addClass('disabled');
            $('.pagination li:eq(1)').addClass('disabled');
        }
        else if(i == 3){
            $('.pagination li:eq(0)').addClass('disabled');
            $('.pagination li:eq(1)').removeClass('disabled');
        }
        else{
            $('.pagination li:eq(0)').removeClass('disabled');
            $('.pagination li:eq(1)').removeClass('disabled');
        }


        if(i == n - 2 - 1){
            $('.pagination li:eq('+(n - 2 - 1 + 1)+')').addClass('disabled');
            $('.pagination li:eq('+(n - 2 - 1 + 2)+')').addClass('disabled');
        }
        else if(i == n - 3 - 1){
            $('.pagination li:eq('+(n - 2 - 1 + 2)+')').addClass('disabled');
            $('.pagination li:eq('+(n - 2 - 1 + 1)+')').removeClass('disabled');
        }
        else{
            $('.pagination li:eq('+(n - 2 - 1 + 1)+')').removeClass('disabled');
            $('.pagination li:eq('+(n - 2 - 1 + 2)+')').removeClass('disabled');
        }

        var nnnn = ((i - 1) * pagination_n);


        if(nnnn > items_n) nnnn = items_n;
//
        // console.log(nnnn)
        // console.log(parseInt($('.page.show:visible .col-xs-4').length))
        // console.log(nnnn - parseInt($('.page.show:visible .col-xs-4').length) + 1)

        $('.divSpagina > span').html('Risultati '+(nnnn - parseInt($('.page.show:visible .col-xs-4').length) + 1)+' - '+nnnn+' di '+items_n)
    }
    init();
}

/* Box Tematiche */
function initTematicaBox() {
    $('.box-tematica .box').click(function (e) {
        e.preventDefault();
        if ($(this).hasClass('opened')) {
            $(this).removeClass('opened');
        }
        else {
            $('.box-tematica .box.opened').removeClass('opened');
            $(this).addClass('opened')
        }
    })
}
function initCanicolaMap(){
    var data
    var mouseTimer
    function init(){
        $.getJSON('/fileadmin/DSS/DSP/canicola/map-data.php', function (r){
            if(r && r[301]){
                data = r
                for(x in r){
                    $('#canicola_map_container [data-id='+x+']').attr('class', 'lv'+r[x].level)
                }
                $('#canicola_map_container').removeClass('hidden')
                $('#canicola_map #regioni g').hover(mIn, mOut)
            }
        })
    }
    function mIn(){

        if(mouseTimer) clearTimeout(mouseTimer)

        var d = data[$(this).data('id')]
        var html = ''
        html += '<b>Regione</b><br><span>'+d.title+'</span><br>'
        html += '<b>Grado</b><br><span>'+d.level+'</span><br>'
        if(d.level != 0) html += '<b>Evento</b><br><span>'+d.event+'</span><br>'
        // html += '<b>Probabilità</b><br><span>'+d.certainty+'</span><br>'

        $('#canicola_map_legend').html(html)
    }
    function mOut(){
        mouseTimer = setTimeout(function (){
            $('#canicola_map_legend').html('Seleziona una regione per vedere i dettagli sulla canicola')
        }, 200)
    }
    init()
}
function initComuni(){
	$("#sliderComuni").carousel();
}
/* Contatto */
function initModuloContattato(){
    var htmlOverlay = '<div class="overlay" tabindex="-1" style="text-align:center; opacity:1;background-color: rgba(0,0,0,0.9)"></div><div class="overlay-close"><div class="inner"><a href="#" title="Chiudi" aria-label="Chiudi"><i class="fa fa-times" aria-hidden="true"></i></a></div></div>';
    var url = '/typo3conf/ext/user_contatti/requests/';
    var contactData = {};
    function init(){
        $('.modulo_contatto').click(openModal);

    }
    function openModal(e){
        e.preventDefault();

        overlayOpener = $(this);

        var data = {
            idua: $(this).attr('data-idua'),
            dip: $(this).attr('data-dip'),
            url: location.href,
            title: $(this).attr('data-title') ? $(this).attr('data-title') : $(this).attr('data-titolo'),
            lang: $(this).attr('data-lang') ? $(this).attr('data-lang') : 'it'
        };
        contactData = data;

        $.post(url+'load.php', data, function (r){

            // FIX a problema su IE e FF - se cé un video wowza viene mostrato sopra il form
            if($('.tx-tichwowza-pi2 object').length){
                $('.tx-tichwowza-pi2 object').css('visibility', 'hidden');
            }

            $('body').append(htmlOverlay);
            $('.overlay-close').click(function (e){
                e.preventDefault();
                hideOverlay();
            });
            $('.overlay').html(r);

            var h = $(".background").outerHeight() + $(".footer").outerHeight();
            var wh = (window.innerHeight|| document.documentElement.clientHeight || document.body.clientHeight) - 50;
            var fh = $('#contact-form').height() + 50;
            if(h < wh) h = wh;
            if(h < fh) h = fh;
            if($('#ti-map').length) h += 350
            $('.overlay').css({'height': h});

            $('html, body').animate({ scrollTop: 0 }, 500);

            initForm();

            setTimeout(function (){ $('#contact-form').addClass('shown'); }, 300);

            $(window).on('keydown', function (e){
                if(e.keyCode == 27){
                    $('.overlay-close a').trigger('click');
                }
            })
        });
    }
    /* Form */
    var errorMessages = {
        'it': {
            'empty': 'Campo obbligatorio',
            'radio-empty': 'Campo obbligatorio',
            'email': 'L\'e-mail inserita non è corretta',
            'phone': 'Il campo non può contenere caratteri',
            'shareThankyou': 'Il messaggio è stato correttamente inviato',
            'thankyou': 'Grazie del suo messaggio',
            'sent': 'Il messaggio è stato correttamente inviato all’unità amministrativa competente',
            'errorTitle': 'Errore di invio',
            'errorText': 'Il messaggio non è stato correttamente inviato, la preghiamo di riprovare.</br>Qualora il problema persista contattare webmaster@ti.ch.<br>Grazie della comprensione',
            'fillCorrectly': 'Compilare il campo correttamente',
            'notEmpty': 'Il campo non può essere vuoto',
            'maxFilesize': 'L\'allegato supera il limite consentito di 10MB',
            'uploadError': 'Errore durante il caricamento degli allegati',
            'wrongFormat': 'Il formato del file selezionato non é permesso'
        },
        'en': {
            'empty': 'Required field',
            'radio-empty': 'Required field',
            'email': 'The inserted email is incorrect',
            'phone': 'The field can not contain characters',
            'shareThankyou': 'The message was successfully sent',
            'thankyou': 'Thank you for your message',
            'sent': 'The message was successfully sent',
            'errorTitle': 'Sending error',
            'errorText': 'The message has not been successfully submitted, please try again. <br> If the problem persists contact webmaster@ti.ch. <br> Thank you for your understanding',
            'fillCorrectly': 'Fill in the field correctly',
            'notEmpty': 'The field can not be empty',
            'maxFilesize': 'The attachment exceeds the allowed limit of 10MB',
            'uploadError': 'Error loading attachments',
            'wrongFormat': 'The format of the selected file is not allowed'
        }
    };
    var loadJs = true;
    var sendButtonContent = '';
    var uploadButtonContent = '';
    var recaptchaChecked = false;
    function initForm(){
        $('#contact-form .send-form').width($('#contact-form .send-form').width());
        sendButtonContent = $('#contact-form .send-form').html();

        $('#contact-form .allegati .add').width($('#contact-form .allegati .add').width());
        uploadButtonContent = $('#contact-form .allegati .add').html();

        $('#contact-form .send-form').click(sendForm);
        $('.refresh-button').trigger('click')
        $('#contact-form .form-group').each(function (){
            if($(this).children('div.row').length){
                $(this).children('div.row').children().each(function (){
                    $(this).append('<div class="error-messages hidden"></div>');
                })
            }
            else $(this).append('<div class="error-messages hidden"></div>');
        });

        $('a.info-button').click(function (e){ e.preventDefault(); });

        initMultiUpload();

        $('.overlay .col-xs-4 h4').click(function (){
            $('.overlay .col-xs-8 input[data-check], .overlay .col-xs-8 textarea[data-check]').each(function (){
                var name = ($(this).attr('name') == 'email') ? 'test@test.com' : $(this).attr('name');
                $(this).val(name);
            });
        });

        if($('.info-button').length){
            $('.info-button').popover();
            $('a.info-button').click(function (e){ e.preventDefault(); });
        }

        jQuery("#contact-form").highlighter({
            "selector" : ".holder",
            "minWords" : 1
        });

        $('#contact-form input[type=text]:first').focus();



        // Tab navigation
        mouseTrap($('.overlay input:first'), $('.overlay-close a'));



        $('input[type=radio][name=ente]').click(function (){
            if($(this).attr('id') == 'altro_ente'){
                $('#nome_altro_ente').removeClass('hidden');
                $('#nome_comune').addClass('hidden');
            }
            else if($(this).attr('id') == 'comune'){
                $('#nome_altro_ente').addClass('hidden');
                $('#nome_comune').removeClass('hidden');
            }
            else {
                $('#nome_altro_ente').addClass('hidden');
                $('#nome_comune').addClass('hidden');
            }
        });
        $('input[type=radio][name=ruolo]').click(function (){
            if($(this).attr('id') == 'altro_ruolo') $('#nome_altro_ruolo').removeClass('hidden');
            else $('#nome_altro_ruolo').addClass('hidden');
        });

    }
    function updateCaptcha(e){
        e.preventDefault();

        var src = $(this).siblings('img').attr('src');
        if(src.indexOf('?') > -1){
            tmp = src.split('?');
            src = tmp[0];
        }
        src += '?' + Math.random();
        $('.captcha img').attr('src', src);
    }
    function sendForm(e){
        e.preventDefault();

        var error = false;
        $('body').append('<div id="sending-form" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; z-index: 10002;"></div>');
        $('#contact-form .send-form').html('<i class="fa fa-spinner fa-spin"></i>');

        $('#contact-form [data-check]').each(function (){
            if(!checkField($(this))) error = true;
        });

        if($('#ti-map').length){
            if($('#coordX').val() == '' || $('#coordY').val() == ''){
                error = true;
                $('#ti-map').siblings('.error-messages').removeClass('hidden')
                $('#ti-map > div').css('border-color', '#ebccd1');
            }
            else{
                $('#ti-map').siblings('.error-messages').addClass('hidden')
                $('#ti-map > div').css('border-color', '#eee');
            }
        }
        else {
            $('#ti-map').siblings('.error-messages').addClass('hidden')
            $('#ti-map > div').css('border-color', '#eee');
        }

        if(!checkCaptchaField()){
           error = true;
        }

        if(!error){
            sendData(false);
            $('#sending-form').remove();
            $('#contact-form .send-form').html(sendButtonContent);
        }
        else {
            $('#sending-form').remove();
            $('#contact-form .send-form').html(sendButtonContent);
            $('.form-control.error:first').focus();
            $('.refresh-button').trigger('click');
        }
    }
    function sendData(attachments){
        var data = contactData;

        $('#contact-form [data-check]').each(function (){
            if($(this).attr('data-check') == 'radio-empty'){
                var i = $(this).find('input:checked');
                data[i.attr('name')] = i.val();
            }
            else if($(this).attr('data-check') == 'checkboxes-empty'){
                var text = [];
                $(this).find('input:checked').each(function (){
                    text.push($(this).val());
                });
                data[$(this).find('input:first:checked').attr('name')] = text.join(', ');
            }
            else if($(this).attr('type') == 'checkbox'){
                data[$(this).attr('name')] = ($(this).is(':checked')) ? 'si' : 'no';
            }
            else data[$(this).attr('name')] = $(this).val();
        });

        $('#contact-form select:not([data-check])').each(function (){
            data[$(this).attr('name')] = $(this).val();
        });

        if($('.allegato:not(.hidden)').length){
            var v = new Array();
            $('.allegato:not(.hidden) input').each(function (){
                v.push($(this).attr('data-file'));
            });
            data['allegati'] = v.join(';');
        }

        if($('#ti-map').length){
            data.coordx = $('#coordX').val();
            data.coordy = $('#coordY').val();
        }

        $.post(url+'send.php', data, function (r){
            $('html, body').animate({ scrollTop: 0 }, 500);
            $('#contact-form h2').remove();
            if(r == 'ok'){
                if($('.overlay h1').text() == 'Condividi') var text = '<h2 style="margin: 0 0 10px 0">'+errorMessages[contactData.lang].shareThankyou+'.</h2>';
                else var text = '<h2 style="margin: 0 0 10px 0">'+errorMessages[contactData.lang].thankyou+'</h2><p>'+errorMessages[contactData.lang].sent+'.</p>';
            }
            else{
                var text = '<h2 style="margin: 0 0 10px 0">'+errorMessages[contactData.lang].errorTitle+'</h2><p>'+errorMessages[contactData.lang].errorText+'.</p>';
            }

            $('#contact-form > .row:eq(1)').html('<div class="col-xs-12 conferma" role="alert">'+text+'</div>');
            $('#contact-form > .row:eq(1) h2').focus();

        });
    }
    function checkField(field){
        var error = false;
        var checks = field.attr('data-check');
        var messages = new Array();
        var v = field.val();
        if(checks.indexOf(',') > -1) checks = checks.split(',');
        else checks = new Array(checks);

        if(checks[0] == 'radio-empty'){
            var found = false;
            field.find('input').each(function (){
                if($(this).is(':checked')) found = true;
            });
            if(!found){
                messages.push('radio-empty');
                error = true;
            }
        }
        else if(checks[0] == 'checkboxes-empty'){
            var found = false;
            field.find('input').each(function (){
                if($(this).is(':checked')) found = true;
            });
            if(!found){
                messages.push('radio-empty');
                error = true;
            }
        }
        else{
            for(x in checks){
                if(checks[x] == 'empty'){
                    if(v == '' || ((v == '-' || v == '0') && field.is('select'))){
                        error = true;
                        messages.push('empty');
                    }
                }
                else if(checks[x] == 'email' && v){
                    var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
                    if(!re.test(v)){
                        error = true;
                        messages.push('email');
                    }
                }
            }
        }

        if(error){
            field.addClass('error');
            field.next().removeClass('hidden').html(getErrorMessage(messages));
            return false;
        }
        else{
            field.removeClass('error');
            field.next().addClass('hidden');
            return true;
        }
    }
    function checkCaptchaField(){
        var field = $('#contact-form [name=captcha]');
        var error = false;

        if(field.val()){
            var r = checkCaptcha(field.val());
            if(r.responseText == 'ok'){
                field.removeClass('error');
                if($('#contact-form .captcha .error-messages').length) $('#contact-form .captcha .error-messages').remove();
            }
            else{
                field.addClass('error').val('');
                $('#contact-form .captcha a').trigger('click');
                if($('#contact-form .captcha .error-messages').length) $('#contact-form .captcha .error-messages').remove();
                $('#contact-form .captcha').append('<div class="error-messages"><ul><li>'+errorMessages[contactData.lang].fillCorrectly+'</li></ul></div>')
                error = true;
            }
        }
        else{
            field.addClass('error');
            $('#contact-form .captcha a').trigger('click');

            if($('#contact-form .captcha .error-messages').length) $('#contact-form .captcha .error-messages').remove();
            $('#contact-form .captcha').append('<div class="error-messages"><ul><li>'+errorMessages[contactData.lang].notEmpty+'</li></ul></div>')
            error = true;
        }

        if(!error) return true;
        return false;
    }
    function checkCaptcha(value){
        var rand = Math.floor((Math.random() * 100000) + 1);
        return $.ajax({
            url: $('base').attr('href')+'user_librerie/securimage/check.php?r='+rand,
            data: {
                value: value
            },
            async: false,
            method: 'post'
        });
    }
    function getErrorMessage(messages){
        var html = '<ul>';
        for(x in messages){
            html += '<li role="alert">'+errorMessages[contactData.lang][messages[x]]+'</li>';
        }
        html += '</ul>';
        return html;
    }
    /* Allegati */
    function hasAttachments(){
        for(x in uploadFile){
            if(uploadFile[x]){
                return true;
            }
        }
        return false;
    }
    function uploadFiles(event){
        var data = new FormData();

        for(x in uploadFile){
            if(uploadFile[x]){
                $.each(uploadFile[x], function(key, value){
                    data.append('file'+x, value);
                });
            }
        }

        $.ajax({
            url: url+'upload.php', // point to server-side PHP script
            dataType: 'text',  // what to expect back from the PHP script, if anything
            cache: false,
            contentType: false,
            processData: false,
            data: data,
            type: 'post',
            success: function(php_script_response){
                if(php_script_response == 'filesize'){
                    if($('#attachments-error').length) $('#attachments-error').remove();
                    $('.allegato.hidden').after('<div id="attachments-error"><ul style="color:#c33;position: relative; top: -10px;"><ul>'+errorMessages[contactData.lang].maxFilesize+'.</li></ul></div>');
                }
                else if(php_script_response == 'error'){
                    if($('#attachments-error').length) $('#attachments-error').remove();
                    $('.allegato.hidden').after('<div id="attachments-error"><ul style="color:#c33;position: relative; top: -10px;"><ul>'+errorMessages[contactData.lang].uploadError+'.</li></ul></div>');
                }
                else sendData(php_script_response);

                $('#sending-form').remove();
                $('#contact-form .send-form').html(sendButtonContent);
            }
        });
    }
    var uploadFile = {};
    function initMultiUpload(){
        var attachments_n = 1;
        var max_weight = 10;
        var used_weight = 0;
        var working = false;
        function init(){
            $('#contact-form').on('click', '.allegati .add', addAttachemnt);
            $('#contact-form').on('click', '.allegati .remove', clearAttachemnt);

            $('#contact-form').on('change', '.inputfile', change);
        }
        function addAttachemnt(e){
            e.preventDefault();

            if(!working){
                $(this).siblings('.allegato.hidden.new').remove();

                if($('#attachments-error').length) $('#attachments-error').remove();

                $(this).prev().before($(this).siblings('.allegato.hidden').clone().addClass('new'));
                $('#contact-form .allegato.new label').attr('for', 'file'+attachments_n);
                $('#contact-form .allegato.new input').attr('id', 'file'+attachments_n).attr('name', 'file'+attachments_n);

                $('#contact-form .allegato.new input:last').trigger('click');

                attachments_n++;
            }
        }
        function clearAttachemnt(e){
            e.preventDefault();

            var id = $(this).parents('.allegato').find('input[type=file]').attr('id');
            uploadFile[id] = false;

            var p = $(this).parents('.allegato');
            used_weight -= parseInt(p.find('input').attr('data-weight'));
            updateWeights();

            p.find('input[type=file]').val('');
            p.find('input[type=file]').next().children('span').text('Allega un file');
            p.remove();
        }
        function change(event){
            var id = $(this).attr('id');

            tmp = $(this).val().split("\\");
            var v = tmp[tmp.length - 1];

            if(v){
                tmp2 = v.split('.');
                var ext = tmp2[(tmp2.length - 1)];

                if(ext == 'exe' || ext == 'bat' || ext == 'com'){
                    if($('#attachments-error').length) $('#attachments-error').remove();
                    $('.allegato.hidden:not(.new)').after('<div id="attachments-error"><p style="color:#c33;position: relative; top: -10px;">'+errorMessages[contactData.lang].wrongFormat+'.</p></div>');

                    $('label[for='+id+'] span').text('Allega un file (10Mb massimo)');
                }
                else{
                    $('label[for='+id+'] span').text(v);

                    if($('#attachments-error').length) $('#attachments-error').remove();


                    uploadFile[id] = event.target.files;

                    upload(id, event.target.files);
                }
            }
        }
        function upload(x, value){
            var data = new FormData();
            var upd = {
                x: value
            };

            $('body').append('<div id="sending-form" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; z-index: 10002;"></div>');
            $('#contact-form .allegati .add').html('<i class="fa fa-spinner fa-spin"></i>');
            working = true;

            for(x in upd){
                if(upd[x]){
                    $.each(upd[x], function(key, value){
                        data.append('file'+x, value);
                    });
                }
            }

            $.ajax({
                url: url+'upload.php?max='+(max_weight - used_weight), // point to server-side PHP script
                dataType: 'text',  // what to expect back from the PHP script, if anything
                cache: false,
                contentType: false,
                processData: false,
                data: data,
                type: 'post',
                success: function(php_script_response){

                    if(php_script_response == 'filesize'){
                        if($('#attachments-error').length) $('#attachments-error').remove();
                        $('.allegato.hidden:not(.new)').after('<div id="attachments-error"><ul style="color:#c33;position: relative; top: -10px;"><ul>L'+errorMessages[contactData.lang].maxFilesize+'.</li></ul></div>');
                    }
                    else if(php_script_response == 'error'){
                        if($('#attachments-error').length) $('#attachments-error').remove();
                        $('.allegato.hidden:not(.new)').after('<div id="attachments-error"><ul style="color:#c33;position: relative; top: -10px;"><ul>'+errorMessages[contactData.lang].uploadError+'.</li></ul></div>');
                    }
                    else{
                        var tmp = php_script_response.split('|');
                        used_weight += parseInt(tmp[1]);

                        $('.allegato.new.hidden input').attr('data-file', tmp[0]);
                        $('.allegato.new.hidden input').attr('data-weight', tmp[1]);

                        updateWeights()
                        $('.allegato.new.hidden').removeClass('new hidden');
                    }

                    $('#contact-form .allegati .add').html(uploadButtonContent);
                    $('#sending-form').remove();
                    // $('.allegati .add').removeClass('disabled');
                    working = false;
                }
            });
        }
        function updateWeights(){
            if(contactData.lang == 'en') $('.allegati h4').html('Attachments '+(used_weight)+' MB(maximum size allowed 10 MB)');
            else $('.allegati h4').html('Allegati '+(used_weight)+' MB(dimensione massima consentita 10 MB)');

            if(used_weight == max_weight) $('.allegati .add').hide();
            else $('.allegati .add').show();
        }
        init();
    }
    init();
}

function initModuloContattatoPage(){

    var url = '/typo3conf/ext/user_contatti/requests/';
    var contactData = {
        lang: $.urlParam('lang')
    };
    function init(){
        initForm();
        $('#contact-form').addClass('shown');
    }

    /* Form */
    var errorMessages = {
        'it': {
            'empty': 'Campo obbligatorio',
            'radio-empty': 'Campo obbligatorio',
            'email': 'L\'e-mail inserita non è corretta',
            'phone': 'Il campo non può contenere caratteri',
            'shareThankyou': 'Il messaggio è stato correttamente inviato',
            'thankyou': 'Grazie del suo messaggio',
            'sent': 'Il messaggio è stato correttamente inviato all’unità amministrativa competente',
            'errorTitle': 'Errore di invio',
            'errorText': 'Il messaggio non è stato correttamente inviato, la preghiamo di riprovare.</br>Qualora il problema persista contattare webmaster@ti.ch.<br>Grazie della comprensione',
            'fillCorrectly': 'Compilare il campo correttamente',
            'notEmpty': 'Il campo non può essere vuoto',
            'maxFilesize': 'L\'allegato supera il limite consentito di 10MB',
            'uploadError': 'Errore durante il caricamento degli allegati',
            'wrongFormat': 'Il formato del file selezionato non é permesso'
        },
        'en': {
            'empty': 'Required field',
            'radio-empty': 'Required field',
            'email': 'The inserted email is incorrect',
            'phone': 'The field can not contain characters',
            'shareThankyou': 'The message was successfully sent',
            'thankyou': 'Thank you for your message',
            'sent': 'The message was successfully sent',
            'errorTitle': 'Sending error',
            'errorText': 'The message has not been successfully submitted, please try again. <br> If the problem persists contact webmaster@ti.ch. <br> Thank you for your understanding',
            'fillCorrectly': 'Fill in the field correctly',
            'notEmpty': 'The field can not be empty',
            'maxFilesize': 'The attachment exceeds the allowed limit of 10MB',
            'uploadError': 'Error loading attachments',
            'wrongFormat': 'The format of the selected file is not allowed'
        }
    };
    var loadJs = true;
    var sendButtonContent = '';
    var uploadButtonContent = '';
    var recaptchaChecked = false;
    function initForm(){
        $('#contact-form .send-form').width($('#contact-form .send-form').width());
        sendButtonContent = $('#contact-form .send-form').html();

        $('#contact-form .allegati .add').width($('#contact-form .allegati .add').width());
        uploadButtonContent = $('#contact-form .allegati .add').html();

        $('#contact-form .send-form').click(sendForm);
        $('#contact-form .form-group').each(function (){
            if($(this).children('div.row').length){
                $(this).children('div.row').children().each(function (){
                    $(this).append('<div class="error-messages hidden"></div>');
                })
            }
            else $(this).append('<div class="error-messages hidden"></div>');
        });

        $('a.info-button').click(function (e){ e.preventDefault(); });

        initMultiUpload();

        if($('.info-button').length){
            $('.info-button').popover();
            $('a.info-button').click(function (e){ e.preventDefault(); });
        }
        setTimeout(function (){
            $('#contact-form input[type=text]:first').focus();
        }, 1000)

    }
    function updateCaptcha(e){
        e.preventDefault();

        var src = $('#captcha_image').attr('src');
        if(src.indexOf('?') > -1){
            tmp = src.split('?');
            src = tmp[0];
        }
        src += '?' + Math.random();
        $('.captcha img').attr('src', src);
    }
    function sendForm(e){
        e.preventDefault();

        var error = false;
        $('body').append('<div id="sending-form" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; z-index: 10002;"></div>');
        $('#contact-form .send-form').html('<i class="fa fa-spinner fa-spin"></i>');

        $('#contact-form [data-check]').each(function (){
            if(!checkField($(this))) error = true;
        });

        if(!checkCaptchaField()){
           error = true;
        }

        if(!error){
            sendData(false);
            $('#sending-form').remove();
            $('#contact-form .send-form').html(sendButtonContent);
        }
        else {
            $('#sending-form').remove();
            $('#contact-form .send-form').html(sendButtonContent);
            $('.form-control.error:first').focus();
        }
    }
    function sendData(attachments){
        var data = contactData;
        $('#contact-form [data-check]').each(function (){
            if($(this).attr('data-check') == 'radio-empty'){
                var i = $(this).find('input:checked');
                data[i.attr('name')] = i.val();
            }
            else if($(this).attr('type') == 'checkbox'){
                data[$(this).attr('name')] = ($(this).is(':checked')) ? 'si' : 'no';
            }
            else data[$(this).attr('name')] = $(this).val();
        });

        $('#contact-form select:not([data-check])').each(function (){
            data[$(this).attr('name')] = $(this).val();
        });


        data['idua'] = $.urlParam('idua');
        data['dip'] = $.urlParam('dip');
        data['lang'] = $.urlParam('lang');

        if($('.allegato:not(.hidden)').length){
            var v = new Array();
            $('.allegato:not(.hidden) input').each(function (){
                v.push($(this).attr('data-file'));
            });
            data['allegati'] = v.join(';');
        }

        $.post(url+'send.php', data, function (r){
            $('html, body').animate({ scrollTop: 0 }, 500);
            $('#contact-form h2').remove();

            if(r == 'ok'){
                if($('.overlay h1').text() == 'Condividi') var text = '<h2>'+errorMessages[contactData.lang].shareThankyou+'.</h2>';
                else var text = '<h2>'+errorMessages[contactData.lang].thankyou+'</h2><p>'+errorMessages[contactData.lang].sent+'.</p>';
            }
            else{
                var text = '<h2>'+errorMessages[contactData.lang].errorTitle+'</h2><p>'+errorMessages[contactData.lang].errorText+'.</p>';
            }

            // if(contactData.lang == 'en') msg = '<h2>Grazie del suo messaggio.</h2><p>Il messaggio è stato correttamente inviato all’unità amministrativa competente.</p>';
            // else msg = '<h2>Thank you for your message.</h2><p>The message has been successfully sent to the appropriate administrative department.</p>';
            $('#contact-form > .row:eq(1)').html('<div class="thankyou">'+text+'</div>');
        });
    }
    function checkField(field){
        var error = false;
        var checks = field.attr('data-check');
        var messages = new Array();
        var v = field.val();
        if(checks.indexOf(',') > -1) checks = checks.split(',');
        else checks = new Array(checks);

        if(checks[0] == 'radio-empty'){
            var found = false;
            field.find('input').each(function (){
                if($(this).is(':checked')) found = true;
            });
            if(!found){
                messages.push('radio-empty');
                error = true;
            }
        }
        else{
            for(x in checks){
                if(checks[x] == 'empty'){
                    if(v == '' || ((v == '-' || v == '0') && field.is('select'))){
                        error = true;
                        messages.push('empty');
                    }
                }
                else if(checks[x] == 'email' && v){
                    var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
                    if(!re.test(v)){
                        error = true;
                        messages.push('email');
                    }
                }
            }
        }

        if(error){
            field.addClass('error');
            field.next().removeClass('hidden').html(getErrorMessage(messages));
            return false;
        }
        else{
            field.removeClass('error');
            field.next().addClass('hidden');
            return true;
        }
    }
    function checkCaptchaField(){
        var field = $('#contact-form [name=captcha]');
        var error = false;

        if(field.val()){
            var r = checkCaptcha(field.val());
            if(r.responseText == 'ok'){
                field.removeClass('error');
                if($('#contact-form .captcha .error-messages').length) $('#contact-form .captcha .error-messages').remove();
            }
            else{
                field.addClass('error').val('');
                $('#contact-form .captcha a').trigger('click');

                if(!$('#contact-form .captcha .error-messages').length) $('#contact-form .captcha').append('<div class="error-messages"><ul><li>'+errorMessages[contactData.lang].fillCorrectly+'</li></ul></div>')
                error = true;
            }
        }
        else{
            field.addClass('error');
            $('#contact-form .captcha a').trigger('click');

            if(!$('#contact-form .captcha .error-messages').length) $('#contact-form .captcha').append('<div class="error-messages"><ul><li>'+errorMessages[contactData.lang].notEmpty+'</li></ul></div>')
            error = true;
        }

        if(!error) return true;
        return false;
    }
    function checkCaptcha(value){
        return $.ajax({
            url: $('base').attr('href')+'user_librerie/securimage/check.php',
            data: {
                value: value
            },
            async: false,
            method: 'post'
        });
    }
    function getErrorMessage(messages){
        var html = '<ul>';
        for(x in messages){
            html += '<li>'+errorMessages[contactData.lang][messages[x]]+'</li>';
        }
        html += '</ul>';
        return html;
    }
    /* Allegati */
    function hasAttachments(){
        for(x in uploadFile){
            if(uploadFile[x]){
                return true;
            }
        }
        return false;
    }
    function uploadFiles(event){
        var data = new FormData();

        for(x in uploadFile){
            if(uploadFile[x]){
                $.each(uploadFile[x], function(key, value){
                    data.append('file'+x, value);
                });
            }
        }

        $.ajax({
            url: url+'upload.php', // point to server-side PHP script
            dataType: 'text',  // what to expect back from the PHP script, if anything
            cache: false,
            contentType: false,
            processData: false,
            data: data,
            type: 'post',
            success: function(php_script_response){
                if(php_script_response == 'filesize'){
                    if($('#attachments-error').length) $('#attachments-error').remove();
                    $('.allegato.hidden').after('<div id="attachments-error"><ul style="color:#c33;position: relative; top: -10px;"><ul>'+errorMessages[contactData.lang].maxFilesize+'.</li></ul></div>');
                }
                else if(php_script_response == 'error'){
                    if($('#attachments-error').length) $('#attachments-error').remove();
                    $('.allegato.hidden').after('<div id="attachments-error"><ul style="color:#c33;position: relative; top: -10px;"><ul>'+errorMessages[contactData.lang].uploadError+'.</li></ul></div>');
                }
                else sendData(php_script_response);

                $('#sending-form').remove();
                $('#contact-form .send-form').html(sendButtonContent);
            }
        });
    }
    var uploadFile = {};
    function initMultiUpload(){
        var attachments_n = 1;
        var max_weight = 10;
        var used_weight = 0;
        var working = false;
        function init(){
            $('#contact-form').on('click', '.allegati .add', addAttachemnt);
            $('#contact-form').on('click', '.allegati .remove', clearAttachemnt);
            $('#contact-form').on('change', '.inputfile', change);
        }
        function addAttachemnt(e){
            e.preventDefault();

            if(!working){
                $(this).siblings('.allegato.hidden.new').remove();

                if($('#attachments-error').length) $('#attachments-error').remove();

                // var n = $('#contact-form .allegato').length - 1;
                $(this).prev().before($(this).siblings('.allegato.hidden').clone().addClass('new'));
                $('#contact-form .allegato.new label').attr('for', 'file'+attachments_n);
                $('#contact-form .allegato.new input').attr('id', 'file'+attachments_n).attr('name', 'file'+attachments_n);

                $('#contact-form .allegato.new input:last').trigger('click');

                attachments_n++;
            }
        }
        function clearAttachemnt(e){
            e.preventDefault();

            var id = $(this).parents('.allegato').find('input[type=file]').attr('id');
            uploadFile[id] = false;

            var p = $(this).parents('.allegato');
            used_weight -= parseInt(p.find('input').attr('data-weight'));
            updateWeights();

            p.find('input[type=file]').val('');
            p.find('input[type=file]').next().children('span').text('Allega un file');
            p.remove();
        }
        function change(event){
            var id = $(this).attr('id');

            tmp = $(this).val().split("\\");
            var v = tmp[tmp.length - 1];

            if(v){
                tmp2 = v.split('.');
                var ext = tmp2[(tmp2.length - 1)];

                if(ext == 'exe' || ext == 'bat' || ext == 'com'){
                    if($('#attachments-error').length) $('#attachments-error').remove();
                    $('.allegato.hidden:not(.new)').after('<div id="attachments-error"><p style="color:#c33;position: relative; top: -10px;">'+errorMessages[contactData.lang].wrongFormat+'.</p></div>');

                    $('label[for='+id+'] span').text('Allega un file (10Mb massimo)');
                }
                else{
                    $('label[for='+id+'] span').text(v);

                    if($('#attachments-error').length) $('#attachments-error').remove();

                    uploadFile[id] = event.target.files;

                    upload(id, event.target.files);
                }
            }
        }
        function upload(x, value){
            var data = new FormData();
            var upd = {
                x: value
            };

            $('body').append('<div id="sending-form" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; z-index: 10002;"></div>');
            $('#contact-form .allegati .add').html('<i class="fa fa-spinner fa-spin"></i>');
            // $('.allegati .add').addClass('disabled');
            working = true;

            for(x in upd){
                if(upd[x]){
                    $.each(upd[x], function(key, value){
                        data.append('file'+x, value);
                    });
                }
            }

            $.ajax({
                url: url+'upload.php?max='+(max_weight - used_weight), // point to server-side PHP script
                dataType: 'text',  // what to expect back from the PHP script, if anything
                cache: false,
                contentType: false,
                processData: false,
                data: data,
                type: 'post',
                success: function(php_script_response){

                    if(php_script_response == 'filesize'){
                        if($('#attachments-error').length) $('#attachments-error').remove();
                        $('.allegato.hidden:not(.new)').after('<div id="attachments-error"><ul style="color:#c33;position: relative; top: -10px;"><ul>'+errorMessages[contactData.lang].maxFilesize+'.</li></ul></div>');
                    }
                    else if(php_script_response == 'error'){
                        if($('#attachments-error').length) $('#attachments-error').remove();
                        $('.allegato.hidden:not(.new)').after('<div id="attachments-error"><ul style="color:#c33;position: relative; top: -10px;"><ul>'+errorMessages[contactData.lang].uploadError+'.</li></ul></div>');
                    }
                    else{
                        var tmp = php_script_response.split('|');
                        used_weight += parseInt(tmp[1]);

                        $('.allegato.new.hidden input').attr('data-file', tmp[0]);
                        $('.allegato.new.hidden input').attr('data-weight', tmp[1]);

                        updateWeights()
                        $('.allegato.new.hidden').removeClass('new hidden');
                    }

                    $('#contact-form .allegati .add').html(uploadButtonContent);
                    $('#sending-form').remove();
                    // $('.allegati .add').removeClass('disabled');
                    working = false;

                    // else sendData(php_script_response);
                    // $('#sending-form').remove();
                    // $('#contact-form .send-form').html(sendButtonContent);
                }
            });
        }
        function updateWeights(){
            if(contactData.lang == 'en') $('.allegati h4').html('Attachments '+(used_weight)+' MB(maximum size allowed 10 MB)');
            else $('.allegati h4').html('Allegati '+(used_weight)+' MB(dimensione massima consentita 10 MB)');

            if(used_weight == max_weight) $('.allegati .add').hide();
            else $('.allegati .add').show();
        }
        init();
    }
    init();
}

/* CPA */
function initCPA() {
    $('#contenitore').addClass('cpa-container');
}

function initCPANew(){
    $('.flipster').flipster({
        style: 'carousel',
        buttons: true,
        loop: true
    });
    $('.flipster .next').click(function (e){
      e.preventDefault()
      $('.flip-item.flip-next').trigger('click')
    })
    $('.flipster .prev').click(function (e){
      e.preventDefault()
      $('.flip-item.flip-prev').trigger('click')
    })

    $('.cpa_results td a.opener').click(function (){
      var i = $(this).children('i')
      if(i.hasClass('fa-angle-down')){
        i.removeClass('fa-angle-down').addClass('fa-angle-up')
        $(this).parents('tr').next().removeClass('hidden')
      }
      else{
        i.removeClass('fa-angle-up').addClass('fa-angle-down')
        $(this).parents('tr').next().addClass('hidden')
      }
    })

    $('.dropdown-menu[aria-labelledby=dropdownMenu1] a').click(function (){
      location.href = $(this).attr('href')
    })

    $('.dropdown.range .dropdown-menu input, .dropdown.range .dropdown-menu label').click(function (e){
      e.stopPropagation()

    });

    $('.col-xs-2:eq(5) .dropdown-menu').click(function (e){
      e.stopPropagation()
    })


    $(".js-range-slider").ionRangeSlider({
        type: "double",
        min: $(".js-range-slider").data('inizio'),
        max: $(".js-range-slider").data('fine'),
        from: $(".js-range-slider").data('da'),
        to: $(".js-range-slider").data('a'),
        grid: true
    });

}
function initDepressione() {
    function init() {
        initSlider();
        initParallax();
        initMenu();
        initOpener();
    }

    function initOpener() {
        var h = new Array();
        var n = 0;
        $('.inner .text').each(function() {
            h.push($(this).height());
            $(this).prev().attr('data-id', n);
            n++;
            $(this).height(0);
        });

        $('.inner a').click(function(e) {
            e.preventDefault();
            if ($(this).hasClass('opened')) {
                $(this).removeClass('opened');
                // $(this).next().height(0);
                $(this).next().animate({ height: 0}, 1000);
            } else {
                $(this).addClass('opened');
                // $(this).next().height(h[$(this).attr('data-id')]);
                $(this).next().animate({height: h[$(this).attr('data-id')]}, 1000);
            }

        })
    }

    function initMenu() {
        var menuTrigger;
        var menu;
        var tornaSu = $('.dp-torna-su');
        var triggers = new Array();
        var scrolling = false;

        function init() {
            menu = $('.dp-floating-menu');
            menuTrigger = ($('.main-section').length) ? $('.main-section').offset().top - 8 : 10000000;

            setTimeout(calcTriggers, 560);

            $('.dp-menu a').click(menuClick);

            $(window).scroll(onScroll).trigger('scroll');
            $(window).resize(calcTriggers);

            tornaSu.click(moveUp);
            $('.dp-menu.dp-floating-menu h5').css({
                cursor: 'pointer'
            }).click(moveUp);

            if ($('.nav.no-click').length) $('.nav.no-click a').click(menuClick);
        }

        function onScroll(e) {
            var v = $(window).scrollTop();
            if (v >= menuTrigger) {
                tornaSu.addClass('out');
                menu.removeClass('closed');
            } else {
                tornaSu.removeClass('out');
                menu.addClass('closed');
            }

            for (x in triggers) {

                if (v >= triggers[x].from - 5 && v < triggers[x].to - 5) {
                    $('.dp-floating-menu .hover').removeClass('hover');
                    $('.dp-floating-menu a[href*="#' + triggers[x].id + '"]').addClass('hover');
                    break;
                }
            }

        }

        function calcTriggers() {
            $('.full-page-layout.depressione .section').each(function() {
                var top = $(this).offset().top - 200;
                // if($(this).attr('id') == 'chi-siamo'){
                //   top -= 15;
                // }
                triggers.push({
                    id: $(this).attr('id'),
                    from: top,
                    to: top + $(this).outerHeight()
                });
            });
        }

        function menuClick(e) {
            if (!$(this).hasClass('bb')) {
                e.preventDefault();

                var tmp = $(this).attr('href').split('#');
                var top = $('.section#' + tmp[1]).offset().top - 56;
                $('html, body').animate({
                    scrollTop: top + 'px'
                }, 700);
            }
        }

        function moveUp(e) {
            e.preventDefault();
            $('html, body').animate({
                scrollTop: 0
            }, 700);
        }
        init();
    }

    function initParallax() {
        var items = [];
        var h = 0;

        function init() {
            h = windowHeight();
            setTimeout(function() {
                $('.full-page.image').each(function() {
                    items.push({
                        from: $(this).offset().top - 800,
                        to: $(this).offset().top + $(this).outerHeight() + 800
                    });
                });
                $(window).scroll(scroll);

            }, 200);
        }

        function scroll(e) {
            var v = $(window).scrollTop();

            for (x in items) {
                if (v >= items[x].from <= items[x].to) {
                    n = (v - items[x].from) / 8;
                    if (n < 0) n = 0;
                    $('.full-page.image:eq(' + x + ')').css('background-position', 'center -' + n + 'px');
                }
            }
        }
        init();
    }

    function initSlider() {
        var owl = $("#owl-demo")

        owl.owlCarousel({
            navigation: false,
            mouseDrag: false,
            touchDrag: false,
            responsiveClass: true,
            responsive: {
                0: {
                    items: 1,
                    // nav:true
                },
                600: {
                    items: 3,
                    // nav:false
                },
                1400: {
                    items: 5,
                    // nav:true,
                    // loop:false
                }
            }
        });

        $("#owl-demo2").owlCarousel({
            navigation: false,
            mouseDrag: false,
            touchDrag: false,
            responsiveClass: true,
            responsive: {
                0: {
                    items: 1,
                    // nav:true
                },
                600: {
                    items: 3,
                    // nav:false
                }
            }
        });

        $("#owl-demo3").owlCarousel({
            navigation: false,
            mouseDrag: false,
            touchDrag: false,
            responsiveClass: true,
            responsive: {
                0: {
                    items: 1,
                    // nav:true
                },
                600: {
                    items: 3,
                    // nav:false
                },
                1400: {
                    items: 5,
                    // nav:true,
                    // loop:false
                }
            }
        });

        $(".images-slider .next").click(function(e) {
            e.preventDefault();
            owl.trigger('next.owl.carousel');
        });

        $(".images-slider .prev").click(function(e) {
            e.preventDefault();
            owl.trigger('prev.owl.carousel');
        });

        // $("#owl-demo a.fancybox").fancybox();
    }
    init();
}
function initDFEInnerForm(){
    var formData = {};
    var events_dates = {
        'chiasso': new Date(2017, 8, 22, 0, 0, 0, 0),
        'bellinzona': new Date(2017, 9, 13, 0, 0, 0, 0),
        'lugano': new Date(2018, 1, 22, 0, 0, 0, 0),
        'locarno': new Date(2018, 3, 19, 0, 0, 0, 0)
    }

    function init(){

        $.getJSON('/fileadmin/DFE/DE-EVENTI/check_max.php', {}, function (r){
            if(r){
                formData = r;
                for(x in r){
                    $('#dfe-inner-form .row.titles .col-xs-3[data-id='+x+']').show();
                }

                $('#dfe-inner-form .row.titles .col-xs-3:not(:visible)').addClass('disabled').show();

                var n = 0;
                $('#dfe-inner-form .row.titles .col-xs-3:visible').each(function (){
                    $(this).attr('data-n', n);
                    n++;
                });

                var t = new Date();
                for(x in events_dates){
                    if(events_dates[x] <= t) {
                        $('#dfe-inner-form .row.titles .col-xs-3[data-id='+x+']').addClass('disabled').children('p').html('Evento concluso.');
                    }
                }
            }
        });

        $('#dfe-inner-form .titles > div > a').click(selectDate);
        $('#dfe-inner-form button').click(submit);
        $('#dfe-inner-form .captcha a').click(refreshCaptcha);

        $('#dfe-inner-form .inner i.closeform').click(function (){
            $('#dfe-inner-form .titles a i').removeClass('hidden');
            $('#dfe-inner-form .inner').css("display","none");
        });

        // $('#dfe-inner-form button').contextmenu(function (){
        //     $(this).parent().addClass('hidden');
        //     $(this).parent().prev().removeClass('hidden');
        // });
    }
    function selectDate(e){
        e.preventDefault();

        if(!$(this).parent().hasClass('disabled')){
            var index = $(this).parent().attr('data-n');
            var city = $(this).children('b').text().toLowerCase();


            $('#dfe-inner-form .inner').attr('class', 'inner i'+index).show();
            $('#dfe-inner-form .inner h3 span').text(capitalizeFirstLetter(city));
            $('#dfe-inner-form input[name=luogo]').val(city);


            $('#dfe-inner-form .form').removeClass('hidden');
            $('#dfe-inner-form .thankyou').addClass('hidden');

            $('#dfe-inner-form .titles a i').removeClass('hidden');
            $(e.currentTarget).find('i').addClass("hidden");

            if(formData[city] == 1){
                $('#dfe-inner-form .form .person2').addClass('hidden');
                $('#dfe-inner-form .form .person2 input').val('');
                $('#dfe-inner-form .form h5 span').text('(ultimo posto disponibile)');
            }
            else{
                $('#dfe-inner-form .form .person2').removeClass('hidden');

                $('#dfe-inner-form .form h5 span').text('(massimo 2 per azienda)');
            }
        }
    }


    function submit(){
        var error = false;

        if(!checkField('azienda')) error = true;
        if(!checkField('nap_luogo')) error = true;
        if(!checkField('telefono')) error = true;


        if(!checkField('p1_nome')) error = true;
        if(!checkField('p1_cognome')) error = true;
        if(!checkField('p1_email')) error = true;

        var p2 = false;
        if($('#dfe-inner-form input[name=p2_nome]').val() || $('#dfe-inner-form input[name=p2_cognome]').val() || $('#dfe-inner-form input[name=p2_email]').val()){
            if(!checkField('p2_nome')) error = true;
            if(!checkField('p2_cognome')) error = true;
            if(!checkField('p2_email')) error = true;
            p2 = true;
        }
        else{
            $('#dfe-inner-form input[name=p2_nome], #dfe-inner-form input[name=p2_cognome], #dfe-inner-form input[name=p2_email]').removeClass('form-error');
        }

        // Captcha!
        if(!checkField('captcha')) error = true;
        // else{

        // }

        if(!error){
            var data = {
                luogo: $('#dfe-inner-form input[name=luogo]').val(),
                azienda: $('#dfe-inner-form input[name=azienda]').val(),
                nap_luogo: $('#dfe-inner-form input[name=nap_luogo]').val(),
                telefono: $('#dfe-inner-form input[name=telefono]').val(),
                p1_nome: $('#dfe-inner-form input[name=p1_nome]').val(),
                p1_cognome: $('#dfe-inner-form input[name=p1_cognome]').val(),
                p1_email: $('#dfe-inner-form input[name=p1_email]').val(),
                captcha: $('#dfe-inner-form input[name=captcha]').val()
            }
            if(p2){
                data.p2_nome = $('#dfe-inner-form input[name=p2_nome]').val();
                data.p2_cognome = $('#dfe-inner-form input[name=p2_cognome]').val();
                data.p2_email = $('#dfe-inner-form input[name=p2_email]').val();
            }


            $.post('/fileadmin/DFE/DE-EVENTI/send.php', data, function (r){
                if(r == 'ok'){
                    $('#dfe-inner-form input[name=luogo]').val('').removeClass('form-error');
                    $('#dfe-inner-form input[name=azienda]').val('').removeClass('form-error');
                    $('#dfe-inner-form input[name=nap_luogo]').val('').removeClass('form-error');
                    $('#dfe-inner-form input[name=telefono]').val('').removeClass('form-error');
                    $('#dfe-inner-form input[name=p1_nome]').val('').removeClass('form-error');
                    $('#dfe-inner-form input[name=p1_cognome]').val('').removeClass('form-error');
                    $('#dfe-inner-form input[name=p1_email]').val('').removeClass('form-error');
                    $('#dfe-inner-form input[name=captcha]').val('').removeClass('form-error');
                    $('#dfe-inner-form input[name=p2_nome]').val('').removeClass('form-error');
                    $('#dfe-inner-form input[name=p2_cognome]').val('').removeClass('form-error');
                    $('#dfe-inner-form input[name=p2_email]').val('').removeClass('form-error');

                    $('#dfe-inner-form .form').addClass('hidden');
                    $('#dfe-inner-form .thankyou').removeClass('hidden');
                }
                else if(r == 'captcha'){
                    $('#dfe-inner-form input[name=captcha]').addClass('error-form').val('');

                    var src = $('#dfe-inner-form .captcha img').attr('src');
                    if(src.indexOf('?') > -1){
                        var tmp = src.split('?');
                        src = tmp[0]+'?';
                    }
                    else src += '?';
                    src += Math.floor((Math.random() * 10000) + 1);
                    $('#dfe-inner-form .captcha img').attr('src', src);
                }
                else{

                }
            });
        }

    }
    function checkField(field){
        if(!$('#dfe-inner-form input[name='+field+']').val()){
            $('#dfe-inner-form input[name='+field+']').addClass('form-error');
            return false;
        }
        else $('#dfe-inner-form input[name='+field+']').removeClass('form-error');
        return true;
    }
    function refreshCaptcha(e){
        e.preventDefault();

        var src = $('.captcha img').attr('src');
        if(src.indexOf('?') > -1){
            tmp = src.split('?');
            src = tmp[0];
        }
        src += '?'+Math.floor((Math.random() * 10000) + 1);

        $('.captcha img').attr('src', src);

    }
    init();
}
function initDISVGSchema(){
    for(x in link_procedure_di){
        $('#'+x).attr('class', $('#'+x).attr('class') + ' link').attr('data-link', link_procedure_di[x]);
        // $('#'+x).next().attr('class', $('#'+x).next().attr('class') + ' link').attr('data-link', link_procedure_di[x]);
    }
    // console.log('test')
    function procedura_click(){
        if($(this).attr('data-link')){
            // window.open($(this).attr('data-link'));
            location.href = $(this).attr('data-link');
        }
    }
    function mouseover(){
        if($(this).attr('data-link')){
            $(this).children('rect').css('fill', '#333');
        }
        // if($(this).attr('data-link')){
        //     window.open($(this).attr('data-link'));
        // }
    }
    function mouseout(){
        if($(this).attr('data-link')){
            $(this).children('rect').removeAttr('style');
        }
        // if($(this).attr('data-link')){
        //     window.open($(this).attr('data-link'));
        // }
    }
    d3.select('svg').selectAll('g').on('click', procedura_click)
    d3.select('svg').selectAll('g').on('mouseover', mouseover).on('mouseout', mouseout);
}
/* DT Mappa Ticino */
function initDTMappaTicino() {
    function init() {
        d3.select('svg').selectAll('#Limiti_pubbl_x_sito_web > g')
            .on('mouseover', mouseover)
            .on('mouseout', mouseout)
            .on('click', click);
    }
    function mouseover() {
        $(this).attr('class', 'hover');
    }
    function mouseout() {
        $(this).attr('class', '');
    }
    function click() {
        var id = $(this).attr('id');
        var href = $('a:contains(' + id + ')').attr('href');
        if(href) window.open(href);
    }
    init();
}
function initDTCF(){

	if ($('#deputatiHome').length) 
	{	
		$(function() {
			$("#deputatiHome .deputato").mouseover(function() {
		            $(this).find('.testoHover').show();
		            $(this).find('.testo').hide();

		        }).mouseout(function(){
		            $(this).find('.testoHover').hide();
		            $(this).find('.testo').show();
		        });
		});	
	}
	else if ($('#listaArticoli').length)
	{
		$(function() {
			
			$('input[name="daterange"]').daterangepicker({
				autoUpdateInput: false,
				locale: {
				  format: 'DD.MM.YYYY',
				  firstDay: 1,
				  cancelLabel: 'Cancella',
				  applyLabel: 'Applica',
				  customRangeLabel: "Custom",
			      daysOfWeek: ["Do","Lu","Ma","Me","Gi","Ve", "Sa"],
			      monthNames: ["Gennaio","Febbraio","Marzo","Aprile","Maggio","Giugno","Luglio","Agosto","Settembre","Ottobre","Novembre","Dicembre"]
				}
		    });
			
			$('input[name="daterange"]').on('apply.daterangepicker', function(ev, picker) {
				$(this).val(picker.startDate.format('DD.MM.YYYY') + ' - ' + picker.endDate.format('DD.MM.YYYY'));
				$('.myForm').submit();
			});
			
			$('input[name="daterange"]').on('cancel.daterangepicker', function(ev, picker) {
				$(this).val('');
				$('.myForm').submit();
			});
		});	

	}	

}	
function initFormularioIAS(){
    var uploadFile = {};
    var url = '/fileadmin/DSS/IAS/formulario_modifica_indirizzo/';
    var loading = false;
    var prestazioniUpload = false;
    function init(){
        $('select#tipo').change(changeForm);
        $('input[name=prestazioni]').change(checkPrestazioni);
        $('.send-form').click(send);

        $.getScript(url+'securimage/securimage.js', function (){
            captcha_image_audioObj = new SecurimageAudio({ audioElement: 'captcha_image_audio', controlsElement: 'captcha_image_audio_controls' });
        });

        $.fn.datepicker.dates['it'] = {
            days: ["Domenica", "Lunedì", "Martedì", "Mercoledì", "Giovedì", "Venerdì", "Sabato", "Domenica"],
            daysShort: ["Dom", "Lun", "Mar", "Mer", "Gio", "Ven", "Sab", "Dom"],
            daysMin: ["Do", "Lu", "Ma", "Me", "Gi", "Ve", "Sa", "Do"],
            months: ["Gennaio", "Febbraio", "Marzo", "Aprile", "Maggio", "Giugno", "Luglio", "Agosto", "Settembre", "Ottobre", "Novembre", "Dicembre"],
            monthsShort: ["Gen", "Feb", "Mar", "Apr", "Mag", "Giu", "Lug", "Ago", "Set", "Ott", "Nov", "Dic"],
            today: "Oggi",
            clear: "Svuota"
        };

        $('.birthdate').datepicker({
            format: "dd.mm.yyyy",
            language: 'it',
            // defaultViewDate: '1970',
            startView: 'year'
        });

        initMultiUpload1();
        initMultiUpload2();
    }
    function changeForm(){
        if($(this).val() == ''){
            $('.all-fields').addClass('hidden');
        }
        else{
            $('.prestazioni, .prestazioni_single, .allegati-box1, .allegati-box2').addClass('hidden');
            $('.g3').addClass('hidden')

            if($(this).val() == 1){
                $('.prestazioni, .presso').removeClass('hidden');
                $('.ragione_sociale, .supplemento_indirizzo').addClass('hidden');
            }
            else if($(this).val() == 2){
                $('.prestazioni_single, .ragione_sociale, .supplemento_indirizzo').removeClass('hidden');
                $('.presso').addClass('hidden');
            }
            else if($(this).val() == 3){
                $('.prestazioni, .allegati-box1, .ragione_sociale, .presso').removeClass('hidden');
                $('.g3').removeClass('hidden');
                $('.supplemento_indirizzo').addClass('hidden');
            }
            $('.all-fields').removeClass('hidden');
        }
    }
    function checkPrestazioni(){
        if($('input[name=prestazioni]:checked').length){
            var show = false;
            $('input[name=prestazioni]:checked').each(function (){
                if($(this).val() == 'assegno_integrativo' || $(this).val() == 'pc') show = true;
            });

            if(show){
                $('.allegati-box2').removeClass('hidden');
                prestazioniUpload = true;
            }
            else{
                $('.allegati-box2').addClass('hidden');
                prestazioniUpload = false;
            }
        }
        else{
            $('.allegati-box2').addClass('hidden');
            prestazioniUpload = false;
        }
    }
    function send(e){
        e.preventDefault();

        if(!loading){
            loading = true;

            var error = false;


            if($('#nome').val() != '' || $('#cognome').val() != ''){
                if(!checkField('#nome')) error = true;
                if(!checkField('#cognome')) error = true;
                $('#ragione_sociale').siblings('.error-messages').addClass('hidden');
            }
            else if($('#ragione_sociale').val() != ''){
                $('#nome, #cognome').siblings('.error-messages').addClass('hidden');
            }
            else if($('#ragione_sociale').val() == ''){
                if(!checkField('#nome')) error = true;
                if(!checkField('#cognome')) error = true;
                if(!checkField('#ragione_sociale')) error = true;
            }


            if(!checkField('#avs')) error = true;
            // if($('input[name=assoggettamento]:checked').length || $('#prestazioni1').is(':checked')){
            //     if(!checkField('#avs')) error = true;
            // }
            // else $('#avs').siblings('.error-messages').addClass('hidden');

            if(!checkField('#telefono')) error = true;
            if(!checkField('#email', 'email')) error = true;
            if(!checkField('#via')) error = true;
            // if(!checkField('#indirizzo_supplementare')) error = true;
            if(!checkField('#localita')) error = true;
            if(!checkField('#data_indirizzo', 'date')) error = true;

            if(($('select#tipo').val() == 1 || $('select#tipo').val() == 3)){
                if(!checkField('#presso')) error = true;
            }
            else{
                if(!checkField('#supplemento_indirizzo')) error = true;
            }

            if(!checkField('#nascita')) error = true;

            // Prestazioni
            if($('select#tipo').val() == 1 || $('select#tipo').val() == 3){
                if(!$('input[name=prestazioni]:checked').length && !$('input[name=assoggettamento]:checked').length){
                    $('label[for=assoggettamento1]').siblings('.error-messages').removeClass('hidden');
                    error = true;
                }
                else $('label[for=assoggettamento1]').siblings('.error-messages').addClass('hidden');
            }
            else{
                if(!$('input[name=prestazioni_single]:checked').length && !$('input[name=assoggettamento]:checked').length){
                    $('label[for=assoggettamento1]').siblings('.error-messages').removeClass('hidden');
                    error = true;
                }
                else $('label[for=assoggettamento1]').siblings('.error-messages').addClass('hidden');
            }

            // Allegati 1
            if($('select#tipo').val() == 3){
                if(!$('.allegati1 .allegato:not(.hidden)').length){
                    error = true;
                    $('.allegati1 .error-messages').removeClass('hidden');
                }
                else $('.allegati1 .error-messages').addClass('hidden');
            }

            // Allegati 2
            if(prestazioniUpload){
                if(!$('.allegati2 .allegato:not(.hidden)').length){
                    error = true;
                    $('.allegati2 .error-messages').removeClass('hidden');
                }
                else $('.allegati2 .error-messages').addClass('hidden');
            }

            if(!error){
                // Captcha
                if(!checkCaptchaField()) error = true;
            }


            if(!error){
                var data = new FormData();

                data.append('tipo', $('#tipo').val());
                data.append('nome', $('#nome').val());
                data.append('cognome', $('#cognome').val());
                data.append('ragione_sociale', $('#ragione_sociale').val());
                data.append('avs', $('#avs').val());
                data.append('nascita', $('#nascita').val());
                data.append('telefono', $('#telefono').val());
                data.append('email', $('#email').val());
                data.append('via', $('#via').val());
                // data.append('indirizzo_supplementare', $('#indirizzo_supplementare').val());
                data.append('localita', $('#localita').val());
                data.append('data_indirizzo', $('#data_indirizzo').val());

                if(($('select#tipo').val() == 1 || $('select#tipo').val() == 3)) data.append('presso', $('#presso').val());
                else data.append('supplemento_indirizzo', $('#supplemento_indirizzo').val());

                for(x in uploadFile){
                    data.append(x, document.getElementById(x).files[0]);
                }

                // Prestazioni
                if(($('select#tipo').val() == 1 || $('select#tipo').val() == 3) && $('input[name=prestazioni]:checked').length){
                    var prestazioni = [];
                    $('input[name=prestazioni]:checked').each(function (){
                        prestazioni.push($(this).val());
                    });
                    data.append('prestazioni', prestazioni.join('+'));
                }
                else if($('select#tipo').val() == 2 && $('input[name=prestazioni_single]:checked').length){
                    data.append('prestazioni_single', $('input[name=prestazioni_single]:checked').val());
                }

                // Assoggettamento
                if($('input[name=assoggettamento]:checked').length){
                    var assoggettamento = [];
                    $('input[name=assoggettamento]:checked').each(function (){
                        assoggettamento.push($(this).val());
                    });
                    data.append('assoggettamento', assoggettamento.join('+'));
                }

                var button_text = $('button.send-form').text();
                $('button.send-form').html('<i class="fa fa-spinner fa-spin"></i>').addClass('disabled');
                $.ajax({
                    url: url+'save.php', // point to server-side PHP script
                    dataType: 'text',  // what to expect back from the PHP script, if anything
                    cache: false,
                    contentType: false,
                    processData: false,
                    data: data,
                    type: 'post',
                    success: function(php_script_response){
                        if(php_script_response == 'ok'){
                            $('form, .intro p').remove();
                            $('.success').removeClass('hidden');
                        }
                        else{
                            $('button.send-form').html(button_text).removeClass('disabled');
                            loading = false;

                            // if(php_script_response == 'no_file'){
                            //     $('.allegati .error-messages').removeClass('hidden');
                            // }
                            // else if(php_script_response == 'filesize'){
                            //     $('.allegati .error-messages-size').removeClass('hidden');
                            // }
                        }
                    }
                });
            }
            else loading = false;
        }
    }
    function checkField(s, type){
        if(typeof type == 'undefined'){
            if($(s).val() == ''){
                $(s).siblings('.error-messages').removeClass('hidden');
                return false;
            }
            else{
                $(s).siblings('.error-messages').addClass('hidden');
                return true;
            }
        }
        else if(type == 'radio' || type == 'checkbox'){
            if($(s+':checked').length == 0){
                $(s+':first').parent().parent().siblings('.error-messages').removeClass('hidden');
                return false;
            }
            else{
                $(s+':first').parent().parent().siblings('.error-messages').addClass('hidden');
                return true;
            }
        }
        else if(type == 'email'){
            if($(s).val() == '' || !checkEmail($(s).val())){
                $(s).siblings('.error-messages').removeClass('hidden');
                return false;
            }
            else{
                $(s).siblings('.error-messages').addClass('hidden');
                return true;
            }
        }
        else if(type == 'date'){
            if($(s).val() == '' || !checkDate($(s).val())){
                $(s).siblings('.error-messages').removeClass('hidden');
                return false;
            }
            else{
                $(s).siblings('.error-messages').addClass('hidden');
                return true;
            }
        }
    }
    function checkEmail(email) {
        var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(String(email).toLowerCase());
    }
    function checkDate(value){
        if(new RegExp("[0-9]{2}\.[0-9]{2}\.[0-9]{4}").test(value)) return true;
        else return false;
    }
    function checkCaptchaField(){
        var field = $('input[name=captcha]');
        var error = false;

        if(field.val()){
            var r = checkCaptcha(field.val());
            if(r.responseText == 'ok'){
                field.removeClass('error');
                $('.captcha .error-messages').addClass('hidden');
            }
            else{
                field.addClass('error').val('');
                $('.refresh-button').trigger('click');
                $('.captcha .error-messages').removeClass('hidden');
                error = true;
            }
        }
        else{
            field.addClass('error');
            $('.refresh-button').trigger('click');
            $('.captcha .error-messages').removeClass('hidden');
            error = true;
        }

        if(!error) return true;
        return false;
    }
    function checkCaptcha(value){
        var rand = Math.floor((Math.random() * 100000) + 1);
        return $.ajax({
            url: url+'securimage/check.php?r='+rand,
            data: {
                value: value
            },
            async: false,
            method: 'post'
        });
    }
    function initMultiUpload1(){
        var attachments_n = 1;
        var max_uploads = 1;
        var max_weight = 10;
        var working = false;
        var uploadButtonContent = '';
        function init(){
            uploadButtonContent = $('#formulario_ias .allegati1 .add').html();

            $('#formulario_ias').on('click', '.allegati1 .add', addAttachemnt);
            $('#formulario_ias').on('click', '.allegati1 .remove', clearAttachemnt);

            $('#formulario_ias').on('change', '.allegati1 .inputfile', change);
        }
        function addAttachemnt(e){
            e.preventDefault();

            if(!working){
                $(this).siblings('.allegato.hidden.new').remove();

                if($('#attachments-error').length) $('#attachments-error').remove();

                $(this).prev().before($(this).siblings('.allegato.hidden').clone().addClass('new'));
                $('#formulario_ias .allegati1 .allegato.new label').attr('for', 'file'+attachments_n);
                $('#formulario_ias .allegati1 .allegato.new input').attr('id', 'file'+attachments_n).attr('name', 'file'+attachments_n);

                $('#formulario_ias .allegati1 .allegato.new input:last').trigger('click');
            }
        }
        function clearAttachemnt(e){
            e.preventDefault();

            var id = $(this).parents('.allegato').find('input[type=file]').attr('id');
            uploadFile[id] = false;

            var p = $(this).parents('.allegato');

            p.find('input[type=file]').val('');
            p.find('input[type=file]').next().children('span').text('Allega un file');
            p.remove();

            attachments_n--;

            $('#formulario_ias .allegati1 .add').removeClass('hidden');
        }
        function change(event){
            var id = $(this).attr('id');

            tmp = $(this).val().split("\\");
            var v = tmp[tmp.length - 1];

            if(v){
                tmp2 = v.split('.');
                var ext = tmp2[(tmp2.length - 1)];


                $('.allegati1 .error-messages, .allegati1 .error-messages-type, .allegati1 .error-messages-size').addClass('hidden');

                if(ext.toLowerCase() != 'jpg' && ext.toLowerCase() != 'pdf' && ext.toLowerCase() != 'png'){
                    // Type error
                    $('.allegati1 .error-messages-type').removeClass('hidden');
                    $('.allegati1 .allegato.new.hidden .remove').trigger('click');
                }
                else{
                    if(Math.round(event.target.files[0].size / 1048576) > max_weight){
                        // Size error
                        $('.allegati1 .error-messages-size').removeClass('hidden');
                        $('.allegati1 .allegato.new.hidden .remove').trigger('click');
                    }
                    else{
                        $('label[for='+id+'] span').text(v);

                        if($('#attachments-error').length) $('#attachments-error').remove();

                        uploadFile[id] = event.target.files;

                        $('.allegati1 .allegato.new.hidden').removeClass('new hidden');
                        $('#formulario_ias .allegati1 .add').html(uploadButtonContent);


                        attachments_n++;
                        if(max_uploads < attachments_n) $('#formulario_ias .allegati1 .add').addClass('hidden');
                    }
                }
            }
        }
        init();
    }
    function initMultiUpload2(){
        var attachments_n = 2;
        var max_uploads = 1;
        var max_weight = 10;
        var working = false;
        var uploadButtonContent = '';
        function init(){
            uploadButtonContent = $('#formulario_ias .allegati2 .add').html();

            $('#formulario_ias').on('click', '.allegati2 .add', addAttachemnt);
            $('#formulario_ias').on('click', '.allegati2 .remove', clearAttachemnt);

            $('#formulario_ias').on('change', '.allegati2 .inputfile', change);
        }
        function addAttachemnt(e){
            e.preventDefault();

            if(!working){
                $(this).siblings('.allegato.hidden.new').remove();

                if($('#attachments-error').length) $('#attachments-error').remove();

                $(this).prev().before($(this).siblings('.allegato.hidden').clone().addClass('new'));
                $('#formulario_ias .allegati2 .allegato.new label').attr('for', 'file'+attachments_n);
                $('#formulario_ias .allegati2 .allegato.new input').attr('id', 'file'+attachments_n).attr('name', 'file'+attachments_n);

                $('#formulario_ias .allegati2 .allegato.new input:last').trigger('click');
            }
        }
        function clearAttachemnt(e){
            e.preventDefault();

            var id = $(this).parents('.allegato').find('input[type=file]').attr('id');
            uploadFile[id] = false;

            var p = $(this).parents('.allegato');

            p.find('input[type=file]').val('');
            p.find('input[type=file]').next().children('span').text('Allega un file');
            p.remove();

            attachments_n--;

            $('#formulario_ias .allegati2 .add').removeClass('hidden');
        }
        function change(event){
            var id = $(this).attr('id');

            tmp = $(this).val().split("\\");
            var v = tmp[tmp.length - 1];

            if(v){
                tmp2 = v.split('.');
                var ext = tmp2[(tmp2.length - 1)];


                $('.allegati2 .error-messages, .allegati2 .error-messages-type, .allegati2 .error-messages-size').addClass('hidden');

                if(ext.toLowerCase() != 'jpg' && ext.toLowerCase() != 'pdf' && ext.toLowerCase() != 'png'){
                    // Type error
                    $('.allegati2 .error-messages-type').removeClass('hidden');
                    $('.allegati2 .allegato.new.hidden .remove').trigger('click');
                }
                else{
                    if(Math.round(event.target.files[0].size / 1048576) > max_weight){
                        // Size error
                        $('.allegati2 .error-messages-size').removeClass('hidden');
                        $('.allegati2 .allegato.new.hidden .remove').trigger('click');
                    }
                    else{
                        $('label[for='+id+'] span').text(v);

                        if($('#attachments-error').length) $('#attachments-error').remove();

                        uploadFile[id] = event.target.files;

                        $('.allegati2 .allegato.new.hidden').removeClass('new hidden');
                        $('#formulario_ias .allegati2 .add').html(uploadButtonContent);


                        attachments_n++;
                        if(max_uploads < attachments_n) $('#formulario_ias .allegati2 .add').addClass('hidden');
                    }
                }
            }
        }
        init();
    }
    init();
}

function initFormularioIAS2(){
    var uploadFile = {};
    var url = '/fileadmin/DSS/IAS/formulario_corrispondenza/';
    var loading = false;
    var prestazioniUpload = false;
    function init(){
        $('.add-element').click(addElement)
        $('.lamal-table').on('click', '.remove-element', removeElement)

        $('.send-form').click(send);

        $.getScript(url+'securimage/securimage.js', function (){
            captcha_image_audioObj = new SecurimageAudio({ audioElement: 'captcha_image_audio', controlsElement: 'captcha_image_audio_controls' });
        });

        $.fn.datepicker.dates['it'] = {
            days: ["Domenica", "Lunedì", "Martedì", "Mercoledì", "Giovedì", "Venerdì", "Sabato", "Domenica"],
            daysShort: ["Dom", "Lun", "Mar", "Mer", "Gio", "Ven", "Sab", "Dom"],
            daysMin: ["Do", "Lu", "Ma", "Me", "Gi", "Ve", "Sa", "Do"],
            months: ["Gennaio", "Febbraio", "Marzo", "Aprile", "Maggio", "Giugno", "Luglio", "Agosto", "Settembre", "Ottobre", "Novembre", "Dicembre"],
            monthsShort: ["Gen", "Feb", "Mar", "Apr", "Mag", "Giu", "Lug", "Ago", "Set", "Ott", "Nov", "Dic"],
            today: "Oggi",
            clear: "Svuota"
        };

        // $('.birthdate, .lamal-table input[name=data]').datepicker({
        //     format: "dd.mm.yyyy",
        //     language: 'it',
        //     // defaultViewDate: '1970',
        //     startView: 'year'
        // });

        initMultiUpload1();
        // initMultiUpload2();
    }
    function addElement(e){
        e.preventDefault()
        var e = $('.lamal-table tr.placeholder').clone()
        e.removeClass('placeholder hidden');

        // e.find('input[name=data]').datepicker({
        //     format: "dd.mm.yyyy",
        //     language: 'it',
        //     // defaultViewDate: '1970',
        //     startView: 'year'
        // });

        $('.lamal-table tr.placeholder').before(e)
        if($('.lamal-table tr').length == 10) $('.add-element').addClass('hidden')
    }
    function removeElement(e){
        e.preventDefault()
        $(this).parents('tr').remove()
        if($('.lamal-table tr').length < 10) $('.add-element').removeClass('hidden')
    }
    function send(e){
        e.preventDefault();

        if(!loading){
            loading = true;

            var error = false;


            if(!checkField('#nome')) error = true;
            if(!checkField('#cognome')) error = true;
            if(!checkField('#avs')) error = true;
            if(!checkField('#nascita')) error = true;
            if(!checkField('#telefono')) error = true;
            if(!checkField('#email', 'email')) error = true;

            if(!$('#complementari1').is(':checked') && !$('#complementari2').is(':checked')){
                error = true
                $('#complementari2').parent().siblings('.error-messages').removeClass('hidden')
            }
            else $('#complementari2').parent().siblings('.error-messages').addClass('hidden')

            var n = 0;
            $('.lamal-table tbody tr').each(function (){
                if(!$(this).hasClass('placeholder')){

                    $(this).find('input[name=cognome]').attr('id', 'cognome'+n);
                    if(!checkField('#cognome'+n)) error = true;

                    $(this).find('input[name=nome]').attr('id', 'nome'+n);
                    if(!checkField('#nome'+n)) error = true;

                    $(this).find('input[name=data]').attr('id', 'data'+n);
                    if(!checkField('#data'+n)) error = true;

                    $(this).find('input[name=assicurazione]').attr('id', 'assicurazione'+n);
                    if(!checkField('#assicurazione'+n)) error = true;

                    n++;
                }
            })

            // Allegati 1
            if(!$('.allegati1 .allegato:not(.hidden)').length){
                error = true;
                $('.allegati1 .error-messages').removeClass('hidden');
            }
            else $('.allegati1 .error-messages').addClass('hidden');

            // // Allegati 2
            // if(prestazioniUpload){
            //     if(!$('.allegati2 .allegato:not(.hidden)').length){
            //         error = true;
            //         $('.allegati2 .error-messages').removeClass('hidden');
            //     }
            //     else $('.allegati2 .error-messages').addClass('hidden');
            // }

            if(!error){
                // Captcha
                if(!checkCaptchaField()) error = true;
            }


            if(!error){
                var data = new FormData();

                data.append('nome', $('#nome').val());
                data.append('cognome', $('#cognome').val());
                data.append('avs', $('#avs').val());
                data.append('nascita', $('#nascita').val());
                data.append('telefono', $('#telefono').val());
                data.append('email', $('#email').val());
                data.append('complementari', $('input[name=complementari]:checked').val());

                var n = 0;
                $('.lamal-table tbody tr').each(function (){
                    if(!$(this).hasClass('placeholder')){
                        data.append('cognome'+n, $(this).find('input[name=cognome]').val());
                        data.append('nome'+n, $(this).find('input[name=nome]').val());
                        data.append('data'+n, $(this).find('input[name=data]').val());
                        data.append('assicurazione'+n, $(this).find('input[name=assicurazione]').val());
                        n++;
                    }
                })
                data.append('element_n', n);

                for(x in uploadFile){
                    data.append(x, document.getElementById(x).files[0]);
                }

                var button_text = $('button.send-form').text();
                $('button.send-form').html('<i class="fa fa-spinner fa-spin"></i>').addClass('disabled');
                $.ajax({
                    url: url+'save.php', // point to server-side PHP script
                    dataType: 'text',  // what to expect back from the PHP script, if anything
                    cache: false,
                    contentType: false,
                    processData: false,
                    data: data,
                    type: 'post',
                    success: function(php_script_response){
                        if(php_script_response == 'ok'){
                            $('form, .intro p').remove();
                            $('.success').removeClass('hidden');
                        }
                        else{
                            $('button.send-form').html(button_text).removeClass('disabled');
                            loading = false;

                            // if(php_script_response == 'no_file'){
                            //     $('.allegati .error-messages').removeClass('hidden');
                            // }
                            // else if(php_script_response == 'filesize'){
                            //     $('.allegati .error-messages-size').removeClass('hidden');
                            // }
                        }
                    }
                });
            }
            else loading = false;
        }
    }
    function checkField(s, type){
        if(typeof type == 'undefined'){
            if($(s).val() == ''){
                $(s).siblings('.error-messages').removeClass('hidden');
                return false;
            }
            else{
                $(s).siblings('.error-messages').addClass('hidden');
                return true;
            }
        }
        else if(type == 'radio' || type == 'checkbox'){
            if($(s+':checked').length == 0){
                $(s+':first').parent().parent().siblings('.error-messages').removeClass('hidden');
                return false;
            }
            else{
                $(s+':first').parent().parent().siblings('.error-messages').addClass('hidden');
                return true;
            }
        }
        else if(type == 'email'){
            if($(s).val() == '' || !checkEmail($(s).val())){
                $(s).siblings('.error-messages').removeClass('hidden');
                return false;
            }
            else{
                $(s).siblings('.error-messages').addClass('hidden');
                return true;
            }
        }
        else if(type == 'date'){
            if($(s).val() == '' || !checkDate($(s).val())){
                $(s).siblings('.error-messages').removeClass('hidden');
                return false;
            }
            else{
                $(s).siblings('.error-messages').addClass('hidden');
                return true;
            }
        }
    }
    function checkEmail(email) {
        var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(String(email).toLowerCase());
    }
    function checkDate(value){
        if(new RegExp("[0-9]{2}\.[0-9]{2}\.[0-9]{4}").test(value)) return true;
        else return false;
    }
    function checkCaptchaField(){
        var field = $('input[name=captcha]');
        var error = false;

        if(field.val()){
            var r = checkCaptcha(field.val());
            if(r.responseText == 'ok'){
                field.removeClass('error');
                $('.captcha .error-messages').addClass('hidden');
            }
            else{
                field.addClass('error').val('');
                $('.refresh-button').trigger('click');
                $('.captcha .error-messages').removeClass('hidden');
                error = true;
            }
        }
        else{
            field.addClass('error');
            $('.refresh-button').trigger('click');
            $('.captcha .error-messages').removeClass('hidden');
            error = true;
        }

        if(!error) return true;
        return false;
    }
    function checkCaptcha(value){
        var rand = Math.floor((Math.random() * 100000) + 1);
        return $.ajax({
            url: url+'securimage/check.php?r='+rand,
            data: {
                value: value
            },
            async: false,
            method: 'post'
        });
    }
    function initMultiUpload1(){
        var attachments_n = 1;
        var max_uploads = 8;
        var max_weight = 10;
        var working = false;
        var uploadButtonContent = '';
        function init(){
            uploadButtonContent = $('#formulario_ias2 .allegati1 .add').html();

            $('#formulario_ias2').on('click', '.allegati1 .add', addAttachemnt);
            $('#formulario_ias2').on('click', '.allegati1 .remove', clearAttachemnt);

            $('#formulario_ias2').on('change', '.allegati1 .inputfile', change);
        }
        function addAttachemnt(e){
            e.preventDefault();

            if(!working){
                $(this).siblings('.allegato.hidden.new').remove();

                if($('#attachments-error').length) $('#attachments-error').remove();

                $(this).prev().before($(this).siblings('.allegato.hidden').clone().addClass('new'));
                $('#formulario_ias2 .allegati1 .allegato.new label').attr('for', 'file'+attachments_n);
                $('#formulario_ias2 .allegati1 .allegato.new input').attr('id', 'file'+attachments_n).attr('name', 'file'+attachments_n);

                $('#formulario_ias2 .allegati1 .allegato.new input:last').trigger('click');
            }
        }
        function clearAttachemnt(e){
            e.preventDefault();

            var id = $(this).parents('.allegato').find('input[type=file]').attr('id');
            uploadFile[id] = false;

            var p = $(this).parents('.allegato');

            p.find('input[type=file]').val('');
            p.find('input[type=file]').next().children('span').text('Allega un file');
            p.remove();

            attachments_n--;

            $('#formulario_ias2 .allegati1 .add').removeClass('hidden');
        }
        function change(event){
            var id = $(this).attr('id');

            tmp = $(this).val().split("\\");
            var v = tmp[tmp.length - 1];

            if(v){
                tmp2 = v.split('.');
                var ext = tmp2[(tmp2.length - 1)];


                $('.allegati1 .error-messages, .allegati1 .error-messages-type, .allegati1 .error-messages-size').addClass('hidden');

                if(ext.toLowerCase() != 'pdf' && ext.toLowerCase() != 'doc' && ext.toLowerCase() != 'docx'){
                    // Type error
                    $('.allegati1 .error-messages-type').removeClass('hidden');
                    $('.allegati1 .allegato.new.hidden .remove').trigger('click');
                }
                else{
                    if(Math.round(event.target.files[0].size / 1048576) > max_weight){
                        // Size error
                        $('.allegati1 .error-messages-size').removeClass('hidden');
                        $('.allegati1 .allegato.new.hidden .remove').trigger('click');
                    }
                    else{
                        $('label[for='+id+'] span').text(v);

                        if($('#attachments-error').length) $('#attachments-error').remove();

                        uploadFile[id] = event.target.files;

                        $('.allegati1 .allegato.new.hidden').removeClass('new hidden');
                        $('#formulario_ias2 .allegati1 .add').html(uploadButtonContent);


                        attachments_n++;
                        if(max_uploads < attachments_n) $('#formulario_ias2 .allegati1 .add').addClass('hidden');
                    }
                }
            }
        }
        init();
    }
    function initMultiUpload2(){
        var attachments_n = 2;
        var max_uploads = 1;
        var max_weight = 10;
        var working = false;
        var uploadButtonContent = '';
        function init(){
            uploadButtonContent = $('#formulario_ias .allegati2 .add').html();

            $('#formulario_ias').on('click', '.allegati2 .add', addAttachemnt);
            $('#formulario_ias').on('click', '.allegati2 .remove', clearAttachemnt);

            $('#formulario_ias').on('change', '.allegati2 .inputfile', change);
        }
        function addAttachemnt(e){
            e.preventDefault();

            if(!working){
                $(this).siblings('.allegato.hidden.new').remove();

                if($('#attachments-error').length) $('#attachments-error').remove();

                $(this).prev().before($(this).siblings('.allegato.hidden').clone().addClass('new'));
                $('#formulario_ias .allegati2 .allegato.new label').attr('for', 'file'+attachments_n);
                $('#formulario_ias .allegati2 .allegato.new input').attr('id', 'file'+attachments_n).attr('name', 'file'+attachments_n);

                $('#formulario_ias .allegati2 .allegato.new input:last').trigger('click');
            }
        }
        function clearAttachemnt(e){
            e.preventDefault();

            var id = $(this).parents('.allegato').find('input[type=file]').attr('id');
            uploadFile[id] = false;

            var p = $(this).parents('.allegato');

            p.find('input[type=file]').val('');
            p.find('input[type=file]').next().children('span').text('Allega un file');
            p.remove();

            attachments_n--;

            $('#formulario_ias .allegati2 .add').removeClass('hidden');
        }
        function change(event){
            var id = $(this).attr('id');

            tmp = $(this).val().split("\\");
            var v = tmp[tmp.length - 1];

            if(v){
                tmp2 = v.split('.');
                var ext = tmp2[(tmp2.length - 1)];


                $('.allegati2 .error-messages, .allegati2 .error-messages-type, .allegati2 .error-messages-size').addClass('hidden');

                if(ext.toLowerCase() != 'jpg' && ext.toLowerCase() != 'pdf' && ext.toLowerCase() != 'png'){
                    // Type error
                    $('.allegati2 .error-messages-type').removeClass('hidden');
                    $('.allegati2 .allegato.new.hidden .remove').trigger('click');
                }
                else{
                    if(Math.round(event.target.files[0].size / 1048576) > max_weight){
                        // Size error
                        $('.allegati2 .error-messages-size').removeClass('hidden');
                        $('.allegati2 .allegato.new.hidden .remove').trigger('click');
                    }
                    else{
                        $('label[for='+id+'] span').text(v);

                        if($('#attachments-error').length) $('#attachments-error').remove();

                        uploadFile[id] = event.target.files;

                        $('.allegati2 .allegato.new.hidden').removeClass('new hidden');
                        $('#formulario_ias .allegati2 .add').html(uploadButtonContent);


                        attachments_n++;
                        if(max_uploads < attachments_n) $('#formulario_ias .allegati2 .add').addClass('hidden');
                    }
                }
            }
        }
        init();
    }
    init();
}

function initFormularioIASAdeguamento1(){
    var uploadFile = {};
    var url = '/fileadmin/DSS/IAS/formulario_ias_adeguamento_1/';
    var loading = false;
    var utile_presumibile = false;
    function init(){
        $('.intro .start').click(startForm)
        $('input[name=adeguare]').change(checkAdeguare)
        $('input[name=adeguare_retroattivi]').change(checkAdeguamentiRetroattivi)
        $('.send-form').click(send);

        $.getScript(url+'securimage/securimage.js', function (){
            captcha_image_audioObj = new SecurimageAudio({ audioElement: 'captcha_image_audio', controlsElement: 'captcha_image_audio_controls' });
        });

        initMultiUpload1();
    }
    function startForm(){
        $('.intro').addClass('hidden')
        $('form.hidden').removeClass('hidden')
    }
    function checkAdeguare(){
        if($('#adeguare1').is(':checked')){
            $('.utile_presumibile').removeClass('hidden');
            utile_presumibile = true;
        }
        else{
            $('.utile_presumibile').addClass('hidden');
            utile_presumibile = false;
        }
    }
    function checkAdeguamentiRetroattivi(){
        if($(this).is(':checked')) $(this).parent().next().removeClass('hidden')
        else{
            $(this).parent().next().addClass('hidden')
            $(this).parents('.checkbox').next().addClass('hidden')
        }
    }
    function send(e){
        e.preventDefault();

        if(!loading){
            loading = true;

            var error = false;


            if(!checkField('#numero_affiliato')) error = true;
            if(!checkField('#nome')) error = true;
            if(!checkField('#cognome')) error = true;
            if(!checkField('#ragione_sociale')) error = true;
            if(!checkField('#indirizzo')) error = true;
            if(!checkField('#cap')) error = true;
            if(!checkField('#localita')) error = true;
            if(!checkField('#nazione')) error = true;
            if(!checkField('#telefono')) error = true;
            if(!checkField('#email', 'email')) error = true;
            if(!checkField('input[name=adeguare]', 'radio')) error = true;

            if(utile_presumibile){
                if(!checkField('#utile_presumibile')) error = true;
            }

            if($('input[name=adeguare_retroattivi]:checked').length){
                $('input[name=adeguare_retroattivi]:checked').each(function (){
                    var f = $('input[name='+$(this).attr('id')+'_v]')
                    if(f.val()) $(this).parents('.checkbox').next().addClass('hidden')
                    else{
                        $(this).parents('.checkbox').next().removeClass('hidden')
                        error = true
                    }
                })
            }

            // // Allegati 1
            // if(!$('.allegati1 .allegato:not(.hidden)').length){
            //     error = true;
            //     $('.allegati1 .error-messages').removeClass('hidden');
            // }
            // else $('.allegati1 .error-messages').addClass('hidden');

            if(!error){
                if(!checkCaptchaField()) error = true;
            }


            if(!error){
                var data = new FormData();

                data.append('numero_affiliato', $('#numero_affiliato').val());
                data.append('nome', $('#nome').val());
                data.append('cognome', $('#cognome').val());
                data.append('ragione_sociale', $('#ragione_sociale').val());
                data.append('indirizzo', $('#indirizzo').val());
                data.append('cap', $('#cap').val());
                data.append('localita', $('#localita').val());
                data.append('nazione', $('#nazione').val());
                data.append('telefono', $('#telefono').val());
                data.append('email', $('#email').val());
                data.append('adeguare', $('input[name=adeguare]:checked').val());
                data.append('utile_presumibile', $('#utile_presumibile').val());

                if($('input[name=adeguare_retroattivi]:checked').length){
                    var d = {}
                    $('input[name=adeguare_retroattivi]:checked').each(function (){
                        d[$(this).val()] = $('input[name='+$(this).attr('id')+'_v]').val()
                    })
                    data.append('adeguare_retroattivi', JSON.stringify(d))
                }

                for(x in uploadFile){
                    data.append(x, document.getElementById(x).files[0]);
                }

                var button_text = $('button.send-form').text();
                $('button.send-form').html('<i class="fa fa-spinner fa-spin"></i>').addClass('disabled');
                $.ajax({
                    url: url+'save.php', // point to server-side PHP script
                    dataType: 'text',  // what to expect back from the PHP script, if anything
                    cache: false,
                    contentType: false,
                    processData: false,
                    data: data,
                    type: 'post',
                    success: function(php_script_response){
                        if(php_script_response == 'ok'){
                            $('form, .intro').remove();
                            $('.success').removeClass('hidden');
                        }
                        else{
                            $('button.send-form').html(button_text).removeClass('disabled');
                            loading = false;

                            // if(php_script_response == 'no_file'){
                            //     $('.allegati .error-messages').removeClass('hidden');
                            // }
                            // else if(php_script_response == 'filesize'){
                            //     $('.allegati .error-messages-size').removeClass('hidden');
                            // }
                        }
                    }
                });
            }
            else{
                loading = false;
                $('html, body').animate({'scrollTop': $('.error-messages:not(.hidden):first').offset().top - 50}, 50)
            }
        }
    }
    function checkField(s, type){
        if(typeof type == 'undefined'){
            if($(s).val() == ''){
                $(s).siblings('.error-messages').removeClass('hidden');
                return false;
            }
            else{
                $(s).siblings('.error-messages').addClass('hidden');
                return true;
            }
        }
        else if(type == 'radio' || type == 'checkbox'){
            if($(s+':checked').length == 0){
                $(s+':first').parent().parent().siblings('.error-messages').removeClass('hidden');
                return false;
            }
            else{
                $(s+':first').parent().parent().siblings('.error-messages').addClass('hidden');
                return true;
            }
        }
        else if(type == 'email'){
            if($(s).val() == '' || !checkEmail($(s).val())){
                $(s).siblings('.error-messages').removeClass('hidden');
                return false;
            }
            else{
                $(s).siblings('.error-messages').addClass('hidden');
                return true;
            }
        }
        else if(type == 'date'){
            if($(s).val() == '' || !checkDate($(s).val())){
                $(s).siblings('.error-messages').removeClass('hidden');
                return false;
            }
            else{
                $(s).siblings('.error-messages').addClass('hidden');
                return true;
            }
        }
    }
    function checkEmail(email) {
        var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(String(email).toLowerCase());
    }
    function checkDate(value){
        if(new RegExp("[0-9]{2}\.[0-9]{2}\.[0-9]{4}").test(value)) return true;
        else return false;
    }
    function checkCaptchaField(){
        var field = $('input[name=captcha]');
        var error = false;

        if(field.val()){
            var r = checkCaptcha(field.val());
            if(r.responseText == 'ok'){
                field.removeClass('error');
                $('.captcha .error-messages').addClass('hidden');
            }
            else{
                field.addClass('error').val('');
                $('.refresh-button').trigger('click');
                $('.captcha .error-messages').removeClass('hidden');
                error = true;
            }
        }
        else{
            field.addClass('error');
            $('.refresh-button').trigger('click');
            $('.captcha .error-messages').removeClass('hidden');
            error = true;
        }

        if(!error) return true;
        return false;
    }
    function checkCaptcha(value){
        var rand = Math.floor((Math.random() * 100000) + 1);
        return $.ajax({
            url: url+'securimage/check.php?r='+rand,
            data: {
                value: value
            },
            async: false,
            method: 'post'
        });
    }
    function initMultiUpload1(){
        var id_form = '#formulario_ias_adeguamento_1';
        var attachments_n = 1;
        var max_uploads = 5;
        var max_weight = 10;
        var working = false;
        var uploadButtonContent = '';
        function init(){
            uploadButtonContent = $(id_form+' .allegati1 .add').html();

            $(id_form).on('click', '.allegati1 .add', addAttachemnt);
            $(id_form).on('click', '.allegati1 .remove', clearAttachemnt);

            $(id_form).on('change', '.allegati1 .inputfile', change);
        }
        function addAttachemnt(e){
            e.preventDefault();

            if(!working){
                $(this).siblings('.allegato.hidden.new').remove();

                if($('#attachments-error').length) $('#attachments-error').remove();

                $(this).prev().before($(this).siblings('.allegato.hidden').clone().addClass('new'));
                $(id_form+' .allegati1 .allegato.new label').attr('for', 'file'+attachments_n);
                $(id_form+' .allegati1 .allegato.new input').attr('id', 'file'+attachments_n).attr('name', 'file'+attachments_n);

                $(id_form+' .allegati1 .allegato.new input:last').trigger('click');
            }
        }
        function clearAttachemnt(e){
            e.preventDefault();

            var id = $(this).parents('.allegato').find('input[type=file]').attr('id');
            uploadFile[id] = false;

            var p = $(this).parents('.allegato');

            p.find('input[type=file]').val('');
            p.find('input[type=file]').next().children('span').text('Allega un file');
            p.remove();

            attachments_n--;
            if(attachments_n < 1) attachments_n = 1

            $(id_form+' .allegati1 .add').removeClass('hidden');

            // Reset ids
            if($(id_form+' .allegati1 .allegato:not(.hidden)').length){
                var n = 1
                $(id_form+' .allegati1 .allegato:not(.hidden)').each(function (){
                    $(this).find('input').attr('name', 'file'+n).attr('id', 'file'+n)
                    $(this).find('label').attr('for', 'file'+n)
                    n++
                })
            }
        }
        function change(event){
            var id = $(this).attr('id');

            tmp = $(this).val().split("\\");
            var v = tmp[tmp.length - 1];

            if(v){
                tmp2 = v.split('.');
                var ext = tmp2[(tmp2.length - 1)].toLowerCase();


                $('.allegati1 .error-messages, .allegati1 .error-messages-type, .allegati1 .error-messages-size').addClass('hidden');

                if(ext != 'jpg' && ext != 'jpeg' && ext != 'pdf' && ext != 'png' && ext != 'doc' && ext != 'docx' && ext != 'xls' && ext != 'xlsx'){
                    // Type error
                    $('.allegati1 .error-messages-type').removeClass('hidden');
                    $('.allegati1 .allegato.new.hidden .remove').trigger('click');
                }
                else{
                    if(Math.round(event.target.files[0].size / 1048576) > max_weight){
                        // Size error
                        $('.allegati1 .error-messages-size').removeClass('hidden');
                        $('.allegati1 .allegato.new.hidden .remove').trigger('click');
                    }
                    else{
                        $('label[for='+id+'] span').text(v);

                        if($('#attachments-error').length) $('#attachments-error').remove();

                        uploadFile[id] = event.target.files;

                        $('.allegati1 .allegato.new.hidden').removeClass('new hidden');
                        $(id_form+' .allegati1 .add').html(uploadButtonContent);


                        attachments_n++;
                        if(max_uploads < attachments_n) $(id_form+' .allegati1 .add').addClass('hidden');
                    }
                }
            }
        }
        init();
    }
    init();
}

function initFormularioIASAdeguamento2(){
    var uploadFile = {};
    var url = '/fileadmin/DSS/IAS/formulario_ias_adeguamento_2/';
    var loading = false;
    var anno_contributivo = false;
    function init(){
        $('.intro .start').click(startForm)
        $('input[name=adeguare]').change(checkAdeguare)
        $('input[name=adeguare_anni]').change(checkAdeguamentiRetroattivi)
        $('input[name=redditi]').change(checkRedditi)
        $('.send-form').click(send);

        $.getScript(url+'securimage/securimage.js', function (){
            captcha_image_audioObj = new SecurimageAudio({ audioElement: 'captcha_image_audio', controlsElement: 'captcha_image_audio_controls' });
        });

        initMultiUpload1();
        // initMultiUpload2();



        // $('head').append('<link rel="stylesheet" type="text/css" href="/typo3conf/ext/theme/Resources/Public/css/daterangepicker.css">');
        // $.getScript('/typo3conf/ext/theme/Resources/Public/js/moment.js', function (){
        //     $.getScript('/typo3conf/ext/theme/Resources/Public/js/daterangepicker.js', function (){

        //         var d = new Date();
        //         dd = d.getDate() < 10 ? '0'+d.getDate() : d.getDate();
        //         dm = d.getMonth() + 1 < 10 ? '0'+(d.getMonth() + 1) : d.getMonth() + 1;

        //         $('input[name*=da]').daterangepicker({
        //             autoUpdateInput: false,
        //             locale: {
        //               format: 'DD.MM.YYYY',
        //               firstDay: 1,
        //               cancelLabel: 'Cancella',
        //               applyLabel: 'Applica',
        //               customRangeLabel: "Custom",
        //               daysOfWeek: ["Do","Lu","Ma","Me","Gi","Ve", "Sa"],
        //               monthNames: ["Gennaio","Febbraio","Marzo","Aprile","Maggio","Giugno","Luglio","Agosto","Settembre","Ottobre","Novembre","Dicembre"],
        //             },
        //             // minDate: dd+'/'+dm+'/'+d.getFullYear()
        //         });

        //         $('input[name*=da]').on('apply.daterangepicker', function(ev, picker) {
        //             $(this).val(picker.startDate.format('DD.MM.YYYY') + ' - ' + picker.endDate.format('DD.MM.YYYY'));
        //             // $('.myForm').submit();
        //         });

        //         $('input[name*=da]').on('cancel.daterangepicker', function(ev, picker) {
        //             $(this).val('');
        //             // $('.myForm').submit();
        //         });
        //     });
        // });
        $('input[name*=da]').attr('placeholder', 'xx.xx.xxxx')

    }
    function startForm(){
        $('.intro').addClass('hidden')
        $('form.hidden').removeClass('hidden')
    }
    function checkAdeguare(){
        if($('#adeguare1').is(':checked')){
            $('.anno_contributivo').removeClass('hidden');
            $('.redditi, .sostanza_netta').addClass('hidden');
            anno_contributivo = true;
        }
        else{
            $('.anno_contributivo').addClass('hidden');
            $('.redditi, .sostanza_netta').removeClass('hidden');
            anno_contributivo = false;
        }
    }
    function checkAdeguamentiRetroattivi(){
        if($(this).is(':checked')) $(this).parent().next().removeClass('hidden')
        else{
            $(this).parent().next().addClass('hidden')
            $(this).parents('.checkbox').next().addClass('hidden')
        }
    }
    function checkRedditi(){
        var p = $(this).parents('tr')
        if($(this).is(':checked')){
            p.find('input[type=text]').removeAttr('disabled')
        }
        else{
            p.find('input[type=text]').prop('disabled', true)
            p.find('.error-messages').addClass('hidden')
        }
    }
    function send(e){
        e.preventDefault();

        if(!loading){
            loading = true;

            var error = false;


            if(!checkField('#numero_affiliato')) error = true;
            if(!checkField('#nome')) error = true;
            if(!checkField('#cognome')) error = true;
            // if(!checkField('#ragione_sociale')) error = true;
            if(!checkField('#indirizzo')) error = true;
            if(!checkField('#cap')) error = true;
            if(!checkField('#localita')) error = true;
            if(!checkField('#nazione')) error = true;
            if(!checkField('#telefono')) error = true;
            if(!checkField('#email', 'email')) error = true;
            if(!checkField('input[name=adeguare]', 'radio')) error = true;

            if(anno_contributivo){
                if(!checkField('#anno_contributivo')) error = true;

                if($('input[name=adeguare_anni]:checked').length){
                    $('input[name=adeguare_anni]:checked').each(function (){
                        var f = $('input[name='+$(this).attr('id')+'_v]')
                        if(f.val()) $(this).parents('.checkbox').next().addClass('hidden')
                        else{
                            $(this).parents('.checkbox').next().removeClass('hidden')
                            error = true
                        }
                    })
                }
            }



            if($('input[name=redditi]:checked').length){
                $('input[name=redditi]:checked').each(function (){
                    if(!checkField('input[name='+$(this).attr('id')+'_chf]')) error = true;
                    if(!checkField('input[name='+$(this).attr('id')+'_da]')) error = true;
                })
            }

            // // Allegati 1
            // if(!$('.allegati1 .allegato:not(.hidden)').length){
            //     error = true;
            //     $('.allegati1 .error-messages').removeClass('hidden');
            // }
            // else $('.allegati1 .error-messages').addClass('hidden');

            if(!error){
                if(!checkCaptchaField()) error = true;
            }


            if(!error){
                var data = new FormData();

                data.append('numero_affiliato', $('#numero_affiliato').val());
                data.append('nome', $('#nome').val());
                data.append('cognome', $('#cognome').val());
                // data.append('ragione_sociale', $('#ragione_sociale').val());
                data.append('indirizzo', $('#indirizzo').val());
                data.append('cap', $('#cap').val());
                data.append('localita', $('#localita').val());
                data.append('nazione', $('#nazione').val());
                data.append('telefono', $('#telefono').val());
                data.append('email', $('#email').val());
                data.append('adeguare', $('input[name=adeguare]:checked').val());
                data.append('anno_contributivo', $('#anno_contributivo').val());

                if($('input[name=adeguare_anni]:checked').length){
                    var d = {}
                    $('input[name=adeguare_anni]:checked').each(function (){
                        d[$(this).val()] = $('input[name='+$(this).attr('id')+'_v]').val()
                    })
                    data.append('adeguare_anni', JSON.stringify(d))
                }

                if($('input[name=redditi]:checked').length){
                    var d = {}
                    $('input[name=redditi]:checked').each(function (){
                        d[$(this).val()] = {
                            'chf': $('input[name='+$(this).attr('id')+'_chf]').val(),
                            'date': $('input[name='+$(this).attr('id')+'_da]').val()
                        }
                    })
                    data.append('redditi', JSON.stringify(d))
                }

                for(x in uploadFile){
                    data.append(x, document.getElementById(x).files[0]);
                }

                var button_text = $('button.send-form').text();
                $('button.send-form').html('<i class="fa fa-spinner fa-spin"></i>').addClass('disabled');
                $.ajax({
                    url: url+'save.php', // point to server-side PHP script
                    dataType: 'text',  // what to expect back from the PHP script, if anything
                    cache: false,
                    contentType: false,
                    processData: false,
                    data: data,
                    type: 'post',
                    success: function(php_script_response){
                        if(php_script_response == 'ok'){
                            $('form, .intro').remove();
                            $('.success').removeClass('hidden');
                        }
                        else{
                            $('button.send-form').html(button_text).removeClass('disabled');
                            loading = false;

                            // if(php_script_response == 'no_file'){
                            //     $('.allegati .error-messages').removeClass('hidden');
                            // }
                            // else if(php_script_response == 'filesize'){
                            //     $('.allegati .error-messages-size').removeClass('hidden');
                            // }
                        }
                    }
                });
            }
            else{
                loading = false;
                $('html, body').animate({'scrollTop': $('.error-messages:not(.hidden):first').offset().top - 50}, 50)
            }
        }
    }
    function checkField(s, type){
        if(typeof type == 'undefined'){
            if($(s).val() == ''){
                $(s).siblings('.error-messages').removeClass('hidden');
                return false;
            }
            else{
                $(s).siblings('.error-messages').addClass('hidden');
                return true;
            }
        }
        else if(type == 'radio' || type == 'checkbox'){
            if($(s+':checked').length == 0){
                $(s+':first').parent().parent().siblings('.error-messages').removeClass('hidden');
                return false;
            }
            else{
                $(s+':first').parent().parent().siblings('.error-messages').addClass('hidden');
                return true;
            }
        }
        else if(type == 'email'){
            if($(s).val() == '' || !checkEmail($(s).val())){
                $(s).siblings('.error-messages').removeClass('hidden');
                return false;
            }
            else{
                $(s).siblings('.error-messages').addClass('hidden');
                return true;
            }
        }
        else if(type == 'date'){
            if($(s).val() == '' || !checkDate($(s).val())){
                $(s).siblings('.error-messages').removeClass('hidden');
                return false;
            }
            else{
                $(s).siblings('.error-messages').addClass('hidden');
                return true;
            }
        }
    }
    function checkEmail(email) {
        var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(String(email).toLowerCase());
    }
    function checkDate(value){
        if(new RegExp("[0-9]{2}\.[0-9]{2}\.[0-9]{4}").test(value)) return true;
        else return false;
    }
    function checkCaptchaField(){
        var field = $('input[name=captcha]');
        var error = false;

        if(field.val()){
            var r = checkCaptcha(field.val());
            if(r.responseText == 'ok'){
                field.removeClass('error');
                $('.captcha .error-messages').addClass('hidden');
            }
            else{
                field.addClass('error').val('');
                $('.refresh-button').trigger('click');
                $('.captcha .error-messages').removeClass('hidden');
                error = true;
            }
        }
        else{
            field.addClass('error');
            $('.refresh-button').trigger('click');
            $('.captcha .error-messages').removeClass('hidden');
            error = true;
        }

        if(!error) return true;
        return false;
    }
    function checkCaptcha(value){
        var rand = Math.floor((Math.random() * 100000) + 1);
        return $.ajax({
            url: url+'securimage/check.php?r='+rand,
            data: {
                value: value
            },
            async: false,
            method: 'post'
        });
    }
    function initMultiUpload1(){
        var id_form = '#formulario_ias_adeguamento_2';
        var attachments_n = 1;
        var max_uploads = 5;
        var max_weight = 10;
        var working = false;
        var uploadButtonContent = '';
        function init(){
            uploadButtonContent = $(id_form+' .allegati1 .add').html();

            $(id_form).on('click', '.allegati1 .add', addAttachemnt);
            $(id_form).on('click', '.allegati1 .remove', clearAttachemnt);

            $(id_form).on('change', '.allegati1 .inputfile', change);
        }
        function addAttachemnt(e){
            e.preventDefault();

            if(!working){
                $(this).siblings('.allegato.hidden.new').remove();

                if($('#attachments-error').length) $('#attachments-error').remove();

                $(this).prev().before($(this).siblings('.allegato.hidden').clone().addClass('new'));
                $(id_form+' .allegati1 .allegato.new label').attr('for', 'file'+attachments_n);
                $(id_form+' .allegati1 .allegato.new input').attr('id', 'file'+attachments_n).attr('name', 'file'+attachments_n);

                $(id_form+' .allegati1 .allegato.new input:last').trigger('click');
            }
        }
        function clearAttachemnt(e){
            e.preventDefault();

            var id = $(this).parents('.allegato').find('input[type=file]').attr('id');
            uploadFile[id] = false;

            var p = $(this).parents('.allegato');

            p.find('input[type=file]').val('');
            p.find('input[type=file]').next().children('span').text('Allega un file');
            p.remove();

            attachments_n--;
            if(attachments_n < 1) attachments_n = 1

            $(id_form+' .allegati1 .add').removeClass('hidden');

            // Reset ids
            if($(id_form+' .allegati1 .allegato:not(.hidden)').length){
                var n = 1
                $(id_form+' .allegati1 .allegato:not(.hidden)').each(function (){
                    $(this).find('input').attr('name', 'file'+n).attr('id', 'file'+n)
                    $(this).find('label').attr('for', 'file'+n)
                    n++
                })
            }
        }
        function change(event){
            var id = $(this).attr('id');

            tmp = $(this).val().split("\\");
            var v = tmp[tmp.length - 1];

            if(v){
                tmp2 = v.split('.');
                var ext = tmp2[(tmp2.length - 1)].toLowerCase();


                $('.allegati1 .error-messages, .allegati1 .error-messages-type, .allegati1 .error-messages-size').addClass('hidden');

                if(ext != 'jpg' && ext != 'pdf' && ext != 'png' && ext != 'doc' && ext != 'docx' && ext != 'xls' && ext != 'xlsx'){
                    // Type error
                    $('.allegati1 .error-messages-type').removeClass('hidden');
                    $('.allegati1 .allegato.new.hidden .remove').trigger('click');
                }
                else{
                    if(Math.round(event.target.files[0].size / 1048576) > max_weight){
                        // Size error
                        $('.allegati1 .error-messages-size').removeClass('hidden');
                        $('.allegati1 .allegato.new.hidden .remove').trigger('click');
                    }
                    else{
                        $('label[for='+id+'] span').text(v);

                        if($('#attachments-error').length) $('#attachments-error').remove();

                        uploadFile[id] = event.target.files;

                        $('.allegati1 .allegato.new.hidden').removeClass('new hidden');
                        $(id_form+' .allegati1 .add').html(uploadButtonContent);


                        attachments_n++;
                        if(max_uploads < attachments_n) $(id_form+' .allegati1 .add').addClass('hidden');
                    }
                }
            }
        }
        init();
    }
    init();
}

function initFormularioIASAdeguamento3(){
    var uploadFile = {};
    var url = '/fileadmin/DSS/IAS/formulario_ias_adeguamento_3/';
    var loading = false;
    var reddito_professionale = false;
    function init(){
        $('.intro .start').click(startForm)
        $('input[name=adeguare]').change(checkAdeguare)
        $('input[name=adeguare_anni]').change(checkAdeguamentiRetroattivi)
        $('.send-form').click(send);

        $.getScript(url+'securimage/securimage.js', function (){
            captcha_image_audioObj = new SecurimageAudio({ audioElement: 'captcha_image_audio', controlsElement: 'captcha_image_audio_controls' });
        });

        initMultiUpload1();
    }
    function startForm(){
        $('.intro').addClass('hidden')
        $('form.hidden').removeClass('hidden')
    }
    function checkAdeguare(){
        if($('#adeguare1').is(':checked')){
            $('.reddito_professionale').removeClass('hidden');
            $('.redditi').addClass('hidden');
            reddito_professionale = true;
        }
        else{
            $('.reddito_professionale').addClass('hidden');
            $('.redditi').removeClass('hidden');
            reddito_professionale = false;
        }
    }
    function checkAdeguamentiRetroattivi(){
        if($(this).is(':checked')) $(this).parent().next().removeClass('hidden')
        else{
            $(this).parent().next().addClass('hidden')
            $(this).parents('.checkbox').next().addClass('hidden')
        }
    }
    function send(e){
        e.preventDefault();

        if(!loading){
            loading = true;

            var error = false;


            if(!checkField('#numero_affiliato')) error = true;
            if(!checkField('#nome')) error = true;
            if(!checkField('#cognome')) error = true;
            if(!checkField('#ragione_sociale')) error = true;
            if(!checkField('#indirizzo')) error = true;
            if(!checkField('#cap')) error = true;
            if(!checkField('#localita')) error = true;
            if(!checkField('#nazione')) error = true;
            if(!checkField('#telefono')) error = true;
            if(!checkField('#email', 'email')) error = true;
            if(!checkField('input[name=adeguare]', 'radio')) error = true;

            if(reddito_professionale){
                if(!checkField('#reddito_professionale')) error = true;
            }

            if($('input[name=adeguare_anni]:checked').length){
                $('input[name=adeguare_anni]:checked').each(function (){
                    var f = $('input[name='+$(this).attr('id')+'_v]')
                    if(f.val()) $(this).parents('.checkbox').next().addClass('hidden')
                    else{
                        $(this).parents('.checkbox').next().removeClass('hidden')
                        error = true
                    }
                })
            }

            // // Allegati 1
            // if(!$('.allegati1 .allegato:not(.hidden)').length){
            //     error = true;
            //     $('.allegati1 .error-messages').removeClass('hidden');
            // }
            // else $('.allegati1 .error-messages').addClass('hidden');

            if(!error){
                if(!checkCaptchaField()) error = true;
            }


            if(!error){
                var data = new FormData();

                data.append('numero_affiliato', $('#numero_affiliato').val());
                data.append('nome', $('#nome').val());
                data.append('cognome', $('#cognome').val());
                data.append('ragione_sociale', $('#ragione_sociale').val());
                data.append('indirizzo', $('#indirizzo').val());
                data.append('cap', $('#cap').val());
                data.append('localita', $('#localita').val());
                data.append('nazione', $('#nazione').val());
                data.append('telefono', $('#telefono').val());
                data.append('email', $('#email').val());
                data.append('adeguare', $('input[name=adeguare]:checked').val());
                data.append('reddito_professionale', $('#reddito_professionale').val());

                if($('input[name=adeguare_anni]:checked').length){
                    var d = {}
                    $('input[name=adeguare_anni]:checked').each(function (){
                        d[$(this).val()] = $('input[name='+$(this).attr('id')+'_v]').val()
                    })
                    data.append('adeguare_anni', JSON.stringify(d))
                }

                for(x in uploadFile){
                    data.append(x, document.getElementById(x).files[0]);
                }

                var button_text = $('button.send-form').text();
                $('button.send-form').html('<i class="fa fa-spinner fa-spin"></i>').addClass('disabled');
                $.ajax({
                    url: url+'save.php', // point to server-side PHP script
                    dataType: 'text',  // what to expect back from the PHP script, if anything
                    cache: false,
                    contentType: false,
                    processData: false,
                    data: data,
                    type: 'post',
                    success: function(php_script_response){
                        if(php_script_response == 'ok'){
                            $('form, .intro').remove();
                            $('.success').removeClass('hidden');
                        }
                        else{
                            $('button.send-form').html(button_text).removeClass('disabled');
                            loading = false;

                            // if(php_script_response == 'no_file'){
                            //     $('.allegati .error-messages').removeClass('hidden');
                            // }
                            // else if(php_script_response == 'filesize'){
                            //     $('.allegati .error-messages-size').removeClass('hidden');
                            // }
                        }
                    }
                });
            }
            else{
                loading = false;
                $('html, body').animate({'scrollTop': $('.error-messages:not(.hidden):first').offset().top - 50}, 50)
            }
        }
    }
    function checkField(s, type){
        if(typeof type == 'undefined'){
            if($(s).val() == ''){
                $(s).siblings('.error-messages').removeClass('hidden');
                return false;
            }
            else{
                $(s).siblings('.error-messages').addClass('hidden');
                return true;
            }
        }
        else if(type == 'radio' || type == 'checkbox'){
            if($(s+':checked').length == 0){
                $(s+':first').parent().parent().siblings('.error-messages').removeClass('hidden');
                return false;
            }
            else{
                $(s+':first').parent().parent().siblings('.error-messages').addClass('hidden');
                return true;
            }
        }
        else if(type == 'email'){
            if($(s).val() == '' || !checkEmail($(s).val())){
                $(s).siblings('.error-messages').removeClass('hidden');
                return false;
            }
            else{
                $(s).siblings('.error-messages').addClass('hidden');
                return true;
            }
        }
        else if(type == 'date'){
            if($(s).val() == '' || !checkDate($(s).val())){
                $(s).siblings('.error-messages').removeClass('hidden');
                return false;
            }
            else{
                $(s).siblings('.error-messages').addClass('hidden');
                return true;
            }
        }
    }
    function checkEmail(email) {
        var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(String(email).toLowerCase());
    }
    function checkDate(value){
        if(new RegExp("[0-9]{2}\.[0-9]{2}\.[0-9]{4}").test(value)) return true;
        else return false;
    }
    function checkCaptchaField(){
        var field = $('input[name=captcha]');
        var error = false;

        if(field.val()){
            var r = checkCaptcha(field.val());
            if(r.responseText == 'ok'){
                field.removeClass('error');
                $('.captcha .error-messages').addClass('hidden');
            }
            else{
                field.addClass('error').val('');
                $('.refresh-button').trigger('click');
                $('.captcha .error-messages').removeClass('hidden');
                error = true;
            }
        }
        else{
            field.addClass('error');
            $('.refresh-button').trigger('click');
            $('.captcha .error-messages').removeClass('hidden');
            error = true;
        }

        if(!error) return true;
        return false;
    }
    function checkCaptcha(value){
        var rand = Math.floor((Math.random() * 100000) + 1);
        return $.ajax({
            url: url+'securimage/check.php?r='+rand,
            data: {
                value: value
            },
            async: false,
            method: 'post'
        });
    }
    function initMultiUpload1(){
        var id_form = '#formulario_ias_adeguamento_3';
        var attachments_n = 1;
        var max_uploads = 5;
        var max_weight = 10;
        var working = false;
        var uploadButtonContent = '';
        function init(){
            uploadButtonContent = $(id_form+' .allegati1 .add').html();

            $(id_form).on('click', '.allegati1 .add', addAttachemnt);
            $(id_form).on('click', '.allegati1 .remove', clearAttachemnt);

            $(id_form).on('change', '.allegati1 .inputfile', change);
        }
        function addAttachemnt(e){
            e.preventDefault();

            if(!working){
                $(this).siblings('.allegato.hidden.new').remove();

                if($('#attachments-error').length) $('#attachments-error').remove();

                $(this).prev().before($(this).siblings('.allegato.hidden').clone().addClass('new'));
                $(id_form+' .allegati1 .allegato.new label').attr('for', 'file'+attachments_n);
                $(id_form+' .allegati1 .allegato.new input').attr('id', 'file'+attachments_n).attr('name', 'file'+attachments_n);

                $(id_form+' .allegati1 .allegato.new input:last').trigger('click');
            }
        }
        function clearAttachemnt(e){
            e.preventDefault();

            var id = $(this).parents('.allegato').find('input[type=file]').attr('id');
            uploadFile[id] = false;

            var p = $(this).parents('.allegato');

            p.find('input[type=file]').val('');
            p.find('input[type=file]').next().children('span').text('Allega un file');
            p.remove();

            attachments_n--;
            if(attachments_n < 1) attachments_n = 1

            $(id_form+' .allegati1 .add').removeClass('hidden');

            // Reset ids
            if($(id_form+' .allegati1 .allegato:not(.hidden)').length){
                var n = 1
                $(id_form+' .allegati1 .allegato:not(.hidden)').each(function (){
                    $(this).find('input').attr('name', 'file'+n).attr('id', 'file'+n)
                    $(this).find('label').attr('for', 'file'+n)
                    n++
                })
            }
        }
        function change(event){
            var id = $(this).attr('id');

            tmp = $(this).val().split("\\");
            var v = tmp[tmp.length - 1];

            if(v){
                tmp2 = v.split('.');
                var ext = tmp2[(tmp2.length - 1)].toLowerCase();


                $('.allegati1 .error-messages, .allegati1 .error-messages-type, .allegati1 .error-messages-size').addClass('hidden');

                if(ext != 'jpg' && ext != 'pdf' && ext != 'png' && ext != 'doc' && ext != 'docx' && ext != 'xls' && ext != 'xlsx'){
                    // Type error
                    $('.allegati1 .error-messages-type').removeClass('hidden');
                    $('.allegati1 .allegato.new.hidden .remove').trigger('click');
                }
                else{
                    if(Math.round(event.target.files[0].size / 1048576) > max_weight){
                        // Size error
                        $('.allegati1 .error-messages-size').removeClass('hidden');
                        $('.allegati1 .allegato.new.hidden .remove').trigger('click');
                    }
                    else{
                        $('label[for='+id+'] span').text(v);

                        if($('#attachments-error').length) $('#attachments-error').remove();

                        uploadFile[id] = event.target.files;

                        $('.allegati1 .allegato.new.hidden').removeClass('new hidden');
                        $(id_form+' .allegati1 .add').html(uploadButtonContent);


                        attachments_n++;
                        if(max_uploads < attachments_n) $(id_form+' .allegati1 .add').addClass('hidden');
                    }
                }
            }
        }
        init();
    }
    init();
}

function initFormularioSEL(){
    var uploadFile = {};
    var url = '/fileadmin/DI/SEL/formulario_sel/';
    var loading = false;
    var scelte = false
    function init(){
        var f = $('#formulario_sel').clone()
        $('#formulario_sel').remove()
        $('main .container:eq(2)').append(f)

        $('.iscrizione').click(startForm)
        $('input[name=iscrizione]').change(checkIscrizione)
        $('.send-form').click(send);

        $.getScript(url+'securimage/securimage.js', function (){
            captcha_image_audioObj = new SecurimageAudio({ audioElement: 'captcha_image_audio', controlsElement: 'captcha_image_audio_controls' });
        });
    }
    function startForm(e){
        e.preventDefault()
        $('#formulario_sel').removeClass('hidden')
        $('html, body').animate({scrollTop: $('#formulario_sel').offset().top - 50}, 500)
    }
    function checkIscrizione(){
        if($(this).val() == 1 || $(this).val() == 3){
            $('.scelte').removeClass('hidden')
            scelte = true
        }
        else{
            $('.scelte').addClass('hidden')
            scelte = false
        }
    }
    function send(e){
        e.preventDefault();

        if(!loading){
            loading = true;

            var error = false;

            if(!checkField('#nome')) error = true;
            if(!checkField('#cognome')) error = true;
            if(!checkField('#indirizzo')) error = true;
            if(!checkField('#nap')) error = true;
            if(!checkField('#luogo')) error = true;
            if(!checkField('#telefono')) error = true;
            if(!checkField('#email', 'email')) error = true;
            if(!checkField('input[name=ente]', 'radio')) error = true;
            if(!checkField('input[name=ruolo]', 'radio')) error = true;
            if(!checkField('input[name=iscrizione]', 'radio')) error = true;

            // Iscrizioni
            if(scelte){
                if(!checkField('#scelta1')) error = true;
                if(!checkField('#scelta2')) error = true;
            }

            if(!error){
                // Captcha
                if(!checkCaptchaField()) error = true;
            }


            if(!error){
                var data = new FormData()

                data.append('nome', $('#nome').val());
                data.append('cognome', $('#cognome').val());
                data.append('indirizzo', $('#indirizzo').val());
                data.append('nap', $('#nap').val());
                data.append('luogo', $('#luogo').val());
                data.append('telefono', $('#telefono').val());
                data.append('email', $('#email').val());
                data.append('ente', $('input[name=ente]:checked').val());
                data.append('ruolo', $('input[name=ruolo]:checked').val());
                data.append('iscrizione', $('input[name=iscrizione]:checked').val());

                // Iscrizioni
                if(scelte){
                    data.append('scelta1', $('#scelta1').val());
                    data.append('scelta2', $('#scelta2').val());
                }


                var button_text = $('button.send-form').text();
                $('button.send-form').html('<i class="fa fa-spinner fa-spin"></i>').addClass('disabled');
                $.ajax({
                    url: url+'save.php', // point to server-side PHP script
                    dataType: 'text',  // what to expect back from the PHP script, if anything
                    cache: false,
                    contentType: false,
                    processData: false,
                    data: data,
                    type: 'post',
                    success: function(php_script_response){
                        if(php_script_response == 'ok'){
                            $('form').remove();
                            $('.success').removeClass('hidden');
                            $('html, body').animate({scrollTop: $('#formulario_sel').offset().top}, 500)
                        }
                        else{
                            $('button.send-form').html(button_text).removeClass('disabled');
                            loading = false;
                        }
                    }
                });
            }
            else{
                loading = false;
                $('html, body').animate({scrollTop: $('.error-messages:first').offset().top - 70}, 500)
            }
        }
    }
    function checkField(s, type){
        if(typeof type == 'undefined'){
            if($(s).val() == ''){
                $(s).siblings('.error-messages').removeClass('hidden');
                return false;
            }
            else{
                $(s).siblings('.error-messages').addClass('hidden');
                return true;
            }
        }
        else if(type == 'radio' || type == 'checkbox'){
            if($(s+':checked').length == 0){
                $(s+':first').parent().siblings('.error-messages').removeClass('hidden');
                return false;
            }
            else{
                $(s+':first').parent().siblings('.error-messages').addClass('hidden');
                return true;
            }
        }
        else if(type == 'email'){
            if($(s).val() == '' || !checkEmail($(s).val())){
                $(s).siblings('.error-messages').removeClass('hidden');
                return false;
            }
            else{
                $(s).siblings('.error-messages').addClass('hidden');
                return true;
            }
        }
        else if(type == 'date'){
            if($(s).val() == '' || !checkDate($(s).val())){
                $(s).siblings('.error-messages').removeClass('hidden');
                return false;
            }
            else{
                $(s).siblings('.error-messages').addClass('hidden');
                return true;
            }
        }
    }
    function checkEmail(email) {
        var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(String(email).toLowerCase());
    }
    function checkDate(value){
        if(new RegExp("[0-9]{2}\.[0-9]{2}\.[0-9]{4}").test(value)) return true;
        else return false;
    }
    function checkCaptchaField(){
        var field = $('input[name=captcha]');
        var error = false;

        if(field.val()){
            var r = checkCaptcha(field.val());
            if(r.responseText == 'ok'){
                field.removeClass('error');
                $('.captcha .error-messages').addClass('hidden');
            }
            else{
                field.addClass('error').val('');
                $('.refresh-button').trigger('click');
                $('.captcha .error-messages').removeClass('hidden');
                error = true;
            }
        }
        else{
            field.addClass('error');
            $('.refresh-button').trigger('click');
            $('.captcha .error-messages').removeClass('hidden');
            error = true;
        }

        if(!error) return true;
        return false;
    }
    function checkCaptcha(value){
        var rand = Math.floor((Math.random() * 100000) + 1);
        return $.ajax({
            url: url+'securimage/check.php?r='+rand,
            data: {
                value: value
            },
            async: false,
            method: 'post'
        });
    }
    init();
}
function initFormularioTLET(){
    var uploadFile = {};
    var url = '/fileadmin/DFE/DE/formulario_tlet/';
    var loading = false;
    var prestazioniUpload = false;
    var pranzo = false
    function init(){
        $('.modulo_tlet').click(startForm)
       // $('input[name=pranzo]').click(checkPranzo)
        $('.send-form').click(send);

        $.getScript(url+'securimage/securimage.js', function (){
            captcha_image_audioObj = new SecurimageAudio({ audioElement: 'captcha_image_audio', controlsElement: 'captcha_image_audio_controls' });
        });

        // $.getScript('https://raw.githack.com/SortableJS/Sortable/master/Sortable.js', function (){
        //     $.getScript('https://cdn.jsdelivr.net/npm/jquery-sortablejs@latest/jquery-sortable.js', function (){
        //         $('.order').sortable()
        //     });
        // });
    }
    function startForm(e){
        e.preventDefault()
        $('.boxFisso').removeClass('hidden')
        location.hash = 'formulario_tlet'
        $('#nome').trigger('focus')
    }
    function checkPranzo(){
        pranzo = ($('#pranzo1').is(':checked')) ? true : false
        if(pranzo) $('.regime').removeClass('hidden')
        else $('.regime').addClass('hidden')
    }
    function send(e){
        e.preventDefault();

        if(!loading){
            loading = true;

            var error = false;

            if(!checkField('#nome')) error = true;
            if(!checkField('#cognome')) error = true;
            if(!checkField('#azienda')) error = true;
            if(!checkField('#indirizzo')) error = true;
            if(!checkField('#email', 'email')) error = true;
            if(!checkField('#telefono')) error = true;
            if(!checkField('input[name=partecipo]', 'radio')) error = true;
           // if(!checkField('input[name=pranzo]', 'radio')) error = true;

            if(!error){
                // Captcha
                if(!checkCaptchaField()) error = true;
            }


            if(!error){
                var data = new FormData()

                data.append('nome', $('#nome').val());
                data.append('cognome', $('#cognome').val());
                data.append('azienda', $('#azienda').val());
                data.append('indirizzo', $('#indirizzo').val());
                data.append('email', $('#email').val());
                data.append('telefono', $('#telefono').val());
                data.append('partecipo', $('input[name=partecipo]:checked').val());
               // data.append('pranzo', $('input[name=pranzo]:checked').val());

                // Cibo
               /* var cibo = 0
                if($('input[name=cibo]:checked').length){
                    var n = []
                    $('input[name=cibo]:checked').each(function (){
                        n.push($(this).val())
                    })
                    cibo = n.join(',')
                }
                data.append('cibo', cibo);*/

                // Ordine
                var n = []
                $('.order li').each(function (){
                    n.push($(this).data('n')+':'+$(this).children('select').val())
                })
                data.append('ordine', n.join(','));

                // Navetta
                var n = []
                $('input[name=navetta]:checked').each(function (){
                    n.push($(this).val())
                })
                data.append('navetta', n.join(','));


                var button_text = $('button.send-form').text();
                $('button.send-form').html('<i class="fa fa-spinner fa-spin"></i>').addClass('disabled');
                $.ajax({
                    url: url+'save.php', // point to server-side PHP script
                    dataType: 'text',  // what to expect back from the PHP script, if anything
                    cache: false,
                    contentType: false,
                    processData: false,
                    data: data,
                    type: 'post',
                    success: function(php_script_response){
                        if(php_script_response == 'ok'){
                            $('form').remove();
                            $('.success').removeClass('hidden');
                        }
                        else{
                            $('button.send-form').html(button_text).removeClass('disabled');
                            loading = false;
                        }
                    }
                });
            }
            else loading = false;
        }
    }
    function checkField(s, type){
        if(typeof type == 'undefined'){
            if($(s).val() == ''){
                $(s).siblings('.error-messages').removeClass('hidden');
                return false;
            }
            else{
                $(s).siblings('.error-messages').addClass('hidden');
                return true;
            }
        }
        else if(type == 'radio' || type == 'checkbox'){
            if($(s+':checked').length == 0){
                $(s+':first').parent().siblings('.error-messages').removeClass('hidden');
                return false;
            }
            else{
                $(s+':first').parent().siblings('.error-messages').addClass('hidden');
                return true;
            }
        }
        else if(type == 'email'){
            if($(s).val() == '' || !checkEmail($(s).val())){
                $(s).siblings('.error-messages').removeClass('hidden');
                return false;
            }
            else{
                $(s).siblings('.error-messages').addClass('hidden');
                return true;
            }
        }
        else if(type == 'date'){
            if($(s).val() == '' || !checkDate($(s).val())){
                $(s).siblings('.error-messages').removeClass('hidden');
                return false;
            }
            else{
                $(s).siblings('.error-messages').addClass('hidden');
                return true;
            }
        }
    }
    function checkEmail(email) {
        var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(String(email).toLowerCase());
    }
    function checkDate(value){
        if(new RegExp("[0-9]{2}\.[0-9]{2}\.[0-9]{4}").test(value)) return true;
        else return false;
    }
    function checkCaptchaField(){
        var field = $('input[name=captcha]');
        var error = false;

        if(field.val()){
            var r = checkCaptcha(field.val());
            if(r.responseText == 'ok'){
                field.removeClass('error');
                $('.captcha .error-messages').addClass('hidden');
            }
            else{
                field.addClass('error').val('');
                $('.refresh-button').trigger('click');
                $('.captcha .error-messages').removeClass('hidden');
                error = true;
            }
        }
        else{
            field.addClass('error');
            $('.refresh-button').trigger('click');
            $('.captcha .error-messages').removeClass('hidden');
            error = true;
        }

        if(!error) return true;
        return false;
    }
    function checkCaptcha(value){
        var rand = Math.floor((Math.random() * 100000) + 1);
        return $.ajax({
            url: url+'securimage/check.php?r='+rand,
            data: {
                value: value
            },
            async: false,
            method: 'post'
        });
    }
    init();
}
function initFormularioUOSPWorkshop(){
    var url = '/fileadmin/DECS/DS/UOSP/formulario_workshop/';
    var iscritti_max = 30;
    var workshop1_options = {};
    var workshop2_options = {};
    function init(){
        $.getJSON(url+'iscrizioni.json?_='+Math.round(Math.random()*1000000000), function (data){
            if(data.state == 3){
                $('.closed').removeClass('hidden');
            }
            else{
                if(data.state != 1){
                    var n = 1;
                    for(x in data[1]){
                        if(data[1][x] < iscritti_max){
                            $('select[name=workshop1]').append('<option value="'+n+'">'+x+'</option>');
                            workshop1_options[n] = x;
                        }
                        n++;
                    }
                    $('.workshop1').removeClass('disabled');
                    $('select[name=workshop1]').selectpicker('refresh');

                    $('select[name=workshop1]').change(changeSelect1);
                }

                if(data.state != 2){
                    var n = 1;
                    for(x in data[2]){
                        if(data[2][x] < iscritti_max){
                            $('select[name=workshop2]').append('<option value="'+n+'">'+x+'</option>');
                            workshop2_options[n] = x;
                        }
                        n++;
                    }
                    $('.workshop2').removeClass('disabled');
                    $('select[name=workshop2]').selectpicker('refresh');

                    $('select[name=workshop2]').change(changeSelect2);
                }

                $('form').show();
            }
        })
        $('#formulario_uosp_workshop button').click(send);
    }
    function changeSelect1(){
        $('select[name=workshop2] option').show();

        if($(this).val()){
            $('select[name=workshop2] option[value='+$(this).val()+']').hide();
            $('.workshop2').removeClass('disabled');
        }
        // else $('.workshop2').addClass('disabled');

        $('select[name=workshop2]').selectpicker('refresh');
    }
    function changeSelect2(){
        $('select[name=workshop1] option').show();

        if($(this).val()){
            $('select[name=workshop1] option[value='+$(this).val()+']').hide();
            // $('.workshop2').removeClass('disabled');
        }

        $('select[name=workshop1]').selectpicker('refresh');
    }

    function send(e){
        e.preventDefault();

        var error = false;

        if($('#nome').val() == ''){
            $('#nome').siblings('.error-messages').removeClass('hidden');
            error = true;
        }
        else $('#nome').siblings('.error-messages').addClass('hidden');

        if($('#cognome').val() == ''){
            $('#cognome').siblings('.error-messages').removeClass('hidden');
            error = true;
        }
        else $('#cognome').siblings('.error-messages').addClass('hidden');

        if($('#email').val() == ''){
            $('#email').siblings('.error-messages').removeClass('hidden');
            error = true;
        }
        else $('#email').siblings('.error-messages').addClass('hidden');

        if($('#telefono').val() == ''){
            $('#telefono').siblings('.error-messages').removeClass('hidden');
            error = true;
        }
        else $('#telefono').siblings('.error-messages').addClass('hidden');

        if($('#istituzione').val() == ''){
            $('#istituzione').siblings('.error-messages').removeClass('hidden');
            error = true;
        }
        else $('#istituzione').siblings('.error-messages').addClass('hidden');


        if($('#workshop1').val() == ''){
            $('#workshop1').siblings('.error-messages').removeClass('hidden');
            error = true;
        }
        else $('#workshop1').siblings('.error-messages').addClass('hidden');

        if($('#workshop2').val() == ''){
            $('#workshop2').siblings('.error-messages').removeClass('hidden');
            error = true;
        }
        else $('#workshop2').siblings('.error-messages').addClass('hidden');


        if(!error){
            var data = {
                nome: $('#nome').val(),
                cognome: $('#cognome').val(),
                email: $('#email').val(),
                telefono: $('#telefono').val(),
                istituzione: $('#istituzione').val(),
                workshop1: $('select[name=workshop1] option:selected').text(),
                workshop2: $('select[name=workshop2] option:selected').text(),
                ricevere_atti: $('input[name=ricevere_atti]').is(':checked') ? 1 : 0
            };

            $.post(url+'save.php', data, function (r){
                if(r == 'ok'){
                    $('#formulario_uosp_workshop').remove();
                    $('h1').next().remove();
                    $('.thankyou').removeClass('hidden');
                }
                else $('.form-error').removeClass('hidden');
            });
        }
    }
    init();
}

function initContatoreUOSPWorkshop(){
    var url = '/fileadmin/DECS/DS/UOSP/formulario_workshop/';
    var iscritti_max = 30;
    function init(){
        $.getJSON(url+'iscrizioni.json?_='+Math.round(Math.random()*1000000000), function (data){
            if(data.state == 3){
                $('#contatore_uosp_workshop').prepend('<p>Formulario chiuso, tutti i workshop sono completi.</p>');
            }
            for(i=1;i<=2;i++){
                var html = '<ul>';
                for(x in data[i]){
                    // html += '<li><b>'+x+':</b> '+data[i][x]+'</li>';
                    html += '<li>'+x+': <b>'+data[i][x]+'</b></li>';
                }
                html += '</ul>';
                $('.workshop'+i).html(html);
            }
        });
    }
    init();
}
var captcha_image_audioObj;
function initFormularioUSE(){
    var uploadFile = {};
    var url = '/fileadmin/DFE/DE-USE/formulario/';
    var legge;
    var loading = false;
    function init(){
        $('#legge').change(changeFields);
        $('input[name=misura_richiesta]').click(checkFiere);
        $('#formulario_use input[name=has_iva]').click(checkIVA);
        $('#formulario_use button.send-form').click(send);

        $('input[name=numero_etp_residenti], input[name=numero_etp_non_residenti]').keyup(calcDipendenti)
        $('input[name=totale_investimento], input[name=totale_investimento_ltur], input[name=totale_investimento_lalpr], input[name=totale_investimento_dlc]').blur(formatValue).focus(unformatValue)

        initMultiUpload();

        var h = location.hash.substring(1)
        if(h){
            if($('#legge option[value='+h+']').length){
                $('#legge option[value='+h+']').prop('selected', true).trigger('change')
            }
        }

        $('head').append('<link rel="stylesheet" type="text/css" href="/typo3conf/ext/theme/Resources/Public/css/daterangepicker.css">');
        $.getScript('/typo3conf/ext/theme/Resources/Public/js/moment.js', function (){
            $.getScript('/typo3conf/ext/theme/Resources/Public/js/daterangepicker.js', function (){

                var d = new Date();
                dd = d.getDate() < 10 ? '0'+d.getDate() : d.getDate();
                dm = d.getMonth() + 1 < 10 ? '0'+(d.getMonth() + 1) : d.getMonth() + 1;

                $('#date_fiera').daterangepicker({
                    autoUpdateInput: false,
                    locale: {
                      format: 'DD.MM.YYYY',
                      firstDay: 1,
                      cancelLabel: 'Cancella',
                      applyLabel: 'Applica',
                      customRangeLabel: "Custom",
                      daysOfWeek: ["Do","Lu","Ma","Me","Gi","Ve", "Sa"],
                      monthNames: ["Gennaio","Febbraio","Marzo","Aprile","Maggio","Giugno","Luglio","Agosto","Settembre","Ottobre","Novembre","Dicembre"],
                    },
                    minDate: dd+'/'+dm+'/'+d.getFullYear()
                });

                $('#date_fiera').on('apply.daterangepicker', function(ev, picker) {
                    $(this).val(picker.startDate.format('DD.MM.YYYY') + ' - ' + picker.endDate.format('DD.MM.YYYY'));
                    // $('.myForm').submit();
                });

                $('#date_fiera').on('cancel.daterangepicker', function(ev, picker) {
                    $(this).val('');
                    // $('.myForm').submit();
                });
            });
        });

        $.getScript(url+'securimage/securimage.js', function (){
            captcha_image_audioObj = new SecurimageAudio({ audioElement: 'captcha_image_audio', controlsElement: 'captcha_image_audio_controls' });
        });

        // Data richiesta
        var d = new Date();
        dd = d.getDate() < 10 ? '0'+d.getDate() : d.getDate();
        dm = d.getMonth() + 1 < 10 ? '0'+(d.getMonth() + 1) : d.getMonth() + 1;
        $('#data_richiesta').val(dd+'.'+dm+'.'+d.getFullYear());
    }
    function calcDipendenti(){


        var v1 = $('input[name=numero_etp_residenti]').val().replace(',', '.')
        var v2 = $('input[name=numero_etp_non_residenti]').val().replace(',', '.')

        v1 = parseFloat(v1)
        v2 = parseFloat(v2)

        if(v1 >= 0 && v2 >= 0){
            $('input[name=numero_etp_totale]').val(v1+v2)
        }
    }
    function formatValue(){
        var v = $(this).val()
        var i = false
        var d = false
        var s = false

        if(v.indexOf('.') > -1){
            tmp = v.split('.')
            i = tmp[0]
            d = tmp[1]
            s = '.'
        }
        else if(v.indexOf(',') > -1){
            tmp = v.split(',')
            i = tmp[0]
            d = tmp[1]
            s = ','
        }
        else i = v

        // if(i.length > 3){
        //     var t = i.slice(0, (i.length - 3))
        //     i = t + "'" + i.slice((i.length - 3))
        // }

        if(i.length > 3){
            // console.log()
            var n = []
            for(x=0;x<Math.ceil(i.length / 3);x++){
                start = (i.length-(3*(x+1)))
                if(start < 0) start = 0
                n.push(i.slice(start, (i.length-(3*x))))
            }
            n.reverse()
            i = n.join("'")
        //     var t = i.slice(0, (i.length - 3))
        //     i = t + "'" + i.slice((i.length - 3))
        }

        if(d){
            i += s + d
        }

        $(this).val(i)
    }
    function unformatValue(){
        var v = $(this).val()

        if(v.indexOf("'") > -1){
            v = v.replace(/'/g, '')
            $(this).val(v)
        }
    }
    function send(e){
        e.preventDefault();

        if(!loading){
            loading = true;

            var error = false;

            if(!checkField('#legge')) error = true;
            if(!error){
                if(!checkField('#ragione_sociale')) error = true;
                if(!checkField('#email', 'email')) error = true;
                if(!checkField('#numero_idi')) error = true;

                // Numero IVA
                if(!checkField('input[name=has_iva]', 'radio')) error = true;
                else if($('input[name=has_iva]:checked').val() == 'si'){
                    if(!checkField('#numero_iva', 'iva')) error = true;
                }

                if(!checkField('input[name=dimensione_azienda]', 'radio')) error = true;
                if(!checkField('#comune_sede')) error = true;
                // if($('#comune_sede').val()){
                //     if(!checkField('#comune_esecuzione')) error = true;
                // }
                // else $('#comune_esecuzione').siblings('.error-messages').addClass('hidden')
                if(!checkField('#distretto')) error = true;
                if(!checkField('#progetto')) error = true;
                if(!checkField('#data_richiesta')) error = true;

                if(legge == 'linn'){
                    if(!checkField('#numero_etp_residenti')) error = true;
                    if(!checkField('#numero_etp_non_residenti')) error = true;
                    if(!checkField('#numero_etp_totale')) error = true;
                    if(!checkField('input[name=assoggettazione]', 'radio')) error = true;
                    if(!checkField('input[name=misura_richiesta]', 'radio')) error = true;
                    if(!checkField('#totale_investimento')) error = true;

                    if($('input[name=misura_richiesta]:checked').val() == 'Partecipazione a fiere specialistiche'){
                        if(!checkField('#nazione_fiera')) error = true;
                        if(!checkField('#citta_fiera')) error = true;
                        if(!checkField('#date_fiera')) error = true;
                    }

                    if(!$('#terms:checked').length){
                        error = true;
                        $('#special_linn .error-messages').removeClass('hidden');
                    }
                    else $('#special_linn .error-messages').addClass('hidden');
                }
                else if(legge == 'ltur'){
                    // if(!checkField('#proprietario_fondo')) error = true;
                    // if(!checkField('#numero_mappale')) error = true;

                    if(!checkField('input[name=otr]', 'radio')) error = true;
                    if(!checkField('#totale_investimento_ltur')) error = true;
                    if(!checkField('input[name=misura_richiesta2]', 'radio')) error = true;
                }
                else if(legge == 'lalpr'){
                    if(!checkField('input[name=ers]', 'radio')) error = true;
                    if(!checkField('#totale_investimento_lalpr')) error = true;
                    if(!checkField('input[name=ambito]', 'radio')) error = true;
                }
                else if(legge == 'dlc'){
                    if(!checkField('input[name=ers2]', 'radio')) error = true;
                    if(!checkField('#totale_investimento_dlc')) error = true;
                }

                if(!error){
                    if(!checkCaptchaField()) error = true;
                }

                if(!error){
                    var data = {
                        legge: $('#legge').val(),
                        ragione_sociale: $('#ragione_sociale').val(),
                        email: $('#email').val(),
                        numero_idi: $('#numero_idi').val(),
                        numero_iva: $('#numero_iva').val(),
                        dimensione_azienda: $('input[name=dimensione_azienda]:checked').val(),
                        comune_sede: $('#comune_sede').val(),
                        comune_esecuzione: $('#comune_esecuzione').val(),
                        distretto: $('#distretto').val(),
                        progetto: $('#progetto').val(),
                        data_richiesta: $('#data_richiesta').val()
                    };

                    if(legge == 'linn'){
                        data.numero_etp_residenti = $('#numero_etp_residenti').val();
                        data.numero_etp_non_residenti = $('#numero_etp_non_residenti').val();
                        data.numero_etp_totale = $('#numero_etp_totale').val();
                        data.assoggettazione = $('input[name=assoggettazione]:checked').val();
                        data.misura_richiesta = $('input[name=misura_richiesta]:checked').val();
                        data.totale_investimento = $('#totale_investimento').val();

                        if(data.misura_richiesta == 'Partecipazione a fiere specialistiche'){
                            data.nazione_fiera = $('#nazione_fiera').val();
                            data.citta_fiera = $('#citta_fiera').val();
                            data.date_fiera = $('#date_fiera').val();
                        }
                    }
                    else if(legge == 'ltur'){
                        data.proprietario_fondo = $('#proprietario_fondo').val() == '' ? '-' : $('#proprietario_fondo').val();
                        data.numero_mappale = $('#numero_mappale').val() == '' ? '-' : $('#numero_mappale').val();

                        data.otr = $('input[name=otr]:checked').val();
                        data.totale_investimento = $('#totale_investimento_ltur').val();
                        data.misura_richiesta = $('input[name=misura_richiesta2]:checked').val();
                    }
                    else if(legge == 'lalpr'){
                        data.ers = $('input[name=ers]:checked').val();
                        data.totale_investimento = $('#totale_investimento_lalpr').val();
                        data.ambito = $('input[name=ambito]:checked').val();
                    }
                    else if(legge == 'dlc'){
                        data.ers = $('input[name=ers2]:checked').val();
                        data.totale_investimento = $('#totale_investimento_dlc').val();
                    }

                    data.files = [];
                    $('input[type=file][id]').each(function (){
                        data.files.push($(this).attr('data-file'));
                    });

                    $('button.send-form').html('<i class="fa fa-spinner fa-spin"></i>').addClass('disabled');
                    $.post(url+'save.php', data, function (r){
                        $('form, .intro').remove();
                        $('.success').removeClass('hidden');

                        // $('.success').append('<p><a href="'+url+'files/'+r.split('-')[1]+'.pdf" target="_blank">Scarica PDF</a></p>');
                    }).fail(function (){
                        $('button.send-form').html('Invia').removeClass('disabled');
                    });
                }
                else{
                    $('.error-messages:not(.hidden):first').siblings('input').focus()
                    loading = false;
                }
            }
        }
    }
    function initMultiUpload(){
        var attachments_n = 1;
        var max_weight = 10;
        var used_weight = 0;
        var working = false;
        var uploadButtonContent = '';
        function init(){
            uploadButtonContent = $('#formulario_use .allegati .add').html();

            $('#formulario_use').on('click', '.allegati .add', addAttachemnt);
            $('#formulario_use').on('click', '.allegati .remove', clearAttachemnt);

            $('#formulario_use').on('change', '.inputfile', change);
        }
        function addAttachemnt(e){
            e.preventDefault();

            if(!working){
                $(this).siblings('.allegato.hidden.new').remove();

                if($('#attachments-error').length) $('#attachments-error').remove();

                $(this).prev().before($(this).siblings('.allegato.hidden').clone().addClass('new'));
                $('#formulario_use .allegato.new label').attr('for', 'file'+attachments_n);
                $('#formulario_use .allegato.new input').attr('id', 'file'+attachments_n).attr('name', 'file'+attachments_n);

                $('#formulario_use .allegato.new input:last').trigger('click');

                attachments_n++;
            }
        }
        function clearAttachemnt(e){
            e.preventDefault();

            var id = $(this).parents('.allegato').find('input[type=file]').attr('id');
            uploadFile[id] = false;

            var p = $(this).parents('.allegato');
            used_weight -= parseInt(p.find('input').attr('data-weight'));
            // updateWeights();

            p.find('input[type=file]').val('');
            p.find('input[type=file]').next().children('span').text('Allega un file');
            p.remove();
        }
        function change(event){
            var id = $(this).attr('id');

            tmp = $(this).val().split("\\");
            var v = tmp[tmp.length - 1];

            if(v){
                tmp2 = v.split('.');
                var ext = tmp2[(tmp2.length - 1)];

                if(ext == 'exe' || ext == 'bat' || ext == 'com'){
                    if($('#attachments-error').length) $('#attachments-error').remove();
                    $('.allegato.hidden:not(.new)').after('<div id="attachments-error"><p style="color:#c33;position: relative; top: -10px;">Formato non consentito.</p></div>');

                    $('label[for='+id+'] span').text('Allega un file (10Mb massimo)');
                }
                else{
                    $('label[for='+id+'] span').text(v);

                    if($('#attachments-error').length) $('#attachments-error').remove();


                    uploadFile[id] = event.target.files;

                    upload(id, event.target.files);
                }
            }
        }
        function upload(x, value){
            var data = new FormData();

            // if(value.length > 1){
            //     var upd = {};
            //     n = 1;
            //     console.log(value[0]);
            //     for(y in value){
            //         upd[n] = value[y];
            //         n++;
            //     }
            // }
            // else{
                var upd = {
                    x: value
                };
            // }

            // console.log(upd);
            // console.log(value)
            // console.log(x)

            $('body').append('<div id="sending-form" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; z-index: 10002;"></div>');
            $('#formulario_use .allegati .add').html('<i class="fa fa-spinner fa-spin"></i>');
            working = true;

            for(x in upd){
                if(upd[x]){
                    n = 1;
                    $.each(upd[x], function(key, value){
                        data.append('file'+n, value);
                        n++;
                    });
                }
            }


            $.ajax({
                // url: url+'upload.php?max='+(max_weight - used_weight), // point to server-side PHP script
                url: url+'upload.php', // point to server-side PHP script
                dataType: 'text',  // what to expect back from the PHP script, if anything
                cache: false,
                contentType: false,
                processData: false,
                data: data,
                type: 'post',
                success: function(php_script_response){

                    if(php_script_response == 'filesize'){
                        if($('#attachments-error').length) $('#attachments-error').remove();
                        $('.allegato.hidden:not(.new)').after('<div id="attachments-error"><ul style="color:#c33;position: relative; top: -10px;"><ul>L\'allegato supera il limite consentito di 10MB.</li></ul></div>');
                    }
                    else if(php_script_response == 'error'){
                        if($('#attachments-error').length) $('#attachments-error').remove();
                        $('.allegato.hidden:not(.new)').after('<div id="attachments-error"><ul style="color:#c33;position: relative; top: -10px;"><ul>Errore durante il caricamento degli allegati.</li></ul></div>');
                    }
                    else{
                        if(php_script_response.indexOf(';') > -1){
                            var tmp = php_script_response.split(';');
                        }
                        else var tmp = [php_script_response];
                        // var tmp = php_script_response.split('|');
                        // used_weight += parseInt(tmp[1]);

                        $('.allegato.new.hidden input').attr('data-file', php_script_response);
                        // $('.allegato.new.hidden input').attr('data-weight', tmp[1]);

                        // updateWeights()
                        $('.allegato.new.hidden').removeClass('new hidden');
                    }

                    $('#formulario_use .allegati .add').html(uploadButtonContent);
                    $('#sending-form').remove();
                    // $('.allegati .add').removeClass('disabled');
                    working = false;
                }
            });
        }
        function updateWeights(){
            if(contactData.lang == 'en') $('.allegati h4').html('Attachments '+(used_weight)+' MB(maximum size allowed 10 MB)');
            else $('.allegati h4').html('Allegati '+(used_weight)+' MB(dimensione massima consentita 10 MB)');

            if(used_weight == max_weight) $('.allegati .add').hide();
            else $('.allegati .add').show();
        }
        init();
    }
    function changeFields(){
        legge = $(this).val();

        $('.buttons, .general, .variante').addClass('hidden')
        if(legge){
            $('#variante_'+legge).removeClass('hidden');
            $('.buttons, .general').removeClass('hidden');
            // $('#legge').siblings('.error-messages').addClass('hidden');
            if(legge == 'ltur') $('#special_ltur').removeClass('hidden');
            else $('#special_ltur').addClass('hidden');

            if(legge == 'linn') $('#special_linn').removeClass('hidden');
            else $('#special_linn').addClass('hidden');

            // if(legge == 'dlc')
        }
    }
    function checkFiere(){
        v = $(this).val();
        if(v == 'Partecipazione a fiere specialistiche') $('.fiere').removeClass('hidden');
        else $('.fiere').addClass('hidden');
    }
    function checkIVA(){
        if($(this).attr('id') == 'has_iva1') $('#inserire_iva').removeClass('hidden');
        else $('#inserire_iva').addClass('hidden');
    }
    function checkField(s, type){
        if(typeof type == 'undefined'){
            if($(s).val() == ''){
                $(s).siblings('.error-messages').removeClass('hidden');
                return false;
            }
            else{
                $(s).siblings('.error-messages').addClass('hidden');
                return true;
            }
        }
        else if(type == 'email'){
            if($(s).val() == '' || !checkEmail($(s).val())){
                $(s).siblings('.error-messages').removeClass('hidden');
                return false;
            }
            else{
                $(s).siblings('.error-messages').addClass('hidden');
                return true;
            }
        }
        else if(type == 'radio'){
            if($(s+':checked').length == 0){
                $(s+':first').parent().parent().siblings('.error-messages').removeClass('hidden');
                return false;
            }
            else{
                $(s+':first').parent().parent().siblings('.error-messages').addClass('hidden');
                return true;
            }
        }
        else if(type == 'iva'){
            if($(s).val() == '' || !/^(CHE-[0-9]{3}.[0-9]{3}.[0-9]{3} IVA)$/.test($(s).val())){
                $(s).siblings('.error-messages').removeClass('hidden');
                return false;
            }
            else{
                $(s).siblings('.error-messages').addClass('hidden');
                return true;
            }
        }
    }
    function checkEmail(email) {
        var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(String(email).toLowerCase());
    }
    function checkCaptchaField(){
        var field = $('input[name=captcha]');
        var error = false;

        if(field.val()){
            var r = checkCaptcha(field.val());
            if(r.responseText == 'ok'){
                field.removeClass('error');
                $('.captcha .error-messages').addClass('hidden');
            }
            else{
                field.addClass('error').val('');
                $('.refresh-button').trigger('click');
                $('.captcha .error-messages').removeClass('hidden');
                error = true;
            }
        }
        else{
            field.addClass('error');
            $('.refresh-button').trigger('click');
            $('.captcha .error-messages').removeClass('hidden');
            error = true;
        }

        if(!error) return true;
        return false;
    }
    function checkCaptcha(value){
        var rand = Math.floor((Math.random() * 100000) + 1);
        return $.ajax({
            url: url+'securimage/check.php?r='+rand,
            data: {
                value: value
            },
            async: false,
            method: 'post'
        });
    }
    init();
}

function initFormularioUSEUAC(){
    var uploadFile = {};
    var url = '/fileadmin/DFE/DE-USE/formulario-uac/';
    var legge;
    var loading = false;
    function init(){

        var h = location.hash
        if(h && h != '#'){
            h = h.substring(1)
            if($('#legge option[value='+h+']').length){
                $('#legge option[value='+h+']').prop('selected', true)
                setTimeout(function (){ $('#legge').trigger('change') }, 500)
            }
        }

        $('#legge').change(changeFields);
        $('#formulario_use_uac button.send-form').click(send);
        initMultiUpload1();
        initMultiUpload2();

        $.getScript(url+'securimage/securimage.js', function (){
            captcha_image_audioObj = new SecurimageAudio({ audioElement: 'captcha_image_audio', controlsElement: 'captcha_image_audio_controls' });
        });
    }
    function send(e){
        e.preventDefault();

        if(!loading){
            loading = true;

            var error = false;

            if(!checkField('#legge')) error = true;

            if(!error){
                if($('#legge').val() == 'linn'){
                    if(!checkDossier2()) error = true;
                }
                else{
                    if(!checkDossier()) error = true;
                }

                if(!checkField('#ragione_sociale')) error = true;

                $('#pin').siblings('.error-messages-n').addClass('hidden')
                if(!checkField('#pin')) error = true;
                else{
                    if($('#pin').val() < 1000 || $('#pin').val() > 9999){
                        $('#pin').siblings('.error-messages-n').removeClass('hidden')
                        error = true
                    }
                }

                if(!error){
                    if(!checkCaptchaField()) error = true;
                }

                if(!error){
                    var data = {
                        legge: $('#legge').val(),
                        ragione_sociale: $('#ragione_sociale').val(),
                        pin: $('#pin').val()
                    };

                    if($('#legge').val() == 'linn') data.n_dossier = $('#n_dossier').val()
                    else data.n_dossier = $('#n_dossier1').val()+'.'+$('#n_dossier2').val()+'.'+$('#n_dossier3').val()

                    data.files = [];
                    $('input[type=file][id]').each(function (){
                        data.files.push($(this).attr('data-file'));
                    });

                    $('button.send-form').html('<i class="fa fa-spinner fa-spin"></i>').addClass('disabled');
                    $.post(url+'save.php', data, function (r){
                        $('form, .intro').remove();
                        $('.success').removeClass('hidden');
                    }).fail(function (){
                        $('button.send-form').html('Invia').removeClass('disabled');
                    });
                }
                else{
                    $('.error-messages:not(.hidden):first').siblings('input').focus()
                    loading = false;
                }
            }
        }
    }
    function initMultiUpload1(){
        var attachments_n = 1;
        var max_weight = 10;
        var max_uploads = 2;
        var used_weight = 0;
        var working = false;
        var uploadButtonContent = '';
        function init(){
            uploadButtonContent = $('#formulario_use_uac .allegati1 .add').html();

            $('#formulario_use_uac').on('click', '.allegati1 .add', addAttachemnt);
            $('#formulario_use_uac').on('click', '.allegati1 .remove', clearAttachemnt);

            $('#formulario_use_uac').on('change', '.allegati1 .inputfile', change);
        }
        function addAttachemnt(e){
            e.preventDefault();

            if(!working){
                $(this).siblings('.allegati1 .allegato.hidden.new').remove();

                $('.allegati1 .error-messages, .allegati1 .error-messages-type, .allegati1 .error-messages-size, .allegati1 .error-messages-upload').addClass('hidden')

                $(this).prev().before($(this).siblings('.allegato.hidden').clone().addClass('new'));
                $('#formulario_use_uac .allegati1 .allegato.new label').attr('for', 'file1_'+attachments_n);
                $('#formulario_use_uac .allegati1 .allegato.new input').attr('id', 'file1_'+attachments_n).attr('name', 'file1_'+attachments_n);

                $('#formulario_use_uac .allegati1 .allegato.new input:last').trigger('click');

                // attachments_n++;
            }
        }
        function clearAttachemnt(e){
            e.preventDefault();

            var id = $(this).parents('.allegato').find('input[type=file]').attr('id');
            uploadFile[id] = false;

            var p = $(this).parents('.allegato');
            used_weight -= parseInt(p.find('input').attr('data-weight'));
            // updateWeights();

            p.find('input[type=file]').val('');
            p.find('input[type=file]').next().children('span').text('Allega un file');
            p.remove();

            attachments_n--;
            if(max_uploads >= attachments_n) $('#formulario_use_uac .allegati1 .add').removeClass('hidden');

            if($('.allegati1 .allegato:not(.hidden)').length == 0) $('.allegati1 .add').css('margin-top', '0')
        }
        function change(event){
            var id = $(this).attr('id');

            tmp = $(this).val().split("\\");
            var v = tmp[tmp.length - 1];

            if(v){
                tmp2 = v.split('.');
                var ext = tmp2[(tmp2.length - 1)];

                $('.allegati1 .error-messages, .allegati1 .error-messages-type, .allegati1 .error-messages-size, .allegati1 .error-messages-upload').addClass('hidden')

                if(ext.toLowerCase() != 'xls' && ext.toLowerCase() != 'xlsx'){
                    $('.allegati1 .error-messages-type').removeClass('hidden')
                    // $('label[for='+id+'] span').text('Allega un file (10Mb massimo)');
                    // attachments_n--;
                }
                else{
                    $('label[for='+id+'] span').text(v);

                    uploadFile[id] = event.target.files;

                    upload(id, event.target.files);
                    // attachments_n++;
                }
            }
            // else attachments_n--
        }
        function upload(x, value){
            var data = new FormData();

            // if(value.length > 1){
            //     var upd = {};
            //     n = 1;
            //     console.log(value[0]);
            //     for(y in value){
            //         upd[n] = value[y];
            //         n++;
            //     }
            // }
            // else{
                var upd = {
                    x: value
                };
            // }

            // console.log(upd);
            // console.log(value)
            // console.log(x)

            // $('body').append('<div id="sending-form" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; z-index: 10002;"></div>');
            // $('#formulario_use_uac .allegati2 .add').html('<i class="fa fa-spinner fa-spin"></i>');
            working = true;

            for(x in upd){
                if(upd[x]){
                    n = 1;
                    $.each(upd[x], function(key, value){
                        data.append('file'+n, value);
                        n++;
                    });
                }
            }


            $.ajax({
                // url: url+'upload.php?max='+(max_weight - used_weight), // point to server-side PHP script
                url: url+'upload.php', // point to server-side PHP script
                dataType: 'text',  // what to expect back from the PHP script, if anything
                cache: false,
                contentType: false,
                processData: false,
                data: data,
                type: 'post',
                success: function(php_script_response){

                    $('.allegati1 .error-messages, .allegati1 .error-messages-type, .allegati1 .error-messages-size, .allegati1 .error-messages-upload').addClass('hidden')

                    if(php_script_response == 'filesize'){
                        $('.allegati1 .error-messages-size').removeClass('hidden')
                    }
                    else if(php_script_response == 'error'){
                        $('.allegati1 .error-messages-upload').removeClass('hidden')
                    }
                    else{
                        if(php_script_response.indexOf(';') > -1){
                            var tmp = php_script_response.split(';');
                        }
                        else var tmp = [php_script_response];
                        // var tmp = php_script_response.split('|');
                        // used_weight += parseInt(tmp[1]);

                        $('.allegati1 .allegato.new.hidden input').attr('data-file', php_script_response);
                        // $('.allegato.new.hidden input').attr('data-weight', tmp[1]);

                        // updateWeights()
                        $('.allegati1 .allegato.new.hidden').removeClass('new hidden');

                        attachments_n++;
                    }

                    $('#formulario_use_uac .allegati1 .add').html(uploadButtonContent);
                    if(attachments_n > max_uploads) $('#formulario_use_uac .allegati1 .add').addClass('hidden');
                    // $('#sending-form').remove();
                    // $('.allegati2 .add').removeClass('disabled');
                    working = false;

                    if($('.allegati1 .allegato:not(.hidden)').length) $('.allegati1 .add').css('margin-top', '20px')
                }
            });
        }
        function updateWeights(){
            if(contactData.lang == 'en') $('.allegati1 h4').html('Attachments '+(used_weight)+' MB(maximum size allowed 10 MB)');
            else $('.allegati1 h4').html('Allegati '+(used_weight)+' MB(dimensione massima consentita 10 MB)');

            if(used_weight == max_weight) $('.allegati1 .add').hide();
            else $('.allegati1 .add').show();
        }
        init();
    }
    function initMultiUpload2(){
        var attachments_n = 1;
        var max_weight = 10;
        var max_uploads = 2;
        var used_weight = 0;
        var working = false;
        var uploadButtonContent = '';
        function init(){
            uploadButtonContent = $('#formulario_use_uac .allegati2 .add').html();

            $('#formulario_use_uac').on('click', '.allegati2 .add', addAttachemnt);
            $('#formulario_use_uac').on('click', '.allegati2 .remove', clearAttachemnt);

            $('#formulario_use_uac').on('change', '.allegati2 .inputfile', change);
        }
        function addAttachemnt(e){
            e.preventDefault();

            if(!working){
                $(this).siblings('.allegati2 .allegato.hidden.new').remove();

                $('.allegati2 .error-messages, .allegati2 .error-messages-type, .allegati2 .error-messages-size, .allegati2 .error-messages-upload').addClass('hidden')

                $(this).prev().before($(this).siblings('.allegato.hidden').clone().addClass('new'));
                $('#formulario_use_uac .allegati2 .allegato.new label').attr('for', 'file2_'+attachments_n);
                $('#formulario_use_uac .allegati2 .allegato.new input').attr('id', 'file2_'+attachments_n).attr('name', 'file2_'+attachments_n);

                $('#formulario_use_uac .allegati2 .allegato.new input:last').trigger('click');

                // attachments_n++;
            }
        }
        function clearAttachemnt(e){
            e.preventDefault();

            var id = $(this).parents('.allegato').find('input[type=file]').attr('id');
            uploadFile[id] = false;

            var p = $(this).parents('.allegato');
            used_weight -= parseInt(p.find('input').attr('data-weight'));
            // updateWeights();

            p.find('input[type=file]').val('');
            p.find('input[type=file]').next().children('span').text('Allega un file');
            p.remove();

            attachments_n--;
            if(max_uploads >= attachments_n) $('#formulario_use_uac .allegati2 .add').removeClass('hidden');

            if($('.allegati2 .allegato:not(.hidden)').length == 0) $('.allegati2 .add').css('margin-top', '0')
        }
        function change(event){
            var id = $(this).attr('id');

            tmp = $(this).val().split("\\");
            var v = tmp[tmp.length - 1];

            if(v){
                tmp2 = v.split('.');
                var ext = tmp2[(tmp2.length - 1)];

                $('.allegati2 .error-messages, .allegati2 .error-messages-type, .allegati2 .error-messages-size, .allegati2 .error-messages-upload').addClass('hidden')

                if(ext.toLowerCase() != 'pdf'){
                    $('.allegati2 .error-messages-type').removeClass('hidden')
                    // attachments_n--;
                    // $('label[for='+id+'] span').text('Allega un file (10Mb massimo)');
                }
                else{
                    $('label[for='+id+'] span').text(v);

                    uploadFile[id] = event.target.files;

                    upload(id, event.target.files);
                }
            }
        }
        function upload(x, value){
            var data = new FormData();

            // if(value.length > 1){
            //     var upd = {};
            //     n = 1;
            //     console.log(value[0]);
            //     for(y in value){
            //         upd[n] = value[y];
            //         n++;
            //     }
            // }
            // else{
                var upd = {
                    x: value
                };
            // }

            // console.log(upd);
            // console.log(value)
            // console.log(x)

            // $('body').append('<div id="sending-form" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; z-index: 10002;"></div>');
            // $('#formulario_use_uac .allegati2 .add').html('<i class="fa fa-spinner fa-spin"></i>');
            working = true;

            for(x in upd){
                if(upd[x]){
                    n = 1;
                    $.each(upd[x], function(key, value){
                        data.append('file'+n, value);
                        n++;
                    });
                }
            }


            $.ajax({
                // url: url+'upload.php?max='+(max_weight - used_weight), // point to server-side PHP script
                url: url+'upload.php', // point to server-side PHP script
                dataType: 'text',  // what to expect back from the PHP script, if anything
                cache: false,
                contentType: false,
                processData: false,
                data: data,
                type: 'post',
                success: function(php_script_response){

                    $('.allegati2 .error-messages, .allegati2 .error-messages-type, .allegati2 .error-messages-size, .allegati2 .error-messages-upload').addClass('hidden')

                    if(php_script_response == 'filesize'){

                        $('.allegati2 .error-messages-size').removeClass('hidden')
                    }
                    else if(php_script_response == 'error'){
                        $('.allegati2 .error-messages-upload').removeClass('hidden')
                    }
                    else{
                        if(php_script_response.indexOf(';') > -1){
                            var tmp = php_script_response.split(';');
                        }
                        else var tmp = [php_script_response];
                        // var tmp = php_script_response.split('|');
                        // used_weight += parseInt(tmp[1]);

                        $('.allegati2 .allegato.new.hidden input').attr('data-file', php_script_response);
                        // $('.allegato.new.hidden input').attr('data-weight', tmp[1]);

                        // updateWeights()
                        $('.allegati2 .allegato.new.hidden').removeClass('new hidden');

                        attachments_n++;
                    }

                    $('#formulario_use_uac .allegati2 .add').html(uploadButtonContent);
                    if(attachments_n > max_uploads) $('#formulario_use_uac .allegati2 .add').addClass('hidden');

                    if($('.allegati2 .allegato:not(.hidden)').length) $('.allegati2 .add').css('margin-top', '20px')

                    // $('#sending-form').remove();
                    // $('.allegati2 .add').removeClass('disabled');
                    working = false;
                }
            });
        }
        function updateWeights(){
            if(contactData.lang == 'en') $('.allegati2 h4').html('Attachments '+(used_weight)+' MB(maximum size allowed 10 MB)');
            else $('.allegati2 h4').html('Allegati '+(used_weight)+' MB(dimensione massima consentita 10 MB)');

            if(used_weight == max_weight) $('.allegati2 .add').hide();
            else $('.allegati2 .add').show();
        }
        init();
    }
    function changeFields(){
        legge = $(this).val();

        if(legge) $('.fields').removeClass('hidden')
        else $('.fields').addClass('hidden')

        $('#n_dossier1').val('')

        // if(legge == 'linn') $('#n_dossier1').attr('maxlength', 1)
        // else $('#n_dossier1').attr('maxlength', 2)

        if(legge == 'linn'){
            $('.n_dossier1').removeClass('hidden')
            $('.n_dossier2').addClass('hidden')
        }
        else{
            $('.n_dossier2').removeClass('hidden')
            $('.n_dossier1').addClass('hidden')
        }
    }
    function checkDossier(){
        var error = false;
        var dossier = [
            $('#n_dossier1').val(),
            $('#n_dossier2').val(),
            $('#n_dossier3').val()
        ]
        var error_message = $('#n_dossier1').siblings('.error-messages');

        if(dossier[0] == "" || dossier[1] == "" || dossier[2] == ""){
            error = true;
            error_message.text('Compila i campi')
        }
        else{
            if(legge == 'ltur'){
                if(!/T[0-9]/.test(dossier[0])) error = true
            }
            else if(legge == 'linn'){
                if(dossier[0] != 'F' && dossier[0] != 'i') error = true
            }
            else if(legge == 'lalpr'){
                if(dossier[0] != 'PR') error = true
            }

            if(!/[0-9]{2}/.test(dossier[1]) || !/[0-9]{3}/.test(dossier[2])) error = true

            error_message.text('Compila correttamente i campi')
        }

        if(error){
            error_message.removeClass('hidden')
            return false;
        }
        else{
            error_message.addClass('hidden')
            return true
        }
    }
    function checkDossier2(){
        var error = false;
        var dossier = $('#n_dossier').val()
        var error_message = $('#n_dossier').siblings('.error-messages');

        if(dossier == ""){
            error = true;
            error_message.text('Compila il campo')
        }
        else{
            if(dossier.indexOf('.') == -1) error = true
            else{
                tmp = dossier.split('.')
                if(tmp.length == 3 || tmp.length == 4){
                    if(tmp[0] != 'F' && dossier[0] != 'i') error = true
                    else if(!/^[0-9]{2}$/.test(tmp[1]) || !/^[0-9]{3}$/.test(tmp[2])) error = true

                    if(tmp.length == 4){
                        if(!/^[a-zA-Z]{3}$/.test(tmp[3])) error = true
                    }
                }
                else error = true
            }
            error_message.text('Compila correttamente i campi')
        }

        if(error){
            error_message.removeClass('hidden')
            return false;
        }
        else{
            error_message.addClass('hidden')
            return true
        }
    }
    function checkField(s, type){
        if(typeof type == 'undefined'){
            if($(s).val() == ''){
                $(s).siblings('.error-messages').removeClass('hidden');
                return false;
            }
            else{
                $(s).siblings('.error-messages').addClass('hidden');
                return true;
            }
        }
        else if(type == 'radio'){
            if($(s+':checked').length == 0){
                $(s+':first').parent().parent().siblings('.error-messages').removeClass('hidden');
                return false;
            }
            else{
                $(s+':first').parent().parent().siblings('.error-messages').addClass('hidden');
                return true;
            }
        }
    }
    function checkCaptchaField(){
        var field = $('input[name=captcha]');
        var error = false;

        if(field.val()){
            var r = checkCaptcha(field.val());
            if(r.responseText == 'ok'){
                field.removeClass('error');
                $('.captcha .error-messages').addClass('hidden');
            }
            else{
                field.addClass('error').val('');
                $('.refresh-button').trigger('click');
                $('.captcha .error-messages').removeClass('hidden');
                error = true;
            }
        }
        else{
            field.addClass('error');
            $('.refresh-button').trigger('click');
            $('.captcha .error-messages').removeClass('hidden');
            error = true;
        }

        if(!error) return true;
        return false;
    }
    function checkCaptcha(value){
        var rand = Math.floor((Math.random() * 100000) + 1);
        return $.ajax({
            url: url+'securimage/check.php?r='+rand,
            data: {
                value: value
            },
            async: false,
            method: 'post'
        });
    }
    init();
}
var captcha_image_audioObj;
function initFormularioUSE2(){
    var uploadFile = {};
    var url = '/fileadmin/DFE/DE-USE/formulario2/';
    var legge;
    var loading = false;
    function init(){
        // $('#legge').change(changeFields);
        // $('input[name=misura_richiesta]').click(checkFiere);
        // $('#formulario_use2 input[name=has_iva]').click(checkIVA);
        $('#formulario_use2 button.send-form').click(send);
        initMultiUpload();

        // $('head').append('<link rel="stylesheet" type="text/css" href="/typo3conf/ext/theme/Resources/Public/css/daterangepicker.css">');
        // $.getScript('/typo3conf/ext/theme/Resources/Public/js/moment.js', function (){
        //     $.getScript('/typo3conf/ext/theme/Resources/Public/js/daterangepicker.js', function (){

        //         var d = new Date();
        //         dd = d.getDate() < 10 ? '0'+d.getDate() : d.getDate();
        //         dm = d.getMonth() + 1 < 10 ? '0'+(d.getMonth() + 1) : d.getMonth() + 1;

        //         $('#date_fiera').daterangepicker({
        //             autoUpdateInput: false,
        //             locale: {
        //               format: 'DD.MM.YYYY',
        //               firstDay: 1,
        //               cancelLabel: 'Cancella',
        //               applyLabel: 'Applica',
        //               customRangeLabel: "Custom",
        //               daysOfWeek: ["Do","Lu","Ma","Me","Gi","Ve", "Sa"],
        //               monthNames: ["Gennaio","Febbraio","Marzo","Aprile","Maggio","Giugno","Luglio","Agosto","Settembre","Ottobre","Novembre","Dicembre"],
        //             },
        //             minDate: dd+'/'+dm+'/'+d.getFullYear()
        //         });

        //         $('#date_fiera').on('apply.daterangepicker', function(ev, picker) {
        //             $(this).val(picker.startDate.format('DD.MM.YYYY') + ' - ' + picker.endDate.format('DD.MM.YYYY'));
        //             // $('.myForm').submit();
        //         });

        //         $('#date_fiera').on('cancel.daterangepicker', function(ev, picker) {
        //             $(this).val('');
        //             // $('.myForm').submit();
        //         });
        //     });
        // });

        $.getScript(url+'securimage/securimage.js', function (){
            captcha_image_audioObj = new SecurimageAudio({ audioElement: 'captcha_image_audio', controlsElement: 'captcha_image_audio_controls' });
        });

        // // Data richiesta
        // var d = new Date();
        // dd = d.getDate() < 10 ? '0'+d.getDate() : d.getDate();
        // dm = d.getMonth() + 1 < 10 ? '0'+(d.getMonth() + 1) : d.getMonth() + 1;
        // $('#data_richiesta').val(dd+'.'+dm+'.'+d.getFullYear());
    }
    function send(e){
        e.preventDefault();

        if(!loading){
            loading = true;

            var error = false;

            if(!checkField('#legge')) error = true;
            if(!error){
                if(!checkField('#n_incarto')) error = true;
                if(!checkField('#ragione_sociale')) error = true;
                if(!checkField('#nome_progetto')) error = true;

                $('#pin').siblings('.error-messages-n').addClass('hidden')
                if(!checkField('#pin')) error = true;
                else{
                    if($('#pin').val() < 1000 || $('#pin').val() > 9999){
                        $('#pin').siblings('.error-messages-n').removeClass('hidden')
                        error = true
                    }
                }


                if(!error){
                    if(!checkCaptchaField()) error = true;
                }

                if(!error){
                    var data = new FormData();

                    data.append('n_incarto', $('#n_incarto').val());
                    data.append('ragione_sociale', $('#ragione_sociale').val());
                    data.append('nome_progetto', $('#nome_progetto').val());
                    data.append('pin', $('#pin').val());

                    for(x in uploadFile){
                        data.append(x, document.getElementById(x).files[0]);
                    }

                    $('button.send-form').html('<i class="fa fa-spinner fa-spin"></i>').addClass('disabled');
                    $.ajax({
                        url: url+'save.php', // point to server-side PHP script
                        dataType: 'text',  // what to expect back from the PHP script, if anything
                        cache: false,
                        contentType: false,
                        processData: false,
                        data: data,
                        type: 'post',
                        success: function(php_script_response){
                            if(php_script_response.split('-')[0] == 'ok'){
                                $('form, .intro p').remove();
                                $('.success').removeClass('hidden');
                            }
                            else{
                                $('button.send-form').html('Invia').removeClass('disabled');
                                loading = false;
                            }
                        }
                    });
                }
                else{
                    $('.error-messages:not(.hidden):first').siblings('input').focus()
                    loading = false;
                }
            }
        }
    }
    // function initMultiUpload(){
    //     var attachments_n = 1;
    //     var max_weight = 10;
    //     var used_weight = 0;
    //     var working = false;
    //     var uploadButtonContent = '';
    //     function init(){
    //         uploadButtonContent = $('#formulario_use2 .allegati .add').html();

    //         $('#formulario_use2').on('click', '.allegati .add', addAttachemnt);
    //         $('#formulario_use2').on('click', '.allegati .remove', clearAttachemnt);

    //         $('#formulario_use2').on('change', '.inputfile', change);
    //     }
    //     function addAttachemnt(e){
    //         e.preventDefault();

    //         if(!working){
    //             $(this).siblings('.allegato.hidden.new').remove();

    //             if($('#attachments-error').length) $('#attachments-error').remove();

    //             $(this).prev().before($(this).siblings('.allegato.hidden').clone().addClass('new'));
    //             $('#formulario_use2 .allegato.new label').attr('for', 'file'+attachments_n);
    //             $('#formulario_use2 .allegato.new input').attr('id', 'file'+attachments_n).attr('name', 'file'+attachments_n);

    //             $('#formulario_use2 .allegato.new input:last').trigger('click');

    //             attachments_n++;
    //         }
    //     }
    //     function clearAttachemnt(e){
    //         e.preventDefault();

    //         var id = $(this).parents('.allegato').find('input[type=file]').attr('id');
    //         uploadFile[id] = false;

    //         var p = $(this).parents('.allegato');
    //         used_weight -= parseInt(p.find('input').attr('data-weight'));
    //         // updateWeights();

    //         p.find('input[type=file]').val('');
    //         p.find('input[type=file]').next().children('span').text('Allega un file');
    //         p.remove();
    //     }
    //     function change(event){
    //         var id = $(this).attr('id');

    //         tmp = $(this).val().split("\\");
    //         var v = tmp[tmp.length - 1];

    //         if(v){
    //             tmp2 = v.split('.');
    //             var ext = tmp2[(tmp2.length - 1)];

    //             if(ext == 'exe' || ext == 'bat' || ext == 'com'){
    //                 if($('#attachments-error').length) $('#attachments-error').remove();
    //                 $('.allegato.hidden:not(.new)').after('<div id="attachments-error"><p style="color:#c33;position: relative; top: -10px;">Formato non consentito.</p></div>');

    //                 $('label[for='+id+'] span').text('Allega un file (10Mb massimo)');
    //             }
    //             else{
    //                 $('label[for='+id+'] span').text(v);

    //                 if($('#attachments-error').length) $('#attachments-error').remove();


    //                 uploadFile[id] = event.target.files;

    //                 // upload(id, event.target.files);
    //             }
    //         }
    //     }
    //     function upload(x, value){
    //         var data = new FormData();

    //         // if(value.length > 1){
    //         //     var upd = {};
    //         //     n = 1;
    //         //     console.log(value[0]);
    //         //     for(y in value){
    //         //         upd[n] = value[y];
    //         //         n++;
    //         //     }
    //         // }
    //         // else{
    //             var upd = {
    //                 x: value
    //             };
    //         // }

    //         // console.log(upd);
    //         // console.log(value)
    //         // console.log(x)

    //         $('body').append('<div id="sending-form" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; z-index: 10002;"></div>');
    //         $('#formulario_use2 .allegati .add').html('<i class="fa fa-spinner fa-spin"></i>');
    //         working = true;

    //         for(x in upd){
    //             if(upd[x]){
    //                 n = 1;
    //                 $.each(upd[x], function(key, value){
    //                     data.append('file'+n, value);
    //                     n++;
    //                 });
    //             }
    //         }


    //         $.ajax({
    //             // url: url+'upload.php?max='+(max_weight - used_weight), // point to server-side PHP script
    //             url: url+'upload.php', // point to server-side PHP script
    //             dataType: 'text',  // what to expect back from the PHP script, if anything
    //             cache: false,
    //             contentType: false,
    //             processData: false,
    //             data: data,
    //             type: 'post',
    //             success: function(php_script_response){

    //                 if(php_script_response == 'filesize'){
    //                     if($('#attachments-error').length) $('#attachments-error').remove();
    //                     $('.allegato.hidden:not(.new)').after('<div id="attachments-error"><ul style="color:#c33;position: relative; top: -10px;"><ul>L\'allegato supera il limite consentito di 10MB.</li></ul></div>');
    //                 }
    //                 else if(php_script_response == 'error'){
    //                     if($('#attachments-error').length) $('#attachments-error').remove();
    //                     $('.allegato.hidden:not(.new)').after('<div id="attachments-error"><ul style="color:#c33;position: relative; top: -10px;"><ul>Errore durante il caricamento degli allegati.</li></ul></div>');
    //                 }
    //                 else{
    //                     if(php_script_response.indexOf(';') > -1){
    //                         var tmp = php_script_response.split(';');
    //                     }
    //                     else var tmp = [php_script_response];
    //                     // var tmp = php_script_response.split('|');
    //                     // used_weight += parseInt(tmp[1]);

    //                     $('.allegato.new.hidden input').attr('data-file', php_script_response);
    //                     // $('.allegato.new.hidden input').attr('data-weight', tmp[1]);

    //                     // updateWeights()
    //                     $('.allegato.new.hidden').removeClass('new hidden');
    //                 }

    //                 $('#formulario_use2 .allegati .add').html(uploadButtonContent);
    //                 $('#sending-form').remove();
    //                 // $('.allegati .add').removeClass('disabled');
    //                 working = false;
    //             }
    //         });
    //     }
    //     function updateWeights(){
    //         if(contactData.lang == 'en') $('.allegati h4').html('Attachments '+(used_weight)+' MB(maximum size allowed 10 MB)');
    //         else $('.allegati h4').html('Allegati '+(used_weight)+' MB(dimensione massima consentita 10 MB)');

    //         if(used_weight == max_weight) $('.allegati .add').hide();
    //         else $('.allegati .add').show();
    //     }
    //     init();
    // }
    function initMultiUpload(){
        var attachments_n = 1;
        var max_uploads = 5;
        var max_weight = 10;
        var working = false;
        var uploadButtonContent = '';
        function init(){
            uploadButtonContent = $('#formulario_use2 .allegati .add').html();

            $('#formulario_use2').on('click', '.allegati .add', addAttachemnt);
            $('#formulario_use2').on('click', '.allegati .remove', clearAttachemnt);

            $('#formulario_use2').on('change', '.allegati .inputfile', change);
        }
        function addAttachemnt(e){
            e.preventDefault();

            if(!working){
                $(this).siblings('.allegato.hidden.new').remove();

                if($('#attachments-error').length) $('#attachments-error').remove();

                $(this).prev().before($(this).siblings('.allegato.hidden').clone().addClass('new'));
                $('#formulario_use2 .allegati .allegato.new label').attr('for', 'file'+attachments_n);
                $('#formulario_use2 .allegati .allegato.new input').attr('id', 'file'+attachments_n).attr('name', 'file'+attachments_n);

                $('#formulario_use2 .allegati .allegato.new input:last').trigger('click');
            }
        }
        function clearAttachemnt(e){
            e.preventDefault();

            var id = $(this).parents('.allegato').find('input[type=file]').attr('id');
            uploadFile[id] = false;

            var p = $(this).parents('.allegato');

            p.find('input[type=file]').val('');
            p.find('input[type=file]').next().children('span').text('Allega un file');
            p.remove();

            attachments_n--;

            $('#formulario_use2 .allegati .add').removeClass('hidden');
        }
        function change(event){
            var id = $(this).attr('id');

            tmp = $(this).val().split("\\");
            var v = tmp[tmp.length - 1];

            if(v){
                tmp2 = v.split('.');
                var ext = tmp2[(tmp2.length - 1)];


                $('.allegati .error-messages, .allegati .error-messages-type, .allegati .error-messages-size').addClass('hidden');

                if(ext.toLowerCase() != 'pdf'){
                    // Type error
                    $('.allegati .error-messages-type').removeClass('hidden');
                    $('.allegati .allegato.new.hidden .remove').trigger('click');
                }
                else{
                    if(Math.round(event.target.files[0].size / 1048576) > max_weight){
                        // Size error
                        $('.allegati .error-messages-size').removeClass('hidden');
                        $('.allegati .allegato.new.hidden .remove').trigger('click');
                    }
                    else{
                        $('label[for='+id+'] span').text(v);

                        if($('#attachments-error').length) $('#attachments-error').remove();

                        uploadFile[id] = event.target.files;

                        $('.allegati .allegato.new.hidden').removeClass('new hidden');
                        $('#formulario_use2 .allegati .add').html(uploadButtonContent);


                        attachments_n++;
                        if(max_uploads < attachments_n) $('#formulario_use2 .allegati .add').addClass('hidden');
                    }
                }
            }
        }
        init();
    }
    function changeFields(){
        legge = $(this).val();

        $('.buttons, .general, .variante').addClass('hidden')
        if(legge){
            $('#variante_'+legge).removeClass('hidden');
            $('.buttons, .general').removeClass('hidden');
            // $('#legge').siblings('.error-messages').addClass('hidden');
            if(legge == 'ltur') $('#special_ltur').removeClass('hidden');
            else $('#special_ltur').addClass('hidden');

            if(legge == 'linn') $('#special_linn').removeClass('hidden');
            else $('#special_linn').addClass('hidden');

            // if(legge == 'dlc')
        }
    }
    function checkFiere(){
        v = $(this).val();
        if(v == 'Partecipazione a fiere specialistiche') $('.fiere').removeClass('hidden');
        else $('.fiere').addClass('hidden');
    }
    function checkIVA(){
        if($(this).attr('id') == 'has_iva1') $('#inserire_iva').removeClass('hidden');
        else $('#inserire_iva').addClass('hidden');
    }
    function checkField(s, type){
        if(typeof type == 'undefined'){
            if($(s).val() == ''){
                $(s).siblings('.error-messages').removeClass('hidden');
                return false;
            }
            else{
                $(s).siblings('.error-messages').addClass('hidden');
                return true;
            }
        }
        else if(type == 'radio'){
            if($(s+':checked').length == 0){
                $(s+':first').parent().parent().siblings('.error-messages').removeClass('hidden');
                return false;
            }
            else{
                $(s+':first').parent().parent().siblings('.error-messages').addClass('hidden');
                return true;
            }
        }
    }
    function checkCaptchaField(){
        var field = $('input[name=captcha]');
        var error = false;

        if(field.val()){
            var r = checkCaptcha(field.val());
            if(r.responseText == 'ok'){
                field.removeClass('error');
                $('.captcha .error-messages').addClass('hidden');
            }
            else{
                field.addClass('error').val('');
                $('.refresh-button').trigger('click');
                $('.captcha .error-messages').removeClass('hidden');
                error = true;
            }
        }
        else{
            field.addClass('error');
            $('.refresh-button').trigger('click');
            $('.captcha .error-messages').removeClass('hidden');
            error = true;
        }

        if(!error) return true;
        return false;
    }
    function checkCaptcha(value){
        var rand = Math.floor((Math.random() * 100000) + 1);
        return $.ajax({
            url: url+'securimage/check.php?r='+rand,
            data: {
                value: value
            },
            async: false,
            method: 'post'
        });
    }
    init();
}
function initFrancoInTasca(){

	$("a.suggerimento").click(function() {
	         val=$(this).attr('data-termine');
	         $("#q").val(val);
	         $('#ricerca').submit();
	     });
	
	initAutocompleteFIT();

    function initAutocompleteFIT(){
        function init(){
            $('head').append('<link rel="stylesheet" type="text/css" href="https://www4.ti.ch/typo3conf/ext/theme/Resources/Public/css/jquery-ui.css">');

            if(typeof $.ui === "undefined")
                $.getScript('https://www4.ti.ch/typo3conf/ext/theme/Resources/Public/js/jquery-ui.js', suggest);
            else
                suggest();

        }
        function suggest() {
            $("#q").autocomplete({
                source : function(request, response) {
                    $.ajax({
                        url: "https://ricerca.ti.ch/suggest?client=francointasca&site=francointasca&max=5&format=rich",
                        dataType: "jsonp",
                        data : {
                            q : request.term
                        },
                        success : function(data) {
                            response( $.map( data.results, function( item ) {
                                return {
                                    label: item.name,
                                    value: item.name
                                }
                            }));
                        }
                    });
                },
            });
        }
        init();
    }
}	
/* GC */
function initGC() {

    var isOut = true;
    var overs = {};
    var url = 'https://www4.ti.ch/poteri/gc/parlamento/composizione-del-parlamento/composizione-nelle-ultime-legislature/dettaglio-deputati/?user_gcparlamento_pi3[canID]=';

    function mouseover() {

        var n = parseInt($(this).attr('id').substring(1));

        overs[n] = true;

        if ($('.deputato.d' + n + ' img[data-src]').length) {
            $('.deputato.d' + n + ' img').attr('src', $('.deputato.d' + n + ' img').attr('data-src'));
        }

        setTimeout(function () {
            if (overs[n]) {
                $('.deputato').removeClass('shown');
                $('.deputato.d' + n).addClass('shown');
            }
        }, 500);
    }
    function mouseout() {
        var n = parseInt($(this).attr('id').substring(1));

        setTimeout(function () {
            if (!overs[n]) {
                $('.deputato.d' + n).removeClass('shown');
            }
        }, 1000);

        overs[n] = false;
    }
    function click() {
        var n = parseInt($(this).attr('id').substring(1));
        if (!isNaN($('.deputato.d' + n).attr('data-id')))
            location.href = url + $('.deputato.d' + n).attr('data-id');
    }

    d3.select('svg').selectAll('circle, path, ellipse').on('mouseover', mouseover);
    d3.select('svg').selectAll('circle, path, ellipse').on('mouseout', mouseout);
    d3.select('svg').selectAll('circle, path, ellipse').on('click', click);
}
function initGCHome(){
    var colors = {
        'lega': '#387a45',
        'ps': '#c63834',
        'plr': '#005bac',
        'verdi': '#72a651',
        'ppd': '#cf5a38',
        'mps-pop': '#dec24c',
        'mc': '#a78842',
        'udc': '#712b5a',
        'piu-donne': '#c56e79'
    };
    var url = 'https://www4.ti.ch/poteri/gc/parlamento/composizione-del-parlamento/composizione-nelle-ultime-legislature/dettaglio-deputati/?user_gcparlamento_pi3[canID]=';
    var isOut = true;
    var overs = {};
    var searching = false;
    function init(){
        initMap();

        $('.partiti input').click(filterMap);

        d3.select('svg').selectAll('circle, path, ellipse').on('click', click);
        d3.select('svg').selectAll('circle, path, ellipse').on('mouseover', mouseover);
        d3.select('svg').selectAll('circle, path, ellipse').on('mouseout', mouseout);

        $.ui.autocomplete.filter = function (array, term) {
            // var matcher = new RegExp("^" + $.ui.autocomplete.escapeRegex(term), "i");
            var matcher = new RegExp("(?:^| )"+$.ui.autocomplete.escapeRegex(term), "gi");


            return $.grep(array, function (value) {
                return matcher.test(value);
                // return matcher.test(value.label || value.value || value);
            });
        };

        $('.ricerca input[type=text]').autocomplete({
            source: deputati,
            select: searchDeputato,
            position: { my: "left bottom", at: "left top", collision: "flip" }
            // change: searchDeputato
        }).keydown(function (e){
            if((e.keyCode >= 37 && e.keyCode <= 40) || e.keyCode == 27){
                var v = $(this).val();
                $('svg circle, svg path, svg ellipse').css('opacity', 1);
                $('.deputato.shown').removeClass('shown');
                if(v != ''){
                    var o = $('.deputato[data-name="'+v.toLowerCase()+'"]');
                    if(o.length){
                        var posto = o.attr('data-posto');
                        if(posto){
                            $('svg circle[id!='+posto+'], svg path[id!='+posto+'], svg ellipse[id!='+posto+']').css('opacity', 0.3);

                            if ($('.deputato[data-posto=' + posto + '] img[data-src]').length) {
                                $('.deputato[data-posto=' + posto + '] img').attr('src', $('.deputato[data-posto=' + posto + '] img').attr('data-src'));
                            }
                            $('.deputato.shown').removeClass('shown');
                            $('.deputato[data-posto=' + posto + ']').addClass('shown');
                        }
                    }
                }
            }
        }).focus(function (){
            $('.user-gcdeputazione-pi1 input[type=checkbox]').prop('disabled', true);
            searching = true;
        }).blur(function (){
            if($(this).val() == ''){


                $('.user-gcdeputazione-pi1 input[type=checkbox]').prop('disabled', false);
                if($('.user-gcdeputazione-pi1 input[type=checkbox]:checked').length){
                    $('svg circle, svg path, svg ellipse').css('opacity', 0.3);

                    $('.partiti input:checked').each(function (){
                        $('svg .'+$(this).val()).css('opacity', 1)
                    });
                }
                else{
                    $('svg circle, svg path, svg ellipse').css('opacity', 1);
                }


                // $('.user-gcdeputazione-pi1 input[type=checkbox]').prop('disabled', false);
                // $('svg circle, svg path, svg ellipse').css('opacity', 1);

                // $('.partiti input:not(:checked)').each(function (){
                //     $('svg .'+$(this).val()).css('opacity', 0.3)
                // });

                $('.deputato.shown').removeClass('shown');

                searching = false;
            }
        });

        $('.ricerca').on('click', '.clear-field a', function (){
            $('.deputato.shown').removeClass('shown');

            $('.user-gcdeputazione-pi1 input[type=checkbox]').prop('disabled', false);

            if($('.user-gcdeputazione-pi1 input[type=checkbox]:checked').length){
                $('svg circle, svg path, svg ellipse').css('opacity', 0.3);

                $('.partiti input:checked').each(function (){
                    $('svg .'+$(this).val()).css('opacity', 1)
                });
            }
            else{
                $('svg circle, svg path, svg ellipse').css('opacity', 1);
            }

            // $('.partiti input:not(:checked)').each(function (){
            //     $('svg .'+$(this).val()).css('opacity', 0.3)
            // });
            searching = false;
        })
    }
    function searchDeputato( event, ui ) {
        var v = (ui.item.label) ? ui.item.label : $(this).val();
        $('svg circle, svg path, svg ellipse').css('opacity', 1);
        if(v != ''){
            var o = $('.deputato[data-name="'+v.toLowerCase()+'"]');
            if(o.length){
                var posto = o.attr('data-posto');
                if(posto){
                    $('svg circle[id!='+posto+'], svg path[id!='+posto+'], svg ellipse[id!='+posto+']').css('opacity', 0.3);

                    if ($('.deputato[data-posto=' + posto + '] img[data-src]').length) {
                        $('.deputato[data-posto=' + posto + '] img').attr('src', $('.deputato[data-posto=' + posto + '] img').attr('data-src'));
                    }
                    $('.deputato').removeClass('shown');
                    $('.deputato[data-posto=' + posto + ']').addClass('shown');
                }
            }
        }
    }
    function initMap(){
        for(x in disposizione_deputati){
            $('svg #p'+x).attr('class', disposizione_deputati[x].replace('ù','u'));
        }
    }
    function filterMap(){

        var v = $(this).val();
        var active = $(this).is(':checked');

        if(active){
            if($('.partiti input:checked').length == 1){
                $('svg circle[class], svg path[class], svg ellipse[class]').css('opacity', 0.3)
            }
            $('svg .'+$(this).val()).css('opacity', 1);
        }
        else{
            if($('.partiti input:checked').length == 0){
                $('svg circle[class], svg path[class], svg ellipse[class]').css('opacity', 1)
            }
            else $('svg .'+$(this).val()).css('opacity', 0.3);
        }



        // var v = $(this).val();
        // var active = $(this).is(':checked');

        // if(active){
        //     $('svg .'+v).css('opacity', 1)
        // }
        // else $('svg .'+v).css('opacity', 0.3)
    }
    function click(){
        var o = $('.deputato[data-posto='+$(this).attr('id')+']');
        if(o.length) location.href = url + o.attr('data-id');
    }
    function mouseover() {
        if(!searching){
            var id = $(this).attr('id');

            overs[id] = true;

            if ($('.deputato[data-posto=' + id + '] img[data-src]').length) {
                $('.deputato[data-posto=' + id + '] img').attr('src', $('.deputato[data-posto=' + id + '] img').attr('data-src'));
            }

            setTimeout(function () {
                if (overs[id]) {
                    $('.deputato').removeClass('shown');
                    $('.deputato[data-posto=' + id + ']').addClass('shown');
                }
            }, 500);
        }
    }
    function mouseout() {
        if(!searching){
            var id = $(this).attr('id');

            setTimeout(function () {
                if (!overs[id]) {
                    $('.deputato[data-posto=' + id + ']').removeClass('shown');
                }
            }, 1000);

            overs[id] = false;
        }
    }
    init();
}
function initIASAssegniParentali(){
    var code = '1592'
    function init(){
        $('.checkCode').click(checkCode)

        // initIASAssegniParentaliQuestions()
    }
    function checkCode(e){
        e.preventDefault()

        if($('#codice').val() == code) initIASAssegniParentaliQuestions()
        else $('.error-messages').removeClass('hidden')
    }
    init();
}

function initIASAssegniParentaliQuestions(){
    var questions = {
        0: '<span class="a hidden">Il richiedente è soggetto a tassazione</span><span class="b hidden">Il richiedente e/o l’altro genitore sono soggetti a tassazione</span>?',
        1: 'Il richiedente è salariato?',
        2: 'L’altro genitore è salariato?',
        3: '<span class="a hidden">Il richiedente è indipendente</span><span class="b hidden">Il richiedente e/o l’altro genitore è/sono indipendente/i</span>?',
        4: 'Il richiedente è beneficiario di rendita (AVS-AI-LPP-Estera)?',
        5: 'L’altro genitore è beneficiario di rendita (AVS-AI-LPP-Estera)?',
        6: 'Il richiedente è beneficiario d\'indennità (disoccupazione – IPG - maternità – infortunio – malattia)?',
        7: 'L’altro genitore è beneficiario d\'indennità (disoccupazione – IPG - maternità – infortunio – malattia)?',
        8: 'Il richiedente è proprietario di sostanza immobiliare nel Canton Ticino?',
        9: 'L’altro genitore è proprietario di sostanza immobiliare nel Canton Ticino?',
        10: 'Il richiedente è proprietario di sostanza immobiliare in altri Cantoni e/o all’estero?',
        11: 'L’altro genitore è proprietario di sostanza immobiliare in altri Cantoni e/o all’estero?',
        12: 'Il richiedente è titolare di debito (ipotecario – privato)?',
        13: 'L’altro genitore è titolare di debito (ipotecario – privato)?'
    }
    //in caso di risposta negativa alla prima domanda
     var questions1 = {
        0: 'Il richiedente è soggetto a tassazione',
        1: 'Il richiedente è salariato?',
        3: 'Il richiedente è indipendente?',
        4: 'Il richiedente è beneficiario di rendita (AVS-AI-LPP-Estera)?',
        6: 'Il richiedente è beneficiario d\'indennità (disoccupazione – IPG - maternità – infortunio – malattia)?',
        8: 'Il richiedente è proprietario di sostanza immobiliare nel Canton Ticino?',
        10: 'Il richiedente è proprietario di sostanza immobiliare in altri Cantoni e/o all’estero?',
        12: 'Il richiedente è titolare di debito (ipotecario – privato)?'
    }
    var documents = {
        0: 'Ultima decisione di tassazione cresciuta in giudicato',
        1: 'Conteggio stipendio del mese di XX',
        2: 'Conteggio stipendio dell’altro genitore del mese di XX',
        3: 'Formulario «Dichiarazione dei dati relativi al/ai reddito/i da attività indipendente» da scaricare dal sito internet e compilare',
        4: 'Ultima decisione di rendita (AVS-AI-LPP-Estera)',
        5: 'Ultima decisione di rendita dell’altro genitore (AVS-AI-LPP-Estera) ',
        6: 'Conteggio dell\'indennità (disoccupazione - IPG - maternità - infortunio - malattia) del mese di XX',
        7: 'Conteggio dell\'indennità dell\'altro genitore (disoccupazione - IPG - maternità - infortunio - malattia) del mese di XX',
        // 8: 'La risposta dovrà figurare nel riassunto',
        // 9: 'La risposta dovrà figurare nel riassunto',
        10: 'Copia dei documenti ufficiali attestanti il valore di stima della sostanza in altri Cantoni e/o all\'estero',
        11: 'Copia dei documenti ufficiali dell\'altro genitore attestanti il valore di stima della sostanza in altri Cantoni e/o all\'estero',
        12: 'Estratto di tutti i debiti bancari/postali: saldo al mese di XX (all\'ultimo giorno del mese)',
        13: 'Estratto di tutti i debiti bancari/postali intestati all\'altro genitore: saldo al mese di XX (all\'ultimo giorno del mese)'
    }
    var months = [
        'gennaio',
        'febbraio',
        'marzo',
        'aprile',
        'maggio',
        'giugno',
        'luglio',
        'agosto',
        'settembre',
        'ottobre',
        'novembre',
        'dicembre'
    ]
    var questions_n = 14
    var questionTpl = '<div class="question hidden" data-n="::n::"><h2>::title::</h2><label><input type="radio" value="1" name="question::n::"> Si</label><label><input type="radio" value="0" name="question::n::"> No</label><div class="error-messages hidden">Compila il campo</div></div>'
    var loading = false
    var url = 'fileadmin/DSS/IAS/formulario_assegni_parentali/'
    function init(){
        generate()
        $('#assegni_parentali .question input').click(answered)
        $('#assegni_parentali input[name=pre-question]').click(preQuestionAnswered)
        $('#assegni_parentali .send').click(send)
    }
    function generate(){
        $('#assegni_parentali').html('')

        var pre_question = '<div class="question"><h2>I genitori del figlio per il quale si sta richiedendo l’AP sono una coppia</h2><label><input type="radio" value="1" name="pre-question"> Si</label><label><input type="radio" value="0" name="pre-question"> No</label></div>'
        $('#assegni_parentali').append(pre_question)

        $('#assegni_parentali').append('<div class="pre-form hidden">'+$('div.form-part').html()+'</div>')

        var html = ''
        for(x=1;x<=31;x++) html += '<option value="'+x+'">'+('0'+x).substr('-2')+'</option>'
        $('#nascita_g').html(html)
        var html = ''
        for(x=1;x<=12;x++) html += '<option value="'+x+'">'+('0'+x).substr('-2')+'</option>'
        $('#nascita_m').html(html)
        var html = ''
        for(x=2019;x<=moment().year();x++) html += '<option value="'+x+'">'+x+'</option>'
        $('#nascita_a').html(html)


        for(x in questions){
            var html = questionTpl.replace('::title::', questions[x]).replace(/\:\:n\:\:/g, x)
            $('#assegni_parentali').append(html);
        }
        $('#assegni_parentali').append('<button class="btn btn-primary send hidden">Invia</button>');
    }
    function preQuestionAnswered(){
        if($(this).val() == 1){
            $('.altro').removeClass('hidden')

            if($('.question:not(.hidden):last').data('n') > 13) $('.question[data-n=00], .question[data-n=2], .question[data-n=5], .question[data-n=7], .question[data-n=9], .question[data-n=11], .question[data-n=13]').removeClass('hidden')
            else if($('.question:not(.hidden):last').data('n') > 11) $('.question[data-n=00], .question[data-n=2], .question[data-n=5], .question[data-n=7], .question[data-n=9], .question[data-n=11]').removeClass('hidden')
            else if($('.question:not(.hidden):last').data('n') > 9) $('.question[data-n=00], .question[data-n=2], .question[data-n=5], .question[data-n=7], .question[data-n=9]').removeClass('hidden')
            else if($('.question:not(.hidden):last').data('n') > 7) $('.question[data-n=00], .question[data-n=2], .question[data-n=5], .question[data-n=7]').removeClass('hidden')
            else if($('.question:not(.hidden):last').data('n') > 5) $('.question[data-n=00], .question[data-n=2], .question[data-n=5]').removeClass('hidden')
            else if($('.question:not(.hidden):last').data('n') > 2) $('.question[data-n=00], .question[data-n=2]').removeClass('hidden')

            $('.question .a').addClass('hidden')
            $('.question .b').removeClass('hidden')
        }
        else{
            $('.altro').addClass('hidden')
            $('.question[data-n=2], .question[data-n=5], .question[data-n=7], .question[data-n=9], .question[data-n=11], .question[data-n=13]').addClass('hidden')

            $('.question .b').addClass('hidden')
            $('.question .a').removeClass('hidden')
        }

        if($('#assegni_parentali .pre-form').hasClass('hidden')){
            $('#assegni_parentali .pre-form').removeClass('hidden')
            // showQuestion($(this).val() == 1 ? 1 : 0)
            showQuestion(0)
        }
    }
    function answered(){
        var n = parseInt($(this).parents('.question').data('n'))

        $(this).parent().siblings('.error-messages').addClass('hidden');

        if((n == 1 || n == 4 || n == 6 || n == 8 || n == 10 || n == 12) && $('input[name=pre-question]:checked').val() == 0){
            n += 2
        }
        else{
            n++
        }

        if(n >= questions_n) showEndButton()
        else showQuestion(n)
    }
    function showQuestion(n){
        $('.question[data-n='+n+']').removeClass('hidden')
    }
    function hideQuestion(n){
        $('.question[data-n='+n+']').addClass('hidden')
    }
    function showEndButton(){
        $('button.send').removeClass('hidden')
    }
    function send(e){
        e.preventDefault()

        if(!loading){
            loading = true;

            var error = false;

            if(!checkField('#richiedente')) error = true;
            if($('input[name=pre-question]:checked').val() == '1'){
                if(!checkField('#altro_genitore')) error = true;
            }
            if(!checkField('#figlio')) error = true;
            // if(!checkField('#nascita')) error = true;
            if(!checkField('#email', 'email')) error = true;


            $('.question:not(.hidden)').each(function (){
                if(!$(this).find('input:checked').length)  $(this).children('.error-messages').removeClass('hidden');
            })


            if(!error){
                var data = {
                    q: []
                }

                data.richiedente = $('#richiedente').val()
                if($('input[name=pre-question]:checked').val() == '1') data.altro_genitore = $('#altro_genitore').val()
                data.figlio = $('#figlio').val()
                data.nascita = ('0'+$('#nascita_g').val()).substr('-2')+'/'+('0'+$('#nascita_m').val()).substr('-2')+'/'+$('#nascita_a').val()
                data.email = $('#email').val()

                data.pre_question = $('input[name=pre-question]:checked').val()

                // Questions
                $('.question:not(.hidden):not(:first)').each(function (){
                    data.q.push($(this).data('n'))
                    data[$(this).data('n')] = $(this).find('input:checked').val()
                })

                // Documents
                var tmp = data.nascita.split('/')
                var birthday = moment(tmp[1]+'/'+tmp[0]+'/'+tmp[2]).add(6, 'months');
                data.documents = [
                    'Estratto di tutti i conti bancari/postali: saldo al mese di '+ months[birthday.month()] +' '+birthday.year()+' (all’ultimo giorno del mese)',
                    'Formulario «Procura, compensazione e restituzione» da scaricare dal sito internet e compilare'
                ]

                $('.question:not(.hidden):not(:first)').each(function (){
                    if(documents[$(this).data('n')] && $(this).find('input:checked').val() == '1'){
                        data.documents.push(documents[$(this).data('n')].replace('XX', months[birthday.month()] +' '+birthday.year()))
                    }
                })

                $.post(url+'save.php', data, function (r){
                    $('.btn-primary.send').remove()

                    $('#assegni_parentali').html('<p>Grazie per aver risposto alle domande inerenti la sua situazione personale. Consulti la sua casella e-mail dove troverà una comunicazione con la documentazione da trasmetterci.<br>Cordiali saluti.</p>')
                    // Fields
                   /*  var html = ''
                    $('.pre-form .form-group:not(.hidden)').each(function (){
                       html += '<h2>'+$(this).children('label').text()+'</h2>'
                        if($(this).children('input').length) html += '<div class="value">'+$(this).children('input').val()+'</div>';
                        else html += '<div class="value">'+data.nascita+'</div>';

                    })
                    $('.pre-form').html(html);


                    // Documents
                    var html = '<h2>Documenti necessari</h2>'
                    html += '<ul>'
                    for(x in data.documents) html += '<li>'+data.documents[x]+'</li>'
                    html += '</ul>'
                    $('#assegni_parentali').prepend(html)


                    // Questions
                    $('.question:not(.hidden)').each(function (){
                        var r = $(this).find('input:checked').val() == 1 ? 'Sì' : 'No';
                        $(this).children('label').remove();
                        $(this).append(r);
                    })
                    */
                    $('html, body').animate({scrollTop: 0}, 500)
                })
            }
            else{
                $('body, html').animate({ scrollTop: $('.error-messages:not(.hidden):first').offset().top - 100 }, 200)
                loading = false
            }
        }
    }
    function checkField(s, type){
        if(typeof type == 'undefined'){
            if($(s).val() == ''){
                $(s).siblings('.error-messages').removeClass('hidden');
                return false;
            }
            else{
                $(s).siblings('.error-messages').addClass('hidden');
                return true;
            }
        }
        else if(type == 'radio' || type == 'checkbox'){
            if($(s+':checked').length == 0){
                $(s+':first').parent().parent().siblings('.error-messages').removeClass('hidden');
                return false;
            }
            else{
                $(s+':first').parent().parent().siblings('.error-messages').addClass('hidden');
                return true;
            }
        }
        else if(type == 'email'){
            if($(s).val() == '' || !checkEmail($(s).val())){
                $(s).siblings('.error-messages').removeClass('hidden');
                return false;
            }
            else{
                $(s).siblings('.error-messages').addClass('hidden');
                return true;
            }
        }
        else if(type == 'date'){
            if($(s).val() == '' || !checkDate($(s).val())){
                $(s).siblings('.error-messages').removeClass('hidden');
                return false;
            }
            else{
                $(s).siblings('.error-messages').addClass('hidden');
                return true;
            }
        }
    }
    function checkEmail(email) {
        var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(String(email).toLowerCase());
    }
    init()
}
function initIAS(){
    var prefooter_timer;
    var background_height;
    var contenitore_height
    function init(){
        $('.privati-list a').click(showMenuItems);
        if($('.ias.home').length){
            $('.home .image').addClass('i'+Math.ceil(Math.random() * 4));
        }
        else if($('.ias .privati-list').length){
            $('.privati-list a').attr('aria-expanded', false);
            if(location.hash){
                hash = location.hash.substring(1);
                $("html, body").animate({ scrollTop: $('.privati-list').offset().top });
                $('[data-id="'+hash+'"]').trigger('click');
            }
        }

        // Prefooter position
        background_height = $('.background').outerHeight();
        contenitore_height = $('body').outerHeight();
        prefooterPosition();
        $(window).resize(function (){
            if(prefooter_timer) clearTimeout(prefooter_timer);
            prefooter_timer = setTimeout(prefooterPosition, 200);
        });
    }
    function prefooterPosition(){
        if(windowHeight() > background_height){
            $('#contenitore').css('min-height', windowHeight() - $('footer').outerHeight() - $('header').outerHeight() - $('#box-top').outerHeight() - $('.prefooter').outerHeight() - 60 - 76);
        }
    }
    function showMenuItems(e){
        e.preventDefault();

        if(!$(this).parent().hasClass('selected')){
            $('.right-menu > div').addClass('hidden');
            $('.right-menu > div:eq('+$(this).parent().index()+')').removeClass('hidden');

            $('.privati-list .selected').children().attr('aria-expanded', false);
            $('.privati-list .selected').removeClass('selected');
            $(this).parent().addClass('selected');
            $(this).attr('aria-expanded', true);

            // $('.privati-list').animate({ width: '300px' }, 500);
            $('.in').addClass('opened');
        }
    }
    init();


     $(".dropdownPrestazioni li a").click(function() {
        val=$(this).attr('data-valore');
        $("#idPrestazione").val(val);
        $("#idCategoria").val('');
        $('#ricerca').submit();

    });

    $(".dropdownTematiche li a").click(function() {
        val=$(this).attr('data-valore');
        $("#idCategoria").val(val);
        $("#idPrestazione").val('');
        $('#ricerca').submit();

    });


    $("a.suggerimento").click(function(e) {
        e.preventDefault();
         val=$(this).attr('data-termine');
         $("#q").val(val);
         $('#ricerca').submit();
     });

     $("a.prestazione").click(function(e) {
         e.stopPropagation();
         e.preventDefault();

         val=$(this).attr('data-valore');
         url=$(this).attr('data-url');


         var inputs = '<input type="hidden" name="Prestazione" value="'+val+'" />';

         $("body").append('<form action="'+url+'" method="post" id="poster">'+inputs+'</form>');
         $("#poster").submit();
     });

    initAutocompleteIAS();

    function initAutocompleteIAS(){
        function init(){
            $('head').append('<link rel="stylesheet" type="text/css" href="https://www4.ti.ch/typo3conf/ext/theme/Resources/Public/css/jquery-ui.css">');

            if(typeof $.ui === "undefined")
                $.getScript('https://www4.ti.ch/typo3conf/ext/theme/Resources/Public/js/jquery-ui.js', suggest);
            else
                suggest();

        }
        function suggest(){
            $("#q").autocomplete({
                source : function(request, response) {
                    $.ajax({
                        url: "https://ricerca.ti.ch/suggest?client=IAS&site=IAS_schede&max=5&format=rich",
                        dataType: "jsonp",
                        data : {
                            q : request.term
                        },
                        success : function(data) {
                            response( $.map( data.results, function( item ) {
                                return {
                                    label: item.name,
                                    value: item.name
                                }
                            }));
                        }
                    });
                },
            });
        }
        init();
    }
}

function initImpiantiSportivi()
{


	$(".dropdown-menu").keyup(function(e) {
	     if (e.keyCode == 27) {
	    	 $(".input-group-btn").removeClass("open");
	    	 $(".dropdownRegione").removeClass("open");
	    	 $(".dropdownComune").removeClass("open");
	    	 $(".dropdownDisciplina").removeClass("open");
	    	 $(".dropdownGruppo").removeClass("open");
	    }
	});


	$('.formRicerca2 select').change(function (){
		$('#ricerca').submit();
	});

	$('.ricercaImpianti select').change(function (){
		$('#ricerca').submit();
	});
	
	
	/*$(".formRicerca1 li a").click(function() {
		val=$(this).attr('data-valore');
		//$("#idDistretto").val(val);
		$("#idComune").val('');
		$('#ricerca').submit();

	});*/

	/*$(".ricercaImpianti li a").click(function() {

		val=$(this).attr('data-valore');
		//$("#idDistretto").val(val);
		$('.ricercaImpianti').submit();

	});*/
	
	

	$('#showMore').click(showMore);

	function showMore(){

		//controllo se last>tot
		var tot=$('#showMore').attr('data-tot');

		var last_id = $(".impianto:last").attr("id");
		last_id=last_id.split('-');
		var last=parseInt(last_id[1])+1;
		last_id[1]=parseInt(last_id[1])+1+25;


		if(last >= tot)
		{
			$('.moreResults').hide();
		}
		else
		{
			//aggiungere a URL ultimo elemento caricato in modo da passarlo al dettaglio
			var url=document.location.href;
			if(url.indexOf('&last=') !== -1)
			{
				var last=getParametroURL('last');
				url=url.replace('&last='+last,'&last='+last_id[1]);
			}
			else
			{
				 url = url+"&last="+last_id[1];
			}

		    window.history.replaceState(null, null, url);

		    var comune=getParametroURL('comune');
		    var disciplina=getParametroURL('disciplina');
		    var parola=getParametroURL('parola');
		    //var distretto=getParametroURL('distretto');
		    var regione=getParametroURL('regione');
		    var gruppo=getParametroURL('gruppo');

			var ordinamento=$('#showMore').attr('data-ordine');
			var direzione=$('#showMore').attr('data-direzione');


			 $.ajax(
	            {
	                url: '/user_librerie/php/DECS/impiantiSportivi/loadMoreData.php?start='+last_id[1]+'&comune='+comune+'&disciplina='+disciplina+'&parola='+parola+'&regione='+regione+'&gruppo='+gruppo+'&ordinamento='+ordinamento+'&direzione='+direzione,
	                type: "get",
	                beforeSend: function()
	                {
	                    $('.ajax-load').show();
	                }
	            })
	            .done(function(data)
	            {
	                $('.ajax-load').hide();
	                $("#post-data").before(data);

	                var ultimo = $(".impianto:last").attr("id");
	                ultimo=ultimo.split('-');
	                ultimo=parseInt(ultimo[1])+1;
	                if(ultimo >= tot)
	        		{
	        			$('.moreResults').hide();
	        		}

	            })

	            .fail(function(jqXHR, ajaxOptions, thrownError)
	            {
	                  alert('il server non risponde...');
	            });
		}

		var url=document.location.href;
		if(url.indexOf('&last=') !== -1)
		{
			var last=getParametroURL('last');

			//distretto
			var oldUrlDistretto = $('#elencoImpianti th.distretto a'). attr("href");
			if(oldUrlDistretto.indexOf('&last=') !== -1)
			{
				var oldLast=getParametro(oldUrlDistretto,'last');
				var newUrlDistretto=oldUrlDistretto.replace("&last="+oldLast, "&last="+last);
				$('#elencoImpianti th.distretto a'). attr("href", newUrlDistretto);
			}
			else
			{
				var newUrlDistretto=oldUrlDistretto+'&last='+last;
				$('#elencoImpianti th.distretto a'). attr("href", newUrlDistretto);
			}

			//comune
			var oldUrlComune = $('#elencoImpianti th.comune a'). attr("href");
			if(oldUrlComune.indexOf('&last=') !== -1)
			{
				var oldLast=getParametro(oldUrlComune,'last');
				var newUrlComune=oldUrlComune.replace("&last="+oldLast, "&last="+last);
				$('#elencoImpianti th.comune a'). attr("href", newUrlComune);
			}
			else
			{
				var newUrlComune=oldUrlComune+'&last='+last;
				$('#elencoImpianti th.comune a'). attr("href", newUrlComune);
			}

			//impianto
			var oldUrlImpianto = $('#elencoImpianti th.impianto a'). attr("href");
			if(oldUrlImpianto.indexOf('&last=') !== -1)
			{
				var oldLast=getParametro(oldUrlImpianto,'last');
				var newUrlImpianto=oldUrlImpianto.replace("&last="+oldLast, "&last="+last);
				$('#elencoImpianti th.impianto a'). attr("href", newUrlImpianto);
			}
			else
			{
				var newUrlImpianto=oldUrlImpianto+'&last='+last;
				$('#elencoImpianti th.impianto a'). attr("href", newUrlImpianto);
			}
		}


	}


	function getParametroURL(name){
		var url=window.location.href;

		if(url.indexOf(name)>0)
		{
			var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);
			return results[1] || '';
		}
		else
			return '';
	}

	function getParametro(url,name){

		if(url.indexOf(name)>0)
		{
			var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(url);
			return results[1] || '';
		}
		else
			return '';
	}


	$('a.mappa').click(openMappaGoogle);
	$('a.mappaAerea').click(openMappaAerea);


	function openMappaGoogle(){

		href=$('a.mappa').attr('data-src');
		content='<iframe src="'+href+'" style="display: 1none; width: 100%; height: 480px; border: 0"></iframe>';

		var html = '<div class="modal fade" id="modalMappaGoogle" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">';
        html += '<div class="modal-dialog modal-lg" role="document">';
        html += '<div class="modal-content">';
        html += '<div class="modal-header"><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button><h4 class="modal-title" id="myModalLabel">Mappa</h4></div>';
        html += '<div class="modal-body">'+content+'</div>';
        html += '</div></div></div>';

        $('#mappa').append(html);
	}

	function openMappaAerea(){

		href=$('a.mappaAerea').attr('data-src');
		content='<iframe src="'+href+'" style="display: 1none; width: 100%; height: 480px; border: 0"></iframe>';

		var html = '<div class="modal fade" id="modalMappaAerea" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">';
        html += '<div class="modal-dialog modal-lg" role="document">';
        html += '<div class="modal-content">';
        html += '<div class="modal-header"><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button><h4 class="modal-title" id="myModalLabel">Foto aerea</h4></div>';
        html += '<div class="modal-body">'+content+'</div>';
        html += '</div></div></div>';

        $('#mappa').append(html);
	}

}

/* Info Giovani */
//function initInfoGiovani() {
    // $('.panel-heading:first').addClass('opened');
    // $('.panel-heading:first a').removeClass('collapsed');
    // $('.panel-heading a').click(function (){
    //     $('.panel-heading.opened').removeClass('opened')
    //     if($(this).hasClass('collapsed')) $(this).parents('.panel-heading').addClass('opened');
    // });
//}

function initInfoGiovani() {
    $('#cancella').click(function () {

        $("#mese option:selected").removeAttr("selected");
        $("#mese option:first").attr("selected", true);
        //$('#mese').trigger('chosen:updated');
          //$('#mese').val('');
          $('#anno').val('');
          $('#titolo').val('');
          $('#eta').val('');
    });
}
function initLaboratorioCantonale(){
	$("a.suggerimento").click(function() {
         val=$(this).attr('data-termine');
         $("#q").val(val);
         $('#ricerca').submit();
     });
}
//gestione acquisti legislazione
function initLegislazione(){

    //per gestire il back del browser
    $(window).on('popstate', function(event) {

    var hash = location.hash;
    if(hash.length==0)
    {
        $("#riassuntoOrdinazione").hide();
        $("#DatiPersonali").hide();
        $("#moduloOrdinaizonePubblicazioni").show();
        $("#testoIntro").show();
        $('html, body').animate({scrollTop: '0px'}, 300);
    }
});


    // Ordinazione altre pubblicazioni
    // ------------------------------------
        $("#riassuntoOrdinazione").hide();
        $("#DatiPersonali").hide();

        $('#altrePubb .pubblicazione').on('change', function (e) {
            var totale=0;
            $("#ordinazione select").each(function(){
                 var input = $(this);
                 var optionSelected = $("option:selected", this);
                 var quantita = this.value;
                 var prezzo=optionSelected.data('prezzo');
                 totale=totale+(quantita*prezzo);
                });

            totale="fr. "+totale+".00";

            $('#totale').text(totale);
        });

        $("#altrePubb #procediOrdinazione").click(function() {

            window.location.hash="riepilogo";

            var totale=0;
            var riassunto="";
            var tmp="";

            $("#ordinazione select").each(function(){
                var input = $(this);
                var optionSelected = $("option:selected", this);
                var quantita = this.value;
                var prezzo=optionSelected.data('prezzo');
                var prezzolibri="";
                var titolo=input.data('titolo');

                if(quantita > 0)
                {
                    totale=totale+(quantita*prezzo);
                    prezzolibri=quantita*prezzo;

                    riassunto=riassunto+'<div class="row"><div class="col-xs-8">'+titolo+'</div><div class="col-xs-2">'+quantita+'x</div><div class="col-xs-2">fr. '+prezzolibri+'.00</div></div>';
                    tmp=tmp+quantita+'x    '+titolo+'\n';
                }
            });

            riassunto= riassunto+'<div class="row"><div class="col-xs-8"></div><div class="col-xs-4 totale"><span class="spanStringa"><b>Totale IVA incl. 2.5%</b></span><span id="totale" class="spanTotale">fr. '+totale+'.00</span></div></div>';

            tmp=tmp+'\nTOTALE IVA incl. 2.5%: fr. '+totale+'.00';

            riassunto='<h1 class="csc-firstHeader">Riepilogo e ordinazione</h1><div class="box-info1"><b>Riepilogo ordine</b><br /><br />'+riassunto+'<div class="row"><p>Al totale saranno aggiunte le spese di spedizione (in Svizzera, fr. 1.- per una piccola pubblicazione, fr. 7.- per un volume della RtiD).<br />La fattura, da pagare entro 30 giorni dalla ricezione, verrà spedita separatamente.</p></div></div>';

            $("#riassuntoOrdinazione").html(riassunto);
            $("#riassuntoOrdinazione").show();
            $("#DatiPersonali").show();
            $("#moduloOrdinaizonePubblicazioni").hide();
            $("#testoIntro").hide();
            $('html, body').animate({scrollTop: '0px'}, 300);

            $("#powermail_field_ordinazione").val(tmp);
        });

        // ------------------------------------


    // Ordinazione RtiD
    // ------------------------------------

    $("#RtiD a.aggiungiA1").click(function() {
        var nrEl=$("#RtiD #ordinazioneRTID .row .col-xs-6").find(".el").length;
        nrEl=nrEl+1;

        var campo='<div class="row el"><div class="col-xs-4"><select id="a'+nrEl+'" name="a'+nrEl+'" class="pubblicazione a" data-titolo="Rivista ticinese di diritto"><option value="2020 - I" data-prezzo="114">2020 - I</option><option value="2019 - II" data-prezzo="114">2019 - II</option><option value="2019 - I" data-prezzo="114">2019 - I</option><option value="2018 - II" data-prezzo="114">2018 - II</option><option value="2018 - I" data-prezzo="114">2018 - I</option><option value="2017 - II" data-prezzo="114">2017 - II</option><option value="2017 - I" data-prezzo="114">2017 - I</option><option value="2016 - II" data-prezzo="114">2016 - II</option><option value="2016 - I" data-prezzo="114">2016 - I</option><option value="2015 - II" data-prezzo="114">2015 - II</option><option value="2015 - I" data-prezzo="114">2015 - I</option><option value="2014 - II" data-prezzo="114">2014 - II</option><option value="2014 - I" data-prezzo="114">2014 - I</option><option value="2013 - II" data-prezzo="114">2013 - II</option><option value="2013 - I" data-prezzo="114">2013 - I</option><option value="2012 - II" data-prezzo="114">2012 - II</option><option value="2012 - I" data-prezzo="114">2012 - I</option><option value="2011 - II" data-prezzo="114">2011 - II</option><option value="2011 - I" data-prezzo="114">2011 - I</option>  <option value="2010 - II" data-prezzo="114">2010 - II</option><option value="2010 - I" data-prezzo="114">2010 - I</option><option value="2009 - II" data-prezzo="114">2009 - II</option><option value="2009 - I" data-prezzo="114">2009 - I</option><option value="2008 - I" data-prezzo="114">2008 - I</option><option value="2007 - II" data-prezzo="114">2007 - II</option><option value="2007 - I" data-prezzo="114">2007 - I</option><option value="2006 - II" data-prezzo="114">2006 - II</option><option value="2006 - I" data-prezzo="114">2006 - I</option><option value="2005 - II" data-prezzo="114">2005 - II</option><option value="2005 - I" data-prezzo="114">2005 - I</option><option value="2004 - II" data-prezzo="99">2004 - II</option><option value="2004 - I" data-prezzo="99">2004 - I</option></select></div><div class="col-xs-4"><select name="qt'+nrEl+'" class="pubblicazione qt'+nrEl+'" data-titolo="Rivista ticinese di diritto"><option value="0">0</option><option value="1">1</option><option value="2">2</option><option value="3">3</option><option value="4">4</option><option value="5">5</option><option value="6">6</option><option value="7">7</option><option value="8">8</option><option value="9">9</option><option value="10">10</option></select></div><div class="col-xs-4 p'+nrEl+'">fr. 114.00</div></div>';

        $(campo).insertBefore( ".pulsanteAggiungi" );
         // Selectpicker
        if ($('select').length){
            jQuery('select').selectpicker();
        }

        $("#RtiD select.pubblicazione").change(function(){
            aggiornaTotale();
        });

        $("#RtiD select.pubblicazione.a").change(function(){
            aggiornaPrezzoUnitario(this.id,'a','p');
        });

    });

    $("#RtiD a.aggiungiB1").click(function() {
        var nrEl=$("#RtiD #ordinazioneRTID .row .col-xs-6").find(".el2").length;
        nrEl=nrEl+1;

        var campo='<div class="row el2"><div class="col-xs-4"><select id="b'+nrEl+'" name="b'+nrEl+'" class="pubblicazione b" data-titolo="Rivista di diritto amministrativo e tributario ticinese"><option value="2003 - II" data-prezzo="99">2003 - II</option><option value="2003 - I" data-prezzo="99">2003 - I</option><option value="2002 - II" data-prezzo="99">2002 - II</option><option value="2002 - I" data-prezzo="99">2002 - I</option><option value="2001 - II" data-prezzo="99">2001 - II</option><option value="2001 - I" data-prezzo="99">2001 - I</option><option value="2000 - II" data-prezzo="36">2000 - II</option><option value="2000 - I" data-prezzo="36">2000 - I</option><option value="1999 - I" data-prezzo="36">1999 - I</option><option value="1998 - II" data-prezzo="36">1998 - II</option><option value="1998 - I" data-prezzo="36">1998 - I</option><option value="1997 - II" data-prezzo="36">1997 - II</option><option value="1997 - I" data-prezzo="36">1997 - I</option><option value="1996 - II" data-prezzo="36">1996 - II</option><option value="1996 - I" data-prezzo="36">1996 - I</option><option value="1995 - I" data-prezzo="36">1995 - I</option><option value="1994 - II" data-prezzo="36">1994 - II</option><option value="1994 - I" data-prezzo="36">1994 - I</option><option value="1993 - II" data-prezzo="36">1993 - II</option><option value="1993 - I" data-prezzo="36">1993 - I</option><option value="1992 - II" data-prezzo="36">1992 - II</option><option value="1992 - I" data-prezzo="36">1992 - I</option><option value="1991 - II" data-prezzo="36">1991 - II</option><option value="1991 - I" data-prezzo="36">1991 - I</option><option value="1990" data-prezzo="26">1990</option><option value="1989" data-prezzo="26">1989</option><option value="1988" data-prezzo="26">1988</option><option value="1987" data-prezzo="26">1987</option><option value="1984" data-prezzo="26">1984</option><option value="1981" data-prezzo="26">1981</option><option value="1979" data-prezzo="26">1979</option><option value="1978" data-prezzo="26">1978</option><option value="1977" data-prezzo="26">1977</option><option value="1976" data-prezzo="26">1976</option></select></div><div class="col-xs-4"><select name="tt'+nrEl+'" class="pubblicazione tt'+nrEl+'" data-titolo="Rivista di diritto amministrativo e tributario ticinese"><option value="0">0</option><option value="1">1</option><option value="2">2</option><option value="3">3</option><option value="4">4</option><option value="5">5</option><option value="6">6</option><option value="7">7</option><option value="8">8</option><option value="9">9</option><option value="10">10</option></select></div><div class="col-xs-4 t'+nrEl+'">fr. 99.00</div></div>';

        $(campo).insertBefore( ".pulsanteAggiungi2" );
         // Selectpicker
        if ($('select').length){
            jQuery('select').selectpicker();
        }

        $("#RtiD select.pubblicazione").change(function(){
            aggiornaTotale();
        });


        $("#RtiD select.pubblicazione.b").change(function(){
            aggiornaPrezzoUnitario(this.id,'b','t');
        });
    });



    // Procedi all'ordinazione
    $("#RtiD #procediOrdinazione").click(function() {

        window.location.hash="riepilogo";

        var totale=0;
        var riassunto="";
        var tmp="";

        //Calcolo RTID
        $("#ordinazioneRTID select.a").each(function(){
            var input = $(this);
            var nomecampo=input.attr("id").replace("a","qt");
            var optionSelected = $("option:selected", this);
            var anno = this.value;
            var prezzo=optionSelected.data('prezzo');
            var titolo=input.data('titolo')+" "+anno;

            var quantita=$("#ordinazioneRTID ."+nomecampo).find("option:selected").val();

            if(quantita > 0)
            {
                totale=totale+(quantita*prezzo);
                prezzolibri=quantita*prezzo;

                riassunto=riassunto+'<div class="row"><div class="col-xs-8">'+titolo+'</div><div class="col-xs-2">'+quantita+'x</div><div class="col-xs-2">fr. '+prezzolibri+'.00</div></div>';
                tmp=tmp+quantita+'x    '+titolo+'\n';
            }


        });


        // calcolo massimari + GAT
        $("#ordinazioneRTID select.max").each(function(){
            var input = $(this);
            var optionSelected = $("option:selected", this);
            var quantita = this.value;
            var prezzo=optionSelected.data('prezzo');
            var prezzolibri="";
            var titolo=input.data('titolo');

            if(quantita > 0)
            {
                totale=totale+(quantita*prezzo);
                prezzolibri=quantita*prezzo;

                riassunto=riassunto+'<div class="row"><div class="col-xs-8">'+titolo+'</div><div class="col-xs-2">'+quantita+'x</div><div class="col-xs-2">fr. '+prezzolibri+'.00</div></div>';
                tmp=tmp+quantita+'x    '+titolo+'\n';
            }
        });


        //calcolo RDAT
        $("#ordinazioneRTID select.b").each(function(){
            var input = $(this);
            var nomecampo=input.attr("id").replace("b","tt");
            var optionSelected = $("option:selected", this);
            var anno = this.value;
            var prezzo=optionSelected.data('prezzo');
            var titolo=input.data('titolo')+" "+anno;

            var quantita=$("#ordinazioneRTID ."+nomecampo).find("option:selected").val();

            if(quantita > 0)
            {
                totale=totale+(quantita*prezzo);
                prezzolibri=quantita*prezzo;

                riassunto=riassunto+'<div class="row"><div class="col-xs-8">'+titolo+'</div><div class="col-xs-2">'+quantita+'x</div><div class="col-xs-2">fr. '+prezzolibri+'.00</div></div>';
                tmp=tmp+quantita+'x    '+titolo+'\n';
            }
        });



        riassunto= riassunto+'<div class="row"><div class="col-xs-8"></div><div class="col-xs-4 totale"><span class="spanStringa"><b>Totale IVA incl. 2.5%</b></span><span id="totale" class="spanTotale">fr. '+totale+'.00</span></div></div>';
        tmp=tmp+'\nTOTALE IVA incl. 2.5%: fr. '+totale+'.00';
        riassunto='<h1 class="csc-firstHeader">Riepilogo e ordinazione</h1><div class="box-info1"><b>Riepilogo ordine</b><br /><br />'+riassunto+'<div class="row"><p>Al totale saranno aggiunte le spese di spedizione (in Svizzera, fr. 1.- per una piccola pubblicazione, fr. 7.- per un volume della RtiD).<br />La fattura, da pagare entro 30 giorni dalla ricezione, verrà spedita separatamente.</p></div></div>';

        $("#riassuntoOrdinazione").html(riassunto);

        $("#riassuntoOrdinazione").show();
        $("#DatiPersonali").show();
        $("#moduloOrdinaizonePubblicazioni").hide();
        $("#testoIntro").hide();
        $('html, body').animate({scrollTop: '0px'}, 300);

        $("#powermail_field_ordinazione").val(tmp);

    });


    $("#RtiD select.pubblicazione").change(function(){
        aggiornaTotale();
    });

    $("#RtiD select.pubblicazione.a").change(function(){
        aggiornaPrezzoUnitario(this.id,'a','p');
    });


    $("#RtiD select.pubblicazione.b").change(function(){
        aggiornaPrezzoUnitario(this.id,'b','t');
    });


    function aggiornaTotale(){
        var totale=0;

        //Calcolo RTID
        $("#ordinazioneRTID select.a").each(function(){
            var input = $(this);
            var nomecampo=input.attr("id").replace("a","qt");
            var optionSelected = $("option:selected", this);
            var prezzo=optionSelected.data('prezzo');
            var quantita=$("#ordinazioneRTID ."+nomecampo).find("option:selected").val();

            if(quantita > 0)
            {
                totale=totale+(quantita*prezzo);
            }
        });

        // calcolo massimari + GAT
        $("#ordinazioneRTID select.max").each(function(){
            var input = $(this);
            var optionSelected = $("option:selected", this);
            var quantita = this.value;
            var prezzo=optionSelected.data('prezzo');

            if(quantita > 0)
            {
                totale=totale+(quantita*prezzo);
            }
        });

        //calcolo RDAT
        $("#ordinazioneRTID select.b").each(function(){
            var input = $(this);
            var nomecampo=input.attr("id").replace("b","tt");
            var optionSelected = $("option:selected", this);
            var prezzo=optionSelected.data('prezzo');
            var quantita=$("#ordinazioneRTID ."+nomecampo).find("option:selected").val();

            if(quantita > 0)
            {
                totale=totale+(quantita*prezzo);
            }
        });

        totale="fr. "+totale+".00";
        $('#totale').text(totale);
    }


    function aggiornaPrezzoUnitario(elemento,search,replace){
        //aggiorno il prezzo unitaro della pubblicazione
        var prezzo = $("#"+elemento).find(":selected").data('prezzo');
        var nomecampo=elemento.replace(search,replace);
        $("."+nomecampo).html('fr. '+prezzo+'.00');
    }

// ------------------------------------
}
/* ODG */
function initODG(){
    $('#ODG a').click(function () {

        var link = $(this).attr('href');

        start = link.lastIndexOf(".") + 1;
        len = link.length - start;
        estensione = link.substr(start, len);

        var tat = '';
        if (estensione != 'htm') {
            return true;
        }
        else if (link.indexOf("odg-mes") != '-1') {
            //numero = parseInt(link.replace("odg-mes/", ""));
            start = link.lastIndexOf("/") + 1;
            len = link.length - start;
            numero = parseInt(link.substr(start, len));
            tat = 100;
        }
        else if (link.indexOf("mozioni") != '-1') {
            // +3  = [/MO]
            start = link.lastIndexOf("/") + 3;
            len = link.length - start;
            numero = parseInt(link.substr(start, len));
            tat = 105;
        }
        else if (link.indexOf("inizgeneriche") != '-1') {
            // +3  = [/IG]
            start = link.lastIndexOf("/") + 3;
            len = link.length - start;
            numero = parseInt(link.substr(start, len));
            tat = 102;
        }
        else if (link.indexOf("inizelaborate") != '-1') {
            // +3  = [/IE]
            start = link.lastIndexOf("/") + 3;
            len = link.length - start;
            numero = parseInt(link.substr(start, len));
            //numero = parseInt(link.replace("inizelaborate/IE", ""));
            tat = 103;
        }
        //var urlPagina = "index.php?id=81443&r=1&user_gcparlamento_pi8[ricerca]="+numero+"&user_gcparlamento_pi8[tat]="+tat+"&user_gcparlamento_pi8[data]=&user_gcparlamento_pi8[rel]=&Cerca=Cerca";
        //var newpage = window.open(urlPagina, '', 'window settings');
        document.location.href = "index.php?id=81443&r=1&user_gcparlamento_pi8[ricerca]=" + numero + "&user_gcparlamento_pi8[tat]=" + tat + "&user_gcparlamento_pi8[data]=&user_gcparlamento_pi8[rel]=&Cerca=Cerca";


        return false;
    });
}
/* Organigramma */
function initOpenerOrganigramma() {
    function open(e) {
        e.preventDefault();

        if ($('.overlay-close').length && $('.overlay-close').is(':visible')) {
            $('.overlay-close a').trigger('click');
        }

        if (!$(this).hasClass('opened')) {
            $(this).addClass('opened');

            overlayOpener = $(this);

            if ($('header .right a:eq(1)').hasClass('opened')) {
                $('header .right a:eq(1)').removeClass('opened');
                $('.overlay-content').remove();
            }

            var url = '//www4.ti.ch/';

            jQuery.get(url+'index.php', { 'eID': 'organigramma', 'load': 1 }, function (r) {

                if (!$('.overlay').length) showOverlay();
                jQuery('body').append(r);

                setTimeout(function (){ resizeOverlay(); }, 100);

                $('#link_accessibile').focus();

            });
        }
    }
    function close() {
        $('.overlay-close, .overlay, #organigramma').remove();
        $('header .right .opened').removeClass('opened');
        if(overlayOpener){
            overlayOpener.focus();
            overlayOpener = false;
        }
    }
    $('header .right a.organigramma').click(open);
    setTimeout(function () {
        $('.organigramma.small-icon-link').click(function (e) {
            e.preventDefault();
            $('header .right a.organigramma').trigger('click');
        });
    }, 250);
}
/* PCA */
function initPCA(){
   function init(){
    if($('#pca.page').length){
        var n = 1;
        var max = 27;
         var animationSpeed = 1000;
         var stopShowAll = false;
         var stopHideAll = false;
         var animationN = 1;
         var movingin = false;


          function show(index){
            if($('#a'+index).length){
                var dest = d3.select("#a"+index);
                var dest_cx = dest.attr('cx');
                var dest_cy = dest.attr('cy');


                var objs = d3.selectAll("#g"+index+" circle");

                objs.transition()
                    .duration(animationSpeed)
                    .attr("cx", dest_cx)
                    .attr("cy", dest_cy)
                    .attr('r', 0);

                dest.transition()
                    .duration(animationSpeed)
                    .attr('r', dest.attr("data-r"));
            }
          }
          function hide(index){
            if($('#a'+index).length){
               d3.select("#a"+index).transition()
                     .duration(animationSpeed)
                     .attr('r', 0);

               var dest = d3.select("#a"+index);
               var dest_cx = dest.attr('cx');
               var dest_cy = dest.attr('cy');

               var objs = d3.selectAll("#g"+index+" circle");
               objs.each(function (d, i){

                  var cx = d3.select(this).attr('data-cx');
                  var cy = d3.select(this).attr('data-cy');
                  var r = d3.select(this).attr('data-r');

                  d3.select(this).transition()
                        .duration(animationSpeed)
                        .attr("cx", cx)
                        .attr("cy", cy)
                        .attr('r', r);
               });
              }
            }
            function showAll(){
                animationN = 1;
                var i = setInterval(function (){
                    show(animationN);
                    animationN++;
                    if(animationN > max || stopShowAll){
                  movingin = false;
                  stopShowAll = false;
                  clearInterval(i);
               }
                }, 30);
            }
            function hideAll(){
            animationN--;
                var i = setInterval(function (){
                    hide(animationN);
                    animationN--;
                    if(animationN == 0 || stopHideAll){
                  stopHideAll = false;
                  movingin = false;
                  clearInterval(i);
               }

                }, 30);
            }
         function mousein(){
            if(!movingin) {
               stopShowAll = false;
               movingin = true;
               showAll();
            }
         }
         function mouseout(){
            stopShowAll = true;
            hideAll();
         }


         $('#pca .header').hover(mousein, mouseout);


        initImages();
    }
    else{
        $('#breadcrumbs-two a').click(function (e){
            e.preventDefault();
            if($(this).attr('href')){
                var i = $(this).parent().index() + 1;
                $('.flow-box div.box-n2, .flow-box div.box-n3').addClass('hidden');
                $('.box-n'+i).removeClass('hidden');
            }
        });
    }
   }

    function shuffle(array) {
        var currentIndex = array.length, temporaryValue, randomIndex;
        while (0 !== currentIndex) {

            randomIndex = Math.floor(Math.random() * currentIndex);
            currentIndex -= 1;

            temporaryValue = array[currentIndex];
            array[currentIndex] = array[randomIndex];
            array[randomIndex] = temporaryValue;
        }

        return array;
    }
    function initImages() {
        var n = [1, 2, 3, 4];
        // n = shuffle(n);
        $('.image').each(function (i) {
            $(this).addClass('image' + n[i]);
            var t = $(this);
            setTimeout(function () {
                t.addClass('fadein')
            });
        });
    }
    init();
}
function initPinacoteca(){

    // Inizializzazione slider
    $("#sliderPubblicazioni").carousel();

    /*Ordinazioni*/
    $(".aggiungiPubblicazione").click(function() {
        titolo=$(this).data("titolo");
        prezzo=$(this).data("prezzo");
        immagine=$(this).data("immagine");
        id=$(this).data("id");

        var liste = JSON.parse(window.sessionStorage.getItem("Pinacoteca"));

        if(!liste)
            liste = $.makeArray();

        var lista = {};
        lista.id = id;
        lista.immagine=immagine;
        lista.titolo = titolo;
        lista.prezzo = prezzo;
        lista.quantita=1;

       liste.push(lista);
       window.sessionStorage.setItem("Pinacoteca", JSON.stringify(liste));

       //aggiorno bottone "aggiungi"
       aggiornaBottone(id);

       if ($('#riepilogo').length)
       {
            stampaRiepilogo();
       }
       else
       {
           stampaOrdine();
       }
    });


    //Stampa riepilogo ordine se si è nella pagina "Ordinazioni"
    if ($('#ordine').length)
    {   stampaOrdine();
        aggiornaListaPubblicazioni();
    }


    //aggiorna la lista delle pubblicazioni se si è nella pagina "Pubblicazioni"
    if ($('#pubblicazioni').length || $('#dettaglioPubblicazioni').length || $('.mostra .pubblicazione').length || $('#riepilogoOrdinazione').length)
    {
        aggiornaListaPubblicazioni();
    }

    //stampa gli elementi presenti nello storage
    function stampaOrdine()
    {
        var liste = JSON.parse(window.sessionStorage.getItem("Pinacoteca"));
        var pos=0;


        if (sessionStorage.length > 0)
        {
            //liste.lenght>0 sostituito per errore js
            if(liste) 
            {
                pos = liste.length;
                if(pos > 0){
                    var listOrdini ='';
                    for (var i in liste) {
                        listOrdini += "<li><div class='row'><div class='col-xs-2'><img src='"+liste[i].immagine+"' width='50px'/></div><div class='col-xs-7'><h3>"+liste[i].titolo+"</h3>"+liste[i].prezzo+"</div><div class='col-xs-2'>Quantità<br /><input type='text' value='"+liste[i].quantita+"' class='form-control quantita' data-id='"+liste[i].id+"'/></div><div class='col-xs-1'><i class='fa fa-times-circle elimina' data-id='"+liste[i].id+"' data-riep='0' aria-label='Elimina elemento'/></div></div></li>";
                    }

                    var testo="<h2>Lista delle ordinazioni</h2><form id='formOrdinazione'><ul>"+listOrdini+"</ul><input type='button' value='Ordina' class='btn btn-primary' id='ordina'></form>";

                    $('#ordine').html(testo);
                }
            }
            else
            {
                var testo="È possibile ordinare una o più pubblicazioni selezionandole dall'elenco che trovate sulla destra.";
                $('#ordine').html(testo);
            }
        }

        var spese="<div class=\"spese\"><div class=\"row\"><div class=\"col-xs-2\"><i class=\"fa fa-truck\" aria-hidden=\"true\"></i></div><div class=\"col-xs-10\"><h2>Spese di spedizione</h2><p>Le spese di spedizione verranno comunicate via e-mail all'interessato prima che l'ordinazione venga confermata. Variano infatti molto a seconda del peso. Indicare nel campo &quot;osservazioni&quot; se desiderate la spedizione urgente.</p></div></div><div class=\"row\"><div class=\"col-xs-2\"><i class=\"fa fa-credit-card-alt\" aria-hidden=\"true\"></i></div><div class=\"col-xs-10\"><h2>Metodo di pagamento</h2><p><b>Svizzera</b>: polizza postale<br /><b>Italia</b>: bonifico bancario su banca italiana <br /><br /> Si accettano Euro, cambio indicativo 2014, soggetto a   variazioni:<br />CHF/Euro 1:1</p></div></div></div>";
        $('#ordine').append(spese);
    }


    //aggiornamento quantità nello storage
    $(document).on('change',".quantita",function(){
        id=$(this).data("id");
        quantita=$(this).val();

        var liste = $.parseJSON(window.sessionStorage.getItem("Pinacoteca"));
        aggiornaQuanita(liste,'id',id,quantita);
        window.sessionStorage.setItem("Pinacoteca", JSON.stringify(liste));

        if ($('#riepilogo').length)
        {
            stampaRiepilogo();
        }

    });


    //eliminazione elemento dallo storage
    $(document).on('click',"i.elimina",function(){
        id=$(this).data("id");
        riep=$(this).data("riep");
        var liste = $.parseJSON(window.sessionStorage.getItem("Pinacoteca"));
        findAndRemove(liste, 'id', id);
        window.sessionStorage.setItem("Pinacoteca", JSON.stringify(liste));

        if(riep==1)
        {
            stampaRiepilogo();
            aggiornaBottoneAttivo(id);
        }
        else
        {
            stampaOrdine();
            aggiornaBottoneAttivo(id);
        }
    });

    //elimina il valore dalla lista
    function findAndRemove(array, property, value) {
        array.forEach(function(result, index) {
        if(result[property] === value) {
          array.splice(index, 1);
        }
      });
    }

    //aggiorna la quantità di pubblicazioni prima di salvarli nello storage.
    function aggiornaQuanita(liste,indice,id,quantita){
        liste.forEach(function(result, index) {
              if(result[indice] === id) {
                  result['quantita']=quantita;
              }
        });
    }

    //controlla le pubblicazoni già inserite nello storage e le disattiva nella lista di destra
    function aggiornaListaPubblicazioni(){
        var liste = $.parseJSON(window.sessionStorage.getItem("Pinacoteca"));

        //sessionStorage.length >0 sostituito per errore js
        if(liste) 
        {
            liste.forEach(function(result, index) {
                aggiornaBottone(result['id']);
            });
        }
    }

    // disattivo il bottone quando aggiungo la pubblicazione alla lista degli acquistati
    function aggiornaBottone(id){
        $('button[data-id='+id+']').text('Aggiunto');
        $('button[data-id='+id+']').attr('class', 'btn btn-primary disabled');
    }

    //quando elimino un elemento dalla lista degli acquisti
    function aggiornaBottoneAttivo(id){
        $('button[data-id='+id+']').text('Aggiungi');
        $('button[data-id='+id+']').attr('class', 'btn btn-primary aggiungiPubblicazione');
    }


    // cliccando il tasto ordina dalle pagine "pubblicazioni" e "dettaglio mostra" aggiungo la pubblicazione e vado alla pagina "ordinazioni"
    $(".ordinaPubblicazione").click(function() {
        titolo=$(this).data("titolo");
        prezzo=$(this).data("prezzo");
        immagine=$(this).data("immagine");
        id=$(this).data("id");
        link=$(this).data("link");

        var liste = JSON.parse(window.sessionStorage.getItem("Pinacoteca"));

        if(!liste)
            liste = $.makeArray();

        var lista = {};
        lista.id = id;
        lista.immagine=immagine;
        lista.titolo = titolo;
        lista.prezzo = prezzo;
        lista.quantita=1;

       liste.push(lista);
       window.sessionStorage.setItem("Pinacoteca", JSON.stringify(liste));

       location.href = "https://www4.ti.ch/"+link;
    });


    //click sul bottone ordina -> apro pagina con Powermail
    $(document).on('click',"#ordina",function(){
        window.location.href = "https://www4.ti.ch/index.php?id=100513";
        //window.location.href = "https://www4.ti.ch/decs/dcsu/ac/pinacoteca-zuest/shop/ordinazioni/ordinazione/";
    });

    //Stampa riepilogo nella pagina con la powermail e compila il campo ordinazione
    if ($('#riepilogo').length)
    {
        stampaRiepilogo();
    }

    function stampaRiepilogo()
    {
        var liste = JSON.parse(window.sessionStorage.getItem("Pinacoteca"));
        var pos=0;
        var ordine="";


        if (sessionStorage.length > 0)
        {
            if(liste.length>0)
            {
                pos = liste.length;
                if(pos > 0){
                    var listOrdini ='';
                    for (var i in liste) {
                        //listOrdini += "<li><div class='row'><div class='col-xs-2'><img src='"+liste[i].immagine+"' width='50px'/></div><div class='col-xs-8'><h3>"+liste[i].titolo+"</h3>"+liste[i].prezzo+"</div><div class='col-xs-2'>Quantità<br /><input type='text' value='"+liste[i].quantita+"' class='form-control quantita' data-id='"+liste[i].id+"' disabled/></div></div></li>";
                        listOrdini += "<li><div class='row'><div class='col-xs-2'><img src='"+liste[i].immagine+"' width='50px'/></div><div class='col-xs-7'><h3>"+liste[i].titolo+"</h3>"+liste[i].prezzo+"</div><div class='col-xs-2'>Quantità<br /><input type='text' value='"+liste[i].quantita+"' class='form-control quantita' data-id='"+liste[i].id+"'/></div><div class='col-xs-1'><i class='fa fa-times-circle elimina' data-id='"+liste[i].id+"' data-riep='1' aria-label='Elimina elemento'/></div></div></li>";
                        ordine+=liste[i].quantita+"pz.  "+liste[i].titolo+" \n";
                    }

                    var testo="<h2>Riepilogo dell'ordinazione</h2><form id='formOrdinazione'><ul>"+listOrdini+"</ul>";

                    $('#riepilogo').html(testo);
                    $('#powermail_field_ordinazione_02').val(ordine);

                }
            }
            else
            {
                var testo="Attenzione la lista è vuota.";
                $('#riepilogo').html(testo);
            }
        }
    }



    //Mostre passate -> more
    var size = $("#mostrePassate .timeline li.elemento").size();
    var nrRecord=10; //nr elementi da visualizzare
    var incremento=10;
    $('#mostrePassate .timeline li.elemento:lt('+nrRecord+')').show();


    if(size <= nrRecord)
        $('.showMore').hide();

    $('.showMore').click(function () {
        nrRecord= (nrRecord+incremento <= size) ? nrRecord+incremento : size;
        $('#mostrePassate .timeline li.elemento:lt('+nrRecord+')').show("slow");

        if(nrRecord>=size)
            $('.showMore').hide();
    });



    //Mostre passate -> submit ricerca press enter
    $(".ricercaMostre .form-control").keypress(function (e) {
        if ((e.which && e.which == 13) || (e.keyCode && e.keyCode == 13)) {
            $('.btn-default').click();
            return false;
        } else {
            return true;
        }
    });

}
function initAntibioticiQuiz(){
    var n = 0;
    var data = [
        {
            title: 'Da cosa ci difendono gli antibiotici?',
            answers: {
                'Virus': false,
                'Funghi': false,
                'Batteri': true,
                'Parassiti': false
            },
            phrase: 'Gli antibiotici sono dei medicamenti che ci difendono dai batteri. Non servono a nulla contro virus, funghi e parassiti!'
        },
        {
            title: 'Per quale di queste malattie sono utili gli antibiotici?',
            answers: {
                'Influenza': false,
                'Raffreddore': false,
                'Tosse': false,
                'Polmonite di origine batterica': true
            },
            phrase: 'Gli antibiotici sono dei medicamenti utili per curare le infezioni di origine batterica. Influenza, raffreddore e tosse sono provocate da virus quindi è inutile usarli per queste malattie!'
        },
        {
            title: 'Chi decide se ho bisogno di antibiotici?',
            answers: {
                'Cerco su internet': false,
                'Lo capisco da solo e utilizzo quelli avanzati da una cura precedente': false,
                'Il mio medico': true
            },
            phrase: 'Gli antibiotici possono essere prescritti unicamente dal medico, se necessario. La prescrizione è personale e corrisponde a un bisogno individuale specifico.<br><img src="/fileadmin/DSS/DSP/UMC/quiz/cura-individuale.png" width="100%">'
        },
        {
            title: 'Per quanto tempo devo prendere gli antibiotici prescritti dal medico?',
            answers: {
                'Fino a quando mi sento meglio': false,
                'Fino a quando indicato dal medico': true,
                'Fino a quando non ho più la febbre': false
            },
            phrase: 'È importante seguire in modo preciso le indicazioni sulla durata della cura, sul dosaggio e sulla frequenza di assunzione dell’antibiotico. Prenderlo nel modo corretto ne garantisce l’efficacia.<br><img src="/fileadmin/DSS/DSP/UMC/quiz/indicazioni-cura.png" width="100%">'
        },
        {
            title: 'Cosa faccio se mi avanzano degli antibiotici?',
            answers: {
                'Li conservo per utilizzarli la prossima volta che mi ammalo': false,
                'Li elimino gettandoli nel gabinetto': false,
                'Li riporto in farmacia': true
            },
            phrase: 'Gli antibiotici avanzati non vanno riutilizzati né dispersi nell’ambiente. Questi comportamenti contribuiscono a rendere gli antibiotici meno efficaci.<br><img src="/fileadmin/DSS/DSP/UMC/quiz/smaltimento.png" width="100%"><br><img src="/fileadmin/DSS/DSP/UMC/quiz/ambiente.png" width="100%">'
        },
        {
            title: 'L’assunzione corretta di antibiotici, secondo le indicazioni del medico, favorisce anche la tutela dell’ambiente.',
            answers: {
                'Vero, l’eliminazione dall’organismo di residui antibiotici è ridotta al minimo se si rispetta il dosaggio corretto': true,
                'Falso, gli antibiotici agiscono solo all’interno del corpo umano e non creano residui': false,
                'Falso, i depuratori delle acque eliminano tutti i residui di antibiotici perciò l’ambiente è comunque tutelato': false
            },
            phrase: 'Una parte degli antibiotici assunti finisce nella rete fognaria dopo essere stata eliminata dal nostro organismo con urine e feci. Gli oltre 700 depuratori presenti in Svizzera ne trattengono buona parte ma non la totalità. Infatti, in laghi e fiumi in particolare a ridosso dei depuratori si trovano dei residui di antibiotici. Seguire scrupolosamente le prescrizioni mediche permette di trarre dagli antibiotici il massimo beneficio terapeutico, minimizzandone l’impatto ambientale.<br><img src="/fileadmin/DSS/DSP/UMC/quiz/ambiente.png" width="100%">'
        },
        {
            title: 'Come si creano i batteri resistenti?',
            answers: {
                'Utilizzando in modo sbagliato gli antibiotici': true,
                'Non coprendosi bene durante l’inverno': false,
                'Mangiando poca frutta e verdura': false
            },
            phrase: 'Quando sono minacciati i batteri sviluppano dei meccanismi di difesa. Se gli antibiotici si utilizzano in modo sbagliato (p. es. assumendoli in modo diverso dalle prescrizioni, a dosi inferiori o per un tempo differente da quello raccomandato), i batteri diventano più forti e resistenti. Questo può anche succedere quando i batteri entrano in contatto con gli antibiotici nell’ambiente. Ciò rende gli antibiotici privi di effetto. <b>Evita il “fai da te”!</b>'
        },
        {
            title: 'Parlando di batteri resistenti, quale delle seguenti affermazioni è corretta?',
            answers: {
                'Per permettere agli antibiotici di agire bisogna fare frequenti bagni caldi e bere tisane 3 volte al giorno': false,
                'Gli antibiotici non hanno effetto su questi batteri rendendo la malattia più difficile da curare': true,
                'Le nostre difese immunitarie sono più forti': false
            },
            phrase: 'Interrompere troppo presto una cura di antibiotici o non rispettare la dose prescritta significa assumere una quantità di antibiotico non sufficiente: una parte della popolazione di batteri sarà eliminata ma una piccola parte riuscirà a sopravvivere, sviluppando una resistenza. Di conseguenza, future infezioni batteriche saranno più difficili da curare.'
        },
        {
            title: 'Tra i tipi di suolo indicati, dove è possibile trovare le maggiori concentrazioni di batteri resistenti?',
            answers: {
                'Suolo di prati secchi, dove è ospitata una grande biodiversità': false,
                'Suolo agricolo, dopo lo spargimento di liquami e di letame di origine animale': true,
                'Suolo urbano, dove vengono gestiti orti e giardini da privati cittadini': false
            },
            phrase: 'Nelle urine e nelle feci umane e animali possono essere presenti residui di antibiotici e batteri resistenti. Dopo lo spargimento di liquami animali e di letame, è stato possibile osservare nel suolo un aumento transitorio di batteri resistenti, che tuttavia torna ai livelli iniziali dopo pochi giorni o alcune settimane.<br><img src="/fileadmin/DSS/DSP/UMC/quiz/ambiente.png" width="100%">'
        },
        {
            title: 'Credo di avere l’influenza! Per fortuna mi sono rimasti degli antibiotici che avevo usato tempo fa per curare una polmonite. Li prendo per qualche giorno e continuo ad andare al lavoro. Oggi devo fare assolutamente i biscotti con i miei bambini dell’asilo nido.',
            answers: {
                'Posso curarmi da solo utilizzando degli antibiotici trovati in casa e vado al lavoro': false,
                'Posso curarmi da solo utilizzando degli antibiotici trovati in casa, ma non esco per non contagiare i bambini dell’asilo': false,
                'Non servono gli antibiotici per curare l’influenza perché è causata da un virus. Se sono malato devo restare a casa per evitare di contagiare gli altri': true
            },
            phrase: 'Pensa per tempo a fare la vaccinazione contro l’influenza soprattutto se sei a contatto con bebè, bambini, donne incinte, anziani e persone immunodepresse. In questo modo, in caso di malattia, eviterai di contagiare delle persone particolarmente sensibili appartenenti alle categorie a rischio<br>(<a href="https://www.vaccinarsicontrolinfluenza.ch/it/" target="_blank">www.vaccinarsicontrolinfluenza.ch</a>).'
        }
    ];
    function init(){
        $('#antibiotici_quiz').on('click', '.next', next);
        $('#antibiotici_quiz').on('click', 'input[type=radio]', check);
        $('#antibiotici_quiz').on('click', '.send-mail', sendMail);

        $('#antibiotici_quiz h1').after('<p class="intro_text">Testa la tue conoscenze: 10 domande per imparare qualcosa in più sull’uso degli antibiotici! Se sbagli leggi il commento e ritenta un’altra volta.<br><br></p>');

        generateQuestion();
    }
    function generateQuestion(){
        var html = '';

        html += '<h2>Domanda '+(n+1)+'</h2>';
        html += '<p>'+data[n].title+'</p>';

        html += '<div class="questions">';
        for(x in data[n].answers){
            html += '<div><input type="radio" name="q'+n+'" value="'+x+'" id="q'+n+x+'"><label for="q'+n+x+'">'+x+'</label></div>';
        }
        html += '<button class="btn btn-primary next disabled">Avanti</button>';
        html += '</div>';

        html += '<div class="answer hidden">'+data[n].phrase+'</div><div class="clear"></div>';



        $('#antibiotici_quiz .question').html(html);

        // steps
        $('.steps span.active').removeClass('active');
        $('.steps li:eq('+n+') span').addClass('active');

        if(n == 1) $('#antibiotici_quiz .intro_text').remove();
    }
    function generateFinish(){
        var html = '';

        html += '<h2>Complimenti hai risposto correttamente a tutte le domande!</h2>';
        // html += '<p>Inserisci il tuo indirizzo e-mail e clicca su “Invia” per partecipare all’estrazione del 4 dicembre 2019 e vincere uno dei premi in palio. In caso di vincita, sarai contattato tramite e-mail. <br><br>Partecipando al presente concorso si acconsente all’elaborazione dell’indirizzo di posta elettronica da parte dell’Ufficio del medico cantonale. I dati saranno conservati per il tempo necessario alla comunicazione della vincita. In seguito saranno distrutti.</p>';

        // html += '<br><input type="text" class="form-control" placeholder="Inserisci la tua email" style="width: 300px; display: inline-block; margin-right: 10px"><button class="btn btn-primary send-mail">Invia</button><span class="email-error">Inserisci un email valida</span>';

        $('#antibiotici_quiz .question').html(html);

        // steps
        $('.steps span.active').removeClass('active');
        $('.steps li:eq('+n+') span').addClass('active');
    }
    function next(){
        // generateFinish();
        n++;
        if(n < data.length){
            generateQuestion();
        }
        else{
            generateFinish();
        }
    }
    function check(){
        $('.questions .error, .questions .success').attr('class', '');
        if(data[n].answers[$(this).val()]){
            $('.next').removeClass('disabled');
            $(this).parent().addClass('success');
        }
        else{
            $('.next').addClass('disabled');
            $(this).parent().addClass('error');
        }
        $('.answer').removeClass('hidden');
    }
    function sendMail(){
        var v = $(this).prev().val();
        var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        if(v && re.test(v)){
            $('span.email-error').hide();
            var t = $(this);
            $.post('/fileadmin/DSS/DSP/UMC/quiz/send.php', { email: v }, function (r){
                if(r == 'ok'){
                    t.after('<p>Invio riuscito, grazie di aver partecipato.<br><a href="https://www4.ti.ch/index.php?id=103574">Vai alla campagna antibiotici per scoprire altre informazioni!</a></p>');
                    t.prev().remove();
                    t.remove();
                }
                else t.after('<p>Invio non riuscito, riprovare più tardi.</p>');
            });
        }
        else $('span.email-error').css('display', 'block');
    }
    init();
}
function initRassegnaStampa(){

    var startDate;
    var endDate;

    function init(){
        if($('.daterange').length) setDaterange();
        else if($('.datechooser').length) setDatepicker();
    }
    function setDaterange(){

        var startDate = false;
        var endDate = false;

        if($('#periodoMain').text().indexOf('Periodo') == -1){
            var text = $('#periodoMain').text();
            $("#periodo").val(text);
            var tmp = text.split('-');
            startDate = tmp[0];
            endDate = tmp[1];
        }

        $('.daterange').daterangepicker({
            autoUpdateInput: false,
            startDate: startDate,
            endDate: endDate,
            showDropdowns: true,
            minDate: '01.02.1992',
            maxDate: moment().format('DD.MM.YYYY'),
            locale: {
              format: 'DD.MM.YYYY',
              firstDay: 1,
              cancelLabel: 'Cancella',
              applyLabel: 'Applica',
              customRangeLabel: "Custom",
              daysOfWeek: ["Do","Lu","Ma","Me","Gi","Ve", "Sa"],
              monthNames: ["Gennaio","Febbraio","Marzo","Aprile","Maggio","Giugno","Luglio","Agosto","Settembre","Ottobre","Novembre","Dicembre"]
            }
        },
        function(start, end) {
            var startDate = start;
            var endDate = end;

            var val=startDate.format('DD.MM.YYYY') + '-' + endDate.format('DD.MM.YYYY');
            $("#periodo").val(val);
            $('#ricerca').submit();
           }
        );

        $('.daterange').on('apply.daterangepicker', function(ev, picker) {
            $(this).html('<span class="filter-option pull-left"><b>'+picker.startDate.format('DD.MM.YYYY') + ' - ' + picker.endDate.format('DD.MM.YYYY')+'</b></span><span class="calendar"></span>');
        });

        $('.daterange').on('cancel.daterangepicker', function(ev, picker) {
            $(this).html('<span class="filter-option pull-left">Periodo</span><span class="caret"></span>');
        });
    }
    function setDatepicker(){
        $.fn.datepicker.dates['it'] = {
            days: ["Domenica", "Lunedì", "Martedì", "Mercoledì", "Giovedì", "Venerdì", "Sabato", "Domenica"],
            daysShort: ["Dom", "Lun", "Mar", "Mer", "Gio", "Ven", "Sab", "Dom"],
            daysMin: ["Do", "Lu", "Ma", "Me", "Gi", "Ve", "Sa", "Do"],
            months: ["Gennaio", "Febbraio", "Marzo", "Aprile", "Maggio", "Giugno", "Luglio", "Agosto", "Settembre", "Ottobre", "Novembre", "Dicembre"],
            monthsShort: ["Gen", "Feb", "Mar", "Apr", "Mag", "Giu", "Lug", "Ago", "Set", "Ott", "Nov", "Dic"],
            today: "Oggi",
            clear: "Svuota"
        };

        $('.datechooser').datepicker({
            format: "d MM",
            inline: true,
            todayHighlight: true,
            language: 'it',
            weekStart: 1,
            endDate: moment().format('DD.MM.YYYY'),
        }).on('changeDate', function (e){
            $('.datechooser').html(e.format()+' <span class="caret"></span>');
            val=$(this).attr('data-url');
            window.location.href =val+"?no_cache=1&data="+e.format("d.m.yyyy");
        });


        // Floating titles
        var floating_data = [];
        $('.rassegna-stampa h3').each(function (n){
            floating_data.push({
                top: $(this).offset().top
            });
            $('.rassegna-stampa').append('<div class="floating_title hidden f'+n+'"><div class="inner"><h3>'+$(this).text()+'</h3></div></div>');
        });
        var floating_title_shown;
        $(window).scroll(function (e){
            for(x=floating_data.length-1;x>=0;x--){
                if($(window).scrollTop() > floating_data[x].top){
                    if(floating_title_shown != x){
                        $('.floating_title:not(.hidden)').addClass('hidden');
                        $('.floating_title.f'+x).removeClass('hidden');
                        floating_title_shown = x;
                    }
                    break;
                }
            }
            if($(window).scrollTop() < floating_data[0].top){
                if(floating_title_shown == 0){
                    $('.floating_title.f0').addClass('hidden');
                    floating_title_shown = -1;
                }
            }
        }).trigger('scroll');
    }
    init();

    $(".dropdownTestata li a").click(function() {
        val=$(this).attr('data-valore');
        $("#idTestata").val(val);
        $('#ricerca').submit();

    });

    $(".dropdownDipartimenti li a").click(function() {
        val=$(this).attr('data-valore');
        $("#dipartimento").val(val);
        $('#ricerca').submit();

    });
}

function initRicerca() {


    function init() {
        // $('.search-results').hide();
        $('#' + tiporicerca).removeClass('hidden');
        $('#navMenu a[data-search=' + tiporicerca + ']').addClass('active');

        $('#navMenu .list-group a').click(click);

    }
    function click(e) {

        e.preventDefault();
        $('.search-results').addClass('hidden');
        $('#' + $(this).attr('data-search')).removeClass('hidden');
        $('#navMenu a.active').removeClass('active');
        $(this).addClass('active');

    }
    init();
}


var overlayOpener;
function initPageSearch() {

    var dipids = {
        1009: 'can',
        1110: 'dt',
        1113: 'decs',
        1111: 'dfe',
        1037: 'di',
        1017: 'dss'
    };

    // $('#navMenu1 .list-group a').click(function (e){
    //     e.preventDefault();

    //     if(!$(this).parent().hasClass('active')){
    //         var url = $(this).attr('href');
    //         loadResults(url);
    //     }
    // });

    // $('.risultatiTutti').on('click', '.divSpagina a', pagination);

    function pagination(e) {
        e.preventDefault();

        if (!$(this).hasClass('active')) {

            $(this).siblings('.active').removeClass('active');
            $(this).addClass('active');

            var url = $(this).attr('href');

            loadResults(url);
        }
    }

    function loadResults(url) {
        var searchFrom = '<div class="risultatiTutti">';
        var searchTo = '<form action="" method="POST" name="next"></form>';

        $.get(url, {}, function (r) {
            var p = r.indexOf(searchFrom);
            if (p > -1) {
                tmp = r.substring(p + searchFrom.length);

                var p = tmp.indexOf(searchTo);
                if (p > -1) {
                    tmp2 = tmp.substring(0, p + searchTo.length);

                    // console.log(tmp2);
                    $('.risultatiTutti').html(tmp2);
                }
            }
        });
    }



    function click(e) {
        e.preventDefault();

        if (!$(this).hasClass('opened')) {
            $(this).addClass('opened');

            overlayOpener = $(this);

            if ($('header .right a.organigramma.opened').length) {
                $('header .right a.organigramma.opened').removeClass('opened');
                $('#organigramma').remove();
            }
            if ($('#contact-form').length) $('#contact-form').remove();

            if (!$('.overlay').length) showOverlay($(this));

            var url = '';
            var tmp = $('header .organigramma').attr('data-dipid');
            var dip = (tmp && dipids[tmp]) ? dipids[tmp] : false;
            var dip_link = (dip != false) ? '/' + dip : '';
            var field = (dip) ? '<input type="hidden" name="site" value="' + ((dip.toUpperCase() == '/') ? '' : dip.toUpperCase()) + '">' : '';

            if (url) {
                dip_link = '/' + url;
                if (dip_link == '/') dip_link = '';
                field = '<input type="hidden" name="site" value="' + url.toUpperCase() + '">';
            }

            var dip_title = '';
            if (dip) {
                if (dip == 'dfe') dip_title = "<h2>Dipartimento delle finanze e dell'economia</h2>";
                else if (dip == 'dt') dip_title = "<h2>Dipartimento del territorio</h2>";
                else if (dip == 'di') dip_title = "<h2>Dipartimento delle istituzioni</h2>";
                else if (dip == 'can') dip_title = "<h2>Cancelleria dello Stato</h2>";
                else if (dip == 'dss') dip_title = "<h2>Dipartimento della sanità e della socialità</h2>";
                else if (dip == 'decs') dip_title = "<h2>Dipartimento dell'educazione, della cultura e dello sport</h2>";
            }


            margin = (!dip) ? ' style="margin-bottom: 50px"' : '';

            var html = '<div class="overlay-content ricerca fields" role="dialog"><h1'+margin+'>Cerca nel sito</h1>' + dip_title + '<div class="row"><div class="col-xs-8"><form action="/cerca-nel-sito/" method=post><div class="input-group"><label class="hidden" for="cerca_sito">Inserisci un termine di ricerca</label><input class="form-control" name="q" maxlength="256" size="32" placeholder="p. es. ufficio, collaboratore, formulario, servizio, numero" id="cerca_sito" aria-label="cerca nel sito">' + field + '<span class="input-group-btn"><button class="btn btn-default btn-form" type=submit aria-label="ricerca"><i class="fa fa-search" aria-hidden="true"></i></button></span><input type=hidden name=tipoRicerca value="risultatiGsa"></div></form></div></div></div>';

            // $('body').append(html);
            $('.overlay-close').before(html);
            $('.overlay-content.ricerca').show();

            resizeOverlay();
            suggestions();


            $('input[name=q]').focus();
            window.scrollTo(0, 0);
        document.body.scrollTop = 0;
         }
    }

    function suggestions() {


        $(".overlay-content.ricerca input.form-control").autocomplete({
            source: function (request, response) {
                $.ajax({
                    url: "//ricerca.ti.ch/suggest?client=TI&site=raccolta_completa&max=5&format=rich",
                    dataType: "jsonp",
                    data: {
                        q: request.term
                    },
                    success: function (data) {
                        response($.map(data.results, function (item) {
                            return {
                                label: item.name,
                                value: item.name
                            }
                        }));
                    }
                });
            },
        });
    }

    $('header .right a[data-search]').click(click);

    $('#skiplink2').keydown(function (e){
        if(e.keyCode == 13){
            e.preventDefault();
            $('header .right a[data-search]').trigger('click');
        }
    })

        mouseTrap($('#cerca_sito'), $('.overlay-close a'));

    setTimeout(function () {
        // if (typeof $.ui === "undefined") $.getScript('/typo3conf/ext/theme/Resources/Public/js/jquery-ui.js');
        if (typeof $.ui === "undefined") $.getScript('/typo3conf/ext/theme/Resources/Public/js/jquery-ui.js');
        if ($('head link[href*="query-ui"]').length == 0) $('head').append('<link rel="stylesheet" type="text/css" href="/typo3conf/ext/theme/Resources/Public/css/jquery-ui.css">');
    }, 500);

    if($('.user-ricerca-pi1').length){
        setTimeout(function (){
            $('.risultatiTutti .lista.link li:first a:first').focus();
        }, 500);
    }
}
/* Sai perché */
function initSaiperche() {
    function init() {
        $('.sapevi-che a.refresh').click(click);
    }
    function click(e) {
        e.preventDefault();
        $.getJSON('index.php?eID=losapeviche', function (r) {
            $('.sapevi-che h3').html(r.title);
            $('.sapevi-che p').html(r.text);
            $('.sapevi-che img').attr('src', r.image);
        });
    }
    init();
}
/* Sala Stampa */
function initSelectSalaStampa() {
    jQuery('.selectpicker').selectpicker({
        'selectedText': 'cat'
    });
}
function initSchedarioUTPG(){
    
$(".dropdownStato li a").click(function() {
        val=$(this).attr('data-valore');
        $("#idStato").val(val);
        $('#ricerca').submit();

    });
    
     $('#anno').datepicker({
         format: "yyyy",
         viewMode: "years",
         minViewMode: "years",
     }).on('changeDate', function (e){
         $('#anno').html('<span class="filter-option pull-left">Nel '+e.format()+'</span><span class="caret"></span>');
         $("#idAnno").val(e.format());
         $('#ricerca').submit();
     });
     
     
     $.fn.datepicker.dates['it'] = {
                days: ["Domenica", "Lunedì", "Martedì", "Mercoledì", "Giovedì", "Venerdì", "Sabato", "Domenica"],
                daysShort: ["Dom", "Lun", "Mar", "Mer", "Gio", "Ven", "Sab", "Dom"],
                daysMin: ["Do", "Lu", "Ma", "Me", "Gi", "Ve", "Sa", "Do"],
                months: ["Gennaio", "Febbraio", "Marzo", "Aprile", "Maggio", "Giugno", "Luglio", "Agosto", "Settembre", "Ottobre", "Novembre", "Dicembre"],
                monthsShort: ["Gen", "Feb", "Mar", "Apr", "Mag", "Giu", "Lug", "Ago", "Set", "Ott", "Nov", "Dic"],
                today: "Oggi",
                clear: "Svuota"
            };
     
     $('#data').datepicker({
            format: "dd.mm.yyyy",
            language: 'it',
     }).on('changeDate', function (e){
          $('#data').html('<span class="filter-option pull-left">Il '+e.format()+'</span><span class="caret"></span>');
          $("#idData").val(e.format());
          $('#ricerca').submit();
      });

$("#printSchedario").click(function() {
 window.print();
});

}
function initSPOPMap(){

    function init(){
        d3.select('svg').selectAll('g#Servizi_regionali_dello_stato_civile circle, g#Servizi_regionali_degli_stranieri circle, g#Centri_di_registrazione circle, g#nuovi_bellinzona circle').on('mouseover', mousein).on('mouseout', mouseout).on('click', click);

        var popOverSettings = {
            placement: 'top',
            container: 'body',
            html: true,
            selector: '[rel="popover"]',
            content: function () {
                return di_mappa_data[$(this).attr('data-id')].content
            }
        }

        $('body').popover(popOverSettings);

        $('body').on('click', function (e) {

            if($('.popover.fade').length > 1) $('.popover.fade:eq(0)').remove();

            // if($(e.target).is('[rel="popover"]')) $('.popover.fade').remove();

            // $('[rel="popover"]').each(function () {
            //     //the 'is' for buttons that trigger popups
            //     //the 'has' for icons within a button that triggers a popup
            //     if (!$(this).is(e.target) && $(this).has(e.target).length === 0 && $('.popover').has(e.target).length === 0) {
            //         console.log($(this))
            //         // $(this).popover('hide');
            //         // $(this).popover(popOverSettings);
            //     }
            // });
        });
    }
    function mousein(){
        $(this).trigger('click');
        $(this).css('fill', '#c33');
    }
    function mouseout(){
        $(this).trigger('click');
        $(this).removeAttr('style');
    }
    function click(){
        var id = $(this).attr('data-id');
        location.href = di_mappa_data[id].link;

        // if($(this).parent().is('#Uffici_esecuzione')) location.href = 'https://www4.ti.ch/index.php?id=87273#address'+id;
        // else location.href = 'https://www4.ti.ch/index.php?id=89204#address'+id;
    }
    init();
}
function initSviluppoEconomico(){
    var beneficiari_list = {};
    var lang;
    var schemaLoaded = false;
    var attivitaUrls = {
        999: 'formazione',
        998: 'spazi',
        997: 'sviluppo',
        996: 'finanziamento',
        995: 'coaching',
        994: 'trasferimento'
    };
    var last_detail = false;
    var last_detail_id = false;
    var button_texts = {
        'en': {
            'back': 'Back to the list of results',
            'print': 'PRINT',
            'share': 'SHARE',
            'contact': 'CONTACTS'
        },
        'it': {
            'back': 'Torna alla lista dei risultati',
            'print': 'STAMPA',
            'share': 'CONDIVIDI',
            'contact': 'CONTATTI'
        }
    };
    var myWowzaPlayer;
    function init(){

        // selettore lingua
        lang = $('div[data-lang]').length ? $('div[data-lang]').attr('data-lang') : 'it';
        $('header .languages a:eq('+((lang == 'en') ? 1 : 0)+')').addClass('selected')


        // IE fix
        if(is_explorer){
            $('.sviluppo-economico .content-selector .tabs > a').each(function (){
                $(this).children().find('svg').height($(this).outerHeight()-55).width($(this).outerWidth()-55);
            });
        }

        // Text opener
        $('.overlay-text a.opener').click(textOverlay);
        $('.overlay-text a.closer').click(closeTextOverlay);


        // Hash navigation
        window.addEventListener("hashchange", hashChanged, false);
        hashChanged();

        // $('.open-map').click(initSchema);
        // $('a.close').click(function (){
        //     $('.svg-overlay, .svg-ontop.column, .svg-column').hide();
        // });


        // Carousels
        $('#carousel-example-generic').on('slide.bs.carousel', function () {
            $('#carousel-example-generic .tich-carousel-indicators li.active').removeClass('active');
            setTimeout(function (){
                $('#carousel-example-generic .tich-carousel-indicators li:eq('+$('#carousel-example-generic .carousel-inner .active').index()+')').addClass('active');
            }, 800);
        })

        $('#carousel-example-generic2').on('slide.bs.carousel', function () {
            $('#carousel-example-generic2 .tich-carousel-indicators li.active').removeClass('active');
            setTimeout(function (){
                $('#carousel-example-generic2 .tich-carousel-indicators li:eq('+$('#carousel-example-generic2 .carousel-inner .active').index()+')').addClass('active');
            }, 800);
        });

        $('#carousel-example-generic3').on('slide.bs.carousel', function () {
            $('#carousel-example-generic3 .tich-carousel-indicators li.active').removeClass('active');
            setTimeout(function (){
                $('#carousel-example-generic3 .tich-carousel-indicators li:eq('+$('#carousel-example-generic3 .carousel-inner .active').index()+')').addClass('active');
            }, 800);
        });


        // Phrase slider
        $('.phrase-slider').each(function (){
            initPhraseSlider($(this));
        });


        // Internal link
        $('.sri-internal-link').click(function (e){
            e.preventDefault();
            location.href = $('#maincontent .tabs a:eq(3)').attr('href');
        });

        $('head').append('<script type="text/javascript" src="//player.wowza.com/player/latest/wowzaplayer.min.js"></script>');
        // $('body').prepend('<a href="#" class="video-link">Video</a>')
        $('.video-link').click(function (e){
            e.preventDefault();

            var r = 'playerElement199' + Math.floor((Math.random() * 100) + 1);

            $('body').prepend('<div id="lightbox_video"><div id="'+r+'" style="width:100%; height:0; padding:0 0 56.25% 0"></div><a href="#" id="close_lightbox_video" style="position: absolute; top: 0; right: 0; padding: 0 10px; font-size: 30px; color: #FFF"><i class="fa fa-times"></i></a></div>')

            $('#close_lightbox_video').click(function (e){
                e.preventDefault();
                if(myWowzaPlayer != null) myWowzaPlayer.destroy();
                $('#lightbox_video').remove();
            })


            myWowzaPlayer = WowzaPlayer.create(r,
                {
                "license":"PLAY1-mWhxJ-Gh3GN-vcn6m-JWJhQ-G9PXe",
                "title":"",
                "description":"",
                "posterFrameURL": "fileadmin/DFE/DE/video_schermo_locarno.png",
                "sourceURL":"https://mediap.ti.ch/vod/dfe/mp4:dfe/de/Finale_Portale_impresa_1280_720.mp4/playlist.m3u8",
                "autoPlay":false,
                "volume":"75",
                "mute":false,
                "loop":false,
                "audioOnly":false,
                "uiShowQuickRewind":true,
                "uiQuickRewindSeconds":"30"
                }
            );

        });

        $('.open-modal').click(openInternalModal);
        $('.close-modal').click(closeInternalModal);
    }
    function hashChanged(first){
        var h = location.hash.substring(1);
        if(h){
            if(h.indexOf('/') > -1){
                var tmp = h.split('/');

                $('html, body').animate({scrollTop:0}, 600);

                if(tmp.length == 2){
                    openSchema(function (){
                        $('.benefactor-row a.checked').removeClass('checked');

                        var item = $('.benefactor-row [data-id='+tmp[1]+']');
                        item.addClass('checked');

                        $('.activities-row .checked').removeClass('checked');


                        closeDetail();

                        filter();
                    });

                }
                else if(tmp.length == 3 || tmp.length == 4){
                    openSchema(function (r){
                        $('.benefactor-row a.checked').removeClass('checked');

                        var item = $('.benefactor-row [data-id='+tmp[1]+']');
                        item.addClass('checked');

                        if(parseInt(tmp[2]) > 0){
                            detail(tmp[2]);
                        }
                        else{
                            if(tmp[2].indexOf('+') > -1){
                                var tmp2 = tmp[2].split('+');
                            }
                            else tmp2 = new Array(tmp[2]);

                            $('.activities-row .checked').removeClass('checked');
                            for(x in tmp2){
                                $('.activities-row [data-url='+tmp2[x]+']').addClass('checked');
                            }

                            if(tmp.length == 4) detail(tmp[3]);
                            else closeDetail()
                        }

                        filter();
                    });
                }
            }
            else{
                var t = $('.content-selector .tabs a[data-id='+h+']');
                if(t.length && !t.hasClass('selected')){
                    $('.sviluppo-economico .content-selector .tabs a.selected').removeClass('selected')
                    t.addClass('selected');

                    var i = t.index() + 1;
                    $('.arrow > div').attr('class', 'single e'+i);

                    $('.tcontent.show').removeClass('show');
                    $('.tcontent.t'+i).addClass('show');

                    $('.tcontent.t'+i+' > div > p').focus();
                }

                var t = $('table.aziende_table a[data-id='+h+']');
                if(t.length) t.trigger('click');

                ga('send','event', 'sviluppo-economio','click-'+h,'href',0,{'nonInteraction': false});
            }
        }
        else{
            $('.svg-overlay, .svg-ontop.column, .svg-column').hide();
        }
    }
    function openSchema(callback){
        if(!schemaLoaded){

            var t = $(this);

            $.getJSON('typo3conf/ext/user_sviluppoeconomico/requests.php', {'load' : 1, lang: lang}, function (r){

                // Attività
                var n = 1;
                for(x in r.attivita){
                    html = '<a href="#" class="check c'+r.attivita[x].ATT_ICONA+'" data-n="'+r.attivita[x].ATT_ICONA+'" data-id="'+r.attivita[x].ATT_ID+'" data-url="'+attivitaUrls[r.attivita[x].ATT_ID]+'"><i class="fa fa-square"></i> '+r.attivita[x].ATT_NOME+'</a>';
                    $('.activities-row .col-xs-6:eq('+((n <= 3) ? 0 : 1)+')').append(html);
                    n++;
                }
                $('.filters .check').click(filterAttivita);


                // Beneficiari
                var n = 1;
                for(x in r.beneficiari){
                    html = '<a href="#" class="" data-id="'+r.beneficiari[x].BEN_ICONA+'" data-db-id="'+r.beneficiari[x].BEN_ID+'"><span class="svg-icon '+r.beneficiari[x].BEN_ICONA+'"></span> '+r.beneficiari[x].BEN_NOME+'</a>';
                    $('.benefactor-row .col-xs-6:eq('+((n <= 2) ? 0 : 1)+')').append(html);
                    n++;
                }
                $('.benefactor-row a').click(filterBeneficiari);


                // beneficiari_list[]

                // Aziende
                // var n = 1;
                for(x in r.aziende){
                    var attivita = '';
                    for(y in r.aziende[x]['attivita']) attivita += '<img src="fileadmin/DFE/DE/images/'+r.aziende[x].attivita[y].ATT_ICONA+'.png" alt="" data-n="'+r.aziende[x].attivita[y].ATT_ICONA+'"  title="'+r.aziende[x].attivita[y].ATT_NOME+'" />';

                    var beneficiari = '';
                    for(y in r.aziende[x]['beneficiari']) beneficiari += '<span class="svg-icon '+r.aziende[x].beneficiari[y].BEN_ICONA+'" title="'+r.aziende[x].beneficiari[y].BEN_NOME+'"></span>';

                    html = '<tr><td><a href="#" data-id="'+r.aziende[x].AZI_ID+'">'+r.aziende[x].AZI_NOME+'</a></td><td>'+attivita+'</td><td>'+beneficiari+'</td></tr>';
                    $('.aziende_table tbody').append(html);
                    // n++;


                    var o = $('[data-id-azienda='+r.aziende[x].AZI_ID+']');
                    if(o.length){
                        var beneficiari = new Array();
                        for(y in r.aziende[x]['beneficiari']) beneficiari.push(r.aziende[x].beneficiari[y].ID);
                        o.attr('data-id-attivita', beneficiari.join(',')).attr('title', r.aziende[x].AZI_NOME);
                    }

                }
                $('.aziende_table a').click(showDetail);
                $('.svg-column').on('click', '.back', closeDetailEvent);


                // Pallini attività
                d3.select('svg#fiore').selectAll('g.attivita, circle.attivita, path.attivita').on('click', attivitaEvent);


                d3.select('svg#fiore').selectAll('*[data-id-azienda]').on('click', selectAzienda).on('mouseover', showAziendaTooltip).on('mouseout', hideAziendaTooltip);

                if(is_explorer){
                    var w = $('.sviluppo-economico .svg-ontop .filters').outerWidth();
                    $('svg#fiore').width(w).height(w);
                    $(window).resize(function (){
                        var w = $('.sviluppo-economico .svg-ontop .filters').outerWidth();
                        $('svg#fiore').width(w).height(w);
                    })
                }
                if (typeof callback === "function") callback(false);
            });


            schemaLoaded = true;
        }
        else{
        //     if(!$('.benefactor-row a[data-id='+$(this).attr('data-beneficiario')+']').hasClass('checked')) $('.benefactor-row a[data-id='+$(this).attr('data-beneficiario')+']').trigger('click');

            if (typeof callback === "function") callback(true);
        }

        // var h = window.innerHeight|| document.documentElement.clientHeight || document.body.clientHeight;

        if($('.background').outerHeight() > 50) var h = $('.background').outerHeight() + $('footer').outerHeight() - 106;
        else var h = $('#maincontent').outerHeight() + $('footer').outerHeight() + 29;

        $('.svg-overlay').height(h);
        $('.svg-column').height(h);

        $('.svg-overlay, .svg-ontop, .svg-column').show();
    }
    function textOverlay(e){
        e.preventDefault();

        var p = $(this).parent().parent();
        if(p.hasClass('opened')){
            p.removeClass('opened');
        }
        else p.addClass('opened');
    }
    function closeTextOverlay(e){
        e.preventDefault();

        var p = $(this).parents('.overlay-text');
        if(p.hasClass('opened')){
            p.removeClass('opened');
        }
        else p.addClass('opened');
    }
    function showAziendaTooltip(){
        if(!$('#sri_tooltip').length){
            $('body').append('<div id="sri_tooltip" style="display: none"></div>');
        }
        $('#sri_tooltip').text($(this).attr('title')).css({ top: $(this).position().top, left: $(this).position().left + $(this)[0].getBoundingClientRect().width }).show();
    }
    function hideAziendaTooltip(){
        $('#sri_tooltip').hide();
    }
    function attivitaEvent(){
        var n = $(this).attr('data-id');
        $('.activities-row a[data-n='+n+']').trigger('click');
    }
    function closeDetailEvent(e){
        e.preventDefault();

        var url = location.href;

        var h = location.hash;
        if(h.indexOf('/') > -1){
            tmp = h.split('/');
            if(parseInt(tmp[(tmp.length - 1)]) > 0){
                tmp.pop();
                location.hash = tmp.join('/')
            }
        }
    }
    function filterAttivita(e){
        e.preventDefault();

        var activites = new Array();

        if($('.activities-row .checked').length){
            $('.activities-row .checked').each(function (){
                activites.push($(this).attr('data-url'));
            });
        }

        if(!$(this).hasClass('checked')){
            activites.push($(this).attr('data-url'));
        }
        else{
            var a = new Array();
            for(x in activites){
                if(activites[x] != $(this).attr('data-url')) a.push(activites[x]);
            }
            activites = a;
        }

        var url = location.href;
        if(url.indexOf('#') > -1){
            url = url.split('#')[0]
        }
        url += '#schema/'+$('.benefactor-row .checked').attr('data-id');

        if(activites.length){
            url += '/'+activites.join('+');
        }

        location.href = url;
    }
    function filterBeneficiari(e){
        e.preventDefault();

        var activites = new Array();
        if($('.activities-row .checked').length){
            $('.activities-row .checked').each(function (){
                activites.push($(this).attr('data-url'));
            });
        }

        var url = location.href;
        if(url.indexOf('#') > -1){
            url = url.split('#')[0]
        }
        url += '#schema/'+$(this).attr('data-id');

        if(activites.length){
            url += '/'+activites.join('+');
        }

        location.href = url;
    }
    function filter(){
        var data = {
            lang: 'en'
        }

        // Attività SVG
        var ids = new Array();
        var ns = new Array();

        $('.activities-row .checked').each(function (){
            ids.push($(this).attr('data-id'));
        });
        if(ids.length) data.search_attivita = ids;
        else{
            $('.activities-row .check').each(function (){
                ids.push($(this).attr('data-id'));
            });
            data.search_attivita = ids;
        }

        $('.activities-row .check.checked').each(function (){
            var n = $(this).attr('data-n');
            $('svg .c'+n).removeAttr('style');
        });


        // Beneficiari
        if($('.benefactor-row .checked').length){
            data.search_beneficiari = $('.benefactor-row .checked').attr('data-db-id');
        }

        if(data.search_attivita.length || data.search_beneficiari){
            if(data.search_attivita.length < 6 || data.search_beneficiari){

                $.getJSON('typo3conf/ext/user_sviluppoeconomico/requests.php', data, function (r){

                    $('table.aziende_table tbody tr[data-show]').removeAttr('data-show');
                    $('[data-id-azienda]').removeAttr('data-show');
                    for(x in r){
                        $('table.aziende_table a[data-id='+r[x]+']').parent().parent().attr('data-show', true);
                        $('[data-id-azienda='+r[x]+']').attr('data-show', true);
                    }


                    var n = 0;
                    $('table.aziende_table tr[data-show]').each(function (){
                        if(n % 2 == 0) $(this).attr('class', 'odd');
                        else $(this).attr('class', 'even');
                        n++;
                    });

                    // table
                    $('table.aziende_table tbody tr:not([data-show])').hide();
                    $('table.aziende_table tbody tr[data-show]').show();

                    // svg
                    // $('[data-id-azienda]:not([data-show])').attr('filter', 'url(#grayscale)').css('opacity', '0.5');
                    // $('[data-id-azienda][data-show]').attr('filter', '').css('opacity', '1');


                    // svg
                    $('line[data-id-azienda][data-show], polygon[data-id-azienda][data-show]').css({'fill': '#dbdbdb', 'stroke': '#dbdbdb'});

                    $('[data-id-azienda]:not([data-show])').attr('filter', 'url(#grayscale)').css('opacity', '0.5');
                    $('[data-id-azienda][data-show]').removeAttr('filter').css('opacity', '1');

                    setTimeout(function (){
                        // $('line[filter], polygon[filter]').css('opacity', '0.5');
                        // $('line[data-show], polygon[data-show]').css('opacity', '1');
                        $('line[filter], polygon[filter]').css({'fill': '#dbdbdb', 'stroke': '#dbdbdb'});
                        $('line[data-show], polygon[data-show]').removeAttr('style');

                        if($('.activities-row .check:not(.checked)').length < 6){
                            $('.activities-row .check:not(.checked)').each(function (){
                                $('line.c'+$(this).attr('data-n')+', polygon.c'+$(this).attr('data-n')).css({'fill': '#dbdbdb', 'stroke': '#dbdbdb'});
                            });
                        }
                    }, 10)


                    if(data.search_attivita.length == 6){
                        $('.activities-row .check').each(function (){
                            $('svg .c'+$(this).attr('data-n')).removeAttr('style');
                        });
                    }
                    else{
                        // svg lines and circles
                        $('.activities-row .check:not(.checked)').each(function (){
                            $('svg text.c'+$(this).attr('data-n')).css({'fill': '#dbdbdb'})
                            $('svg line.c'+$(this).attr('data-n')+', svg rect.c'+$(this).attr('data-n')+', svg circle.c'+$(this).attr('data-n')+', svg polygon.c'+$(this).attr('data-n')).css({'fill': '#dbdbdb', 'stroke': '#dbdbdb'});
                        });
                        $('.activities-row .checked').each(function (){
                            $('svg .c'+$(this).attr('data-n')).removeAttr('style');
                        });
                    }

                    if(r === null){
                        $('table.aziende_table tbody').append('<tr id="no-result"><td colspan="3">Nessun servizio disponibile.</td></tr>')
                    }
                    else if($('.no-result').length) $('.no-result').remove();
                });
            }
            else{
                $('table.aziende_table tr').show();

                $('.activities-row .check').each(function (){
                    $('svg .c'+$(this).attr('data-n')).removeAttr('style');
                });
                $('[data-id-azienda]').removeAttr('filter').css('opacity', '1');

                $('table.aziende_table tbody tr').removeClass('odd').removeClass('even');
            }

        }
        else $('[data-id-azienda]').removeAttr('filter').css('opacity', '1');

        if(last_detail_id){
            $('table.aziende_table a[data-id='+last_detail_id+']').trigger('click');
        }
    }
    function showDetail(e){
        e.preventDefault();

        var activites = new Array();
        if($('.activities-row .checked').length){
            $('.activities-row .checked').each(function (){
                activites.push($(this).attr('data-url'));
            });
        }

        var url = location.href;
        if(url.indexOf('#') > -1){
            url = url.split('#')[0]
        }
        url += '#schema/'+$('.benefactor-row .checked').attr('data-id');

        if(activites.length){
            url += '/'+activites.join('+');
        }

        url += '/'+$(this).attr('data-id');

        location.href = url;
    }
    function detail(id){
        var nnnn = id;
        var p = $('table a[data-id='+id+']').parents('tr');
        last_detail_id = id;

        $.getJSON('typo3conf/ext/user_sviluppoeconomico/requests.php', { detail: id, lang: lang }, function (r){
            var address = '<p>';
            if(r.AZI_PRESSO) address += r.AZI_PRESSO+'<br>';
            if(r.AZI_VIA) address += r.AZI_VIA+'<br>';
            if(r.AZI_NAP) address += r.AZI_NAP+' ';
            if(r.AZI_LUOGO) address += r.AZI_LUOGO+'<br>';
            if(address != '<p>') address += '<br>';
            if(r.AZI_TEL) address += 'Tel: '+r.AZI_TEL+'<br>';
            if(r.AZI_FAX) address += 'Fax: '+r.AZI_FAX+'<br>';
            if(r.AZI_MAIL) address += '<a href="mailto:'+r.AZI_MAIL+'">'+r.AZI_MAIL+'</a><br>';
            if(r.AZI_URL){
                if(r.AZI_URL.indexOf('http') == -1) url = 'http://'+r.AZI_URL;
                else url = r.AZI_URL;
                address += '<a href="'+url+'" target="_blank">'+r.AZI_URL+'</a><br>';
            }
            address += '</p>';


            var url = location.href;
            if(url.indexOf('#') > -1){
                url = url.split('#')[0];
            }

            var html = '<div class="detail"><a href="#" class="back btn btn-default">'+button_texts[lang].back+'</a><div class="box">';
            html += '<div class="header">';
            html += p.children('td:eq(1)').html();
            html += p.children('td:eq(2)').html();
            html += '<a href="#" class="print_scheda"><i class="fa fa-print"></i> '+button_texts[lang].print+'</a>';
            html += '<a href="#" class="share_scheda"><i class="fa fa-envelope-o"></i> '+button_texts[lang].share+'</a>';
            html += '<div class="clear"></div>';
            html += '</div>';
            html += '<div class="body">';
            html += '<h3>'+r.AZI_NOME+'</h3>';
            // html += r.AZI_DESCRIZIONE;

            if(r.descriptions.length > 0){

                var attivita = new Array();

                if($('.activities-row .checked').length == 0){
                    $('.activities-row .check').each(function (){
                        attivita.push($(this).attr('data-id'));
                    });
                }
                else{
                    $('.activities-row .checked').each(function (){
                        attivita.push($(this).attr('data-id'));
                    });
                }

                var beneficiari = new Array()
                if($('.benefactor-row .checked').length){
                    beneficiari.push($('.benefactor-row .checked').attr('data-db-id'));
                }
                else{
                    $('.benefactor-row a').each(function (){
                        beneficiari.push($(this).attr('data-db-id'));
                    });
                }

                // console.log(attivita);
                // console.log(beneficiari);

                // html += '<hr>';
                var found = false;
                for(x in r.descriptions){

                    if(attivita.indexOf(r.descriptions[x]['DES_ATT_ID']) > -1 && beneficiari.indexOf(r.descriptions[x]['DES_BEN_ID']) > -1){
                        var n = $('.activities-row a[data-id='+r.descriptions[x]['DES_ATT_ID']+']').attr('data-n');
                        html += '<div class="c'+n+'">' + $('.activities-row a[data-n='+n+']').text()+'</div>' + r.descriptions[x]['DESCRIPTION']+'<br><br>';
                        found = true;
                    }
                }

                if(!found) html += '<i class="fa fa-exclamation-circle" style="font-size:40px"></i> <br/>Questo servizio non si rivolge al beneficiario selezionato, oppure non opera nella/nelle attività selezionata/e.<br><br>';
            }

            html += '<div class="contact">';
            html += '<h4>'+button_texts[lang].contact+'</h4>';
            html += '<h5>'+r.AZI_NOME+'</h5>'+address;
            html += '<div class="clear"></div>';
            html += '<div class="icon"><i class="fa fa-phone"></i></div>';
            html += '</div>';
            html += '</dib>';
            html += '</div><a href="#" class="prev"><i class="fa fa-angle-left"></i></a><a href="#" class="next"><i class="fa fa-angle-right"></i></a>';

            html += '<div class="share-box">';
            // html += '<a href="#" class="close-share"><i class="fa fa-times"></i></a>'
            html += '<input type="text" name="name" class="form-control" placeholder="Nome" />'
            html += '<input type="text" name="recipient" class="form-control" placeholder="Email destinatario" />'
            html += '<textarea name="message" class="form-control" id="" cols="30" rows="4" placeholder="Messaggio"></textarea>';

            html += '<button class="btn btn-default send">Invia</button>&nbsp;';
            html += '<button class="btn btn-default backk">Annulla</button>';
            // html += '<button class="btn btn-default backk hidden close">Chiudi</button>';

            html += '</div></div>';

            if($('.svg-column .detail').length) $('.svg-column .detail').replaceWith(html);
            else $('.aziende_table').hide().after(html);

            $('.detail .body > p a').each(function (){
                if(!$(this).is('[target]')) $(this).attr('target', '_blank');
            });

            last_detail = nnnn;

            $('.print_scheda').click(function (e){
                e.preventDefault();

                var icons = '';
                $('.svg-column .detail .box .header > img') .each(function (){
                    icons += '<img src="https://www4.ti.ch/'+$(this).attr('src')+'">';
                });
                $('.svg-column .detail .box .header > span') .each(function (){
                    // url("/fileadmin/DFE/DE/images/esistenti.png")
                    icons += '<img src="/fileadmin/DFE/DE/images/'+$(this).attr('class').replace('svg-icon ', '')+'.png">';
                });

                var w = window.open('', 'sri_print', 'menubar=no');
                var css = ''
                var html = '<!DOCTYPE html><html lang="en"><head><link rel="stylesheet" type="text/css" href="'+$('base').attr('href')+'typo3conf/ext/theme/Resources/Public/css/styles.css" media="screen" /><link rel="stylesheet" type="text/css" href="'+$('base').attr('href')+'typo3conf/ext/theme/Resources/Public/css/stampa.css" media="print" /><meta charset="UTF-8"><title>Stampa</title></head><body><div class="sri_print">'+icons+'<br>'+$('.svg-column .detail .box .body').html()+'</div></body></html>';
                w.document.write(html);
                setTimeout(function (){
                    w.document.close();
                    w.focus();
                    w.print();
                    w.close();
                }, 300);
            });

            $('.share_scheda').click(function (e){
                e.preventDefault();

                $('.share-box input, .share-box textarea, .share-box button').show();
                $('.share-box h3, .share-box button.close').remove();

                $('.svg-column .detail .box').addClass('over');
                $('.svg-column .detail .share-box').show();
            });

            $('.close-share, button.backk, .btn-default.closer').click(function (e){
                e.preventDefault();
                $('.svg-column .detail .box').removeClass('over');
                $('.svg-column .detail .share-box').hide();
            });

            $('.share-box button.send').click(function (e){
                e.preventDefault();

                var error = false;

                if($('.share-box input[name=name]').val() == ''){
                    $('.share-box input[name=name]').addClass('alert-danger');
                    error = true;
                }
                else $('.share-box input[name=name]').removeClass('alert-danger');

                if($('.share-box input[name=recipient]').val() == ''){
                    $('.share-box input[name=recipient]').addClass('alert-danger');
                    error = true;
                }
                else{
                    var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
                    if(!re.test($('.share-box input[name=recipient]').val())){
                        $('.share-box input[name=recipient]').addClass('alert-danger');
                        error = true;
                    }
                    else $('.share-box input[name=recipient]').removeClass('alert-danger');
                }

                if($('.share-box textarea[name=message]').val() == ''){
                    $('.share-box textarea[name=message]').addClass('alert-danger');
                    error = true;
                }
                else $('.share-box textarea[name=message]').removeClass('alert-danger');

                if(!error){

                    // var url = location.href;
                    // if(url.indexOf('#') > -1){
                    //     url = url.split('#')[0];
                    // }
                    // url += '#'

                    // if($('.benefactor-row a.checked').length){
                    //     url += $('.benefactor-row a.checked').attr('data-id')+'/';
                    // }

                    // if($('.activities-row a.checked').length){
                    //     if($('.activities-row a.checked').length > 1){
                    //         var tmp = [];
                    //         $('.activities-row a.checked').each(function (){
                    //             tmp.push($(this).attr('data-url'));
                    //         });
                    //         url += tmp.join('+');
                    //     }
                    //     else{
                    //         url += $('.activities-row a.checked').attr('data-url');
                    //     }
                    //     url += '/';
                    // }

                    // url += last_detail_id;


                    var data = {
                        share: true,
                        name: $('.share-box input[name=name]').val(),
                        recipient: $('.share-box input[name=recipient]').val(),
                        message: $('.share-box textarea[name=message]').val(),
                        url: location.href,
                        azienda: $('.contact h5').text()
                    };

                    $.post('typo3conf/ext/user_sviluppoeconomico/requests.php', data, function (r){
                        $('.share-box input, .share-box textarea, .share-box button').hide();
                        $('.share-box input[name=name]').after('<h3>Messaggio inviato!</h3><button class="btn btn-default closer">Chiudi</button>');
                        $('.share-box .closer').click(function (e){
                            e.preventDefault();
                            $('.svg-column .detail .box').removeClass('over');
                            $('.svg-column .detail .share-box').hide();
                        });
                    });
                }
            });

            $('.svg-column .detail a.prev').click(function (e){
                e.preventDefault();

                var index = $('a[data-id='+last_detail+']').parents('tr').index();

                for(i=1;i<100;i++){
                    if((index - i) > -1){
                        if($('table tbody tr:eq('+(index - i)+')').length && $('table tbody tr:eq('+(index - i)+')').is('[data-show]')){
                            $('table tbody tr:eq('+(index - i)+') a[data-id]').trigger('click');
                            return false;
                        }
                    }
                    else break;
                }
                $('table tbody tr[data-show]:last a[data-id]').trigger('click');
            });

            $('.svg-column .detail a.next').click(function (e){
                e.preventDefault();

                var index = $('a[data-id='+last_detail+']').parents('tr').index();

                for(i=1;i<100;i++){
                    if((index + i) < $('table tbody tr').length){
                        if($('table tbody tr:eq('+(index + i)+')').length && $('table tbody tr:eq('+(index + i)+')').is('[data-show]')){
                            $('table tbody tr:eq('+(index + i)+') a[data-id]').trigger('click');
                            console.log($('table tbody tr:eq('+(index + i)+') a[data-id]'))
                            return false;
                        }
                    }
                    else break;
                }
                console.log('basd')
                $('table tbody tr[data-show]:first a[data-id]').trigger('click');
            });
        });
    }
    function closeDetail(){
        // var n = $(this).attr('data-id');
        $('.aziende_table').show()
        $('.svg-column .detail').remove();
        last_detail_id = false;
    }
    function selectAzienda(){

        var h = location.hash;
        if(h.indexOf('/') > -1){
            tmp = h.split('/');
            if(parseInt(tmp[(tmp.length - 1)]) > 0){
                tmp.pop();
            }
            location.hash = tmp.join('/')+'/'+$(this).attr('data-id-azienda')
        }

        // $(this).attr('data-id-azienda')

        // if($(this).attr('filter') == '') $('table.aziende_table [data-id='+$(this).attr('data-id-azienda')+']').trigger('click');
    }
    function openInternalModal(e){
        e.preventDefault();

        var id = $(this).attr('data-id');

        $('.sri-modal .content').html($('.sri-modal-content[data-modal-id='+id+']').html()).attr('class', 'content '+id);
        $('.sri-modal').removeClass('hidden');
    }
    function closeInternalModal(e){
        e.preventDefault();
        $('.sri-modal').addClass('hidden');
    }
    init();

    $('.move').click(function (e){
            e.preventDefault();

            var id = $(this).attr('href');
            ;
            // console.log(id)
            var p = $('#'+id.split('#')[1]).offset();
            // console.log(p)
            $('html, body').animate({ scrollTop: p.top }, 400);
        })
}
function initTichSlider(){

    var data = {
        navigation: false,
        mouseDrag: false,
        touchDrag: false,
        responsiveClass: true
    };

    $(".owl-demo").each(function (){
        var d = data;
        if($(this).parents('.fixed').length){
            d.responsive = {
                0:{
                    items:1,
                },
                600:{
                    items:3,
                    loop:true
                }
            }
        }
        else {
            d.responsive = {
                0:{
                    items:1,
                },
                600:{
                    items:3,
                    loop:true
                },
                970:{
                    items:4,
                    loop:true
                },
                1400:{
                    items:5,
                    loop:true
                }
            }
        }
        $(this).owlCarousel(d);
    });


  $(".images-slider .next").click(function(e){
   e.preventDefault();
   var elemento="#"+$(this).attr('data-id');
   if(elemento == '#undefined') elemento = '#'+$(this).siblings('.owl-carousel').attr('id');
   $(elemento).trigger('next.owl.carousel');
 });

 $(".images-slider .prev").click(function(e){
   e.preventDefault();
   var elemento="#"+$(this).attr('data-id');
   if(elemento == '#undefined') elemento = '#'+$(this).siblings('.owl-carousel').attr('id');
   $(elemento).trigger('prev.owl.carousel');
 });

  $(".owl-carousel .item").click(function(e){
     $("#myModal .modal-body img").attr('src',e.target.currentSrc);
     $("#myModal .modal-title").html($("#"+e.currentTarget.id).find("h3").text());
  });


  if($('.images-slider.text img:first').length){
    setTimeout(function (){
        $('.images-slider.text .next, .images-slider.text .prev').css({ top: $('.images-slider.text img:first').height() / 2 + 48});
    }, 500)

  }

}

function initTichPubblicazioni(){
      
    $("#riassuntoOrdinazione").hide();
    $("#DatiPersonali").hide();
    
    
    $("#procediOrdinazione").click(function() {
        var totale=0;
        var riassunto="";
        var tmp="";

       $("#ordinazione input").each(function(){
            var input = $(this);
            var optionSelected = $("option:selected", this);
            var quantita = this.value;
            var prezzo=input.data('prezzo');
            var prezzolibri="";
            var titolo=input.data('titolo');
            var sottotitolo=input.data('sottotitolo');

            if(quantita > 0)
            {
                totale=totale+(quantita*prezzo);
                prezzolibri=quantita*prezzo;

                riassunto=riassunto+'<div class="row"><div class="col-xs-8">'+titolo+' - '+sottotitolo+'</div><div class="col-xs-2">'+quantita+'x</div><div class="col-xs-2">fr. '+prezzolibri+'.00</div></div>';
                tmp=tmp+quantita+'x    '+titolo+' - '+sottotitolo+'\n';
            }
        });

       riassunto= riassunto+'<div class="row"><div class="col-xs-8"></div><div class="col-xs-4 totale"><span class="spanStringa"><b>Totale</b></span><span id="totale" class="spanTotale">fr. '+totale+'.00</span></div></div>';

        tmp=tmp+'\nTOTALE: fr. '+totale+'.00';

        riassunto='<h1 class="csc-firstHeader">Riepilogo e ordinazione</h1><div class="box-info1"><b>Riepilogo ordine</b><br /><br />'+riassunto+'<div class="row"><p>Ordinando una delle pubblicazioni, nel caso in cui fosse a pagamento, l\'utente si impegna a pagare il prezzo indicato, oltre alle spese di spedizione, <b>entro 30 giorni</b> dalla ricezione della fattura. </p></div></div>';

        $("#riassuntoOrdinazione").html(riassunto);
        $("#riassuntoOrdinazione").show();
        $("#DatiPersonali").show();
        $("#moduloOrdinaizonePubblicazioni").hide();
        $("#testoIntro").hide();
        $('html, body').animate({scrollTop: '0px'}, 300);

        $("#powermail_field_ordinazionepubblicazioni").val(tmp);
        
        
    });
}
/* Ticino 2020 */
function initTicino2020(){
   function init(){
    if($('#ticino2020.page').length){
      startPosition();

      h = windowHeight();

      setTimeout(function (){
         items.push({
            from: 0,
            to: $('#ticino2020 #p1').outerHeight()
         });

         items.push({
            from: $('#ticino2020 #p2').offset().top - h,
            to: $('#ticino2020 #p2').offset().top + $('#ticino2020 #p2').outerHeight() - h
         });

         items.push({
            from: $('#ticino2020 #p3').offset().top - h,
            to: $('#ticino2020 #p3').offset().top + $('#ticino2020 #p3').outerHeight() - h
         });

         unifyScroll = $('#p3 .box2 .flow-box').offset().top - 150;
         unifyScroll2 = $('#p2 .content').offset().top - 150;
         closeScroll = $('#p3 .box2').offset().top - 100;
         closeScroll2 = unifyScroll2 + $('#p2 .content').height() - 250;

         $(window).scroll(scroll2).trigger('scroll');
      }, 200);

      $(window).scroll(scroll);

      initImages();
    }
    else{
        $('#breadcrumbs-two a').click(function (e){
            e.preventDefault();
            if($(this).attr('href')){
                var i = $(this).parent().index() + 1;
                $('.flow-box div.box-n2, .flow-box div.box-n3').addClass('hidden');
                $('.box-n'+i).removeClass('hidden');
            }
        });
    }
   }

    function shuffle(array) {
        var currentIndex = array.length, temporaryValue, randomIndex;
        while (0 !== currentIndex) {

            randomIndex = Math.floor(Math.random() * currentIndex);
            currentIndex -= 1;

            temporaryValue = array[currentIndex];
            array[currentIndex] = array[randomIndex];
            array[randomIndex] = temporaryValue;
        }

        return array;
    }
    function initImages() {
        var n = [1, 2, 3];
        n = shuffle(n);
        $('.image').each(function (i) {
            // initImages
            $(this).addClass('image' + n[i]);
            var t = $(this);
            setTimeout(function () {
                t.addClass('fadein')
            });
        });
    }
    function startPosition() {
        var p = $('#ticino2020 .header img').offset();
        leftGap = 182;
        $('.icona-comune').css({ 'left': p.left + leftGap, top: '' }).removeClass('fixed');
        $('.icona-cantone').css({ 'right': $('html, body').outerWidth() - p.left - leftGap - leftGap - 5, top: '' }).removeClass('fixed');
    }
    function endPosition(top) {
        var p = $('#p3 .box3 img').offset();
        top = $('#p3 .box3').offset().top - 94;
        $('.icona-comune').css({ 'left': p.left, top: top }).removeClass('fixed');
        $('.icona-cantone').css({ 'right': p.left, top: top }).removeClass('fixed');
    }
    function unifyIn(top) {
        var p = $('#p3 .box3 img').offset();
        $('.icona-comune').css({ 'left': p.left - 200, top: top })
        $('.icona-cantone').css({ 'right': p.left - 200, top: top })
    }
    function unifyOut(top) {
        $('.icona-comune').css({ 'left': 0, top: top })
        $('.icona-cantone').css({ 'right': 0, top: top })
    }
    function unifyIn2(top) {
        var p = $('.img.frecce').offset();
        $('.icona-comune').css({ 'left': p.left + 100, top: p.top - 100 })
        $('.icona-cantone').css({ 'right': p.left + 100, top: p.top - 100 })
    }
    function unifyOut2(top) {
        $('.icona-comune').css({ 'left': 0, top: top })
        $('.icona-cantone').css({ 'right': 0, top: top })
    }
    var closeScroll = 0;
    var unifyScroll = 0;
    var closeScroll2 = 0;
    var unifyScroll2 = 0;
    function scroll() {
        var v = $(window).scrollTop();
        if ($(this).scrollTop() < 1) {
            startPosition();
        }
        else if ($(this).scrollTop() > closeScroll) {
            endPosition($(this).scrollTop());
        }
        else {
            if ($(this).scrollTop() > unifyScroll2 && $(this).scrollTop() < closeScroll2) unifyIn2($(this).scrollTop());
            else unifyOut2($(this).scrollTop());
        }
    }
    var items = [];
    var h = 0;
    function scroll2(e) {
        var v = $(window).scrollTop();
        for (i = 0; i < items.length; i++) {
            if (v >= items[i].from) {
                var val = (items[i].from - v) / 8;
                $('#p' + (i + 1) + ' .image').css({ 'background-position': '0px ' + val + 'px' })
            }
        }
    }
    init();
}
function initUEFMap(){

    function init(){
        d3.select('svg').selectAll('g#Uffici_esecuzione circle, g#Uffici_fallimenti circle').on('mouseover', mousein).on('mouseout', mouseout).on('click', click);

        var popOverSettings = {
            placement: 'top',
            container: 'body',
            html: true,
            selector: '[rel="popover"]',
            content: function () {
                return di_mappa_data[$(this).attr('data-id')]
            }
        }

        $('body').popover(popOverSettings);

        $('body').on('click', function (e) {

            if($('.popover.fade').length > 1) $('.popover.fade:eq(0)').remove();

            // if($(e.target).is('[rel="popover"]')) $('.popover.fade').remove();

            // $('[rel="popover"]').each(function () {
            //     //the 'is' for buttons that trigger popups
            //     //the 'has' for icons within a button that triggers a popup
            //     if (!$(this).is(e.target) && $(this).has(e.target).length === 0 && $('.popover').has(e.target).length === 0) {
            //         console.log($(this))
            //         // $(this).popover('hide');
            //         // $(this).popover(popOverSettings);
            //     }
            // });
        });
    }
    function mousein(){
        $(this).trigger('click');
        $(this).css('fill', '#c33');
    }
    function mouseout(){
        $(this).trigger('click');
        $(this).removeAttr('style');
    }
    function click(){
        var id = $(this).attr('data-id');
        if($(this).parent().is('#Uffici_esecuzione')) location.href = 'https://www4.ti.ch/index.php?id=87273#address'+id;
        else location.href = 'https://www4.ti.ch/index.php?id=89204#address'+id;
    }
    init();
}
$(document).ready(function() {
  if($('body.aziende-urc').length){
    initURCSlider();

    if(is_safari){
      setTimeout(function (){
        initURCOpener();
      }, 1000)
    }
    else initURCOpener();

    initURCForm();
    if($('.urc-lavoro > section').length){
      initURCArrow();
      initURCMenu();
    }
    initURCCaptcha();

    initURCEventBox();
    if($('#urc-overlay.mobile').length) initURCEventFormMobile();
    else initURCEventForm();
  }
  if($('form[name=urcnew]').length){
    initUrcNew();
  }
});

function initURCSlider(){
  var current = 1;
  var max = $('.urc-lavoro .home .slider > *').length;
  var speed = 4000;
  function init(){

    $('.urc-lavoro .home .slider').append($('.urc-lavoro .home .slider > *:first').clone());
    $('.urc-lavoro .home .slider > *:last').removeClass('e1').addClass('e5');

    setInterval(next, speed);
  }
  function next(){

    $('.urc-lavoro .home .slider .e'+current).addClass('out');
    current++;

    if(current > max){
      current = 1;
      $('.urc-lavoro .home .slider .out').removeClass('out');
    }

  }
  init();
}

function initURCOpener(){
  function init(){
    setTimeout(function (){
      $('.opener').each(function (){
        var o = $(this).prev();
        o.attr('data-h', o.outerHeight()).css({height: 0});//.addClass('closed');
      })
      $('.opener').click(open);
    }, 500)
  }
  function open(e){
    e.preventDefault();

    var o = $(this).prev();
    var h = o.attr('data-h');
    if(o.outerHeight() == 0){
      o.height(h);
      $(this).children('.fa-angle-down').addClass('hidden');
      $(this).children('.fa-angle-up').removeClass('hidden');
    }
    else{
      o.height(0);
      $(this).children('.fa-angle-down').removeClass('hidden');
      $(this).children('.fa-angle-up').addClass('hidden');
    }
  }
  init();
}

function initURCForm(){
  var actualStep = 1;
  var uploadFile;

  var focusAfterForm = $('.urc-panel.urc-team a:first');
  function manageTabs(){
    $('#annuncio .bt-next').focus(function (){
        $('body, html').on('keydown', tabEvent);
        // console.log('set tabEvent');
    });

    // console.log(focusAfterForm)
    focusAfterForm.focus(function (){
        $('body, html').on('keydown', afterFormTabEvent);
        // console.log('set afterFormTabEvent');
    });

    $('#annuncio input[name=nome], #annuncio textarea[name=commenti]').focus(function (){
        $('body, html').on('keydown', tabPrevEvent);
        // console.log('set tabPrevEvent');
    });
  }
  function tabEvent(e){
    // console.log('tabEvent');
    if(e.keyCode == 9 && !e.shiftKey){
        e.preventDefault();
        $('body, html').off('keydown', tabEvent);
        e.stopPropagation();
        // console.log('unset tabEvent')
        focusAfterForm.focus();
    }
    else if((e.keyCode == 9 && e.shiftKey)){
        $('body, html').off('keydown', tabEvent);
    }
  }
  function afterFormTabEvent(e){
    // console.log('afterFormTabEvent');
    if(e.keyCode == 9 && e.shiftKey){
        e.preventDefault();
        $('body, html').off('keydown', afterFormTabEvent);
        e.stopPropagation();
        // console.log('unset afterFormTabEvent')

        // console.log(actualStep);
        // console.log($('#annuncio .step'+actualStep+' .bt-next'));

        if($('#annuncio .step'+actualStep+' .bt-next').length) $('#annuncio .step'+actualStep+' .bt-next').focus();
        else $('#annuncio .step1 .bt-next').focus();
    }
    else if(!$('.urc-panel.urc-team a:first').is(':focus')){
        $('body, html').off('keydown', afterFormTabEvent);
    }
  }
  function tabPrevEvent(e){
    // console.log('tabEvent');
    if(e.keyCode == 9 && e.shiftKey){
        e.preventDefault();
        $('body, html').off('keydown', tabPrevEvent);
        e.stopPropagation();
        // console.log('unset tabPrevEvent')
        if($('#annuncio .step'+actualStep+' .bt-prev').length) $('#annuncio .step'+actualStep+' .bt-prev').trigger('click');
        else $('#annuncio .step1 .bt-prev').trigger('click');
    }
    else if((e.keyCode == 9)){
        $('body, html').off('keydown', tabPrevEvent);
    }
  }

  function init(){
    $('#annuncio .bt-next').click(next);
    $('#annuncio .bt-prev').click(prev);
    $('#annuncio .bt-send').click(send);
    $('#annuncio .bt-reset').click(reset);

    $('#annuncio input[type=file]').on('change', prepareUpload);

    $('#annuncio form a.remove').click(removeFile);

    // $('.step1').addClass('on-left');
    // $('.step3').removeClass('on-right');
    // $('.steps.thankyou').removeClass('on-right');

    manageTabs();
  }
  function prepareUpload(event){
    uploadFile = event.target.files;
  }
  function uploadFiles(event){
    var data = new FormData();
    $.each(uploadFile, function(key, value){
        data.append('file', value);
    });

    $.ajax({
      url: 'fileadmin/DFE/DE-SDL/servizio_aziende/upload.php', // point to server-side PHP script
      dataType: 'text',  // what to expect back from the PHP script, if anything
      cache: false,
      contentType: false,
      processData: false,
      data: data,
      type: 'post',
      success: function(php_script_response){
        sendForm(php_script_response);
      }
    });
  }
  function removeFile(e){
    e.preventDefault();

    $('#annuncio input[type=file]').val('');
    $('#annuncio input[type=file]').next().children('span').text('Allega un file');
  }
  function next(e){
    e.preventDefault();

    var step = $(this).attr('data-step');
    var error = false;

    if(step == 2){
      if(!checkField('nome_azienda')) error = true;
      if(!checkField('via')) error = true;
      if(!checkField('luogo')) error = true;
      // if(!error) $('#annuncio input[name=nome]').focus();
    }
    else if(step == 3){
      if(!checkField('nome')) error = true;
      if(!checkField('cognome')) error = true;
      if(!checkEmailField('email')) error = true;
      // if(!error) $('#annuncio textarea[name=commenti]').focus();
    }
    if(step == 4){
      error = true;
    }

    if(!error){
      $('#annuncio .step'+actualStep).addClass('on-left');
      $('#annuncio .step'+step).removeClass('on-right');
      actualStep = step;

      $('body, html').off('keydown', tabEvent);

      setTimeout(function (){
        if(step == 2){
          $('#annuncio input[name=nome]').focus();
        }
        else if(step == 3){
          $('#annuncio textarea[name=commenti]').focus();
        }
      }, 500);

      // $('.steps').addClass('hidden');
      // $('.step'+step).removeClass('hidden');
    }
  }
  function prev(e){
    e.preventDefault();

    var step = $(this).attr('data-step');
    // $('.steps').addClass('hidden');
    // $('.step'+step).removeClass('hidden');

    $('#annuncio .step'+actualStep).addClass('on-right');
    $('#annuncio .step'+step).removeClass('on-left');
    actualStep = step;

    setTimeout(function (){
        if(step == 1){
          $('#annuncio input[name=web]').focus();
        }
        else if(step == 2){
          $('#annuncio input[name=telefono]').focus();
        }
      }, 500);
  }
  function send(e){
    e.preventDefault();
    var error = false;

    /* Captcha */
    var c = $('#annuncio .captcha input');
    var v = c.val();
    if(v){
      var r = checkCaptcha(v);
      if(r.responseText == 'ok'){
        c.removeClass('error');
      }
      else{
        c.addClass('error').val('');
        $('#annuncio .captcha a').trigger('click');
        error = true;
      }
    }
    else{
      c.addClass('error');
      $('#annuncio .captcha a').trigger('click');
      error = true;
    }


    /* Allegato */
    var f = $('#file');
    if(!f.val()){
      sendForm();
    }
    else{
      uploadFiles();
    }

    // var f = $('#file');
    // if(!f.val()){
    //   $('.step3 label').addClass('error');
    //   error = true;
    // }
    // else{
    //   $('.step3 label').removeClass('error');
    // }

    // if(!error){
    //   uploadFiles();
    // }
  }
  function sendForm(file){
    var data = {
        nome_azienda: $('#annuncio input[name=nome_azienda]').val(),
        via: $('#annuncio input[name=via]').val(),
        luogo: $('#annuncio input[name=luogo]').val(),
        web: $('#annuncio input[name=web]').val(),
        nome: $('#annuncio input[name=nome]').val(),
        cognome: $('#annuncio input[name=cognome]').val(),
        email: $('#annuncio input[name=email]').val(),
        telefono: $('#annuncio input[name=telefono]').val(),
        commenti: $('#annuncio textarea[name=commenti]').val(),
        // file: file
      };

      if (typeof file !== "undefined") {
        data.file = file;
      }

      $.post('fileadmin/DFE/DE-SDL/servizio_aziende/send.php', data, function (r){
        // console.log(r);
        $('#annuncio .urc-form .container > h2, #annuncio .urc-form .container > p').addClass('hidden');
        $('#annuncio .step3').addClass('on-left');
        $('#annuncio .steps.thankyou').removeClass('on-right');
      });
  }
  function checkField(name){
    var f = $('#annuncio .steps input[name='+name+']');
    f.removeClass('error');
    if(f.val()){
      return true;
    }
    f.addClass('error');
    return false;
  }
  function checkEmailField(name){
    var f = $('#annuncio .steps input[name='+name+']');
    f.removeClass('error');
    var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    if(f.val() && re.test(f.val())){
      return true;
    }
    f.addClass('error');
    return false;
  }
  function checkCaptcha(value){
    return $.ajax({
      url: 'fileadmin/DFE/DE-SDL/servizio_aziende/securimage/check.php?namespace=form1',
      data: {
        value: value
      },
      async: false,
      method: 'post',
      success: function (r){
        // console.log(r);
        // if(r == 'error'){
        //   $('.captcha a').trigger('click');
        // }
      }
    });
  }
  function reset(e){
    e.preventDefault();

    $('#annuncio .urc-form .container > h2, #annuncio .urc-form .container > p').removeClass('hidden');
    $('#annuncio .step2, #annuncio .step3').removeClass('on-left').addClass('on-right');
    $('#annuncio .steps.thankyou').addClass('on-right');
    $('#annuncio .step1').removeClass('on-left');

    $('#annuncio .urc-form input[type=text]').removeClass('error').val('');
    $('#annuncio .urc-form textarea').val('');
    $('#annuncio form a.remove').trigger('click');

    $('#annuncio .captcha a').trigger('click');
    $('#annuncio .captcha .error').removeClass('error');

    actualStep = 1;

  }
  init();
}
// function initURCForm(){
//   var actualStep = 1;
//   var uploadFile;
//   function init(){
//     $('#annuncio .bt-next').click(next);
//     $('#annuncio .bt-prev').click(prev);
//     $('#annuncio .bt-send').click(send);
//     $('#annuncio .bt-reset').click(reset);

//     $('#annuncio input[type=file]').on('change', prepareUpload);

//     $('#annuncio form a.remove').click(removeFile);

//     // $('.step1').addClass('on-left');
//     // $('.step3').removeClass('on-right');
//     // $('.steps.thankyou').removeClass('on-right');
//   }
//   function prepareUpload(event){
//     uploadFile = event.target.files;
//   }
//   function uploadFiles(event){
//     var data = new FormData();
//     $.each(uploadFile, function(key, value){
//         data.append('file', value);
//     });

//     $.ajax({
//       url: 'fileadmin/DFE/DE-SDL/servizio_aziende/upload.php', // point to server-side PHP script
//       dataType: 'text',  // what to expect back from the PHP script, if anything
//       cache: false,
//       contentType: false,
//       processData: false,
//       data: data,
//       type: 'post',
//       success: function(php_script_response){
//         sendForm(php_script_response);
//       }
//     });
//   }
//   function removeFile(e){
//     e.preventDefault();

//     $('#annuncio input[type=file]').val('');
//     $('#annuncio input[type=file]').next().children('span').text('Allega un file');
//   }
//   function next(e){
//     e.preventDefault();

//     var step = $(this).attr('data-step');
//     var error = false;

//     if(step == 2){
//       if(!checkField('nome_azienda')) error = true;
//       if(!checkField('via')) error = true;
//       if(!checkField('luogo')) error = true;
//     }
//     else if(step == 3){
//       if(!checkField('nome')) error = true;
//       if(!checkField('cognome')) error = true;
//       if(!checkEmailField('email')) error = true;
//     }
//     if(step == 4){
//       error = true;
//     }

//     if(!error){
//       $('#annuncio .step'+actualStep).addClass('on-left');
//       $('#annuncio .step'+step).removeClass('on-right');
//       actualStep = step;
//       // $('.steps').addClass('hidden');
//       // $('.step'+step).removeClass('hidden');
//     }
//   }
//   function prev(e){
//     e.preventDefault();

//     var step = $(this).attr('data-step');
//     // $('.steps').addClass('hidden');
//     // $('.step'+step).removeClass('hidden');

//     $('#annuncio .step'+actualStep).addClass('on-right');
//     $('#annuncio .step'+step).removeClass('on-left');
//     actualStep = step;
//   }
//   function send(e){
//     e.preventDefault();
//     var error = false;

//     /* Captcha */
//     var c = $('#annuncio .captcha input');
//     var v = c.val();
//     if(v){
//       var r = checkCaptcha(v);
//       if(r.responseText == 'ok'){
//         c.removeClass('error');
//       }
//       else{
//         c.addClass('error').val('');
//         $('#annuncio .captcha a').trigger('click');
//         error = true;
//       }
//     }
//     else{
//       c.addClass('error');
//       $('#annuncio .captcha a').trigger('click');
//       error = true;
//     }


//     /* Allegato */
//     var f = $('#file');
//     if(!f.val()){
//       sendForm();
//     }
//     else{
//       uploadFiles();
//     }

//     // var f = $('#file');
//     // if(!f.val()){
//     //   $('.step3 label').addClass('error');
//     //   error = true;
//     // }
//     // else{
//     //   $('.step3 label').removeClass('error');
//     // }

//     // if(!error){
//     //   uploadFiles();
//     // }
//   }
//   function sendForm(file){
//     var data = {
//         nome_azienda: $('#annuncio input[name=nome_azienda]').val(),
//         via: $('#annuncio input[name=via]').val(),
//         luogo: $('#annuncio input[name=luogo]').val(),
//         web: $('#annuncio input[name=web]').val(),
//         nome: $('#annuncio input[name=nome]').val(),
//         cognome: $('#annuncio input[name=cognome]').val(),
//         email: $('#annuncio input[name=email]').val(),
//         telefono: $('#annuncio input[name=telefono]').val(),
//         commenti: $('#annuncio textarea[name=commenti]').val(),
//         // file: file
//       };

//       if (typeof file !== "undefined") {
//         data.file = file;
//       }

//       $.post('fileadmin/DFE/DE-SDL/servizio_aziende/send.php', data, function (r){
//         // console.log(r);
//         $('#annuncio .urc-form .container > h2, #annuncio .urc-form .container > p').addClass('hidden');
//         $('#annuncio .step3').addClass('on-left');
//         $('#annuncio .steps.thankyou').removeClass('on-right');
//       });
//   }
//   function checkField(name){
//     var f = $('#annuncio .steps input[name='+name+']');
//     f.removeClass('error');
//     if(f.val()){
//       return true;
//     }
//     f.addClass('error');
//     return false;
//   }
//   function checkEmailField(name){
//     var f = $('#annuncio .steps input[name='+name+']');
//     f.removeClass('error');
//     var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
//     if(f.val() && re.test(f.val())){
//       return true;
//     }
//     f.addClass('error');
//     return false;
//   }
//   function checkCaptcha(value){
//     return $.ajax({
//       url: 'fileadmin/DFE/DE-SDL/servizio_aziende/securimage/check.php?namespace=form1',
//       data: {
//         value: value
//       },
//       async: false,
//       method: 'post',
//       success: function (r){
//         // console.log(r);
//         // if(r == 'error'){
//         //   $('.captcha a').trigger('click');
//         // }
//       }
//     });
//   }
//   function reset(e){
//     e.preventDefault();

//     $('#annuncio .urc-form .container > h2, #annuncio .urc-form .container > p').removeClass('hidden');
//     $('#annuncio .step2, #annuncio .step3').removeClass('on-left').addClass('on-right');
//     $('#annuncio .steps.thankyou').addClass('on-right');
//     $('#annuncio .step1').removeClass('on-left');

//     $('#annuncio .urc-form input[type=text]').removeClass('error').val('');
//     $('#annuncio .urc-form textarea').val('');
//     $('#annuncio form a.remove').trigger('click');

//     $('#annuncio .captcha a').trigger('click');
//     $('#annuncio .captcha .error').removeClass('error');

//     actualStep = 1;

//   }
//   init();
// }

function initURCArrow(){
  var offset = $('.urc-lavoro > section:eq(0)').offset().top + 10;
  function init(){
    $('.direction').click(move);
  }
  function move(e){
    e.preventDefault();
    $('html, body').animate({ scrollTop: offset+'px'}, 700);
  }
  init();
}

function initURCMenu(){
  var menuTrigger;
  var menu;
  var tornaSu = $('.urc-torna-su');
  var triggers = new Array();
  var scrolling = false;
  function init(){
    menu = $('.urc-floating-menu');
    // menuTrigger = $('.urc-lavoro > section:eq(0)').offset().top - 8;
    menuTrigger = $('.urc-lavoro section#video').offset().top - 50;

    setTimeout(calcTriggers, 560);

    $('.urc-menu a').click(menuClick);

    $(window).scroll(onScroll).trigger('scroll');
    $(window).resize(calcTriggers);

    $('.urc-opener').click(function (){
      setTimeout(calcTriggers, 10)
    });

    // $(document).on("scrollstart",function(){
    //   // alert("Started scrolling!");
    //   scrolling = true;
    //   $('.urc-floating-menu').removeClass('fade');
    // }).on("scrollstop",function(){
    //   // alert("<Sopt scrolling!");
    //   scrolling = false;
    //   setTimeout(function (){
    //     if(!scrolling){
    //       $('.urc-floating-menu').addClass('fade');
    //     }
    //   }, 500)
    // });

    tornaSu.click(moveUp);
    $('.urc-menu.urc-floating-menu h5').css({cursor: 'pointer'}).click(moveUp);

    if($('.nav.no-click').length) $('.nav.no-click a').click(menuClick);
  }
  function onScroll(e){
    var v = $(window).scrollTop();
    if(v >= menuTrigger){
      tornaSu.addClass('out');
      menu.removeClass('closed');
    }
    else{
      tornaSu.removeClass('out');
      menu.addClass('closed');
    }

    for(x in triggers){

      if(v >= triggers[x].from - 5 && v < triggers[x].to - 5){
        $('.urc-floating-menu .hover').removeClass('hover');
        $('.urc-floating-menu a[href*='+triggers[x].id+']').addClass('hover');
        break;
      }
    }

  }
  function calcTriggers(){
    triggers = new Array();

    triggers.push({
      id: 'video',
      from: $('.urc-lavoro section#video').offset().top - 50,
      to: $('.urc-lavoro section#video').offset().top + $('.urc-lavoro section#video').outerHeight()// + 50
    });

    $('.urc-lavoro > section').each(function (){
      var top = $(this).offset().top;
      // if($(this).attr('id') == 'chi-siamo'){
      //   top -= 25;
      // }
      // tmp = 0;
      // if($(this).attr('id') == 'video'){
      //   tmp = 25;
      // }
      triggers.push({
        id: $(this).attr('id'),
        from: top,
        to: top + $(this).outerHeight()// - tmp
      });
    });
  }
  function menuClick(e){
    if(!$(this).hasClass('bb')){
      e.preventDefault();

      var tmp = $(this).attr('href').split('#');
      var top = $('section#'+tmp[1]).offset().top;
      if(tmp[1] == 'servizi'){
        top += $('section#'+tmp[1]+' img').height();
      }
      $('html, body').animate({ scrollTop: top+'px'}, 700);
    }
  }
  function moveUp(e){
    e.preventDefault();
    $('html, body').animate({ scrollTop: 0 }, 700);
  }
  init();
}

function initURCCaptcha(){
  function init(){
    $('.captcha a').click(refresh);
  }
  function refresh(e){
    e.preventDefault();

    var src = $(this).siblings('img').attr('src');
    // var src = $('.captcha img').attr('src');
    if(src.indexOf('&') > -1){
      tmp = src.split('&');
      src = tmp[0];
    }
    src += '&' + Math.random();
    $('.captcha img').attr('src', src);
  }
  init();
}

function initURCEventBox(){
  var overlay = $('#urc-overlay');
  var opener = $('#urc-overlay .opener-button');
  var fromTop = 106;
  var closedTop;
  function init(){
    if(overlay.hasClass('floating')){
      overlay.click(function (){
        location.href = overlay.attr('data-link');
      });
    }
    else{
      var wh = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight;
      closedTop = wh - 80;

      if( /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ) {
          overlay.css({ top: closedTop, height:'auto' });
         }
      else
          overlay.css({ top: closedTop, height: wh - fromTop });

      opener.click(open);

      if(!$('#urc-overlay.mobile').length){
        setTimeout(function (){

          opener.trigger('click');
          overlay.css('opacity', '0.95');
        }, 1000);
      }
    }
    $('#banner h2.container a').click(function (e){
      e.preventDefault();
      $('.opener-button .fa-angle-up').trigger('click');
    });
  }
  function open(e){
    e.preventDefault();

    if($(this).children('i').is(':visible')){
      $('html, body').animate({ scrollTop: 0 }, 500);
      // $(this).children('i').removeClass('fa-angle-up').addClass('fa-times');
      $(this).children('i').hide();
      $(this).children('i').after('<img src="typo3conf/ext/theme/Resources/Public/images/ics.png">')

      overlay.css({ top: fromTop });
      setTimeout(function (){
        $('body').css({ overflow: 'hidden' });
      }, 500);
    }
    else{
      // $(this).children('i').addClass('fa-angle-up').removeClass('fa-times');
      $(this).children('i').show();
      $(this).children('img').remove();

      overlay.css({ top: closedTop });
      $('body').css({ overflow: '' });
    }
  }
  init();
}

function initURCEventForm(){
  var actualStep = 1;
  var uploadFile;
  function init(){
    $('#urc-overlay .bt-next').click(next);
    $('#urc-overlay .bt-prev').click(prev);
    $('#urc-overlay .bt-send').click(send);
    $('#urc-overlay .bt-back').click(function (){
      $('.opener-button').trigger('click');
    });
    // $('#urc-overlay .bt-reset').click(reset);

    // $('#urc-overlay form a.remove').click(removeFile);

    // var d = {
    //   nome_azienda: 'Nome',
    //   luogo: 'Nome',
    //   telefono: 'Nome',
    //   email: 'email@test.com',
    //   fname1: 'fname',
    //   lname1: 'lname',
    //   email1: 'fname@test.com',
    // }
    // for(x in d) $('input[name='+x+']').val(d[x]);

    initURCEvents();

  }
  function next(e){
    e.preventDefault();

    var step = $(this).attr('data-step');
    var error = false;

    if(step == 2){
      if(!checkField('nome_azienda')) error = true;
      if(!checkField('luogo')) error = true;
      if(!checkField('telefono')) error = true;
      // if(!checkEmailField('email')) error = true;
      if(!$('input[name=evento]:checked').length){
        error = true;
        $('.checks').addClass('error');
      }
      else $('.checks').removeClass('error');
    }

    if(!error){
      $('#urc-overlay .step'+actualStep).addClass('on-left');
      $('#urc-overlay .step'+step).removeClass('on-right');
      actualStep = step;
    }
  }
  function prev(e){
    e.preventDefault();

    var step = $(this).attr('data-step');
    // $('.steps').addClass('hidden');
    // $('.step'+step).removeClass('hidden');

    $('#urc-overlay .step'+actualStep).addClass('on-right');
    $('#urc-overlay .step'+step).removeClass('on-left');
    actualStep = step;
  }
  function send(e){
    e.preventDefault();
    var error = false;

    /* Fields */
    if(!checkField('fname1')) error = true;
    if(!checkField('lname1')) error = true;
    if(!checkEmailField('email1')) error = true;

    if($('#urc-overlay input[name=fname2]').val()){
      if(!checkField('fname2')) error = true;
      if(!checkField('lname2')) error = true;
      if(!checkEmailField('email2')) error = true;
    }
    else{
      $('#urc-overlay .steps input[name=fname2], #urc-overlay .steps input[name=lname2], #urc-overlay .steps input[name=email2]').removeClass('error');
    }

    /* Captcha */
    var c = $('#urc-overlay .captcha input');
    var v = c.val();
    if(v){
      var r = checkCaptcha(v);
      if(r.responseText == 'ok'){
        c.removeClass('error');
      }
      else{
        c.addClass('error').val('');
        $('#urc-overlay .captcha a').trigger('click');
        error = true;
      }
    }
    else{
      c.addClass('error');
      $('#urc-overlay .captcha a').trigger('click');
      error = true;
    }


    if(!error)
      sendForm();
  }
  function sendForm(){
    var data = {
      nome_azienda: $('#urc-overlay input[name=nome_azienda]').val(),
      luogo: $('#urc-overlay input[name=luogo]').val(),
      telefono: $('#urc-overlay input[name=telefono]').val(),
      email: $('#urc-overlay input[name=email]').val(),

      evento: $('#urc-overlay input[name=evento]:checked').val(),

      fname1: $('#urc-overlay input[name=fname1]').val(),
      lname1: $('#urc-overlay input[name=lname1]').val(),
      email1: $('#urc-overlay input[name=email1]').val()
    };

    if($('#urc-overlay input[name=fname2]').val()){
      data.fname2 = $('#urc-overlay input[name=fname2]').val();
      data.lname2 = $('#urc-overlay input[name=lname2]').val();
      data.email2 = $('#urc-overlay input[name=email2]').val();
    }

    $.post('fileadmin/DFE/DE-SDL/servizio_aziende/send_event.php', data, function (r){
      if(r == 'error'){
        $('#urc-overlay .urc-form .container > h2, #urc-overlay .urc-form .container > p').addClass('hidden');
        $('#urc-overlay .step2').addClass('on-left');
        $('#urc-overlay .steps.thankyou').removeClass('on-right');
        $('#urc-overlay .steps.thankyou p:eq(0)').html('<span style="color: #c33">Siamo spiacenti ma questo evento Ã¨ giÃ  completo.</span><br>Puoi iscriverti a uno degli eventi successivi, oppure registrati nella lista d\'attesa presso dfe-urcbel.aziende@ti.ch')
      }
      else{
        $('#urc-overlay .urc-form .container > h2, #urc-overlay .urc-form .container > p').addClass('hidden');
        $('#urc-overlay .step2').addClass('on-left');
        $('#urc-overlay .steps.thankyou').removeClass('on-right');
      }
    });
  }
  function checkField(name){
    var f = $('#urc-overlay .steps input[name='+name+']');
    f.removeClass('error');
    if(f.val()){
      return true;
    }
    f.addClass('error');
    return false;
  }
  function checkEmailField(name){
    var f = $('#urc-overlay .steps input[name='+name+']');
    f.removeClass('error');
    var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    if(f.val() && re.test(f.val())){
      return true;
    }
    f.addClass('error');
    return false;
  }
  function checkCaptcha(value){
    return $.ajax({
      url: 'fileadmin/DFE/DE-SDL/servizio_aziende/securimage/check.php?namespace=form2',
      data: {
        value: value
      },
      async: false,
      method: 'post',
      success: function (r){
        // console.log(r);
        // if(r == 'error'){
        //   $('.captcha a').trigger('click');
        // }
      }
    });
  }
  init();
}

function initURCEventFormMobile(){
  var actualStep = 1;
  var uploadFile;
  function init(){
    $('#urc-overlay .bt-send').click(send);

    // var d = {
    //   nome_azienda: 'Nome',
    //   luogo: 'Nome',
    //   telefono: 'Nome',
    //   email: 'email@test.com',
    //   fname1: 'fname',
    //   lname1: 'lname',
    //   email1: 'fname@test.com',
    // }
    // for(x in d) $('input[name='+x+']').val(d[x]);

    initURCEvents();

  }
  function send(e){
    e.preventDefault();
    var error = false;

    /* Fields */
    if(!checkField('fname1')) error = true;
    if(!checkField('lname1')) error = true;
    if(!checkEmailField('email1')) error = true;


    if(!checkField('nome_azienda')) error = true;
    if(!checkField('luogo')) error = true;
    if(!checkField('telefono')) error = true;
    // if(!checkEmailField('email')) error = true;
    if(!$('input[name=evento]:checked').length){
      error = true;
      $('.checks').addClass('error');
    }
    else $('.checks').removeClass('error');


    /* Captcha */
    var c = $('#urc-overlay .captcha input');
    var v = c.val();
    if(v){
      var r = checkCaptcha(v);
      if(r.responseText == 'ok'){
        c.removeClass('error');
      }
      else{
        c.addClass('error').val('');
        $('#urc-overlay .captcha a').trigger('click');
        error = true;
      }
    }
    else{
      c.addClass('error');
      $('#urc-overlay .captcha a').trigger('click');
      error = true;
    }

    console.log(error);

    if(!error)
      sendForm();
  }
  function sendForm(){
    var data = {
      nome_azienda: $('#urc-overlay input[name=nome_azienda]').val(),
      luogo: $('#urc-overlay input[name=luogo]').val(),
      telefono: $('#urc-overlay input[name=telefono]').val(),
      email: $('#urc-overlay input[name=email]').val(),

      evento: $('#urc-overlay input[name=evento]:checked').val(),

      fname1: $('#urc-overlay input[name=fname1]').val(),
      lname1: $('#urc-overlay input[name=lname1]').val(),
      email1: $('#urc-overlay input[name=email1]').val()
    };

    if($('#urc-overlay input[name=fname2]').val()){
      data.fname2 = $('#urc-overlay input[name=fname2]').val();
      data.lname2 = $('#urc-overlay input[name=lname2]').val();
      data.email2 = $('#urc-overlay input[name=email2]').val();
    }

    $.post('fileadmin/DFE/DE-SDL/servizio_aziende/send_event.php', data, function (r){
      $('#urc-overlay .form').hide();
      $('#urc-overlay .thankyou').show();
    });
  }
  function checkField(name){
    var f = $('#urc-overlay input[name='+name+']');
    f.removeClass('error');
    if(f.val()){
      return true;
    }
    f.addClass('error');
    return false;
  }
  function checkEmailField(name){
    var f = $('#urc-overlay input[name='+name+']');
    f.removeClass('error');
    var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    if(f.val() && re.test(f.val())){
      return true;
    }
    f.addClass('error');
    return false;
  }
  function checkCaptcha(value){
    return $.ajax({
      url: 'fileadmin/DFE/DE-SDL/servizio_aziende/securimage/check.php?namespace=form2',
      data: {
        value: value
      },
      async: false,
      method: 'post',
      success: function (r){
        // console.log(r);
        // if(r == 'error'){
        //   $('.captcha a').trigger('click');
        // }
      }
    });
  }
  init();
}

function initURCEvents(){
  var subjects = {
    'lugano': "Iscrizione lista di attesa all'evento Palazzo dei Congressi a Lugano del 22 settembre",
    'bellinzona': "Iscrizione lista di attesa all'evento Auditorium BancaStato a Bellinzona del 14 ottobre",
    'mendrisio': "Iscrizione lista di attesa all'evento Hotel Coronado a Mendrisio del 11 novembre",
    'locarno': "Iscrizione lista di attesa all'evento Hotel Belvedere a Locarno del 1 dicembre"
  }
  // $.getJSON('/typo3conf/ext/user_urc_aziende_iscritti/check.php', function (items){
  $.getJSON('/user_librerie/aziende_urc/check.php', {_: new Date().getTime()}, function (items){
    for(x in items){

      if(x){
        if(x == 'mendrisio'){
          $('[data-luogo='+x+']').addClass('disabled');
          // var html = '<span style="color: #c33;">Siamo spiacenti ma questo evento é già completo.</span><br>';
          // $('[data-luogo='+x+'] span').html(html);
          $('[data-luogo='+x+'] span').text('Evento concluso');
        }
        else if(items[x] == 0 && x == 'locarno'){
          $('[data-luogo='+x+']').addClass('disabled');
          $('[data-luogo='+x+'] span').text('Evento concluso');
        }
        else if(items[x] == 0){
          $('[data-luogo='+x+']').addClass('disabled');

          var subject = subjects[x];
          var br = '%0D%0A';
          var body = "Vi chiediamo cortesemente di compilare i seguenti dati."+br+br;
          body += 'Nome azienda:'+br;
          body += 'NAP e luogo:'+br;
          body += 'Telefono:'+br;
          body += 'Email azienda:'+br+br;

          body += 'Nome partecipante:'+br;
          body += 'Cognome partecipante:'+br;
          body += 'Email partecipante:'+br;

          var mailto = 'mailto:dfe-urcbel.aziende@ti.ch?subject='+subject+'&body='+body;

          if(x == 'lugano')
          {
              var html = '<span style= "width:425px;display:inline-block;">&nbsp;</span><br>';
          }
          else if(x == 'bellinzona')
          {
              var html = '';
              $('[data-luogo='+x+']').css({clear: 'both'});
          }
          else
          {
              var html = '<span style="color: #c33;">Siamo spiacenti ma questo evento é già completo.</span><br>';
              html += 'Puoi iscriverti a uno degli eventi successivi, oppure registrati nella lista d\'attesa presso<br><a href="'+mailto+'">dfe-urcbel.aziende@ti.ch</a>';
          }
          $('[data-luogo='+x+'] span').html(html);
        }
        else if(items[x] == 2){
          $('[data-luogo='+x+']').addClass('disabled');
          $('[data-luogo='+x+'] span').text('Evento concluso');
        }
      }
    }
    if(!$('#menu-main').length) $('.urc-form .checks').css({overflow: 'auto', height: '420px' })
  });

  // var items = {'lugano': 0};
  // for(x in items){
  //     if(items[x] == 0){
  //       $('[data-luogo='+x+']').addClass('disabled');

  //       var subject = subjects[x];
  //       var br = '%0D%0A';
  //       var body = "Vi chiediamo cortesemente di compilare i seguenti dati."+br+br;
  //       body += 'Nome azienda:'+br;
  //       body += 'NAP e luogo:'+br;
  //       body += 'Telefono:'+br;
  //       body += 'Email azienda:'+br+br;

  //       body += 'Nome partecipante:'+br;
  //       body += 'Cognome partecipante:'+br;
  //       body += 'Email partecipante:'+br;

  //       var mailto = 'mailto:dfe-urcbel.aziende@ti.ch?subject='+subject+'&body='+body;

  //       var html = '<span style="color: #c33;">Siamo spiacenti ma questo evento Ã¨ giÃ  completo.</span><br>';
  //       html += 'Puoi iscriverti a uno degli eventi successivi, oppure registrati nella lista d\'attesa presso<br><a href="'+mailto+'">dfe-urcbel.aziende@ti.ch</a>';
  //       $('[data-luogo='+x+'] span').html(html);
  //     }
  //     else if(items[x] == 2){
  //       $('[data-luogo='+x+']').addClass('disabled');
  //       $('[data-luogo='+x+'] span').text('Evento concluso');
  //     }
  //   }

}

function initUrcNew(){
    var subjects = {
        'lugano': "Iscrizione lista di attesa all'evento Palazzo dei Congressi a Lugano del 22 settembre",
        'bellinzona': "Iscrizione lista di attesa all'evento Auditorium BancaStato a Bellinzona del 14 ottobre",
    'mendrisio': "Iscrizione lista di attesa all'evento Hotel Coronado a Mendrisio del 11 novembre",
    'locarno': "Iscrizione lista di attesa all'evento Hotel Belvedere a Locarno del 1 dicembre"
    }
    function init(){
        preload();
        $('.urc-opener').click(open);
        $('form .btn.btn-primary').click(send);

        $('.urcnew input[name=item]').click(function (){
          if(!$(this).parent().hasClass('selected')){
            $('.urcnew .item.selected').removeClass('selected');
            $(this).parent().addClass('selected');
            $('.event_error').addClass('hidden');
          }
        })
    }
    function preload(){
        var disabled = 0;

        $.getJSON('/typo3conf/ext/user_urc_aziende_iscritti/check.php', {_: new Date().getTime()}, function (items){
            for(x in items){
              if(x){
                if(items[x] == 0 || items[x] == 2){
                    disabled++;
                    n = x == 'lugano' ? 1 : 0;
                    if(items[x] == 0){
                      $('#new-form .row > .col-xs-6:eq('+n+') > p').replaceWith('<p>Siamo spiacenti ma questo evento è già completo.<br>Puoi registrarti nella lista d’attesa presso <a href="mailto:servizioaziende@ti.ch">servizioaziende@ti.ch</a></p>');
                    }
                    else if(items[x] == 2){
                      $('#new-form .row > .col-xs-6:eq('+n+') > p').replaceWith('<p>Evento concluso</p>');
                    }
                    $('#new-form input[name=item]:eq('+n+')').parent().remove();
                }
              }
            }

            if(disabled == 2){
                $('.urc-opener').remove();
            }
            else $('.urc-opener').removeClass('hidden')
        });
    }
    function open(e){
      e.preventDefault();
      $('.urc-opened').toggleClass('hidden');

      if($(this).children('i').hasClass('fa-angle-down')){
        $(this).children('i').removeClass('fa-angle-down').addClass('fa-angle-up')
      }
      else{
        $(this).children('i').removeClass('fa-angle-up').addClass('fa-angle-down')
      }
    }
    function send(e){
      e.preventDefault();

      var error = false;

      if(!$('.urcnew input[name=item]:checked').length) $('.event_error').removeClass('hidden');
      else $('.event_error').addClass('hidden');

      if(!checkField('nome_azienda_new')) error = true;
      if(!checkField('luogo_new')) error = true;
      if(!checkField('telefono_new')) error = true;
      if(!checkField('nome_new')) error = true;
      if(!checkField('cognome_new')) error = true;
      if(!checkEmailField('email_new')) error = true;


      var c = $('input[name=captcha_new]');
      var v = c.val();
      if(v){
        var r = checkCaptcha(v);
        if(r.responseText == 'ok'){
          c.removeClass('error');
        }
        else{
          c.addClass('error').val('');
          $('.urcnew .captcha a').trigger('click');
          error = true;
        }
      }
      else{
        c.addClass('error');
        $('.urcnew .captcha a').trigger('click');
        error = true;
      }


      if(!error){
        var data = {
          evento: $('input[name=item]:checked').val(),
          nome_azienda: $('input[name=nome_azienda_new]').val(),
          luogo: $('input[name=luogo_new]').val(),
          telefono: $('input[name=telefono_new]').val(),
          nome: $('input[name=nome_new]').val(),
          cognome: $('input[name=cognome_new]').val(),
          email: $('input[name=email_new]').val()
        }

        $.post('fileadmin/DFE/DE-SDL/servizio_aziende2/send_event.php', data, function (r){
          if(r == 'ok'){
            $('#new-form > div > div > p, #new-form > div > div > .row').remove();
            $('.urc-opened').before('<p style="margin-top: 38px">Grazie per esservi registrati all’evento “Un’altra opportunità è d’obbligo”. A breve riceverete una mail di conferma.</p>')
            $('.urc-opener, .urc-opened').remove();
            $('html, body').animate({scrollTop: $('#new-form h2').position().top}, 400);
          }
        })
      }
    }
  function checkField(name){
    var f = $('input[name='+name+']');
    f.removeClass('error');
    if(f.val()){
      return true;
    }
    f.addClass('error');
    return false;
  }
  function checkEmailField(name){
    var f = $('input[name='+name+']');
    f.removeClass('error');
    var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    if(f.val() && re.test(f.val())){
      return true;
    }
    f.addClass('error');
    return false;
  }
  function checkCaptcha(value){
    return $.ajax({
      url: 'fileadmin/DFE/DE-SDL/servizio_aziende/securimage/check.php?namespace=form3',
      data: {
        value: value
      },
      async: false,
      method: 'post',
      success: function (r){
        // console.log(r);
        // if(r == 'error'){
        //   $('.captcha a').trigger('click');
        // }
      }
    });
  }
    init();
}
/* Vivere in Ticino */
function initVivereInTicino() {
    var cHeight = 180;
    var contentHeight = cHeight + 'px';
    var opened = {
        row: false,
        n: false,
    };

    function init() {
        $('.inner-row').each(function () {
            $(this).css({ height: 0, overflow: 'hidden' }).removeClass('hidden');
            $(this).prepend('<a class="close" href="#"><i class="fa fa-times"></i></a>')
        })
        $('.vivere-in-ticino a.close').click(close);
        $('.vivere-in-ticino a.item').click(open);



        $('#p1').change(function () {
            var v = $(this).val();
            if (v) {
                $('.vivere-in-ticino-box .right select').next().addClass('hidden');
                $('select[name=' + v + ']').next().removeClass('hidden');
            }
            else {
                $('.vivere-in-ticino-box .right select').next().addClass('hidden');
                $('select[disabled]').next().removeClass('hidden');
            }
        });
        $('.vivere-in-ticino-box .right select').change(function () {
            var v = $(this).val();
            if (v) {
                location.href = v;
            }
        });

    }
    function open(e) {
        e.preventDefault();

        var i = $(this).parent().parent().index();
        var row = ($(this).parent().parent().parent().parent().index() == 1) ? 1 : 2;
        var n = ((row - 1) * 4) + i;



        if (!opened.row || (opened.row != row || opened.n != i)) {

            if (opened.row && opened.row != row) {
                if (opened.row == 1) $('.sub-rows.co-n2, .sub-rows.co-n2 .inner-row').css('height', 0).removeClass('arrow-1').removeClass('arrow-2').removeClass('arrow-3').removeClass('arrow-4');
                else $('.sub-rows.co-n4, .sub-rows.co-n4 .inner-row').css('height', 0).removeClass('arrow-1').removeClass('arrow-2').removeClass('arrow-3').removeClass('arrow-4');
            }

            if (opened.row && opened.row == row) {
                var rown = (row == 1) ? 2 : 4;

                $('.sub-rows.co-n' + rown + ' .inner-row:eq(' + opened.n + ')').css({ height: 0 });
                setTimeout(function () {
                    $('.sub-rows.co-n' + rown + ' .inner-row:eq(' + i + ')').css({ height: contentHeight });
                    $('.sub-rows.co-n' + rown).attr('class', 'sub-rows co-n' + rown + ' arrow-' + (i + 1));
                }, 300);
            }
            else {
                if (row == 1) {
                    $('.sub-rows.co-n2 .inner-row').css('height', 0);

                    $('.sub-rows.co-n2, .sub-rows.co-n2 .inner-row:eq(' + i + ')').css({ height: contentHeight });
                    $('.sub-rows.co-n2').attr('class', 'sub-rows co-n2 arrow-' + (i + 1));
                }
                else {
                    $('.sub-rows.co-n4 .inner-row').css('height', 0);

                    $('.sub-rows.co-n4, .sub-rows.co-n4 .inner-row:eq(' + i + ')').css({ height: contentHeight });
                    $('.sub-rows.co-n4').attr('class', 'sub-rows co-n4 arrow-' + (i + 1));
                }

                // footer fix
                if (!opened.row) $('.sliding-content').css('top', parseInt($('.sliding-content').css('top')) + cHeight + 'px');
            }

            $('.item.selected').removeClass('selected');
            $(this).addClass('selected');

            opened = {
                row: row,
                n: i
            };
        }
        else {
            opened = {
                row: false,
                n: false,
            };
            $('.sub-rows.co-n4, .sub-rows.co-n4 .inner-row, .sub-rows.co-n2, .sub-rows.co-n2 .inner-row').css('height', 0).removeClass('arrow-1').removeClass('arrow-2').removeClass('arrow-3').removeClass('arrow-4');

            // footer fix
            $('.sliding-content').css('top', parseInt($('.sliding-content').css('top')) - cHeight + 'px');
        }
    }
    function close(e) {
        e.preventDefault();
        $('.sub-rows.co-n4, .sub-rows.co-n4 .inner-row, .sub-rows.co-n2, .sub-rows.co-n2 .inner-row').css('height', 0).removeClass('arrow-1').removeClass('arrow-2').removeClass('arrow-3').removeClass('arrow-4');

        $('.item.selected').removeClass('selected');

        // footer fix
        $('.sliding-content').css('top', parseInt($('.sliding-content').css('top')) - cHeight + 'px');

        opened = {
            row: false,
            n: false,
        };
    }

    init();
}
/* Vocalizzatore */
function aprivocalizza(sURL) {
    var w = window.open(sURL, '', 'width=400,height=200,status=yes,menubar=yes,scrollbars=yes,resizable=yes')
}
function chiudi(elemento) {
    jQuery('#visualizza' + elemento).css("display", "none");
    jQuery("#navPrimoLivello" + elemento).css('background-color', '#eeeeee');
}
function apri(elemento) {
    jQuery('#visualizza' + elemento).css("display", "block");
    jQuery("#navPrimoLivello" + elemento).css('background-color', '#ffffff');
}
function initWebcamPage(){
    var timer = 0;
    var interval = 60;
    function init(){
        // setTimeout(checkTimer, 10000);
        setTimeout(checkTimer, interval * 1000);
    }
    function checkTimer(){
        // timer+=10;
        // console.log(timer);
        // if(timer == interval){
            // timer = 0;
            $('.boxWebcams li img').each(function (){
                addTimestamp($(this), 'src');
                addTimestamp($(this).parent(), 'href');
            });
            if($('.ekko-lightbox.modal img').length) addTimestamp($('.ekko-lightbox.modal img'), 'src');
        // }
        // setTimeout(checkTimer, 10000);
        setTimeout(checkTimer, interval * 1000);
    }
    function addTimestamp(o, type){
        var src = o.attr(type);
        if(src.indexOf('?') > -1){
            src = src.split('?')[0];
        }
        o.attr(type, src + '?' + new Date().getTime());
    }
    init();
}