$(document).ready(function() {

    $('.scroll-pane').jScrollPane(
        {
            verticalDragMinHeight: 19,
            verticalDragMaxHeight: 19,
            horizontalDragMinWidth: 19,
            horizontalDragMaxWidth: 19
        }
    )


});
