!function(t,e){"object"==typeof module&&"object"==typeof module.exports?module.exports=t.document?e(t,!0):function(t){if(!t.document)throw new Error("jQuery requires a window with a document");return e(t)}:e(t)}("undefined"!=typeof window?window:this,function(C,t){function e(t,e){return e.toUpperCase()}var d=[],f=C.document,u=d.slice,g=d.concat,a=d.push,s=d.indexOf,n={},i=n.toString,m=n.hasOwnProperty,y={},r="1.12.4",k=function(t,e){return new k.fn.init(t,e)},o=/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g,l=/^-ms-/,c=/-([\da-z])/gi;function h(t){var e=!!t&&"length"in t&&t.length,n=k.type(t);return"function"!==n&&!k.isWindow(t)&&("array"===n||0===e||"number"==typeof e&&0<e&&e-1 in t)}k.fn=k.prototype={jquery:r,constructor:k,selector:"",length:0,toArray:function(){return u.call(this)},get:function(t){return null!=t?t<0?this[t+this.length]:this[t]:u.call(this)},pushStack:function(t){var e=k.merge(this.constructor(),t);return e.prevObject=this,e.context=this.context,e},each:function(t){return k.each(this,t)},map:function(n){return this.pushStack(k.map(this,function(t,e){return n.call(t,e,t)}))},slice:function(){return this.pushStack(u.apply(this,arguments))},first:function(){return this.eq(0)},last:function(){return this.eq(-1)},eq:function(t){var e=this.length,n=+t+(t<0?e:0);return this.pushStack(0<=n&&n<e?[this[n]]:[])},end:function(){return this.prevObject||this.constructor()},push:a,sort:d.sort,splice:d.splice},k.extend=k.fn.extend=function(){var t,e,n,i,s,r,o=arguments[0]||{},a=1,l=arguments.length,c=!1;for("boolean"==typeof o&&(c=o,o=arguments[a]||{},a++),"object"==typeof o||k.isFunction(o)||(o={}),a===l&&(o=this,a--);a<l;a++)if(null!=(s=arguments[a]))for(i in s)t=o[i],o!==(n=s[i])&&(c&&n&&(k.isPlainObject(n)||(e=k.isArray(n)))?(r=e?(e=!1,t&&k.isArray(t)?t:[]):t&&k.isPlainObject(t)?t:{},o[i]=k.extend(c,r,n)):void 0!==n&&(o[i]=n));return o},k.extend({expando:"jQuery"+(r+Math.random()).replace(/\D/g,""),isReady:!0,error:function(t){throw new Error(t)},noop:function(){},isFunction:function(t){return"function"===k.type(t)},isArray:Array.isArray||function(t){return"array"===k.type(t)},isWindow:function(t){return null!=t&&t==t.window},isNumeric:function(t){var e=t&&t.toString();return!k.isArray(t)&&0<=e-parseFloat(e)+1},isEmptyObject:function(t){var e;for(e in t)return!1;return!0},isPlainObject:function(t){var e;if(!t||"object"!==k.type(t)||t.nodeType||k.isWindow(t))return!1;try{if(t.constructor&&!m.call(t,"constructor")&&!m.call(t.constructor.prototype,"isPrototypeOf"))return!1}catch(t){return!1}if(!y.ownFirst)for(e in t)return m.call(t,e);for(e in t);return void 0===e||m.call(t,e)},type:function(t){return null==t?t+"":"object"==typeof t||"function"==typeof t?n[i.call(t)]||"object":typeof t},globalEval:function(t){t&&k.trim(t)&&(C.execScript||function(t){C.eval.call(C,t)})(t)},camelCase:function(t){return t.replace(l,"ms-").replace(c,e)},nodeName:function(t,e){return t.nodeName&&t.nodeName.toLowerCase()===e.toLowerCase()},each:function(t,e){var n,i=0;if(h(t))for(n=t.length;i<n&&!1!==e.call(t[i],i,t[i]);i++);else for(i in t)if(!1===e.call(t[i],i,t[i]))break;return t},trim:function(t){return null==t?"":(t+"").replace(o,"")},makeArray:function(t,e){var n=e||[];return null!=t&&(h(Object(t))?k.merge(n,"string"==typeof t?[t]:t):a.call(n,t)),n},inArray:function(t,e,n){var i;if(e){if(s)return s.call(e,t,n);for(i=e.length,n=n?n<0?Math.max(0,i+n):n:0;n<i;n++)if(n in e&&e[n]===t)return n}return-1},merge:function(t,e){for(var n=+e.length,i=0,s=t.length;i<n;)t[s++]=e[i++];if(n!=n)for(;void 0!==e[i];)t[s++]=e[i++];return t.length=s,t},grep:function(t,e,n){for(var i=[],s=0,r=t.length,o=!n;s<r;s++)!e(t[s],s)!=o&&i.push(t[s]);return i},map:function(t,e,n){var i,s,r=0,o=[];if(h(t))for(i=t.length;r<i;r++)null!=(s=e(t[r],r,n))&&o.push(s);else for(r in t)null!=(s=e(t[r],r,n))&&o.push(s);return g.apply([],o)},guid:1,proxy:function(t,e){var n,i,s;if("string"==typeof e&&(s=t[e],e=t,t=s),k.isFunction(t))return n=u.call(arguments,2),(i=function(){return t.apply(e||this,n.concat(u.call(arguments)))}).guid=t.guid=t.guid||k.guid++,i},now:function(){return+new Date},support:y}),"function"==typeof Symbol&&(k.fn[Symbol.iterator]=d[Symbol.iterator]),k.each("Boolean Number String Function Array Date RegExp Object Error Symbol".split(" "),function(t,e){n["[object "+e+"]"]=e.toLowerCase()});var p=function(n){function d(t,e,n){var i="0x"+e-65536;return i!=i||n?e:i<0?String.fromCharCode(65536+i):String.fromCharCode(i>>10|55296,1023&i|56320)}function s(){x()}var t,f,_,r,o,g,h,m,w,l,c,x,C,a,k,y,u,p,v,S="sizzle"+ +new Date,b=n.document,T=0,i=0,D=st(),E=st(),N=st(),$=function(t,e){return t===e&&(c=!0),0},A={}.hasOwnProperty,e=[],M=e.pop,I=e.push,O=e.push,P=e.slice,R=function(t,e){for(var n=0,i=t.length;n<i;n++)if(t[n]===e)return n;return-1},L="checked|selected|async|autofocus|autoplay|controls|defer|disabled|hidden|ismap|loop|multiple|open|readonly|required|scoped",j="[\\x20\\t\\r\\n\\f]",H="(?:\\\\.|[\\w-]|[^\\x00-\\xa0])+",F="\\["+j+"*("+H+")(?:"+j+"*([*^$|!~]?=)"+j+"*(?:'((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\"|("+H+"))|)"+j+"*\\]",W=":("+H+")(?:\\((('((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\")|((?:\\\\.|[^\\\\()[\\]]|"+F+")*)|.*)\\)|)",Y=new RegExp(j+"+","g"),q=new RegExp("^"+j+"+|((?:^|[^\\\\])(?:\\\\.)*)"+j+"+$","g"),z=new RegExp("^"+j+"*,"+j+"*"),B=new RegExp("^"+j+"*([>+~]|"+j+")"+j+"*"),V=new RegExp("="+j+"*([^\\]'\"]*?)"+j+"*\\]","g"),U=new RegExp(W),G=new RegExp("^"+H+"$"),Q={ID:new RegExp("^#("+H+")"),CLASS:new RegExp("^\\.("+H+")"),TAG:new RegExp("^("+H+"|[*])"),ATTR:new RegExp("^"+F),PSEUDO:new RegExp("^"+W),CHILD:new RegExp("^:(only|first|last|nth|nth-last)-(child|of-type)(?:\\("+j+"*(even|odd|(([+-]|)(\\d*)n|)"+j+"*(?:([+-]|)"+j+"*(\\d+)|))"+j+"*\\)|)","i"),bool:new RegExp("^(?:"+L+")$","i"),needsContext:new RegExp("^"+j+"*[>+~]|:(even|odd|eq|gt|lt|nth|first|last)(?:\\("+j+"*((?:-\\d)?\\d*)"+j+"*\\)|)(?=[^-]|$)","i")},K=/^(?:input|select|textarea|button)$/i,X=/^h\d$/i,Z=/^[^{]+\{\s*\[native \w/,J=/^(?:#([\w-]+)|(\w+)|\.([\w-]+))$/,tt=/[+~]/,et=/'|\\/g,nt=new RegExp("\\\\([\\da-f]{1,6}"+j+"?|("+j+")|.)","ig");try{O.apply(e=P.call(b.childNodes),b.childNodes),e[b.childNodes.length].nodeType}catch(t){O={apply:e.length?function(t,e){I.apply(t,P.call(e))}:function(t,e){for(var n=t.length,i=0;t[n++]=e[i++];);t.length=n-1}}}function it(t,e,n,i){var s,r,o,a,l,c,u,d,h=e&&e.ownerDocument,p=e?e.nodeType:9;if(n=n||[],"string"!=typeof t||!t||1!==p&&9!==p&&11!==p)return n;if(!i&&((e?e.ownerDocument||e:b)!==C&&x(e),e=e||C,k)){if(11!==p&&(c=J.exec(t)))if(s=c[1]){if(9===p){if(!(o=e.getElementById(s)))return n;if(o.id===s)return n.push(o),n}else if(h&&(o=h.getElementById(s))&&v(e,o)&&o.id===s)return n.push(o),n}else{if(c[2])return O.apply(n,e.getElementsByTagName(t)),n;if((s=c[3])&&f.getElementsByClassName&&e.getElementsByClassName)return O.apply(n,e.getElementsByClassName(s)),n}if(f.qsa&&!N[t+" "]&&(!y||!y.test(t))){if(1!==p)h=e,d=t;else if("object"!==e.nodeName.toLowerCase()){for((a=e.getAttribute("id"))?a=a.replace(et,"\\$&"):e.setAttribute("id",a=S),r=(u=g(t)).length,l=G.test(a)?"#"+a:"[id='"+a+"']";r--;)u[r]=l+" "+ht(u[r]);d=u.join(","),h=tt.test(t)&&ut(e.parentNode)||e}if(d)try{return O.apply(n,h.querySelectorAll(d)),n}catch(t){}finally{a===S&&e.removeAttribute("id")}}}return m(t.replace(q,"$1"),e,n,i)}function st(){var n=[];function i(t,e){return n.push(t+" ")>_.cacheLength&&delete i[n.shift()],i[t+" "]=e}return i}function rt(t){return t[S]=!0,t}function ot(t){var e=C.createElement("div");try{return!!t(e)}catch(t){return!1}finally{e.parentNode&&e.parentNode.removeChild(e),e=null}}function at(t,e){for(var n=t.split("|"),i=n.length;i--;)_.attrHandle[n[i]]=e}function lt(t,e){var n=e&&t,i=n&&1===t.nodeType&&1===e.nodeType&&(~e.sourceIndex||1<<31)-(~t.sourceIndex||1<<31);if(i)return i;if(n)for(;n=n.nextSibling;)if(n===e)return-1;return t?1:-1}function ct(o){return rt(function(r){return r=+r,rt(function(t,e){for(var n,i=o([],t.length,r),s=i.length;s--;)t[n=i[s]]&&(t[n]=!(e[n]=t[n]))})})}function ut(t){return t&&void 0!==t.getElementsByTagName&&t}for(t in f=it.support={},o=it.isXML=function(t){var e=t&&(t.ownerDocument||t).documentElement;return!!e&&"HTML"!==e.nodeName},x=it.setDocument=function(t){var e,n,i=t?t.ownerDocument||t:b;return i!==C&&9===i.nodeType&&i.documentElement&&(a=(C=i).documentElement,k=!o(C),(n=C.defaultView)&&n.top!==n&&(n.addEventListener?n.addEventListener("unload",s,!1):n.attachEvent&&n.attachEvent("onunload",s)),f.attributes=ot(function(t){return t.className="i",!t.getAttribute("className")}),f.getElementsByTagName=ot(function(t){return t.appendChild(C.createComment("")),!t.getElementsByTagName("*").length}),f.getElementsByClassName=Z.test(C.getElementsByClassName),f.getById=ot(function(t){return a.appendChild(t).id=S,!C.getElementsByName||!C.getElementsByName(S).length}),f.getById?(_.find.ID=function(t,e){if(void 0!==e.getElementById&&k){var n=e.getElementById(t);return n?[n]:[]}},_.filter.ID=function(t){var e=t.replace(nt,d);return function(t){return t.getAttribute("id")===e}}):(delete _.find.ID,_.filter.ID=function(t){var n=t.replace(nt,d);return function(t){var e=void 0!==t.getAttributeNode&&t.getAttributeNode("id");return e&&e.value===n}}),_.find.TAG=f.getElementsByTagName?function(t,e){return void 0!==e.getElementsByTagName?e.getElementsByTagName(t):f.qsa?e.querySelectorAll(t):void 0}:function(t,e){var n,i=[],s=0,r=e.getElementsByTagName(t);if("*"!==t)return r;for(;n=r[s++];)1===n.nodeType&&i.push(n);return i},_.find.CLASS=f.getElementsByClassName&&function(t,e){if(void 0!==e.getElementsByClassName&&k)return e.getElementsByClassName(t)},u=[],y=[],(f.qsa=Z.test(C.querySelectorAll))&&(ot(function(t){a.appendChild(t).innerHTML="<a id='"+S+"'></a><select id='"+S+"-\r\\' msallowcapture=''><option selected=''></option></select>",t.querySelectorAll("[msallowcapture^='']").length&&y.push("[*^$]="+j+"*(?:''|\"\")"),t.querySelectorAll("[selected]").length||y.push("\\["+j+"*(?:value|"+L+")"),t.querySelectorAll("[id~="+S+"-]").length||y.push("~="),t.querySelectorAll(":checked").length||y.push(":checked"),t.querySelectorAll("a#"+S+"+*").length||y.push(".#.+[+~]")}),ot(function(t){var e=C.createElement("input");e.setAttribute("type","hidden"),t.appendChild(e).setAttribute("name","D"),t.querySelectorAll("[name=d]").length&&y.push("name"+j+"*[*^$|!~]?="),t.querySelectorAll(":enabled").length||y.push(":enabled",":disabled"),t.querySelectorAll("*,:x"),y.push(",.*:")})),(f.matchesSelector=Z.test(p=a.matches||a.webkitMatchesSelector||a.mozMatchesSelector||a.oMatchesSelector||a.msMatchesSelector))&&ot(function(t){f.disconnectedMatch=p.call(t,"div"),p.call(t,"[s!='']:x"),u.push("!=",W)}),y=y.length&&new RegExp(y.join("|")),u=u.length&&new RegExp(u.join("|")),e=Z.test(a.compareDocumentPosition),v=e||Z.test(a.contains)?function(t,e){var n=9===t.nodeType?t.documentElement:t,i=e&&e.parentNode;return t===i||!(!i||1!==i.nodeType||!(n.contains?n.contains(i):t.compareDocumentPosition&&16&t.compareDocumentPosition(i)))}:function(t,e){if(e)for(;e=e.parentNode;)if(e===t)return!0;return!1},$=e?function(t,e){if(t===e)return c=!0,0;var n=!t.compareDocumentPosition-!e.compareDocumentPosition;return n||(1&(n=(t.ownerDocument||t)===(e.ownerDocument||e)?t.compareDocumentPosition(e):1)||!f.sortDetached&&e.compareDocumentPosition(t)===n?t===C||t.ownerDocument===b&&v(b,t)?-1:e===C||e.ownerDocument===b&&v(b,e)?1:l?R(l,t)-R(l,e):0:4&n?-1:1)}:function(t,e){if(t===e)return c=!0,0;var n,i=0,s=t.parentNode,r=e.parentNode,o=[t],a=[e];if(!s||!r)return t===C?-1:e===C?1:s?-1:r?1:l?R(l,t)-R(l,e):0;if(s===r)return lt(t,e);for(n=t;n=n.parentNode;)o.unshift(n);for(n=e;n=n.parentNode;)a.unshift(n);for(;o[i]===a[i];)i++;return i?lt(o[i],a[i]):o[i]===b?-1:a[i]===b?1:0}),C},it.matches=function(t,e){return it(t,null,null,e)},it.matchesSelector=function(t,e){if((t.ownerDocument||t)!==C&&x(t),e=e.replace(V,"='$1']"),f.matchesSelector&&k&&!N[e+" "]&&(!u||!u.test(e))&&(!y||!y.test(e)))try{var n=p.call(t,e);if(n||f.disconnectedMatch||t.document&&11!==t.document.nodeType)return n}catch(t){}return 0<it(e,C,null,[t]).length},it.contains=function(t,e){return(t.ownerDocument||t)!==C&&x(t),v(t,e)},it.attr=function(t,e){(t.ownerDocument||t)!==C&&x(t);var n=_.attrHandle[e.toLowerCase()],i=n&&A.call(_.attrHandle,e.toLowerCase())?n(t,e,!k):void 0;return void 0!==i?i:f.attributes||!k?t.getAttribute(e):(i=t.getAttributeNode(e))&&i.specified?i.value:null},it.error=function(t){throw new Error("Syntax error, unrecognized expression: "+t)},it.uniqueSort=function(t){var e,n=[],i=0,s=0;if(c=!f.detectDuplicates,l=!f.sortStable&&t.slice(0),t.sort($),c){for(;e=t[s++];)e===t[s]&&(i=n.push(s));for(;i--;)t.splice(n[i],1)}return l=null,t},r=it.getText=function(t){var e,n="",i=0,s=t.nodeType;if(s){if(1===s||9===s||11===s){if("string"==typeof t.textContent)return t.textContent;for(t=t.firstChild;t;t=t.nextSibling)n+=r(t)}else if(3===s||4===s)return t.nodeValue}else for(;e=t[i++];)n+=r(e);return n},(_=it.selectors={cacheLength:50,createPseudo:rt,match:Q,attrHandle:{},find:{},relative:{">":{dir:"parentNode",first:!0}," ":{dir:"parentNode"},"+":{dir:"previousSibling",first:!0},"~":{dir:"previousSibling"}},preFilter:{ATTR:function(t){return t[1]=t[1].replace(nt,d),t[3]=(t[3]||t[4]||t[5]||"").replace(nt,d),"~="===t[2]&&(t[3]=" "+t[3]+" "),t.slice(0,4)},CHILD:function(t){return t[1]=t[1].toLowerCase(),"nth"===t[1].slice(0,3)?(t[3]||it.error(t[0]),t[4]=+(t[4]?t[5]+(t[6]||1):2*("even"===t[3]||"odd"===t[3])),t[5]=+(t[7]+t[8]||"odd"===t[3])):t[3]&&it.error(t[0]),t},PSEUDO:function(t){var e,n=!t[6]&&t[2];return Q.CHILD.test(t[0])?null:(t[3]?t[2]=t[4]||t[5]||"":n&&U.test(n)&&(e=g(n,!0))&&(e=n.indexOf(")",n.length-e)-n.length)&&(t[0]=t[0].slice(0,e),t[2]=n.slice(0,e)),t.slice(0,3))}},filter:{TAG:function(t){var e=t.replace(nt,d).toLowerCase();return"*"===t?function(){return!0}:function(t){return t.nodeName&&t.nodeName.toLowerCase()===e}},CLASS:function(t){var e=D[t+" "];return e||(e=new RegExp("(^|"+j+")"+t+"("+j+"|$)"))&&D(t,function(t){return e.test("string"==typeof t.className&&t.className||void 0!==t.getAttribute&&t.getAttribute("class")||"")})},ATTR:function(n,i,s){return function(t){var e=it.attr(t,n);return null==e?"!="===i:!i||(e+="","="===i?e===s:"!="===i?e!==s:"^="===i?s&&0===e.indexOf(s):"*="===i?s&&-1<e.indexOf(s):"$="===i?s&&e.slice(-s.length)===s:"~="===i?-1<(" "+e.replace(Y," ")+" ").indexOf(s):"|="===i&&(e===s||e.slice(0,s.length+1)===s+"-"))}},CHILD:function(f,t,e,g,m){var y="nth"!==f.slice(0,3),v="last"!==f.slice(-4),b="of-type"===t;return 1===g&&0===m?function(t){return!!t.parentNode}:function(t,e,n){var i,s,r,o,a,l,c=y!=v?"nextSibling":"previousSibling",u=t.parentNode,d=b&&t.nodeName.toLowerCase(),h=!n&&!b,p=!1;if(u){if(y){for(;c;){for(o=t;o=o[c];)if(b?o.nodeName.toLowerCase()===d:1===o.nodeType)return!1;l=c="only"===f&&!l&&"nextSibling"}return!0}if(l=[v?u.firstChild:u.lastChild],v&&h){for(p=(a=(i=(s=(r=(o=u)[S]||(o[S]={}))[o.uniqueID]||(r[o.uniqueID]={}))[f]||[])[0]===T&&i[1])&&i[2],o=a&&u.childNodes[a];o=++a&&o&&o[c]||(p=a=0)||l.pop();)if(1===o.nodeType&&++p&&o===t){s[f]=[T,a,p];break}}else if(h&&(p=a=(i=(s=(r=(o=t)[S]||(o[S]={}))[o.uniqueID]||(r[o.uniqueID]={}))[f]||[])[0]===T&&i[1]),!1===p)for(;(o=++a&&o&&o[c]||(p=a=0)||l.pop())&&((b?o.nodeName.toLowerCase()!==d:1!==o.nodeType)||!++p||(h&&((s=(r=o[S]||(o[S]={}))[o.uniqueID]||(r[o.uniqueID]={}))[f]=[T,p]),o!==t)););return(p-=m)===g||p%g==0&&0<=p/g}}},PSEUDO:function(t,r){var e,o=_.pseudos[t]||_.setFilters[t.toLowerCase()]||it.error("unsupported pseudo: "+t);return o[S]?o(r):1<o.length?(e=[t,t,"",r],_.setFilters.hasOwnProperty(t.toLowerCase())?rt(function(t,e){for(var n,i=o(t,r),s=i.length;s--;)t[n=R(t,i[s])]=!(e[n]=i[s])}):function(t){return o(t,0,e)}):o}},pseudos:{not:rt(function(t){var i=[],s=[],a=h(t.replace(q,"$1"));return a[S]?rt(function(t,e,n,i){for(var s,r=a(t,null,i,[]),o=t.length;o--;)(s=r[o])&&(t[o]=!(e[o]=s))}):function(t,e,n){return i[0]=t,a(i,null,n,s),i[0]=null,!s.pop()}}),has:rt(function(e){return function(t){return 0<it(e,t).length}}),contains:rt(function(e){return e=e.replace(nt,d),function(t){return-1<(t.textContent||t.innerText||r(t)).indexOf(e)}}),lang:rt(function(n){return G.test(n||"")||it.error("unsupported lang: "+n),n=n.replace(nt,d).toLowerCase(),function(t){var e;do{if(e=k?t.lang:t.getAttribute("xml:lang")||t.getAttribute("lang"))return(e=e.toLowerCase())===n||0===e.indexOf(n+"-")}while((t=t.parentNode)&&1===t.nodeType);return!1}}),target:function(t){var e=n.location&&n.location.hash;return e&&e.slice(1)===t.id},root:function(t){return t===a},focus:function(t){return t===C.activeElement&&(!C.hasFocus||C.hasFocus())&&!!(t.type||t.href||~t.tabIndex)},enabled:function(t){return!1===t.disabled},disabled:function(t){return!0===t.disabled},checked:function(t){var e=t.nodeName.toLowerCase();return"input"===e&&!!t.checked||"option"===e&&!!t.selected},selected:function(t){return t.parentNode&&t.parentNode.selectedIndex,!0===t.selected},empty:function(t){for(t=t.firstChild;t;t=t.nextSibling)if(t.nodeType<6)return!1;return!0},parent:function(t){return!_.pseudos.empty(t)},header:function(t){return X.test(t.nodeName)},input:function(t){return K.test(t.nodeName)},button:function(t){var e=t.nodeName.toLowerCase();return"input"===e&&"button"===t.type||"button"===e},text:function(t){var e;return"input"===t.nodeName.toLowerCase()&&"text"===t.type&&(null==(e=t.getAttribute("type"))||"text"===e.toLowerCase())},first:ct(function(){return[0]}),last:ct(function(t,e){return[e-1]}),eq:ct(function(t,e,n){return[n<0?n+e:n]}),even:ct(function(t,e){for(var n=0;n<e;n+=2)t.push(n);return t}),odd:ct(function(t,e){for(var n=1;n<e;n+=2)t.push(n);return t}),lt:ct(function(t,e,n){for(var i=n<0?n+e:n;0<=--i;)t.push(i);return t}),gt:ct(function(t,e,n){for(var i=n<0?n+e:n;++i<e;)t.push(i);return t})}}).pseudos.nth=_.pseudos.eq,{radio:!0,checkbox:!0,file:!0,password:!0,image:!0})_.pseudos[t]=function(e){return function(t){return"input"===t.nodeName.toLowerCase()&&t.type===e}}(t);for(t in{submit:!0,reset:!0})_.pseudos[t]=function(n){return function(t){var e=t.nodeName.toLowerCase();return("input"===e||"button"===e)&&t.type===n}}(t);function dt(){}function ht(t){for(var e=0,n=t.length,i="";e<n;e++)i+=t[e].value;return i}function pt(a,t,e){var l=t.dir,c=e&&"parentNode"===l,u=i++;return t.first?function(t,e,n){for(;t=t[l];)if(1===t.nodeType||c)return a(t,e,n)}:function(t,e,n){var i,s,r,o=[T,u];if(n){for(;t=t[l];)if((1===t.nodeType||c)&&a(t,e,n))return!0}else for(;t=t[l];)if(1===t.nodeType||c){if((i=(s=(r=t[S]||(t[S]={}))[t.uniqueID]||(r[t.uniqueID]={}))[l])&&i[0]===T&&i[1]===u)return o[2]=i[2];if((s[l]=o)[2]=a(t,e,n))return!0}}}function ft(s){return 1<s.length?function(t,e,n){for(var i=s.length;i--;)if(!s[i](t,e,n))return!1;return!0}:s[0]}function gt(t,e,n,i,s){for(var r,o=[],a=0,l=t.length,c=null!=e;a<l;a++)(r=t[a])&&(n&&!n(r,i,s)||(o.push(r),c&&e.push(a)));return o}function mt(p,f,g,m,y,t){return m&&!m[S]&&(m=mt(m)),y&&!y[S]&&(y=mt(y,t)),rt(function(t,e,n,i){var s,r,o,a=[],l=[],c=e.length,u=t||function(t,e,n){for(var i=0,s=e.length;i<s;i++)it(t,e[i],n);return n}(f||"*",n.nodeType?[n]:n,[]),d=!p||!t&&f?u:gt(u,a,p,n,i),h=g?y||(t?p:c||m)?[]:e:d;if(g&&g(d,h,n,i),m)for(s=gt(h,l),m(s,[],n,i),r=s.length;r--;)(o=s[r])&&(h[l[r]]=!(d[l[r]]=o));if(t){if(y||p){if(y){for(s=[],r=h.length;r--;)(o=h[r])&&s.push(d[r]=o);y(null,h=[],s,i)}for(r=h.length;r--;)(o=h[r])&&-1<(s=y?R(t,o):a[r])&&(t[s]=!(e[s]=o))}}else h=gt(h===e?h.splice(c,h.length):h),y?y(null,e,h,i):O.apply(e,h)})}function yt(m,y){function t(t,e,n,i,s){var r,o,a,l=0,c="0",u=t&&[],d=[],h=w,p=t||b&&_.find.TAG("*",s),f=T+=null==h?1:Math.random()||.1,g=p.length;for(s&&(w=e===C||e||s);c!==g&&null!=(r=p[c]);c++){if(b&&r){for(o=0,e||r.ownerDocument===C||(x(r),n=!k);a=m[o++];)if(a(r,e||C,n)){i.push(r);break}s&&(T=f)}v&&((r=!a&&r)&&l--,t&&u.push(r))}if(l+=c,v&&c!==l){for(o=0;a=y[o++];)a(u,d,e,n);if(t){if(0<l)for(;c--;)u[c]||d[c]||(d[c]=M.call(i));d=gt(d)}O.apply(i,d),s&&!t&&0<d.length&&1<l+y.length&&it.uniqueSort(i)}return s&&(T=f,w=h),u}var v=0<y.length,b=0<m.length;return v?rt(t):t}return dt.prototype=_.filters=_.pseudos,_.setFilters=new dt,g=it.tokenize=function(t,e){var n,i,s,r,o,a,l,c=E[t+" "];if(c)return e?0:c.slice(0);for(o=t,a=[],l=_.preFilter;o;){for(r in n&&!(i=z.exec(o))||(i&&(o=o.slice(i[0].length)||o),a.push(s=[])),n=!1,(i=B.exec(o))&&(n=i.shift(),s.push({value:n,type:i[0].replace(q," ")}),o=o.slice(n.length)),_.filter)!(i=Q[r].exec(o))||l[r]&&!(i=l[r](i))||(n=i.shift(),s.push({value:n,type:r,matches:i}),o=o.slice(n.length));if(!n)break}return e?o.length:o?it.error(t):E(t,a).slice(0)},h=it.compile=function(t,e){var n,i=[],s=[],r=N[t+" "];if(!r){for(n=(e=e||g(t)).length;n--;)(r=function t(e){for(var s,n,i,r=e.length,o=_.relative[e[0].type],a=o||_.relative[" "],l=o?1:0,c=pt(function(t){return t===s},a,!0),u=pt(function(t){return-1<R(s,t)},a,!0),d=[function(t,e,n){var i=!o&&(n||e!==w)||((s=e).nodeType?c:u)(t,e,n);return s=null,i}];l<r;l++)if(n=_.relative[e[l].type])d=[pt(ft(d),n)];else{if((n=_.filter[e[l].type].apply(null,e[l].matches))[S]){for(i=++l;i<r&&!_.relative[e[i].type];i++);return mt(1<l&&ft(d),1<l&&ht(e.slice(0,l-1).concat({value:" "===e[l-2].type?"*":""})).replace(q,"$1"),n,l<i&&t(e.slice(l,i)),i<r&&t(e=e.slice(i)),i<r&&ht(e))}d.push(n)}return ft(d)}(e[n]))[S]?i.push(r):s.push(r);(r=N(t,yt(s,i))).selector=t}return r},m=it.select=function(t,e,n,i){var s,r,o,a,l,c="function"==typeof t&&t,u=!i&&g(t=c.selector||t);if(n=n||[],1===u.length){if(2<(r=u[0]=u[0].slice(0)).length&&"ID"===(o=r[0]).type&&f.getById&&9===e.nodeType&&k&&_.relative[r[1].type]){if(!(e=(_.find.ID(o.matches[0].replace(nt,d),e)||[])[0]))return n;c&&(e=e.parentNode),t=t.slice(r.shift().value.length)}for(s=Q.needsContext.test(t)?0:r.length;s--&&(o=r[s],!_.relative[a=o.type]);)if((l=_.find[a])&&(i=l(o.matches[0].replace(nt,d),tt.test(r[0].type)&&ut(e.parentNode)||e))){if(r.splice(s,1),!(t=i.length&&ht(r)))return O.apply(n,i),n;break}}return(c||h(t,u))(i,e,!k,n,!e||tt.test(t)&&ut(e.parentNode)||e),n},f.sortStable=S.split("").sort($).join("")===S,f.detectDuplicates=!!c,x(),f.sortDetached=ot(function(t){return 1&t.compareDocumentPosition(C.createElement("div"))}),ot(function(t){return t.innerHTML="<a href='#'></a>","#"===t.firstChild.getAttribute("href")})||at("type|href|height|width",function(t,e,n){if(!n)return t.getAttribute(e,"type"===e.toLowerCase()?1:2)}),f.attributes&&ot(function(t){return t.innerHTML="<input/>",t.firstChild.setAttribute("value",""),""===t.firstChild.getAttribute("value")})||at("value",function(t,e,n){if(!n&&"input"===t.nodeName.toLowerCase())return t.defaultValue}),ot(function(t){return null==t.getAttribute("disabled")})||at(L,function(t,e,n){var i;if(!n)return!0===t[e]?e.toLowerCase():(i=t.getAttributeNode(e))&&i.specified?i.value:null}),it}(C);k.find=p,k.expr=p.selectors,k.expr[":"]=k.expr.pseudos,k.uniqueSort=k.unique=p.uniqueSort,k.text=p.getText,k.isXMLDoc=p.isXML,k.contains=p.contains;function v(t,e,n){for(var i=[],s=void 0!==n;(t=t[e])&&9!==t.nodeType;)if(1===t.nodeType){if(s&&k(t).is(n))break;i.push(t)}return i}function b(t,e){for(var n=[];t;t=t.nextSibling)1===t.nodeType&&t!==e&&n.push(t);return n}var _=k.expr.match.needsContext,w=/^<([\w-]+)\s*\/?>(?:<\/\1>|)$/,x=/^.[^:#\[\.,]*$/;function S(t,n,i){if(k.isFunction(n))return k.grep(t,function(t,e){return!!n.call(t,e,t)!==i});if(n.nodeType)return k.grep(t,function(t){return t===n!==i});if("string"==typeof n){if(x.test(n))return k.filter(n,t,i);n=k.filter(n,t)}return k.grep(t,function(t){return-1<k.inArray(t,n)!==i})}k.filter=function(t,e,n){var i=e[0];return n&&(t=":not("+t+")"),1===e.length&&1===i.nodeType?k.find.matchesSelector(i,t)?[i]:[]:k.find.matches(t,k.grep(e,function(t){return 1===t.nodeType}))},k.fn.extend({find:function(t){var e,n=[],i=this,s=i.length;if("string"!=typeof t)return this.pushStack(k(t).filter(function(){for(e=0;e<s;e++)if(k.contains(i[e],this))return!0}));for(e=0;e<s;e++)k.find(t,i[e],n);return(n=this.pushStack(1<s?k.unique(n):n)).selector=this.selector?this.selector+" "+t:t,n},filter:function(t){return this.pushStack(S(this,t||[],!1))},not:function(t){return this.pushStack(S(this,t||[],!0))},is:function(t){return!!S(this,"string"==typeof t&&_.test(t)?k(t):t||[],!1).length}});var T,D=/^(?:\s*(<[\w\W]+>)[^>]*|#([\w-]*))$/;(k.fn.init=function(t,e,n){var i,s;if(!t)return this;if(n=n||T,"string"!=typeof t)return t.nodeType?(this.context=this[0]=t,this.length=1,this):k.isFunction(t)?void 0!==n.ready?n.ready(t):t(k):(void 0!==t.selector&&(this.selector=t.selector,this.context=t.context),k.makeArray(t,this));if(!(i="<"===t.charAt(0)&&">"===t.charAt(t.length-1)&&3<=t.length?[null,t,null]:D.exec(t))||!i[1]&&e)return!e||e.jquery?(e||n).find(t):this.constructor(e).find(t);if(i[1]){if(e=e instanceof k?e[0]:e,k.merge(this,k.parseHTML(i[1],e&&e.nodeType?e.ownerDocument||e:f,!0)),w.test(i[1])&&k.isPlainObject(e))for(i in e)k.isFunction(this[i])?this[i](e[i]):this.attr(i,e[i]);return this}if((s=f.getElementById(i[2]))&&s.parentNode){if(s.id!==i[2])return T.find(t);this.length=1,this[0]=s}return this.context=f,this.selector=t,this}).prototype=k.fn,T=k(f);var E=/^(?:parents|prev(?:Until|All))/,N={children:!0,contents:!0,next:!0,prev:!0};function $(t,e){for(;(t=t[e])&&1!==t.nodeType;);return t}k.fn.extend({has:function(t){var e,n=k(t,this),i=n.length;return this.filter(function(){for(e=0;e<i;e++)if(k.contains(this,n[e]))return!0})},closest:function(t,e){for(var n,i=0,s=this.length,r=[],o=_.test(t)||"string"!=typeof t?k(t,e||this.context):0;i<s;i++)for(n=this[i];n&&n!==e;n=n.parentNode)if(n.nodeType<11&&(o?-1<o.index(n):1===n.nodeType&&k.find.matchesSelector(n,t))){r.push(n);break}return this.pushStack(1<r.length?k.uniqueSort(r):r)},index:function(t){return t?"string"==typeof t?k.inArray(this[0],k(t)):k.inArray(t.jquery?t[0]:t,this):this[0]&&this[0].parentNode?this.first().prevAll().length:-1},add:function(t,e){return this.pushStack(k.uniqueSort(k.merge(this.get(),k(t,e))))},addBack:function(t){return this.add(null==t?this.prevObject:this.prevObject.filter(t))}}),k.each({parent:function(t){var e=t.parentNode;return e&&11!==e.nodeType?e:null},parents:function(t){return v(t,"parentNode")},parentsUntil:function(t,e,n){return v(t,"parentNode",n)},next:function(t){return $(t,"nextSibling")},prev:function(t){return $(t,"previousSibling")},nextAll:function(t){return v(t,"nextSibling")},prevAll:function(t){return v(t,"previousSibling")},nextUntil:function(t,e,n){return v(t,"nextSibling",n)},prevUntil:function(t,e,n){return v(t,"previousSibling",n)},siblings:function(t){return b((t.parentNode||{}).firstChild,t)},children:function(t){return b(t.firstChild)},contents:function(t){return k.nodeName(t,"iframe")?t.contentDocument||t.contentWindow.document:k.merge([],t.childNodes)}},function(i,s){k.fn[i]=function(t,e){var n=k.map(this,s,t);return"Until"!==i.slice(-5)&&(e=t),e&&"string"==typeof e&&(n=k.filter(e,n)),1<this.length&&(N[i]||(n=k.uniqueSort(n)),E.test(i)&&(n=n.reverse())),this.pushStack(n)}});var A,M,I=/\S+/g;function O(){f.addEventListener?(f.removeEventListener("DOMContentLoaded",P),C.removeEventListener("load",P)):(f.detachEvent("onreadystatechange",P),C.detachEvent("onload",P))}function P(){!f.addEventListener&&"load"!==C.event.type&&"complete"!==f.readyState||(O(),k.ready())}for(M in k.Callbacks=function(i){var t,n;i="string"==typeof i?(t=i,n={},k.each(t.match(I)||[],function(t,e){n[e]=!0}),n):k.extend({},i);function s(){for(a=i.once,o=r=!0;c.length;u=-1)for(e=c.shift();++u<l.length;)!1===l[u].apply(e[0],e[1])&&i.stopOnFalse&&(u=l.length,e=!1);i.memory||(e=!1),r=!1,a&&(l=e?[]:"")}var r,e,o,a,l=[],c=[],u=-1,d={add:function(){return l&&(e&&!r&&(u=l.length-1,c.push(e)),function n(t){k.each(t,function(t,e){k.isFunction(e)?i.unique&&d.has(e)||l.push(e):e&&e.length&&"string"!==k.type(e)&&n(e)})}(arguments),e&&!r&&s()),this},remove:function(){return k.each(arguments,function(t,e){for(var n;-1<(n=k.inArray(e,l,n));)l.splice(n,1),n<=u&&u--}),this},has:function(t){return t?-1<k.inArray(t,l):0<l.length},empty:function(){return l=l&&[],this},disable:function(){return a=c=[],l=e="",this},disabled:function(){return!l},lock:function(){return a=!0,e||d.disable(),this},locked:function(){return!!a},fireWith:function(t,e){return a||(e=[t,(e=e||[]).slice?e.slice():e],c.push(e),r||s()),this},fire:function(){return d.fireWith(this,arguments),this},fired:function(){return!!o}};return d},k.extend({Deferred:function(t){var r=[["resolve","done",k.Callbacks("once memory"),"resolved"],["reject","fail",k.Callbacks("once memory"),"rejected"],["notify","progress",k.Callbacks("memory")]],s="pending",o={state:function(){return s},always:function(){return a.done(arguments).fail(arguments),this},then:function(){var s=arguments;return k.Deferred(function(i){k.each(r,function(t,e){var n=k.isFunction(s[t])&&s[t];a[e[1]](function(){var t=n&&n.apply(this,arguments);t&&k.isFunction(t.promise)?t.promise().progress(i.notify).done(i.resolve).fail(i.reject):i[e[0]+"With"](this===o?i.promise():this,n?[t]:arguments)})}),s=null}).promise()},promise:function(t){return null!=t?k.extend(t,o):o}},a={};return o.pipe=o.then,k.each(r,function(t,e){var n=e[2],i=e[3];o[e[1]]=n.add,i&&n.add(function(){s=i},r[1^t][2].disable,r[2][2].lock),a[e[0]]=function(){return a[e[0]+"With"](this===a?o:this,arguments),this},a[e[0]+"With"]=n.fireWith}),o.promise(a),t&&t.call(a,a),a},when:function(t){function e(e,n,i){return function(t){n[e]=this,i[e]=1<arguments.length?u.call(arguments):t,i===s?c.notifyWith(n,i):--l||c.resolveWith(n,i)}}var s,n,i,r=0,o=u.call(arguments),a=o.length,l=1!==a||t&&k.isFunction(t.promise)?a:0,c=1===l?t:k.Deferred();if(1<a)for(s=new Array(a),n=new Array(a),i=new Array(a);r<a;r++)o[r]&&k.isFunction(o[r].promise)?o[r].promise().progress(e(r,n,s)).done(e(r,i,o)).fail(c.reject):--l;return l||c.resolveWith(i,o),c.promise()}}),k.fn.ready=function(t){return k.ready.promise().done(t),this},k.extend({isReady:!1,readyWait:1,holdReady:function(t){t?k.readyWait++:k.ready(!0)},ready:function(t){(!0===t?--k.readyWait:k.isReady)||(k.isReady=!0)!==t&&0<--k.readyWait||(A.resolveWith(f,[k]),k.fn.triggerHandler&&(k(f).triggerHandler("ready"),k(f).off("ready")))}}),k.ready.promise=function(t){if(!A)if(A=k.Deferred(),"complete"===f.readyState||"loading"!==f.readyState&&!f.documentElement.doScroll)C.setTimeout(k.ready);else if(f.addEventListener)f.addEventListener("DOMContentLoaded",P),C.addEventListener("load",P);else{f.attachEvent("onreadystatechange",P),C.attachEvent("onload",P);var n=!1;try{n=null==C.frameElement&&f.documentElement}catch(t){}n&&n.doScroll&&!function e(){if(!k.isReady){try{n.doScroll("left")}catch(t){return C.setTimeout(e,50)}O(),k.ready()}}()}return A.promise(t)},k.ready.promise(),k(y))break;y.ownFirst="0"===M,y.inlineBlockNeedsLayout=!1,k(function(){var t,e,n,i=f.getElementsByTagName("body")[0];i&&i.style&&(e=f.createElement("div"),(n=f.createElement("div")).style.cssText="position:absolute;border:0;width:0;height:0;top:0;left:-9999px",i.appendChild(n).appendChild(e),void 0!==e.style.zoom&&(e.style.cssText="display:inline;margin:0;border:0;padding:1px;width:1px;zoom:1",y.inlineBlockNeedsLayout=t=3===e.offsetWidth,t&&(i.style.zoom=1)),i.removeChild(n))}),function(){var t=f.createElement("div");y.deleteExpando=!0;try{delete t.test}catch(t){y.deleteExpando=!1}t=null}();function R(t){var e=k.noData[(t.nodeName+" ").toLowerCase()],n=+t.nodeType||1;return(1===n||9===n)&&(!e||!0!==e&&t.getAttribute("classid")===e)}var L,j=/^(?:\{[\w\W]*\}|\[[\w\W]*\])$/,H=/([A-Z])/g;function F(t,e,n){if(void 0===n&&1===t.nodeType){var i="data-"+e.replace(H,"-$1").toLowerCase();if("string"==typeof(n=t.getAttribute(i))){try{n="true"===n||"false"!==n&&("null"===n?null:+n+""===n?+n:j.test(n)?k.parseJSON(n):n)}catch(t){}k.data(t,e,n)}else n=void 0}return n}function W(t){var e;for(e in t)if(("data"!==e||!k.isEmptyObject(t[e]))&&"toJSON"!==e)return;return 1}function Y(t,e,n,i){if(R(t)){var s,r,o=k.expando,a=t.nodeType,l=a?k.cache:t,c=a?t[o]:t[o]&&o;if(c&&l[c]&&(i||l[c].data)||void 0!==n||"string"!=typeof e)return l[c=c||(a?t[o]=d.pop()||k.guid++:o)]||(l[c]=a?{}:{toJSON:k.noop}),"object"!=typeof e&&"function"!=typeof e||(i?l[c]=k.extend(l[c],e):l[c].data=k.extend(l[c].data,e)),r=l[c],i||(r.data||(r.data={}),r=r.data),void 0!==n&&(r[k.camelCase(e)]=n),"string"==typeof e?null==(s=r[e])&&(s=r[k.camelCase(e)]):s=r,s}}function q(t,e,n){if(R(t)){var i,s,r=t.nodeType,o=r?k.cache:t,a=r?t[k.expando]:k.expando;if(o[a]){if(e&&(i=n?o[a]:o[a].data)){s=(e=k.isArray(e)?e.concat(k.map(e,k.camelCase)):e in i||(e=k.camelCase(e))in i?[e]:e.split(" ")).length;for(;s--;)delete i[e[s]];if(n?!W(i):!k.isEmptyObject(i))return}(n||(delete o[a].data,W(o[a])))&&(r?k.cleanData([t],!0):y.deleteExpando||o!=o.window?delete o[a]:o[a]=void 0)}}}k.extend({cache:{},noData:{"applet ":!0,"embed ":!0,"object ":"clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"},hasData:function(t){return!!(t=t.nodeType?k.cache[t[k.expando]]:t[k.expando])&&!W(t)},data:function(t,e,n){return Y(t,e,n)},removeData:function(t,e){return q(t,e)},_data:function(t,e,n){return Y(t,e,n,!0)},_removeData:function(t,e){return q(t,e,!0)}}),k.fn.extend({data:function(t,e){var n,i,s,r=this[0],o=r&&r.attributes;if(void 0!==t)return"object"==typeof t?this.each(function(){k.data(this,t)}):1<arguments.length?this.each(function(){k.data(this,t,e)}):r?F(r,t,k.data(r,t)):void 0;if(this.length&&(s=k.data(r),1===r.nodeType&&!k._data(r,"parsedAttrs"))){for(n=o.length;n--;)o[n]&&0===(i=o[n].name).indexOf("data-")&&F(r,i=k.camelCase(i.slice(5)),s[i]);k._data(r,"parsedAttrs",!0)}return s},removeData:function(t){return this.each(function(){k.removeData(this,t)})}}),k.extend({queue:function(t,e,n){var i;if(t)return e=(e||"fx")+"queue",i=k._data(t,e),n&&(!i||k.isArray(n)?i=k._data(t,e,k.makeArray(n)):i.push(n)),i||[]},dequeue:function(t,e){e=e||"fx";var n=k.queue(t,e),i=n.length,s=n.shift(),r=k._queueHooks(t,e);"inprogress"===s&&(s=n.shift(),i--),s&&("fx"===e&&n.unshift("inprogress"),delete r.stop,s.call(t,function(){k.dequeue(t,e)},r)),!i&&r&&r.empty.fire()},_queueHooks:function(t,e){var n=e+"queueHooks";return k._data(t,n)||k._data(t,n,{empty:k.Callbacks("once memory").add(function(){k._removeData(t,e+"queue"),k._removeData(t,n)})})}}),k.fn.extend({queue:function(e,n){var t=2;return"string"!=typeof e&&(n=e,e="fx",t--),arguments.length<t?k.queue(this[0],e):void 0===n?this:this.each(function(){var t=k.queue(this,e,n);k._queueHooks(this,e),"fx"===e&&"inprogress"!==t[0]&&k.dequeue(this,e)})},dequeue:function(t){return this.each(function(){k.dequeue(this,t)})},clearQueue:function(t){return this.queue(t||"fx",[])},promise:function(t,e){function n(){--s||r.resolveWith(o,[o])}var i,s=1,r=k.Deferred(),o=this,a=this.length;for("string"!=typeof t&&(e=t,t=void 0),t=t||"fx";a--;)(i=k._data(o[a],t+"queueHooks"))&&i.empty&&(s++,i.empty.add(n));return n(),r.promise(e)}}),y.shrinkWrapBlocks=function(){return null!=L?L:(L=!1,(e=f.getElementsByTagName("body")[0])&&e.style?(t=f.createElement("div"),(n=f.createElement("div")).style.cssText="position:absolute;border:0;width:0;height:0;top:0;left:-9999px",e.appendChild(n).appendChild(t),void 0!==t.style.zoom&&(t.style.cssText="-webkit-box-sizing:content-box;-moz-box-sizing:content-box;box-sizing:content-box;display:block;margin:0;border:0;padding:1px;width:1px;zoom:1",t.appendChild(f.createElement("div")).style.width="5px",L=3!==t.offsetWidth),e.removeChild(n),L):void 0);var t,e,n};function z(t,e){return t=e||t,"none"===k.css(t,"display")||!k.contains(t.ownerDocument,t)}var B=/[+-]?(?:\d*\.|)\d+(?:[eE][+-]?\d+|)/.source,V=new RegExp("^(?:([+-])=|)("+B+")([a-z%]*)$","i"),U=["Top","Right","Bottom","Left"];function G(t,e,n,i){var s,r=1,o=20,a=i?function(){return i.cur()}:function(){return k.css(t,e,"")},l=a(),c=n&&n[3]||(k.cssNumber[e]?"":"px"),u=(k.cssNumber[e]||"px"!==c&&+l)&&V.exec(k.css(t,e));if(u&&u[3]!==c)for(c=c||u[3],n=n||[],u=+l||1;u/=r=r||".5",k.style(t,e,u+c),r!==(r=a()/l)&&1!==r&&--o;);return n&&(u=+u||+l||0,s=n[1]?u+(n[1]+1)*n[2]:+n[2],i&&(i.unit=c,i.start=u,i.end=s)),s}var Q,K,X,Z=function(t,e,n,i,s,r,o){var a=0,l=t.length,c=null==n;if("object"===k.type(n))for(a in s=!0,n)Z(t,e,a,n[a],!0,r,o);else if(void 0!==i&&(s=!0,k.isFunction(i)||(o=!0),c&&(e=o?(e.call(t,i),null):(c=e,function(t,e,n){return c.call(k(t),n)})),e))for(;a<l;a++)e(t[a],n,o?i:i.call(t[a],a,e(t[a],n)));return s?t:c?e.call(t):l?e(t[0],n):r},J=/^(?:checkbox|radio)$/i,tt=/<([\w:-]+)/,et=/^$|\/(?:java|ecma)script/i,nt=/^\s+/,it="abbr|article|aside|audio|bdi|canvas|data|datalist|details|dialog|figcaption|figure|footer|header|hgroup|main|mark|meter|nav|output|picture|progress|section|summary|template|time|video";function st(t){var e=it.split("|"),n=t.createDocumentFragment();if(n.createElement)for(;e.length;)n.createElement(e.pop());return n}Q=f.createElement("div"),K=f.createDocumentFragment(),X=f.createElement("input"),Q.innerHTML="  <link/><table></table><a href='/a'>a</a><input type='checkbox'/>",y.leadingWhitespace=3===Q.firstChild.nodeType,y.tbody=!Q.getElementsByTagName("tbody").length,y.htmlSerialize=!!Q.getElementsByTagName("link").length,y.html5Clone="<:nav></:nav>"!==f.createElement("nav").cloneNode(!0).outerHTML,X.type="checkbox",X.checked=!0,K.appendChild(X),y.appendChecked=X.checked,Q.innerHTML="<textarea>x</textarea>",y.noCloneChecked=!!Q.cloneNode(!0).lastChild.defaultValue,K.appendChild(Q),(X=f.createElement("input")).setAttribute("type","radio"),X.setAttribute("checked","checked"),X.setAttribute("name","t"),Q.appendChild(X),y.checkClone=Q.cloneNode(!0).cloneNode(!0).lastChild.checked,y.noCloneEvent=!!Q.addEventListener,Q[k.expando]=1,y.attributes=!Q.getAttribute(k.expando);var rt={option:[1,"<select multiple='multiple'>","</select>"],legend:[1,"<fieldset>","</fieldset>"],area:[1,"<map>","</map>"],param:[1,"<object>","</object>"],thead:[1,"<table>","</table>"],tr:[2,"<table><tbody>","</tbody></table>"],col:[2,"<table><tbody></tbody><colgroup>","</colgroup></table>"],td:[3,"<table><tbody><tr>","</tr></tbody></table>"],_default:y.htmlSerialize?[0,"",""]:[1,"X<div>","</div>"]};function ot(t,e){var n,i,s=0,r=void 0!==t.getElementsByTagName?t.getElementsByTagName(e||"*"):void 0!==t.querySelectorAll?t.querySelectorAll(e||"*"):void 0;if(!r)for(r=[],n=t.childNodes||t;null!=(i=n[s]);s++)!e||k.nodeName(i,e)?r.push(i):k.merge(r,ot(i,e));return void 0===e||e&&k.nodeName(t,e)?k.merge([t],r):r}function at(t,e){for(var n,i=0;null!=(n=t[i]);i++)k._data(n,"globalEval",!e||k._data(e[i],"globalEval"))}rt.optgroup=rt.option,rt.tbody=rt.tfoot=rt.colgroup=rt.caption=rt.thead,rt.th=rt.td;var lt=/<|&#?\w+;/,ct=/<tbody/i;function ut(t){J.test(t.type)&&(t.defaultChecked=t.checked)}function dt(t,e,n,i,s){for(var r,o,a,l,c,u,d,h=t.length,p=st(e),f=[],g=0;g<h;g++)if((o=t[g])||0===o)if("object"===k.type(o))k.merge(f,o.nodeType?[o]:o);else if(lt.test(o)){for(l=l||p.appendChild(e.createElement("div")),c=(tt.exec(o)||["",""])[1].toLowerCase(),d=rt[c]||rt._default,l.innerHTML=d[1]+k.htmlPrefilter(o)+d[2],r=d[0];r--;)l=l.lastChild;if(!y.leadingWhitespace&&nt.test(o)&&f.push(e.createTextNode(nt.exec(o)[0])),!y.tbody)for(r=(o="table"!==c||ct.test(o)?"<table>"!==d[1]||ct.test(o)?0:l:l.firstChild)&&o.childNodes.length;r--;)k.nodeName(u=o.childNodes[r],"tbody")&&!u.childNodes.length&&o.removeChild(u);for(k.merge(f,l.childNodes),l.textContent="";l.firstChild;)l.removeChild(l.firstChild);l=p.lastChild}else f.push(e.createTextNode(o));for(l&&p.removeChild(l),y.appendChecked||k.grep(ot(f,"input"),ut),g=0;o=f[g++];)if(i&&-1<k.inArray(o,i))s&&s.push(o);else if(a=k.contains(o.ownerDocument,o),l=ot(p.appendChild(o),"script"),a&&at(l),n)for(r=0;o=l[r++];)et.test(o.type||"")&&n.push(o);return l=null,p}!function(){var t,e,n=f.createElement("div");for(t in{submit:!0,change:!0,focusin:!0})e="on"+t,(y[t]=e in C)||(n.setAttribute(e,"t"),y[t]=!1===n.attributes[e].expando);n=null}();var ht=/^(?:input|select|textarea)$/i,pt=/^key/,ft=/^(?:mouse|pointer|contextmenu|drag|drop)|click/,gt=/^(?:focusinfocus|focusoutblur)$/,mt=/^([^.]*)(?:\.(.+)|)/;function yt(){return!0}function vt(){return!1}function bt(){try{return f.activeElement}catch(t){}}function _t(t,e,n,i,s,r){var o,a;if("object"==typeof e){for(a in"string"!=typeof n&&(i=i||n,n=void 0),e)_t(t,a,n,i,e[a],r);return t}if(null==i&&null==s?(s=n,i=n=void 0):null==s&&("string"==typeof n?(s=i,i=void 0):(s=i,i=n,n=void 0)),!1===s)s=vt;else if(!s)return t;return 1===r&&(o=s,(s=function(t){return k().off(t),o.apply(this,arguments)}).guid=o.guid||(o.guid=k.guid++)),t.each(function(){k.event.add(this,e,s,i,n)})}k.event={global:{},add:function(t,e,n,i,s){var r,o,a,l,c,u,d,h,p,f,g,m=k._data(t);if(m){for(n.handler&&(n=(l=n).handler,s=l.selector),n.guid||(n.guid=k.guid++),(o=m.events)||(o=m.events={}),(u=m.handle)||((u=m.handle=function(t){return void 0===k||t&&k.event.triggered===t.type?void 0:k.event.dispatch.apply(u.elem,arguments)}).elem=t),a=(e=(e||"").match(I)||[""]).length;a--;)p=g=(r=mt.exec(e[a])||[])[1],f=(r[2]||"").split(".").sort(),p&&(c=k.event.special[p]||{},p=(s?c.delegateType:c.bindType)||p,c=k.event.special[p]||{},d=k.extend({type:p,origType:g,data:i,handler:n,guid:n.guid,selector:s,needsContext:s&&k.expr.match.needsContext.test(s),namespace:f.join(".")},l),(h=o[p])||((h=o[p]=[]).delegateCount=0,c.setup&&!1!==c.setup.call(t,i,f,u)||(t.addEventListener?t.addEventListener(p,u,!1):t.attachEvent&&t.attachEvent("on"+p,u))),c.add&&(c.add.call(t,d),d.handler.guid||(d.handler.guid=n.guid)),s?h.splice(h.delegateCount++,0,d):h.push(d),k.event.global[p]=!0);t=null}},remove:function(t,e,n,i,s){var r,o,a,l,c,u,d,h,p,f,g,m=k.hasData(t)&&k._data(t);if(m&&(u=m.events)){for(c=(e=(e||"").match(I)||[""]).length;c--;)if(p=g=(a=mt.exec(e[c])||[])[1],f=(a[2]||"").split(".").sort(),p){for(d=k.event.special[p]||{},h=u[p=(i?d.delegateType:d.bindType)||p]||[],a=a[2]&&new RegExp("(^|\\.)"+f.join("\\.(?:.*\\.|)")+"(\\.|$)"),l=r=h.length;r--;)o=h[r],!s&&g!==o.origType||n&&n.guid!==o.guid||a&&!a.test(o.namespace)||i&&i!==o.selector&&("**"!==i||!o.selector)||(h.splice(r,1),o.selector&&h.delegateCount--,d.remove&&d.remove.call(t,o));l&&!h.length&&(d.teardown&&!1!==d.teardown.call(t,f,m.handle)||k.removeEvent(t,p,m.handle),delete u[p])}else for(p in u)k.event.remove(t,p+e[c],n,i,!0);k.isEmptyObject(u)&&(delete m.handle,k._removeData(t,"events"))}},trigger:function(t,e,n,i){var s,r,o,a,l,c,u=[n||f],d=m.call(t,"type")?t.type:t,h=m.call(t,"namespace")?t.namespace.split("."):[],p=l=n=n||f;if(3!==n.nodeType&&8!==n.nodeType&&!gt.test(d+k.event.triggered)&&(-1<d.indexOf(".")&&(d=(h=d.split(".")).shift(),h.sort()),r=d.indexOf(":")<0&&"on"+d,(t=t[k.expando]?t:new k.Event(d,"object"==typeof t&&t)).isTrigger=i?2:3,t.namespace=h.join("."),t.rnamespace=t.namespace?new RegExp("(^|\\.)"+h.join("\\.(?:.*\\.|)")+"(\\.|$)"):null,t.result=void 0,t.target||(t.target=n),e=null==e?[t]:k.makeArray(e,[t]),a=k.event.special[d]||{},i||!a.trigger||!1!==a.trigger.apply(n,e))){if(!i&&!a.noBubble&&!k.isWindow(n)){for(o=a.delegateType||d,gt.test(o+d)||(p=p.parentNode);p;p=p.parentNode)u.push(p),l=p;l===(n.ownerDocument||f)&&u.push(l.defaultView||l.parentWindow||C)}for(c=0;(p=u[c++])&&!t.isPropagationStopped();)t.type=1<c?o:a.bindType||d,(s=(k._data(p,"events")||{})[t.type]&&k._data(p,"handle"))&&s.apply(p,e),(s=r&&p[r])&&s.apply&&R(p)&&(t.result=s.apply(p,e),!1===t.result&&t.preventDefault());if(t.type=d,!i&&!t.isDefaultPrevented()&&(!a._default||!1===a._default.apply(u.pop(),e))&&R(n)&&r&&n[d]&&!k.isWindow(n)){(l=n[r])&&(n[r]=null),k.event.triggered=d;try{n[d]()}catch(t){}k.event.triggered=void 0,l&&(n[r]=l)}return t.result}},dispatch:function(t){t=k.event.fix(t);var e,n,i,s,r,o,a=u.call(arguments),l=(k._data(this,"events")||{})[t.type]||[],c=k.event.special[t.type]||{};if((a[0]=t).delegateTarget=this,!c.preDispatch||!1!==c.preDispatch.call(this,t)){for(o=k.event.handlers.call(this,t,l),e=0;(s=o[e++])&&!t.isPropagationStopped();)for(t.currentTarget=s.elem,n=0;(r=s.handlers[n++])&&!t.isImmediatePropagationStopped();)t.rnamespace&&!t.rnamespace.test(r.namespace)||(t.handleObj=r,t.data=r.data,void 0!==(i=((k.event.special[r.origType]||{}).handle||r.handler).apply(s.elem,a))&&!1===(t.result=i)&&(t.preventDefault(),t.stopPropagation()));return c.postDispatch&&c.postDispatch.call(this,t),t.result}},handlers:function(t,e){var n,i,s,r,o=[],a=e.delegateCount,l=t.target;if(a&&l.nodeType&&("click"!==t.type||isNaN(t.button)||t.button<1))for(;l!=this;l=l.parentNode||this)if(1===l.nodeType&&(!0!==l.disabled||"click"!==t.type)){for(i=[],n=0;n<a;n++)void 0===i[s=(r=e[n]).selector+" "]&&(i[s]=r.needsContext?-1<k(s,this).index(l):k.find(s,this,null,[l]).length),i[s]&&i.push(r);i.length&&o.push({elem:l,handlers:i})}return a<e.length&&o.push({elem:this,handlers:e.slice(a)}),o},fix:function(t){if(t[k.expando])return t;var e,n,i,s=t.type,r=t,o=this.fixHooks[s];for(o||(this.fixHooks[s]=o=ft.test(s)?this.mouseHooks:pt.test(s)?this.keyHooks:{}),i=o.props?this.props.concat(o.props):this.props,t=new k.Event(r),e=i.length;e--;)t[n=i[e]]=r[n];return t.target||(t.target=r.srcElement||f),3===t.target.nodeType&&(t.target=t.target.parentNode),t.metaKey=!!t.metaKey,o.filter?o.filter(t,r):t},props:"altKey bubbles cancelable ctrlKey currentTarget detail eventPhase metaKey relatedTarget shiftKey target timeStamp view which".split(" "),fixHooks:{},keyHooks:{props:"char charCode key keyCode".split(" "),filter:function(t,e){return null==t.which&&(t.which=null!=e.charCode?e.charCode:e.keyCode),t}},mouseHooks:{props:"button buttons clientX clientY fromElement offsetX offsetY pageX pageY screenX screenY toElement".split(" "),filter:function(t,e){var n,i,s,r=e.button,o=e.fromElement;return null==t.pageX&&null!=e.clientX&&(s=(i=t.target.ownerDocument||f).documentElement,n=i.body,t.pageX=e.clientX+(s&&s.scrollLeft||n&&n.scrollLeft||0)-(s&&s.clientLeft||n&&n.clientLeft||0),t.pageY=e.clientY+(s&&s.scrollTop||n&&n.scrollTop||0)-(s&&s.clientTop||n&&n.clientTop||0)),!t.relatedTarget&&o&&(t.relatedTarget=o===t.target?e.toElement:o),t.which||void 0===r||(t.which=1&r?1:2&r?3:4&r?2:0),t}},special:{load:{noBubble:!0},focus:{trigger:function(){if(this!==bt()&&this.focus)try{return this.focus(),!1}catch(t){}},delegateType:"focusin"},blur:{trigger:function(){if(this===bt()&&this.blur)return this.blur(),!1},delegateType:"focusout"},click:{trigger:function(){if(k.nodeName(this,"input")&&"checkbox"===this.type&&this.click)return this.click(),!1},_default:function(t){return k.nodeName(t.target,"a")}},beforeunload:{postDispatch:function(t){void 0!==t.result&&t.originalEvent&&(t.originalEvent.returnValue=t.result)}}},simulate:function(t,e,n){var i=k.extend(new k.Event,n,{type:t,isSimulated:!0});k.event.trigger(i,null,e),i.isDefaultPrevented()&&n.preventDefault()}},k.removeEvent=f.removeEventListener?function(t,e,n){t.removeEventListener&&t.removeEventListener(e,n)}:function(t,e,n){var i="on"+e;t.detachEvent&&(void 0===t[i]&&(t[i]=null),t.detachEvent(i,n))},k.Event=function(t,e){if(!(this instanceof k.Event))return new k.Event(t,e);t&&t.type?(this.originalEvent=t,this.type=t.type,this.isDefaultPrevented=t.defaultPrevented||void 0===t.defaultPrevented&&!1===t.returnValue?yt:vt):this.type=t,e&&k.extend(this,e),this.timeStamp=t&&t.timeStamp||k.now(),this[k.expando]=!0},k.Event.prototype={constructor:k.Event,isDefaultPrevented:vt,isPropagationStopped:vt,isImmediatePropagationStopped:vt,preventDefault:function(){var t=this.originalEvent;this.isDefaultPrevented=yt,t&&(t.preventDefault?t.preventDefault():t.returnValue=!1)},stopPropagation:function(){var t=this.originalEvent;this.isPropagationStopped=yt,t&&!this.isSimulated&&(t.stopPropagation&&t.stopPropagation(),t.cancelBubble=!0)},stopImmediatePropagation:function(){var t=this.originalEvent;this.isImmediatePropagationStopped=yt,t&&t.stopImmediatePropagation&&t.stopImmediatePropagation(),this.stopPropagation()}},k.each({mouseenter:"mouseover",mouseleave:"mouseout",pointerenter:"pointerover",pointerleave:"pointerout"},function(t,s){k.event.special[t]={delegateType:s,bindType:s,handle:function(t){var e,n=t.relatedTarget,i=t.handleObj;return n&&(n===this||k.contains(this,n))||(t.type=i.origType,e=i.handler.apply(this,arguments),t.type=s),e}}}),y.submit||(k.event.special.submit={setup:function(){if(k.nodeName(this,"form"))return!1;k.event.add(this,"click._submit keypress._submit",function(t){var e=t.target,n=k.nodeName(e,"input")||k.nodeName(e,"button")?k.prop(e,"form"):void 0;n&&!k._data(n,"submit")&&(k.event.add(n,"submit._submit",function(t){t._submitBubble=!0}),k._data(n,"submit",!0))})},postDispatch:function(t){t._submitBubble&&(delete t._submitBubble,this.parentNode&&!t.isTrigger&&k.event.simulate("submit",this.parentNode,t))},teardown:function(){if(k.nodeName(this,"form"))return!1;k.event.remove(this,"._submit")}}),y.change||(k.event.special.change={setup:function(){if(ht.test(this.nodeName))return"checkbox"!==this.type&&"radio"!==this.type||(k.event.add(this,"propertychange._change",function(t){"checked"===t.originalEvent.propertyName&&(this._justChanged=!0)}),k.event.add(this,"click._change",function(t){this._justChanged&&!t.isTrigger&&(this._justChanged=!1),k.event.simulate("change",this,t)})),!1;k.event.add(this,"beforeactivate._change",function(t){var e=t.target;ht.test(e.nodeName)&&!k._data(e,"change")&&(k.event.add(e,"change._change",function(t){!this.parentNode||t.isSimulated||t.isTrigger||k.event.simulate("change",this.parentNode,t)}),k._data(e,"change",!0))})},handle:function(t){var e=t.target;if(this!==e||t.isSimulated||t.isTrigger||"radio"!==e.type&&"checkbox"!==e.type)return t.handleObj.handler.apply(this,arguments)},teardown:function(){return k.event.remove(this,"._change"),!ht.test(this.nodeName)}}),y.focusin||k.each({focus:"focusin",blur:"focusout"},function(n,i){function s(t){k.event.simulate(i,t.target,k.event.fix(t))}k.event.special[i]={setup:function(){var t=this.ownerDocument||this,e=k._data(t,i);e||t.addEventListener(n,s,!0),k._data(t,i,(e||0)+1)},teardown:function(){var t=this.ownerDocument||this,e=k._data(t,i)-1;e?k._data(t,i,e):(t.removeEventListener(n,s,!0),k._removeData(t,i))}}}),k.fn.extend({on:function(t,e,n,i){return _t(this,t,e,n,i)},one:function(t,e,n,i){return _t(this,t,e,n,i,1)},off:function(t,e,n){var i,s;if(t&&t.preventDefault&&t.handleObj)return i=t.handleObj,k(t.delegateTarget).off(i.namespace?i.origType+"."+i.namespace:i.origType,i.selector,i.handler),this;if("object"!=typeof t)return!1!==e&&"function"!=typeof e||(n=e,e=void 0),!1===n&&(n=vt),this.each(function(){k.event.remove(this,t,n,e)});for(s in t)this.off(s,e,t[s]);return this},trigger:function(t,e){return this.each(function(){k.event.trigger(t,e,this)})},triggerHandler:function(t,e){var n=this[0];if(n)return k.event.trigger(t,e,n,!0)}});var wt=/ jQuery\d+="(?:null|\d+)"/g,xt=new RegExp("<(?:"+it+")[\\s/>]","i"),Ct=/<(?!area|br|col|embed|hr|img|input|link|meta|param)(([\w:-]+)[^>]*)\/>/gi,kt=/<script|<style|<link/i,St=/checked\s*(?:[^=]|=\s*.checked.)/i,Tt=/^true\/(.*)/,Dt=/^\s*<!(?:\[CDATA\[|--)|(?:\]\]|--)>\s*$/g,Et=st(f).appendChild(f.createElement("div"));function Nt(t,e){return k.nodeName(t,"table")&&k.nodeName(11!==e.nodeType?e:e.firstChild,"tr")?t.getElementsByTagName("tbody")[0]||t.appendChild(t.ownerDocument.createElement("tbody")):t}function $t(t){return t.type=(null!==k.find.attr(t,"type"))+"/"+t.type,t}function At(t){var e=Tt.exec(t.type);return e?t.type=e[1]:t.removeAttribute("type"),t}function Mt(t,e){if(1===e.nodeType&&k.hasData(t)){var n,i,s,r=k._data(t),o=k._data(e,r),a=r.events;if(a)for(n in delete o.handle,o.events={},a)for(i=0,s=a[n].length;i<s;i++)k.event.add(e,n,a[n][i]);o.data&&(o.data=k.extend({},o.data))}}function It(n,i,s,r){i=g.apply([],i);var t,e,o,a,l,c,u=0,d=n.length,h=d-1,p=i[0],f=k.isFunction(p);if(f||1<d&&"string"==typeof p&&!y.checkClone&&St.test(p))return n.each(function(t){var e=n.eq(t);f&&(i[0]=p.call(this,t,e.html())),It(e,i,s,r)});if(d&&(t=(c=dt(i,n[0].ownerDocument,!1,n,r)).firstChild,1===c.childNodes.length&&(c=t),t||r)){for(o=(a=k.map(ot(c,"script"),$t)).length;u<d;u++)e=c,u!==h&&(e=k.clone(e,!0,!0),o&&k.merge(a,ot(e,"script"))),s.call(n[u],e,u);if(o)for(l=a[a.length-1].ownerDocument,k.map(a,At),u=0;u<o;u++)e=a[u],et.test(e.type||"")&&!k._data(e,"globalEval")&&k.contains(l,e)&&(e.src?k._evalUrl&&k._evalUrl(e.src):k.globalEval((e.text||e.textContent||e.innerHTML||"").replace(Dt,"")));c=t=null}return n}function Ot(t,e,n){for(var i,s=e?k.filter(e,t):t,r=0;null!=(i=s[r]);r++)n||1!==i.nodeType||k.cleanData(ot(i)),i.parentNode&&(n&&k.contains(i.ownerDocument,i)&&at(ot(i,"script")),i.parentNode.removeChild(i));return t}k.extend({htmlPrefilter:function(t){return t.replace(Ct,"<$1></$2>")},clone:function(t,e,n){var i,s,r,o,a,l=k.contains(t.ownerDocument,t);if(y.html5Clone||k.isXMLDoc(t)||!xt.test("<"+t.nodeName+">")?r=t.cloneNode(!0):(Et.innerHTML=t.outerHTML,Et.removeChild(r=Et.firstChild)),!(y.noCloneEvent&&y.noCloneChecked||1!==t.nodeType&&11!==t.nodeType||k.isXMLDoc(t)))for(i=ot(r),a=ot(t),o=0;null!=(s=a[o]);++o)i[o]&&function(t,e){var n,i,s;if(1===e.nodeType){if(n=e.nodeName.toLowerCase(),!y.noCloneEvent&&e[k.expando]){for(i in(s=k._data(e)).events)k.removeEvent(e,i,s.handle);e.removeAttribute(k.expando)}"script"===n&&e.text!==t.text?($t(e).text=t.text,At(e)):"object"===n?(e.parentNode&&(e.outerHTML=t.outerHTML),y.html5Clone&&t.innerHTML&&!k.trim(e.innerHTML)&&(e.innerHTML=t.innerHTML)):"input"===n&&J.test(t.type)?(e.defaultChecked=e.checked=t.checked,e.value!==t.value&&(e.value=t.value)):"option"===n?e.defaultSelected=e.selected=t.defaultSelected:"input"!==n&&"textarea"!==n||(e.defaultValue=t.defaultValue)}}(s,i[o]);if(e)if(n)for(a=a||ot(t),i=i||ot(r),o=0;null!=(s=a[o]);o++)Mt(s,i[o]);else Mt(t,r);return 0<(i=ot(r,"script")).length&&at(i,!l&&ot(t,"script")),i=a=s=null,r},cleanData:function(t,e){for(var n,i,s,r,o=0,a=k.expando,l=k.cache,c=y.attributes,u=k.event.special;null!=(n=t[o]);o++)if((e||R(n))&&(r=(s=n[a])&&l[s])){if(r.events)for(i in r.events)u[i]?k.event.remove(n,i):k.removeEvent(n,i,r.handle);l[s]&&(delete l[s],c||void 0===n.removeAttribute?n[a]=void 0:n.removeAttribute(a),d.push(s))}}}),k.fn.extend({domManip:It,detach:function(t){return Ot(this,t,!0)},remove:function(t){return Ot(this,t)},text:function(t){return Z(this,function(t){return void 0===t?k.text(this):this.empty().append((this[0]&&this[0].ownerDocument||f).createTextNode(t))},null,t,arguments.length)},append:function(){return It(this,arguments,function(t){1!==this.nodeType&&11!==this.nodeType&&9!==this.nodeType||Nt(this,t).appendChild(t)})},prepend:function(){return It(this,arguments,function(t){var e;1!==this.nodeType&&11!==this.nodeType&&9!==this.nodeType||(e=Nt(this,t)).insertBefore(t,e.firstChild)})},before:function(){return It(this,arguments,function(t){this.parentNode&&this.parentNode.insertBefore(t,this)})},after:function(){return It(this,arguments,function(t){this.parentNode&&this.parentNode.insertBefore(t,this.nextSibling)})},empty:function(){for(var t,e=0;null!=(t=this[e]);e++){for(1===t.nodeType&&k.cleanData(ot(t,!1));t.firstChild;)t.removeChild(t.firstChild);t.options&&k.nodeName(t,"select")&&(t.options.length=0)}return this},clone:function(t,e){return t=null!=t&&t,e=null==e?t:e,this.map(function(){return k.clone(this,t,e)})},html:function(t){return Z(this,function(t){var e=this[0]||{},n=0,i=this.length;if(void 0===t)return 1===e.nodeType?e.innerHTML.replace(wt,""):void 0;if("string"==typeof t&&!kt.test(t)&&(y.htmlSerialize||!xt.test(t))&&(y.leadingWhitespace||!nt.test(t))&&!rt[(tt.exec(t)||["",""])[1].toLowerCase()]){t=k.htmlPrefilter(t);try{for(;n<i;n++)1===(e=this[n]||{}).nodeType&&(k.cleanData(ot(e,!1)),e.innerHTML=t);e=0}catch(t){}}e&&this.empty().append(t)},null,t,arguments.length)},replaceWith:function(){var n=[];return It(this,arguments,function(t){var e=this.parentNode;k.inArray(this,n)<0&&(k.cleanData(ot(this)),e&&e.replaceChild(t,this))},n)}}),k.each({appendTo:"append",prependTo:"prepend",insertBefore:"before",insertAfter:"after",replaceAll:"replaceWith"},function(t,o){k.fn[t]=function(t){for(var e,n=0,i=[],s=k(t),r=s.length-1;n<=r;n++)e=n===r?this:this.clone(!0),k(s[n])[o](e),a.apply(i,e.get());return this.pushStack(i)}});var Pt,Rt={HTML:"block",BODY:"block"};function Lt(t,e){var n=k(e.createElement(t)).appendTo(e.body),i=k.css(n[0],"display");return n.detach(),i}function jt(t){var e=f,n=Rt[t];return n||("none"!==(n=Lt(t,e))&&n||((e=((Pt=(Pt||k("<iframe frameborder='0' width='0' height='0'/>")).appendTo(e.documentElement))[0].contentWindow||Pt[0].contentDocument).document).write(),e.close(),n=Lt(t,e),Pt.detach()),Rt[t]=n),n}function Ht(t,e,n,i){var s,r,o={};for(r in e)o[r]=t.style[r],t.style[r]=e[r];for(r in s=n.apply(t,i||[]),e)t.style[r]=o[r];return s}var Ft,Wt,Yt,qt,zt,Bt,Vt,Ut,Gt=/^margin/,Qt=new RegExp("^("+B+")(?!px)[a-z%]+$","i"),Kt=f.documentElement;function Xt(){var t,e,n=f.documentElement;n.appendChild(Vt),Ut.style.cssText="-webkit-box-sizing:border-box;box-sizing:border-box;position:relative;display:block;margin:auto;border:1px;padding:1px;top:1%;width:50%",Ft=Yt=Bt=!1,Wt=zt=!0,C.getComputedStyle&&(e=C.getComputedStyle(Ut),Ft="1%"!==(e||{}).top,Bt="2px"===(e||{}).marginLeft,Yt="4px"===(e||{width:"4px"}).width,Ut.style.marginRight="50%",Wt="4px"===(e||{marginRight:"4px"}).marginRight,(t=Ut.appendChild(f.createElement("div"))).style.cssText=Ut.style.cssText="-webkit-box-sizing:content-box;-moz-box-sizing:content-box;box-sizing:content-box;display:block;margin:0;border:0;padding:0",t.style.marginRight=t.style.width="0",Ut.style.width="1px",zt=!parseFloat((C.getComputedStyle(t)||{}).marginRight),Ut.removeChild(t)),Ut.style.display="none",(qt=0===Ut.getClientRects().length)&&(Ut.style.display="",Ut.innerHTML="<table><tr><td></td><td>t</td></tr></table>",Ut.childNodes[0].style.borderCollapse="separate",(t=Ut.getElementsByTagName("td"))[0].style.cssText="margin:0;border:0;padding:0;display:none",(qt=0===t[0].offsetHeight)&&(t[0].style.display="",t[1].style.display="none",qt=0===t[0].offsetHeight)),n.removeChild(Vt)}Vt=f.createElement("div"),(Ut=f.createElement("div")).style&&(Ut.style.cssText="float:left;opacity:.5",y.opacity="0.5"===Ut.style.opacity,y.cssFloat=!!Ut.style.cssFloat,Ut.style.backgroundClip="content-box",Ut.cloneNode(!0).style.backgroundClip="",y.clearCloneStyle="content-box"===Ut.style.backgroundClip,(Vt=f.createElement("div")).style.cssText="border:0;width:8px;height:0;top:0;left:-9999px;padding:0;margin-top:1px;position:absolute",Ut.innerHTML="",Vt.appendChild(Ut),y.boxSizing=""===Ut.style.boxSizing||""===Ut.style.MozBoxSizing||""===Ut.style.WebkitBoxSizing,k.extend(y,{reliableHiddenOffsets:function(){return null==Ft&&Xt(),qt},boxSizingReliable:function(){return null==Ft&&Xt(),Yt},pixelMarginRight:function(){return null==Ft&&Xt(),Wt},pixelPosition:function(){return null==Ft&&Xt(),Ft},reliableMarginRight:function(){return null==Ft&&Xt(),zt},reliableMarginLeft:function(){return null==Ft&&Xt(),Bt}}));var Zt,Jt,te=/^(top|right|bottom|left)$/;function ee(t,e){return{get:function(){if(!t())return(this.get=e).apply(this,arguments);delete this.get}}}C.getComputedStyle?(Zt=function(t){var e=t.ownerDocument.defaultView;return e&&e.opener||(e=C),e.getComputedStyle(t)},Jt=function(t,e,n){var i,s,r,o,a=t.style;return""!==(o=(n=n||Zt(t))?n.getPropertyValue(e)||n[e]:void 0)&&void 0!==o||k.contains(t.ownerDocument,t)||(o=k.style(t,e)),n&&!y.pixelMarginRight()&&Qt.test(o)&&Gt.test(e)&&(i=a.width,s=a.minWidth,r=a.maxWidth,a.minWidth=a.maxWidth=a.width=o,o=n.width,a.width=i,a.minWidth=s,a.maxWidth=r),void 0===o?o:o+""}):Kt.currentStyle&&(Zt=function(t){return t.currentStyle},Jt=function(t,e,n){var i,s,r,o,a=t.style;return null==(o=(n=n||Zt(t))?n[e]:void 0)&&a&&a[e]&&(o=a[e]),Qt.test(o)&&!te.test(e)&&(i=a.left,(r=(s=t.runtimeStyle)&&s.left)&&(s.left=t.currentStyle.left),a.left="fontSize"===e?"1em":o,o=a.pixelLeft+"px",a.left=i,r&&(s.left=r)),void 0===o?o:o+""||"auto"});var ne=/alpha\([^)]*\)/i,ie=/opacity\s*=\s*([^)]*)/i,se=/^(none|table(?!-c[ea]).+)/,re=new RegExp("^("+B+")(.*)$","i"),oe={position:"absolute",visibility:"hidden",display:"block"},ae={letterSpacing:"0",fontWeight:"400"},le=["Webkit","O","Moz","ms"],ce=f.createElement("div").style;function ue(t){if(t in ce)return t;for(var e=t.charAt(0).toUpperCase()+t.slice(1),n=le.length;n--;)if((t=le[n]+e)in ce)return t}function de(t,e){for(var n,i,s,r=[],o=0,a=t.length;o<a;o++)(i=t[o]).style&&(r[o]=k._data(i,"olddisplay"),n=i.style.display,e?(r[o]||"none"!==n||(i.style.display=""),""===i.style.display&&z(i)&&(r[o]=k._data(i,"olddisplay",jt(i.nodeName)))):(s=z(i),(n&&"none"!==n||!s)&&k._data(i,"olddisplay",s?n:k.css(i,"display"))));for(o=0;o<a;o++)(i=t[o]).style&&(e&&"none"!==i.style.display&&""!==i.style.display||(i.style.display=e?r[o]||"":"none"));return t}function he(t,e,n){var i=re.exec(e);return i?Math.max(0,i[1]-(n||0))+(i[2]||"px"):e}function pe(t,e,n,i,s){for(var r=n===(i?"border":"content")?4:"width"===e?1:0,o=0;r<4;r+=2)"margin"===n&&(o+=k.css(t,n+U[r],!0,s)),i?("content"===n&&(o-=k.css(t,"padding"+U[r],!0,s)),"margin"!==n&&(o-=k.css(t,"border"+U[r]+"Width",!0,s))):(o+=k.css(t,"padding"+U[r],!0,s),"padding"!==n&&(o+=k.css(t,"border"+U[r]+"Width",!0,s)));return o}function fe(t,e,n){var i=!0,s="width"===e?t.offsetWidth:t.offsetHeight,r=Zt(t),o=y.boxSizing&&"border-box"===k.css(t,"boxSizing",!1,r);if(s<=0||null==s){if(((s=Jt(t,e,r))<0||null==s)&&(s=t.style[e]),Qt.test(s))return s;i=o&&(y.boxSizingReliable()||s===t.style[e]),s=parseFloat(s)||0}return s+pe(t,e,n||(o?"border":"content"),i,r)+"px"}function ge(t,e,n,i,s){return new ge.prototype.init(t,e,n,i,s)}k.extend({cssHooks:{opacity:{get:function(t,e){if(e){var n=Jt(t,"opacity");return""===n?"1":n}}}},cssNumber:{animationIterationCount:!0,columnCount:!0,fillOpacity:!0,flexGrow:!0,flexShrink:!0,fontWeight:!0,lineHeight:!0,opacity:!0,order:!0,orphans:!0,widows:!0,zIndex:!0,zoom:!0},cssProps:{float:y.cssFloat?"cssFloat":"styleFloat"},style:function(t,e,n,i){if(t&&3!==t.nodeType&&8!==t.nodeType&&t.style){var s,r,o,a=k.camelCase(e),l=t.style;if(e=k.cssProps[a]||(k.cssProps[a]=ue(a)||a),o=k.cssHooks[e]||k.cssHooks[a],void 0===n)return o&&"get"in o&&void 0!==(s=o.get(t,!1,i))?s:l[e];if("string"===(r=typeof n)&&(s=V.exec(n))&&s[1]&&(n=G(t,e,s),r="number"),null!=n&&n==n&&("number"===r&&(n+=s&&s[3]||(k.cssNumber[a]?"":"px")),y.clearCloneStyle||""!==n||0!==e.indexOf("background")||(l[e]="inherit"),!(o&&"set"in o&&void 0===(n=o.set(t,n,i)))))try{l[e]=n}catch(t){}}},css:function(t,e,n,i){var s,r,o,a=k.camelCase(e);return e=k.cssProps[a]||(k.cssProps[a]=ue(a)||a),(o=k.cssHooks[e]||k.cssHooks[a])&&"get"in o&&(r=o.get(t,!0,n)),void 0===r&&(r=Jt(t,e,i)),"normal"===r&&e in ae&&(r=ae[e]),""===n||n?(s=parseFloat(r),!0===n||isFinite(s)?s||0:r):r}}),k.each(["height","width"],function(t,s){k.cssHooks[s]={get:function(t,e,n){if(e)return se.test(k.css(t,"display"))&&0===t.offsetWidth?Ht(t,oe,function(){return fe(t,s,n)}):fe(t,s,n)},set:function(t,e,n){var i=n&&Zt(t);return he(0,e,n?pe(t,s,n,y.boxSizing&&"border-box"===k.css(t,"boxSizing",!1,i),i):0)}}}),y.opacity||(k.cssHooks.opacity={get:function(t,e){return ie.test((e&&t.currentStyle?t.currentStyle.filter:t.style.filter)||"")?.01*parseFloat(RegExp.$1)+"":e?"1":""},set:function(t,e){var n=t.style,i=t.currentStyle,s=k.isNumeric(e)?"alpha(opacity="+100*e+")":"",r=i&&i.filter||n.filter||"";((n.zoom=1)<=e||""===e)&&""===k.trim(r.replace(ne,""))&&n.removeAttribute&&(n.removeAttribute("filter"),""===e||i&&!i.filter)||(n.filter=ne.test(r)?r.replace(ne,s):r+" "+s)}}),k.cssHooks.marginRight=ee(y.reliableMarginRight,function(t,e){if(e)return Ht(t,{display:"inline-block"},Jt,[t,"marginRight"])}),k.cssHooks.marginLeft=ee(y.reliableMarginLeft,function(t,e){if(e)return(parseFloat(Jt(t,"marginLeft"))||(k.contains(t.ownerDocument,t)?t.getBoundingClientRect().left-Ht(t,{marginLeft:0},function(){return t.getBoundingClientRect().left}):0))+"px"}),k.each({margin:"",padding:"",border:"Width"},function(s,r){k.cssHooks[s+r]={expand:function(t){for(var e=0,n={},i="string"==typeof t?t.split(" "):[t];e<4;e++)n[s+U[e]+r]=i[e]||i[e-2]||i[0];return n}},Gt.test(s)||(k.cssHooks[s+r].set=he)}),k.fn.extend({css:function(t,e){return Z(this,function(t,e,n){var i,s,r={},o=0;if(k.isArray(e)){for(i=Zt(t),s=e.length;o<s;o++)r[e[o]]=k.css(t,e[o],!1,i);return r}return void 0!==n?k.style(t,e,n):k.css(t,e)},t,e,1<arguments.length)},show:function(){return de(this,!0)},hide:function(){return de(this)},toggle:function(t){return"boolean"==typeof t?t?this.show():this.hide():this.each(function(){z(this)?k(this).show():k(this).hide()})}}),(k.Tween=ge).prototype={constructor:ge,init:function(t,e,n,i,s,r){this.elem=t,this.prop=n,this.easing=s||k.easing._default,this.options=e,this.start=this.now=this.cur(),this.end=i,this.unit=r||(k.cssNumber[n]?"":"px")},cur:function(){var t=ge.propHooks[this.prop];return t&&t.get?t.get(this):ge.propHooks._default.get(this)},run:function(t){var e,n=ge.propHooks[this.prop];return this.options.duration?this.pos=e=k.easing[this.easing](t,this.options.duration*t,0,1,this.options.duration):this.pos=e=t,this.now=(this.end-this.start)*e+this.start,this.options.step&&this.options.step.call(this.elem,this.now,this),n&&n.set?n.set(this):ge.propHooks._default.set(this),this}},ge.prototype.init.prototype=ge.prototype,ge.propHooks={_default:{get:function(t){var e;return 1!==t.elem.nodeType||null!=t.elem[t.prop]&&null==t.elem.style[t.prop]?t.elem[t.prop]:(e=k.css(t.elem,t.prop,""))&&"auto"!==e?e:0},set:function(t){k.fx.step[t.prop]?k.fx.step[t.prop](t):1!==t.elem.nodeType||null==t.elem.style[k.cssProps[t.prop]]&&!k.cssHooks[t.prop]?t.elem[t.prop]=t.now:k.style(t.elem,t.prop,t.now+t.unit)}}},ge.propHooks.scrollTop=ge.propHooks.scrollLeft={set:function(t){t.elem.nodeType&&t.elem.parentNode&&(t.elem[t.prop]=t.now)}},k.easing={linear:function(t){return t},swing:function(t){return.5-Math.cos(t*Math.PI)/2},_default:"swing"},k.fx=ge.prototype.init,k.fx.step={};var me,ye,ve,be,_e,we,xe,Ce=/^(?:toggle|show|hide)$/,ke=/queueHooks$/;function Se(){return C.setTimeout(function(){me=void 0}),me=k.now()}function Te(t,e){var n,i={height:t},s=0;for(e=e?1:0;s<4;s+=2-e)i["margin"+(n=U[s])]=i["padding"+n]=t;return e&&(i.opacity=i.width=t),i}function De(t,e,n){for(var i,s=(Ee.tweeners[e]||[]).concat(Ee.tweeners["*"]),r=0,o=s.length;r<o;r++)if(i=s[r].call(n,e,t))return i}function Ee(r,t,e){var n,o,i=0,s=Ee.prefilters.length,a=k.Deferred().always(function(){delete l.elem}),l=function(){if(o)return!1;for(var t=me||Se(),e=Math.max(0,c.startTime+c.duration-t),n=1-(e/c.duration||0),i=0,s=c.tweens.length;i<s;i++)c.tweens[i].run(n);return a.notifyWith(r,[c,n,e]),n<1&&s?e:(a.resolveWith(r,[c]),!1)},c=a.promise({elem:r,props:k.extend({},t),opts:k.extend(!0,{specialEasing:{},easing:k.easing._default},e),originalProperties:t,originalOptions:e,startTime:me||Se(),duration:e.duration,tweens:[],createTween:function(t,e){var n=k.Tween(r,c.opts,t,e,c.opts.specialEasing[t]||c.opts.easing);return c.tweens.push(n),n},stop:function(t){var e=0,n=t?c.tweens.length:0;if(o)return this;for(o=!0;e<n;e++)c.tweens[e].run(1);return t?(a.notifyWith(r,[c,1,0]),a.resolveWith(r,[c,t])):a.rejectWith(r,[c,t]),this}}),u=c.props;for(!function(t,e){var n,i,s,r,o;for(n in t)if(s=e[i=k.camelCase(n)],r=t[n],k.isArray(r)&&(s=r[1],r=t[n]=r[0]),n!==i&&(t[i]=r,delete t[n]),(o=k.cssHooks[i])&&"expand"in o)for(n in r=o.expand(r),delete t[i],r)n in t||(t[n]=r[n],e[n]=s);else e[i]=s}(u,c.opts.specialEasing);i<s;i++)if(n=Ee.prefilters[i].call(c,r,u,c.opts))return k.isFunction(n.stop)&&(k._queueHooks(c.elem,c.opts.queue).stop=k.proxy(n.stop,n)),n;return k.map(u,De,c),k.isFunction(c.opts.start)&&c.opts.start.call(r,c),k.fx.timer(k.extend(l,{elem:r,anim:c,queue:c.opts.queue})),c.progress(c.opts.progress).done(c.opts.done,c.opts.complete).fail(c.opts.fail).always(c.opts.always)}k.Animation=k.extend(Ee,{tweeners:{"*":[function(t,e){var n=this.createTween(t,e);return G(n.elem,t,V.exec(e),n),n}]},tweener:function(t,e){for(var n,i=0,s=(t=k.isFunction(t)?(e=t,["*"]):t.match(I)).length;i<s;i++)n=t[i],Ee.tweeners[n]=Ee.tweeners[n]||[],Ee.tweeners[n].unshift(e)},prefilters:[function(e,t,n){var i,s,r,o,a,l,c,u=this,d={},h=e.style,p=e.nodeType&&z(e),f=k._data(e,"fxshow");for(i in n.queue||(null==(a=k._queueHooks(e,"fx")).unqueued&&(a.unqueued=0,l=a.empty.fire,a.empty.fire=function(){a.unqueued||l()}),a.unqueued++,u.always(function(){u.always(function(){a.unqueued--,k.queue(e,"fx").length||a.empty.fire()})})),1===e.nodeType&&("height"in t||"width"in t)&&(n.overflow=[h.overflow,h.overflowX,h.overflowY],"inline"===("none"===(c=k.css(e,"display"))?k._data(e,"olddisplay")||jt(e.nodeName):c)&&"none"===k.css(e,"float")&&(y.inlineBlockNeedsLayout&&"inline"!==jt(e.nodeName)?h.zoom=1:h.display="inline-block")),n.overflow&&(h.overflow="hidden",y.shrinkWrapBlocks()||u.always(function(){h.overflow=n.overflow[0],h.overflowX=n.overflow[1],h.overflowY=n.overflow[2]})),t)if(s=t[i],Ce.exec(s)){if(delete t[i],r=r||"toggle"===s,s===(p?"hide":"show")){if("show"!==s||!f||void 0===f[i])continue;p=!0}d[i]=f&&f[i]||k.style(e,i)}else c=void 0;if(k.isEmptyObject(d))"inline"===("none"===c?jt(e.nodeName):c)&&(h.display=c);else for(i in f?"hidden"in f&&(p=f.hidden):f=k._data(e,"fxshow",{}),r&&(f.hidden=!p),p?k(e).show():u.done(function(){k(e).hide()}),u.done(function(){var t;for(t in k._removeData(e,"fxshow"),d)k.style(e,t,d[t])}),d)o=De(p?f[i]:0,i,u),i in f||(f[i]=o.start,p&&(o.end=o.start,o.start="width"===i||"height"===i?1:0))}],prefilter:function(t,e){e?Ee.prefilters.unshift(t):Ee.prefilters.push(t)}}),k.speed=function(t,e,n){var i=t&&"object"==typeof t?k.extend({},t):{complete:n||!n&&e||k.isFunction(t)&&t,duration:t,easing:n&&e||e&&!k.isFunction(e)&&e};return i.duration=k.fx.off?0:"number"==typeof i.duration?i.duration:i.duration in k.fx.speeds?k.fx.speeds[i.duration]:k.fx.speeds._default,null!=i.queue&&!0!==i.queue||(i.queue="fx"),i.old=i.complete,i.complete=function(){k.isFunction(i.old)&&i.old.call(this),i.queue&&k.dequeue(this,i.queue)},i},k.fn.extend({fadeTo:function(t,e,n,i){return this.filter(z).css("opacity",0).show().end().animate({opacity:e},t,n,i)},animate:function(e,t,n,i){function s(){var t=Ee(this,k.extend({},e),o);(r||k._data(this,"finish"))&&t.stop(!0)}var r=k.isEmptyObject(e),o=k.speed(t,n,i);return s.finish=s,r||!1===o.queue?this.each(s):this.queue(o.queue,s)},stop:function(s,t,r){function o(t){var e=t.stop;delete t.stop,e(r)}return"string"!=typeof s&&(r=t,t=s,s=void 0),t&&!1!==s&&this.queue(s||"fx",[]),this.each(function(){var t=!0,e=null!=s&&s+"queueHooks",n=k.timers,i=k._data(this);if(e)i[e]&&i[e].stop&&o(i[e]);else for(e in i)i[e]&&i[e].stop&&ke.test(e)&&o(i[e]);for(e=n.length;e--;)n[e].elem!==this||null!=s&&n[e].queue!==s||(n[e].anim.stop(r),t=!1,n.splice(e,1));!t&&r||k.dequeue(this,s)})},finish:function(o){return!1!==o&&(o=o||"fx"),this.each(function(){var t,e=k._data(this),n=e[o+"queue"],i=e[o+"queueHooks"],s=k.timers,r=n?n.length:0;for(e.finish=!0,k.queue(this,o,[]),i&&i.stop&&i.stop.call(this,!0),t=s.length;t--;)s[t].elem===this&&s[t].queue===o&&(s[t].anim.stop(!0),s.splice(t,1));for(t=0;t<r;t++)n[t]&&n[t].finish&&n[t].finish.call(this);delete e.finish})}}),k.each(["toggle","show","hide"],function(t,i){var s=k.fn[i];k.fn[i]=function(t,e,n){return null==t||"boolean"==typeof t?s.apply(this,arguments):this.animate(Te(i,!0),t,e,n)}}),k.each({slideDown:Te("show"),slideUp:Te("hide"),slideToggle:Te("toggle"),fadeIn:{opacity:"show"},fadeOut:{opacity:"hide"},fadeToggle:{opacity:"toggle"}},function(t,i){k.fn[t]=function(t,e,n){return this.animate(i,t,e,n)}}),k.timers=[],k.fx.tick=function(){var t,e=k.timers,n=0;for(me=k.now();n<e.length;n++)(t=e[n])()||e[n]!==t||e.splice(n--,1);e.length||k.fx.stop(),me=void 0},k.fx.timer=function(t){k.timers.push(t),t()?k.fx.start():k.timers.pop()},k.fx.interval=13,k.fx.start=function(){ye=ye||C.setInterval(k.fx.tick,k.fx.interval)},k.fx.stop=function(){C.clearInterval(ye),ye=null},k.fx.speeds={slow:600,fast:200,_default:400},k.fn.delay=function(i,t){return i=k.fx&&k.fx.speeds[i]||i,t=t||"fx",this.queue(t,function(t,e){var n=C.setTimeout(t,i);e.stop=function(){C.clearTimeout(n)}})},be=f.createElement("input"),_e=f.createElement("div"),we=f.createElement("select"),xe=we.appendChild(f.createElement("option")),(_e=f.createElement("div")).setAttribute("className","t"),_e.innerHTML="  <link/><table></table><a href='/a'>a</a><input type='checkbox'/>",ve=_e.getElementsByTagName("a")[0],be.setAttribute("type","checkbox"),_e.appendChild(be),(ve=_e.getElementsByTagName("a")[0]).style.cssText="top:1px",y.getSetAttribute="t"!==_e.className,y.style=/top/.test(ve.getAttribute("style")),y.hrefNormalized="/a"===ve.getAttribute("href"),y.checkOn=!!be.value,y.optSelected=xe.selected,y.enctype=!!f.createElement("form").enctype,we.disabled=!0,y.optDisabled=!xe.disabled,(be=f.createElement("input")).setAttribute("value",""),y.input=""===be.getAttribute("value"),be.value="t",be.setAttribute("type","radio"),y.radioValue="t"===be.value;var Ne=/\r/g,$e=/[\x20\t\r\n\f]+/g;k.fn.extend({val:function(n){var i,t,s,e=this[0];return arguments.length?(s=k.isFunction(n),this.each(function(t){var e;1===this.nodeType&&(null==(e=s?n.call(this,t,k(this).val()):n)?e="":"number"==typeof e?e+="":k.isArray(e)&&(e=k.map(e,function(t){return null==t?"":t+""})),(i=k.valHooks[this.type]||k.valHooks[this.nodeName.toLowerCase()])&&"set"in i&&void 0!==i.set(this,e,"value")||(this.value=e))})):e?(i=k.valHooks[e.type]||k.valHooks[e.nodeName.toLowerCase()])&&"get"in i&&void 0!==(t=i.get(e,"value"))?t:"string"==typeof(t=e.value)?t.replace(Ne,""):null==t?"":t:void 0}}),k.extend({valHooks:{option:{get:function(t){var e=k.find.attr(t,"value");return null!=e?e:k.trim(k.text(t)).replace($e," ")}},select:{get:function(t){for(var e,n,i=t.options,s=t.selectedIndex,r="select-one"===t.type||s<0,o=r?null:[],a=r?s+1:i.length,l=s<0?a:r?s:0;l<a;l++)if(((n=i[l]).selected||l===s)&&(y.optDisabled?!n.disabled:null===n.getAttribute("disabled"))&&(!n.parentNode.disabled||!k.nodeName(n.parentNode,"optgroup"))){if(e=k(n).val(),r)return e;o.push(e)}return o},set:function(t,e){for(var n,i,s=t.options,r=k.makeArray(e),o=s.length;o--;)if(i=s[o],-1<k.inArray(k.valHooks.option.get(i),r))try{i.selected=n=!0}catch(t){i.scrollHeight}else i.selected=!1;return n||(t.selectedIndex=-1),s}}}}),k.each(["radio","checkbox"],function(){k.valHooks[this]={set:function(t,e){if(k.isArray(e))return t.checked=-1<k.inArray(k(t).val(),e)}},y.checkOn||(k.valHooks[this].get=function(t){return null===t.getAttribute("value")?"on":t.value})});var Ae,Me,Ie=k.expr.attrHandle,Oe=/^(?:checked|selected)$/i,Pe=y.getSetAttribute,Re=y.input;k.fn.extend({attr:function(t,e){return Z(this,k.attr,t,e,1<arguments.length)},removeAttr:function(t){return this.each(function(){k.removeAttr(this,t)})}}),k.extend({attr:function(t,e,n){var i,s,r=t.nodeType;if(3!==r&&8!==r&&2!==r)return void 0===t.getAttribute?k.prop(t,e,n):(1===r&&k.isXMLDoc(t)||(e=e.toLowerCase(),s=k.attrHooks[e]||(k.expr.match.bool.test(e)?Me:Ae)),void 0!==n?null===n?void k.removeAttr(t,e):s&&"set"in s&&void 0!==(i=s.set(t,n,e))?i:(t.setAttribute(e,n+""),n):!(s&&"get"in s&&null!==(i=s.get(t,e)))&&null==(i=k.find.attr(t,e))?void 0:i)},attrHooks:{type:{set:function(t,e){if(!y.radioValue&&"radio"===e&&k.nodeName(t,"input")){var n=t.value;return t.setAttribute("type",e),n&&(t.value=n),e}}}},removeAttr:function(t,e){var n,i,s=0,r=e&&e.match(I);if(r&&1===t.nodeType)for(;n=r[s++];)i=k.propFix[n]||n,k.expr.match.bool.test(n)?Re&&Pe||!Oe.test(n)?t[i]=!1:t[k.camelCase("default-"+n)]=t[i]=!1:k.attr(t,n,""),t.removeAttribute(Pe?n:i)}}),Me={set:function(t,e,n){return!1===e?k.removeAttr(t,n):Re&&Pe||!Oe.test(n)?t.setAttribute(!Pe&&k.propFix[n]||n,n):t[k.camelCase("default-"+n)]=t[n]=!0,n}},k.each(k.expr.match.bool.source.match(/\w+/g),function(t,e){var r=Ie[e]||k.find.attr;Re&&Pe||!Oe.test(e)?Ie[e]=function(t,e,n){var i,s;return n||(s=Ie[e],Ie[e]=i,i=null!=r(t,e,n)?e.toLowerCase():null,Ie[e]=s),i}:Ie[e]=function(t,e,n){if(!n)return t[k.camelCase("default-"+e)]?e.toLowerCase():null}}),Re&&Pe||(k.attrHooks.value={set:function(t,e,n){if(!k.nodeName(t,"input"))return Ae&&Ae.set(t,e,n);t.defaultValue=e}}),Pe||(Ae={set:function(t,e,n){var i=t.getAttributeNode(n);if(i||t.setAttributeNode(i=t.ownerDocument.createAttribute(n)),i.value=e+="","value"===n||e===t.getAttribute(n))return e}},Ie.id=Ie.name=Ie.coords=function(t,e,n){var i;if(!n)return(i=t.getAttributeNode(e))&&""!==i.value?i.value:null},k.valHooks.button={get:function(t,e){var n=t.getAttributeNode(e);if(n&&n.specified)return n.value},set:Ae.set},k.attrHooks.contenteditable={set:function(t,e,n){Ae.set(t,""!==e&&e,n)}},k.each(["width","height"],function(t,n){k.attrHooks[n]={set:function(t,e){if(""===e)return t.setAttribute(n,"auto"),e}}})),y.style||(k.attrHooks.style={get:function(t){return t.style.cssText||void 0},set:function(t,e){return t.style.cssText=e+""}});var Le=/^(?:input|select|textarea|button|object)$/i,je=/^(?:a|area)$/i;k.fn.extend({prop:function(t,e){return Z(this,k.prop,t,e,1<arguments.length)},removeProp:function(t){return t=k.propFix[t]||t,this.each(function(){try{this[t]=void 0,delete this[t]}catch(t){}})}}),k.extend({prop:function(t,e,n){var i,s,r=t.nodeType;if(3!==r&&8!==r&&2!==r)return 1===r&&k.isXMLDoc(t)||(e=k.propFix[e]||e,s=k.propHooks[e]),void 0!==n?s&&"set"in s&&void 0!==(i=s.set(t,n,e))?i:t[e]=n:s&&"get"in s&&null!==(i=s.get(t,e))?i:t[e]},propHooks:{tabIndex:{get:function(t){var e=k.find.attr(t,"tabindex");return e?parseInt(e,10):Le.test(t.nodeName)||je.test(t.nodeName)&&t.href?0:-1}}},propFix:{for:"htmlFor",class:"className"}}),y.hrefNormalized||k.each(["href","src"],function(t,e){k.propHooks[e]={get:function(t){return t.getAttribute(e,4)}}}),y.optSelected||(k.propHooks.selected={get:function(t){var e=t.parentNode;return e&&(e.selectedIndex,e.parentNode&&e.parentNode.selectedIndex),null},set:function(t){var e=t.parentNode;e&&(e.selectedIndex,e.parentNode&&e.parentNode.selectedIndex)}}),k.each(["tabIndex","readOnly","maxLength","cellSpacing","cellPadding","rowSpan","colSpan","useMap","frameBorder","contentEditable"],function(){k.propFix[this.toLowerCase()]=this}),y.enctype||(k.propFix.enctype="encoding");var He=/[\t\r\n\f]/g;function Fe(t){return k.attr(t,"class")||""}k.fn.extend({addClass:function(e){var t,n,i,s,r,o,a,l=0;if(k.isFunction(e))return this.each(function(t){k(this).addClass(e.call(this,t,Fe(this)))});if("string"==typeof e&&e)for(t=e.match(I)||[];n=this[l++];)if(s=Fe(n),i=1===n.nodeType&&(" "+s+" ").replace(He," ")){for(o=0;r=t[o++];)i.indexOf(" "+r+" ")<0&&(i+=r+" ");s!==(a=k.trim(i))&&k.attr(n,"class",a)}return this},removeClass:function(e){var t,n,i,s,r,o,a,l=0;if(k.isFunction(e))return this.each(function(t){k(this).removeClass(e.call(this,t,Fe(this)))});if(!arguments.length)return this.attr("class","");if("string"==typeof e&&e)for(t=e.match(I)||[];n=this[l++];)if(s=Fe(n),i=1===n.nodeType&&(" "+s+" ").replace(He," ")){for(o=0;r=t[o++];)for(;-1<i.indexOf(" "+r+" ");)i=i.replace(" "+r+" "," ");s!==(a=k.trim(i))&&k.attr(n,"class",a)}return this},toggleClass:function(s,e){var r=typeof s;return"boolean"==typeof e&&"string"==r?e?this.addClass(s):this.removeClass(s):k.isFunction(s)?this.each(function(t){k(this).toggleClass(s.call(this,t,Fe(this),e),e)}):this.each(function(){var t,e,n,i;if("string"==r)for(e=0,n=k(this),i=s.match(I)||[];t=i[e++];)n.hasClass(t)?n.removeClass(t):n.addClass(t);else void 0!==s&&"boolean"!=r||((t=Fe(this))&&k._data(this,"__className__",t),k.attr(this,"class",!t&&!1!==s&&k._data(this,"__className__")||""))})},hasClass:function(t){for(var e,n=0,i=" "+t+" ";e=this[n++];)if(1===e.nodeType&&-1<(" "+Fe(e)+" ").replace(He," ").indexOf(i))return!0;return!1}}),k.each("blur focus focusin focusout load resize scroll unload click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup error contextmenu".split(" "),function(t,n){k.fn[n]=function(t,e){return 0<arguments.length?this.on(n,null,t,e):this.trigger(n)}}),k.fn.extend({hover:function(t,e){return this.mouseenter(t).mouseleave(e||t)}});var We=C.location,Ye=k.now(),qe=/\?/,ze=/(,)|(\[|{)|(}|])|"(?:[^"\\\r\n]|\\["\\\/bfnrt]|\\u[\da-fA-F]{4})*"\s*:?|true|false|null|-?(?!0\d)\d+(?:\.\d+|)(?:[eE][+-]?\d+|)/g;k.parseJSON=function(t){if(C.JSON&&C.JSON.parse)return C.JSON.parse(t+"");var s,r=null,e=k.trim(t+"");return e&&!k.trim(e.replace(ze,function(t,e,n,i){return s&&e&&(r=0),0===r?t:(s=n||e,r+=!i-!n,"")}))?Function("return "+e)():k.error("Invalid JSON: "+t)},k.parseXML=function(t){var e;if(!t||"string"!=typeof t)return null;try{C.DOMParser?e=(new C.DOMParser).parseFromString(t,"text/xml"):((e=new C.ActiveXObject("Microsoft.XMLDOM")).async="false",e.loadXML(t))}catch(t){e=void 0}return e&&e.documentElement&&!e.getElementsByTagName("parsererror").length||k.error("Invalid XML: "+t),e};var Be=/#.*$/,Ve=/([?&])_=[^&]*/,Ue=/^(.*?):[ \t]*([^\r\n]*)\r?$/gm,Ge=/^(?:GET|HEAD)$/,Qe=/^\/\//,Ke=/^([\w.+-]+:)(?:\/\/(?:[^\/?#]*@|)([^\/?#:]*)(?::(\d+)|)|)/,Xe={},Ze={},Je="*/".concat("*"),tn=We.href,en=Ke.exec(tn.toLowerCase())||[];function nn(r){return function(t,e){"string"!=typeof t&&(e=t,t="*");var n,i=0,s=t.toLowerCase().match(I)||[];if(k.isFunction(e))for(;n=s[i++];)"+"===n.charAt(0)?(n=n.slice(1)||"*",(r[n]=r[n]||[]).unshift(e)):(r[n]=r[n]||[]).push(e)}}function sn(e,s,r,o){var a={},l=e===Ze;function c(t){var i;return a[t]=!0,k.each(e[t]||[],function(t,e){var n=e(s,r,o);return"string"!=typeof n||l||a[n]?l?!(i=n):void 0:(s.dataTypes.unshift(n),c(n),!1)}),i}return c(s.dataTypes[0])||!a["*"]&&c("*")}function rn(t,e){var n,i,s=k.ajaxSettings.flatOptions||{};for(i in e)void 0!==e[i]&&((s[i]?t:n=n||{})[i]=e[i]);return n&&k.extend(!0,t,n),t}function on(t){if(!k.contains(t.ownerDocument||f,t))return!0;for(;t&&1===t.nodeType;){if("none"===((e=t).style&&e.style.display||k.css(e,"display"))||"hidden"===t.type)return!0;t=t.parentNode}var e;return!1}k.extend({active:0,lastModified:{},etag:{},ajaxSettings:{url:tn,type:"GET",isLocal:/^(?:about|app|app-storage|.+-extension|file|res|widget):$/.test(en[1]),global:!0,processData:!0,async:!0,contentType:"application/x-www-form-urlencoded; charset=UTF-8",accepts:{"*":Je,text:"text/plain",html:"text/html",xml:"application/xml, text/xml",json:"application/json, text/javascript"},contents:{xml:/\bxml\b/,html:/\bhtml/,json:/\bjson\b/},responseFields:{xml:"responseXML",text:"responseText",json:"responseJSON"},converters:{"* text":String,"text html":!0,"text json":k.parseJSON,"text xml":k.parseXML},flatOptions:{url:!0,context:!0}},ajaxSetup:function(t,e){return e?rn(rn(t,k.ajaxSettings),e):rn(k.ajaxSettings,t)},ajaxPrefilter:nn(Xe),ajaxTransport:nn(Ze),ajax:function(t,e){"object"==typeof t&&(e=t,t=void 0),e=e||{};var n,i,u,d,h,p,f,s,g=k.ajaxSetup({},e),m=g.context||g,y=g.context&&(m.nodeType||m.jquery)?k(m):k.event,v=k.Deferred(),b=k.Callbacks("once memory"),_=g.statusCode||{},r={},o={},w=0,a="canceled",x={readyState:0,getResponseHeader:function(t){var e;if(2===w){if(!s)for(s={};e=Ue.exec(d);)s[e[1].toLowerCase()]=e[2];e=s[t.toLowerCase()]}return null==e?null:e},getAllResponseHeaders:function(){return 2===w?d:null},setRequestHeader:function(t,e){var n=t.toLowerCase();return w||(t=o[n]=o[n]||t,r[t]=e),this},overrideMimeType:function(t){return w||(g.mimeType=t),this},statusCode:function(t){var e;if(t)if(w<2)for(e in t)_[e]=[_[e],t[e]];else x.always(t[x.status]);return this},abort:function(t){var e=t||a;return f&&f.abort(e),l(0,e),this}};if(v.promise(x).complete=b.add,x.success=x.done,x.error=x.fail,g.url=((t||g.url||tn)+"").replace(Be,"").replace(Qe,en[1]+"//"),g.type=e.method||e.type||g.method||g.type,g.dataTypes=k.trim(g.dataType||"*").toLowerCase().match(I)||[""],null==g.crossDomain&&(n=Ke.exec(g.url.toLowerCase()),g.crossDomain=!(!n||n[1]===en[1]&&n[2]===en[2]&&(n[3]||("http:"===n[1]?"80":"443"))===(en[3]||("http:"===en[1]?"80":"443")))),g.data&&g.processData&&"string"!=typeof g.data&&(g.data=k.param(g.data,g.traditional)),sn(Xe,g,e,x),2===w)return x;for(i in(p=k.event&&g.global)&&0==k.active++&&k.event.trigger("ajaxStart"),g.type=g.type.toUpperCase(),g.hasContent=!Ge.test(g.type),u=g.url,g.hasContent||(g.data&&(u=g.url+=(qe.test(u)?"&":"?")+g.data,delete g.data),!1===g.cache&&(g.url=Ve.test(u)?u.replace(Ve,"$1_="+Ye++):u+(qe.test(u)?"&":"?")+"_="+Ye++)),g.ifModified&&(k.lastModified[u]&&x.setRequestHeader("If-Modified-Since",k.lastModified[u]),k.etag[u]&&x.setRequestHeader("If-None-Match",k.etag[u])),(g.data&&g.hasContent&&!1!==g.contentType||e.contentType)&&x.setRequestHeader("Content-Type",g.contentType),x.setRequestHeader("Accept",g.dataTypes[0]&&g.accepts[g.dataTypes[0]]?g.accepts[g.dataTypes[0]]+("*"!==g.dataTypes[0]?", "+Je+"; q=0.01":""):g.accepts["*"]),g.headers)x.setRequestHeader(i,g.headers[i]);if(g.beforeSend&&(!1===g.beforeSend.call(m,x,g)||2===w))return x.abort();for(i in a="abort",{success:1,error:1,complete:1})x[i](g[i]);if(f=sn(Ze,g,e,x)){if(x.readyState=1,p&&y.trigger("ajaxSend",[x,g]),2===w)return x;g.async&&0<g.timeout&&(h=C.setTimeout(function(){x.abort("timeout")},g.timeout));try{w=1,f.send(r,l)}catch(t){if(!(w<2))throw t;l(-1,t)}}else l(-1,"No Transport");function l(t,e,n,i){var s,r,o,a,l,c=e;2!==w&&(w=2,h&&C.clearTimeout(h),f=void 0,d=i||"",x.readyState=0<t?4:0,s=200<=t&&t<300||304===t,n&&(a=function(t,e,n){for(var i,s,r,o,a=t.contents,l=t.dataTypes;"*"===l[0];)l.shift(),void 0===s&&(s=t.mimeType||e.getResponseHeader("Content-Type"));if(s)for(o in a)if(a[o]&&a[o].test(s)){l.unshift(o);break}if(l[0]in n)r=l[0];else{for(o in n){if(!l[0]||t.converters[o+" "+l[0]]){r=o;break}i=i||o}r=r||i}if(r)return r!==l[0]&&l.unshift(r),n[r]}(g,x,n)),a=function(t,e,n,i){var s,r,o,a,l,c={},u=t.dataTypes.slice();if(u[1])for(o in t.converters)c[o.toLowerCase()]=t.converters[o];for(r=u.shift();r;)if(t.responseFields[r]&&(n[t.responseFields[r]]=e),!l&&i&&t.dataFilter&&(e=t.dataFilter(e,t.dataType)),l=r,r=u.shift())if("*"===r)r=l;else if("*"!==l&&l!==r){if(!(o=c[l+" "+r]||c["* "+r]))for(s in c)if((a=s.split(" "))[1]===r&&(o=c[l+" "+a[0]]||c["* "+a[0]])){!0===o?o=c[s]:!0!==c[s]&&(r=a[0],u.unshift(a[1]));break}if(!0!==o)if(o&&t.throws)e=o(e);else try{e=o(e)}catch(t){return{state:"parsererror",error:o?t:"No conversion from "+l+" to "+r}}}return{state:"success",data:e}}(g,a,x,s),s?(g.ifModified&&((l=x.getResponseHeader("Last-Modified"))&&(k.lastModified[u]=l),(l=x.getResponseHeader("etag"))&&(k.etag[u]=l)),204===t||"HEAD"===g.type?c="nocontent":304===t?c="notmodified":(c=a.state,r=a.data,s=!(o=a.error))):(o=c,!t&&c||(c="error",t<0&&(t=0))),x.status=t,x.statusText=(e||c)+"",s?v.resolveWith(m,[r,c,x]):v.rejectWith(m,[x,c,o]),x.statusCode(_),_=void 0,p&&y.trigger(s?"ajaxSuccess":"ajaxError",[x,g,s?r:o]),b.fireWith(m,[x,c]),p&&(y.trigger("ajaxComplete",[x,g]),--k.active||k.event.trigger("ajaxStop")))}return x},getJSON:function(t,e,n){return k.get(t,e,n,"json")},getScript:function(t,e){return k.get(t,void 0,e,"script")}}),k.each(["get","post"],function(t,s){k[s]=function(t,e,n,i){return k.isFunction(e)&&(i=i||n,n=e,e=void 0),k.ajax(k.extend({url:t,type:s,dataType:i,data:e,success:n},k.isPlainObject(t)&&t))}}),k._evalUrl=function(t){return k.ajax({url:t,type:"GET",dataType:"script",cache:!0,async:!1,global:!1,throws:!0})},k.fn.extend({wrapAll:function(e){return k.isFunction(e)?this.each(function(t){k(this).wrapAll(e.call(this,t))}):(this[0]&&(t=k(e,this[0].ownerDocument).eq(0).clone(!0),this[0].parentNode&&t.insertBefore(this[0]),t.map(function(){for(var t=this;t.firstChild&&1===t.firstChild.nodeType;)t=t.firstChild;return t}).append(this)),this);var t},wrapInner:function(n){return k.isFunction(n)?this.each(function(t){k(this).wrapInner(n.call(this,t))}):this.each(function(){var t=k(this),e=t.contents();e.length?e.wrapAll(n):t.append(n)})},wrap:function(e){var n=k.isFunction(e);return this.each(function(t){k(this).wrapAll(n?e.call(this,t):e)})},unwrap:function(){return this.parent().each(function(){k.nodeName(this,"body")||k(this).replaceWith(this.childNodes)}).end()}}),k.expr.filters.hidden=function(t){return y.reliableHiddenOffsets()?t.offsetWidth<=0&&t.offsetHeight<=0&&!t.getClientRects().length:on(t)},k.expr.filters.visible=function(t){return!k.expr.filters.hidden(t)};var an=/%20/g,ln=/\[\]$/,cn=/\r?\n/g,un=/^(?:submit|button|image|reset|file)$/i,dn=/^(?:input|select|textarea|keygen)/i;k.param=function(t,e){function n(t,e){e=k.isFunction(e)?e():null==e?"":e,s[s.length]=encodeURIComponent(t)+"="+encodeURIComponent(e)}var i,s=[];if(void 0===e&&(e=k.ajaxSettings&&k.ajaxSettings.traditional),k.isArray(t)||t.jquery&&!k.isPlainObject(t))k.each(t,function(){n(this.name,this.value)});else for(i in t)!function n(i,t,s,r){var e;if(k.isArray(t))k.each(t,function(t,e){s||ln.test(i)?r(i,e):n(i+"["+("object"==typeof e&&null!=e?t:"")+"]",e,s,r)});else if(s||"object"!==k.type(t))r(i,t);else for(e in t)n(i+"["+e+"]",t[e],s,r)}(i,t[i],e,n);return s.join("&").replace(an,"+")},k.fn.extend({serialize:function(){return k.param(this.serializeArray())},serializeArray:function(){return this.map(function(){var t=k.prop(this,"elements");return t?k.makeArray(t):this}).filter(function(){var t=this.type;return this.name&&!k(this).is(":disabled")&&dn.test(this.nodeName)&&!un.test(t)&&(this.checked||!J.test(t))}).map(function(t,e){var n=k(this).val();return null==n?null:k.isArray(n)?k.map(n,function(t){return{name:e.name,value:t.replace(cn,"\r\n")}}):{name:e.name,value:n.replace(cn,"\r\n")}}).get()}}),k.ajaxSettings.xhr=void 0!==C.ActiveXObject?function(){return this.isLocal?mn():8<f.documentMode?gn():/^(get|post|head|put|delete|options)$/i.test(this.type)&&gn()||mn()}:gn;var hn=0,pn={},fn=k.ajaxSettings.xhr();function gn(){try{return new C.XMLHttpRequest}catch(t){}}function mn(){try{return new C.ActiveXObject("Microsoft.XMLHTTP")}catch(t){}}C.attachEvent&&C.attachEvent("onunload",function(){for(var t in pn)pn[t](void 0,!0)}),y.cors=!!fn&&"withCredentials"in fn,(fn=y.ajax=!!fn)&&k.ajaxTransport(function(l){var c;if(!l.crossDomain||y.cors)return{send:function(t,r){var e,o=l.xhr(),a=++hn;if(o.open(l.type,l.url,l.async,l.username,l.password),l.xhrFields)for(e in l.xhrFields)o[e]=l.xhrFields[e];for(e in l.mimeType&&o.overrideMimeType&&o.overrideMimeType(l.mimeType),l.crossDomain||t["X-Requested-With"]||(t["X-Requested-With"]="XMLHttpRequest"),t)void 0!==t[e]&&o.setRequestHeader(e,t[e]+"");o.send(l.hasContent&&l.data||null),c=function(t,e){var n,i,s;if(c&&(e||4===o.readyState))if(delete pn[a],c=void 0,o.onreadystatechange=k.noop,e)4!==o.readyState&&o.abort();else{s={},n=o.status,"string"==typeof o.responseText&&(s.text=o.responseText);try{i=o.statusText}catch(t){i=""}n||!l.isLocal||l.crossDomain?1223===n&&(n=204):n=s.text?200:404}s&&r(n,i,s,o.getAllResponseHeaders())},l.async?4===o.readyState?C.setTimeout(c):o.onreadystatechange=pn[a]=c:c()},abort:function(){c&&c(void 0,!0)}}}),k.ajaxSetup({accepts:{script:"text/javascript, application/javascript, application/ecmascript, application/x-ecmascript"},contents:{script:/\b(?:java|ecma)script\b/},converters:{"text script":function(t){return k.globalEval(t),t}}}),k.ajaxPrefilter("script",function(t){void 0===t.cache&&(t.cache=!1),t.crossDomain&&(t.type="GET",t.global=!1)}),k.ajaxTransport("script",function(e){if(e.crossDomain){var i,s=f.head||k("head")[0]||f.documentElement;return{send:function(t,n){(i=f.createElement("script")).async=!0,e.scriptCharset&&(i.charset=e.scriptCharset),i.src=e.url,i.onload=i.onreadystatechange=function(t,e){!e&&i.readyState&&!/loaded|complete/.test(i.readyState)||(i.onload=i.onreadystatechange=null,i.parentNode&&i.parentNode.removeChild(i),i=null,e||n(200,"success"))},s.insertBefore(i,s.firstChild)},abort:function(){i&&i.onload(void 0,!0)}}}});var yn=[],vn=/(=)\?(?=&|$)|\?\?/;k.ajaxSetup({jsonp:"callback",jsonpCallback:function(){var t=yn.pop()||k.expando+"_"+Ye++;return this[t]=!0,t}}),k.ajaxPrefilter("json jsonp",function(t,e,n){var i,s,r,o=!1!==t.jsonp&&(vn.test(t.url)?"url":"string"==typeof t.data&&0===(t.contentType||"").indexOf("application/x-www-form-urlencoded")&&vn.test(t.data)&&"data");if(o||"jsonp"===t.dataTypes[0])return i=t.jsonpCallback=k.isFunction(t.jsonpCallback)?t.jsonpCallback():t.jsonpCallback,o?t[o]=t[o].replace(vn,"$1"+i):!1!==t.jsonp&&(t.url+=(qe.test(t.url)?"&":"?")+t.jsonp+"="+i),t.converters["script json"]=function(){return r||k.error(i+" was not called"),r[0]},t.dataTypes[0]="json",s=C[i],C[i]=function(){r=arguments},n.always(function(){void 0===s?k(C).removeProp(i):C[i]=s,t[i]&&(t.jsonpCallback=e.jsonpCallback,yn.push(i)),r&&k.isFunction(s)&&s(r[0]),r=s=void 0}),"script"}),k.parseHTML=function(t,e,n){if(!t||"string"!=typeof t)return null;"boolean"==typeof e&&(n=e,e=!1),e=e||f;var i=w.exec(t),s=!n&&[];return i?[e.createElement(i[1])]:(i=dt([t],e,s),s&&s.length&&k(s).remove(),k.merge([],i.childNodes))};var bn=k.fn.load;function _n(t){return k.isWindow(t)?t:9===t.nodeType&&(t.defaultView||t.parentWindow)}k.fn.load=function(t,e,n){if("string"!=typeof t&&bn)return bn.apply(this,arguments);var i,s,r,o=this,a=t.indexOf(" ");return-1<a&&(i=k.trim(t.slice(a,t.length)),t=t.slice(0,a)),k.isFunction(e)?(n=e,e=void 0):e&&"object"==typeof e&&(s="POST"),0<o.length&&k.ajax({url:t,type:s||"GET",dataType:"html",data:e}).done(function(t){r=arguments,o.html(i?k("<div>").append(k.parseHTML(t)).find(i):t)}).always(n&&function(t,e){o.each(function(){n.apply(this,r||[t.responseText,e,t])})}),this},k.each(["ajaxStart","ajaxStop","ajaxComplete","ajaxError","ajaxSuccess","ajaxSend"],function(t,e){k.fn[e]=function(t){return this.on(e,t)}}),k.expr.filters.animated=function(e){return k.grep(k.timers,function(t){return e===t.elem}).length},k.offset={setOffset:function(t,e,n){var i,s,r,o,a,l,c=k.css(t,"position"),u=k(t),d={};"static"===c&&(t.style.position="relative"),a=u.offset(),r=k.css(t,"top"),l=k.css(t,"left"),s=("absolute"===c||"fixed"===c)&&-1<k.inArray("auto",[r,l])?(o=(i=u.position()).top,i.left):(o=parseFloat(r)||0,parseFloat(l)||0),k.isFunction(e)&&(e=e.call(t,n,k.extend({},a))),null!=e.top&&(d.top=e.top-a.top+o),null!=e.left&&(d.left=e.left-a.left+s),"using"in e?e.using.call(t,d):u.css(d)}},k.fn.extend({offset:function(e){if(arguments.length)return void 0===e?this:this.each(function(t){k.offset.setOffset(this,e,t)});var t,n,i={top:0,left:0},s=this[0],r=s&&s.ownerDocument;return r?(t=r.documentElement,k.contains(t,s)?(void 0!==s.getBoundingClientRect&&(i=s.getBoundingClientRect()),n=_n(r),{top:i.top+(n.pageYOffset||t.scrollTop)-(t.clientTop||0),left:i.left+(n.pageXOffset||t.scrollLeft)-(t.clientLeft||0)}):i):void 0},position:function(){if(this[0]){var t,e,n={top:0,left:0},i=this[0];return"fixed"===k.css(i,"position")?e=i.getBoundingClientRect():(t=this.offsetParent(),e=this.offset(),k.nodeName(t[0],"html")||(n=t.offset()),n.top+=k.css(t[0],"borderTopWidth",!0),n.left+=k.css(t[0],"borderLeftWidth",!0)),{top:e.top-n.top-k.css(i,"marginTop",!0),left:e.left-n.left-k.css(i,"marginLeft",!0)}}},offsetParent:function(){return this.map(function(){for(var t=this.offsetParent;t&&!k.nodeName(t,"html")&&"static"===k.css(t,"position");)t=t.offsetParent;return t||Kt})}}),k.each({scrollLeft:"pageXOffset",scrollTop:"pageYOffset"},function(e,s){var r=/Y/.test(s);k.fn[e]=function(t){return Z(this,function(t,e,n){var i=_n(t);if(void 0===n)return i?s in i?i[s]:i.document.documentElement[e]:t[e];i?i.scrollTo(r?k(i).scrollLeft():n,r?n:k(i).scrollTop()):t[e]=n},e,t,arguments.length,null)}}),k.each(["top","left"],function(t,n){k.cssHooks[n]=ee(y.pixelPosition,function(t,e){if(e)return e=Jt(t,n),Qt.test(e)?k(t).position()[n]+"px":e})}),k.each({Height:"height",Width:"width"},function(r,o){k.each({padding:"inner"+r,content:o,"":"outer"+r},function(i,t){k.fn[t]=function(t,e){var n=arguments.length&&(i||"boolean"!=typeof t),s=i||(!0===t||!0===e?"margin":"border");return Z(this,function(t,e,n){var i;return k.isWindow(t)?t.document.documentElement["client"+r]:9===t.nodeType?(i=t.documentElement,Math.max(t.body["scroll"+r],i["scroll"+r],t.body["offset"+r],i["offset"+r],i["client"+r])):void 0===n?k.css(t,e,s):k.style(t,e,n,s)},o,n?t:void 0,n,null)}})}),k.fn.extend({bind:function(t,e,n){return this.on(t,null,e,n)},unbind:function(t,e){return this.off(t,null,e)},delegate:function(t,e,n,i){return this.on(e,t,n,i)},undelegate:function(t,e,n){return 1===arguments.length?this.off(t,"**"):this.off(e,t||"**",n)}}),k.fn.size=function(){return this.length},k.fn.andSelf=k.fn.addBack,"function"==typeof define&&define.amd&&define("jquery",[],function(){return k});var wn=C.jQuery,xn=C.$;return k.noConflict=function(t){return C.$===k&&(C.$=xn),t&&C.jQuery===k&&(C.jQuery=wn),k},t||(C.jQuery=C.$=k),k}),function(){var l,t,s,o,r={}.hasOwnProperty;function e(){this.options_index=0,this.parsed=[]}function n(t,e){this.form_field=t,this.options=null!=e?e:{},n.browser_is_supported()&&(this.is_multiple=this.form_field.multiple,this.set_default_text(),this.set_default_values(),this.setup(),this.set_up_html(),this.register_observers())}function i(){return i.__super__.constructor.apply(this,arguments)}e.prototype.add_node=function(t){return"OPTGROUP"===t.nodeName.toUpperCase()?this.add_group(t):this.add_option(t)},e.prototype.add_group=function(t){var e,n,i,s,r,o=this.parsed.length;for(this.parsed.push({array_index:o,group:!0,label:this.escapeExpression(t.label),children:0,disabled:t.disabled}),r=[],n=0,i=(s=t.childNodes).length;n<i;n++)e=s[n],r.push(this.add_option(e,o,t.disabled));return r},e.prototype.add_option=function(t,e,n){if("OPTION"===t.nodeName.toUpperCase())return""!==t.text?(null!=e&&(this.parsed[e].children+=1),this.parsed.push({array_index:this.parsed.length,options_index:this.options_index,value:t.value,text:t.text,html:t.innerHTML,selected:t.selected,disabled:!0===n?n:t.disabled,group_array_index:e,classes:t.className,style:t.style.cssText})):this.parsed.push({array_index:this.parsed.length,options_index:this.options_index,empty:!0}),this.options_index+=1},e.prototype.escapeExpression=function(t){var e,n;return null==t||!1===t?"":/[\&\<\>\"\'\`]/.test(t)?(e={"<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#x27;","`":"&#x60;"},n=/&(?!\w+;)|[\<\>\"\'\`]/g,t.replace(n,function(t){return e[t]||"&amp;"})):t},(o=e).select_to_array=function(t){for(var e,n=new o,i=t.childNodes,s=0,r=i.length;s<r;s++)e=i[s],n.add_node(e);return n.parsed},n.prototype.set_default_values=function(){var e=this;return this.click_test_action=function(t){return e.test_active_click(t)},this.activate_action=function(t){return e.activate_field(t)},this.active_field=!1,this.mouse_on_container=!1,this.results_showing=!1,this.result_highlighted=null,this.allow_single_deselect=null!=this.options.allow_single_deselect&&null!=this.form_field.options[0]&&""===this.form_field.options[0].text&&this.options.allow_single_deselect,this.disable_search_threshold=this.options.disable_search_threshold||0,this.disable_search=this.options.disable_search||!1,this.enable_split_word_search=null==this.options.enable_split_word_search||this.options.enable_split_word_search,this.group_search=null==this.options.group_search||this.options.group_search,this.search_contains=this.options.search_contains||!1,this.single_backstroke_delete=null==this.options.single_backstroke_delete||this.options.single_backstroke_delete,this.max_selected_options=this.options.max_selected_options||1/0,this.inherit_select_classes=this.options.inherit_select_classes||!1,this.display_selected_options=null==this.options.display_selected_options||this.options.display_selected_options,this.display_disabled_options=null==this.options.display_disabled_options||this.options.display_disabled_options},n.prototype.set_default_text=function(){return this.form_field.getAttribute("data-placeholder")?this.default_text=this.form_field.getAttribute("data-placeholder"):this.is_multiple?this.default_text=this.options.placeholder_text_multiple||this.options.placeholder_text||n.default_multiple_text:this.default_text=this.options.placeholder_text_single||this.options.placeholder_text||n.default_single_text,this.results_none_found=this.form_field.getAttribute("data-no_results_text")||this.options.no_results_text||n.default_no_result_text},n.prototype.mouse_enter=function(){return this.mouse_on_container=!0},n.prototype.mouse_leave=function(){return this.mouse_on_container=!1},n.prototype.input_focus=function(t){var e=this;if(this.is_multiple){if(!this.active_field)return setTimeout(function(){return e.container_mousedown()},50)}else if(!this.active_field)return this.activate_field()},n.prototype.input_blur=function(t){var e=this;if(!this.mouse_on_container)return this.active_field=!1,setTimeout(function(){return e.blur_test()},100)},n.prototype.results_option_build=function(t){for(var e,n="",i=this.results_data,s=0,r=i.length;s<r;s++)(e=i[s]).group?n+=this.result_add_group(e):n+=this.result_add_option(e),null!=t&&t.first&&(e.selected&&this.is_multiple?this.choice_build(e):e.selected&&!this.is_multiple&&this.single_set_selected_text(e.text));return n},n.prototype.result_add_option=function(t){var e,n;return t.search_match&&this.include_option_in_results(t)?(e=[],t.disabled||t.selected&&this.is_multiple||e.push("active-result"),!t.disabled||t.selected&&this.is_multiple||e.push("disabled-result"),t.selected&&e.push("result-selected"),null!=t.group_array_index&&e.push("group-option"),""!==t.classes&&e.push(t.classes),(n=document.createElement("li")).className=e.join(" "),n.style.cssText=t.style,n.setAttribute("data-option-array-index",t.array_index),n.innerHTML=t.search_text,this.outerHTML(n)):""},n.prototype.result_add_group=function(t){var e;return(t.search_match||t.group_match)&&0<t.active_options?((e=document.createElement("li")).className="group-result",e.innerHTML=t.search_text,this.outerHTML(e)):""},n.prototype.results_update_field=function(){if(this.set_default_text(),this.is_multiple||this.results_reset_cleanup(),this.result_clear_highlight(),this.results_build(),this.results_showing)return this.winnow_results()},n.prototype.reset_single_select_options=function(){for(var t,e=this.results_data,n=[],i=0,s=e.length;i<s;i++)(t=e[i]).selected?n.push(t.selected=!1):n.push(void 0);return n},n.prototype.results_toggle=function(){return this.results_showing?this.results_hide():this.results_show()},n.prototype.results_search=function(t){return this.results_showing?this.winnow_results():this.results_show()},n.prototype.winnow_results=function(){var t,e,n,i,s,r,o,a,l,c,u,d,h;for(this.no_results_clear(),s=0,t=(o=this.get_search_text()).replace(/[-[\]{}()*+?.,\\^$|#\s]/g,"\\$&"),i=this.search_contains?"":"^",n=new RegExp(i+t,"i"),c=new RegExp(t,"i"),u=0,d=(h=this.results_data).length;u<d;u++)(e=h[u]).search_match=!1,r=null,this.include_option_in_results(e)&&(e.group&&(e.group_match=!1,e.active_options=0),null!=e.group_array_index&&this.results_data[e.group_array_index]&&(0===(r=this.results_data[e.group_array_index]).active_options&&r.search_match&&(s+=1),r.active_options+=1),e.group&&!this.group_search||(e.search_text=e.group?e.label:e.html,e.search_match=this.search_string_match(e.search_text,n),e.search_match&&!e.group&&(s+=1),e.search_match?(o.length&&(a=e.search_text.search(c),l=e.search_text.substr(0,a+o.length)+"</em>"+e.search_text.substr(a+o.length),e.search_text=l.substr(0,a)+"<em>"+l.substr(a)),null!=r&&(r.group_match=!0)):null!=e.group_array_index&&this.results_data[e.group_array_index].search_match&&(e.search_match=!0)));return this.result_clear_highlight(),s<1&&o.length?(this.update_results_content(""),this.no_results(o)):(this.update_results_content(this.results_option_build()),this.winnow_results_set_highlight())},n.prototype.search_string_match=function(t,e){var n,i,s,r;if(e.test(t))return!0;if(this.enable_split_word_search&&(0<=t.indexOf(" ")||0===t.indexOf("["))&&(i=t.replace(/\[|\]/g,"").split(" ")).length)for(s=0,r=i.length;s<r;s++)if(n=i[s],e.test(n))return!0},n.prototype.choices_count=function(){var t,e,n;if(null!=this.selected_option_count)return this.selected_option_count;for(t=this.selected_option_count=0,e=(n=this.form_field.options).length;t<e;t++)n[t].selected&&(this.selected_option_count+=1);return this.selected_option_count},n.prototype.choices_click=function(t){if(t.preventDefault(),!this.results_showing&&!this.is_disabled)return this.results_show()},n.prototype.keyup_checker=function(t){var e,n=null!=(e=t.which)?e:t.keyCode;switch(this.search_field_scale(),n){case 8:if(this.is_multiple&&this.backstroke_length<1&&0<this.choices_count())return this.keydown_backstroke();if(!this.pending_backstroke)return this.result_clear_highlight(),this.results_search();break;case 13:if(t.preventDefault(),this.results_showing)return this.result_select(t);break;case 27:return this.results_showing&&this.results_hide(),!0;case 9:case 38:case 40:case 16:case 91:case 17:break;default:return this.results_search()}},n.prototype.clipboard_event_checker=function(t){var e=this;return setTimeout(function(){return e.results_search()},50)},n.prototype.container_width=function(){return null!=this.options.width?this.options.width:this.form_field.offsetWidth+"px"},n.prototype.include_option_in_results=function(t){return!(this.is_multiple&&!this.display_selected_options&&t.selected||!this.display_disabled_options&&t.disabled||t.empty)},n.prototype.search_results_touchstart=function(t){return this.touch_started=!0,this.search_results_mouseover(t)},n.prototype.search_results_touchmove=function(t){return this.touch_started=!1,this.search_results_mouseout(t)},n.prototype.search_results_touchend=function(t){if(this.touch_started)return this.search_results_mouseup(t)},n.prototype.outerHTML=function(t){var e;return t.outerHTML?t.outerHTML:((e=document.createElement("div")).appendChild(t),e.innerHTML)},n.browser_is_supported=function(){return"Microsoft Internet Explorer"===window.navigator.appName?8<=document.documentMode:!(/iP(od|hone)/i.test(window.navigator.userAgent)||/Android/i.test(window.navigator.userAgent)&&/Mobile/i.test(window.navigator.userAgent))},n.default_multiple_text="Select Some Options",n.default_single_text="Select an Option",n.default_no_result_text="No results match",t=n,(l=jQuery).fn.extend({chosen:function(i){return t.browser_is_supported()?this.each(function(t){var e=l(this),n=e.data("chosen");"destroy"===i&&n?n.destroy():n||e.data("chosen",new s(this,i))}):this}}),function(t,e){for(var n in e)r.call(e,n)&&(t[n]=e[n]);function i(){this.constructor=t}i.prototype=e.prototype,t.prototype=new i,t.__super__=e.prototype}(i,t),i.prototype.setup=function(){return this.form_field_jq=l(this.form_field),this.current_selectedIndex=this.form_field.selectedIndex,this.is_rtl=this.form_field_jq.hasClass("chosen-rtl")},i.prototype.set_up_html=function(){var t,e=["chosen-container"];return e.push("chosen-container-"+(this.is_multiple?"multi":"single")),this.inherit_select_classes&&this.form_field.className&&e.push(this.form_field.className),this.is_rtl&&e.push("chosen-rtl"),t={class:e.join(" "),style:"width: "+this.container_width()+";",title:this.form_field.title},this.form_field.id.length&&(t.id=this.form_field.id.replace(/[^\w]/g,"_")+"_chosen"),this.container=l("<div />",t),this.is_multiple?this.container.html('<ul class="chosen-choices"><li class="search-field"><input type="text" value="'+this.default_text+'" class="default" autocomplete="off" style="width:25px;" /></li></ul><div class="chosen-drop"><ul class="chosen-results"></ul></div>'):this.container.html('<a class="chosen-single chosen-default" tabindex="-1"><span>'+this.default_text+'</span><div><b></b></div></a><div class="chosen-drop"><div class="chosen-search"><input type="text" autocomplete="off" /></div><ul class="chosen-results"></ul></div>'),this.form_field_jq.hide().after(this.container),this.dropdown=this.container.find("div.chosen-drop").first(),this.search_field=this.container.find("input").first(),this.search_results=this.container.find("ul.chosen-results").first(),this.search_field_scale(),this.search_no_results=this.container.find("li.no-results").first(),this.is_multiple?(this.search_choices=this.container.find("ul.chosen-choices").first(),this.search_container=this.container.find("li.search-field").first()):(this.search_container=this.container.find("div.chosen-search").first(),this.selected_item=this.container.find(".chosen-single").first()),this.results_build(),this.set_tab_index(),this.set_label_behavior(),this.form_field_jq.trigger("chosen:ready",{chosen:this})},i.prototype.register_observers=function(){var e=this;return this.container.bind("mousedown.chosen",function(t){e.container_mousedown(t)}),this.container.bind("mouseup.chosen",function(t){e.container_mouseup(t)}),this.container.bind("mouseenter.chosen",function(t){e.mouse_enter(t)}),this.container.bind("mouseleave.chosen",function(t){e.mouse_leave(t)}),this.search_results.bind("mouseup.chosen",function(t){e.search_results_mouseup(t)}),this.search_results.bind("mouseover.chosen",function(t){e.search_results_mouseover(t)}),this.search_results.bind("mouseout.chosen",function(t){e.search_results_mouseout(t)}),this.search_results.bind("mousewheel.chosen DOMMouseScroll.chosen",function(t){e.search_results_mousewheel(t)}),this.search_results.bind("touchstart.chosen",function(t){e.search_results_touchstart(t)}),this.search_results.bind("touchmove.chosen",function(t){e.search_results_touchmove(t)}),this.search_results.bind("touchend.chosen",function(t){e.search_results_touchend(t)}),this.form_field_jq.bind("chosen:updated.chosen",function(t){e.results_update_field(t)}),this.form_field_jq.bind("chosen:activate.chosen",function(t){e.activate_field(t)}),this.form_field_jq.bind("chosen:open.chosen",function(t){e.container_mousedown(t)}),this.form_field_jq.bind("chosen:close.chosen",function(t){e.input_blur(t)}),this.search_field.bind("blur.chosen",function(t){e.input_blur(t)}),this.search_field.bind("keyup.chosen",function(t){e.keyup_checker(t)}),this.search_field.bind("keydown.chosen",function(t){e.keydown_checker(t)}),this.search_field.bind("focus.chosen",function(t){e.input_focus(t)}),this.search_field.bind("cut.chosen",function(t){e.clipboard_event_checker(t)}),this.search_field.bind("paste.chosen",function(t){e.clipboard_event_checker(t)}),this.is_multiple?this.search_choices.bind("click.chosen",function(t){e.choices_click(t)}):this.container.bind("click.chosen",function(t){t.preventDefault()})},i.prototype.destroy=function(){return l(this.container[0].ownerDocument).unbind("click.chosen",this.click_test_action),this.search_field[0].tabIndex&&(this.form_field_jq[0].tabIndex=this.search_field[0].tabIndex),this.container.remove(),this.form_field_jq.removeData("chosen"),this.form_field_jq.show()},i.prototype.search_field_disabled=function(){return this.is_disabled=this.form_field_jq[0].disabled,this.is_disabled?(this.container.addClass("chosen-disabled"),this.search_field[0].disabled=!0,this.is_multiple||this.selected_item.unbind("focus.chosen",this.activate_action),this.close_field()):(this.container.removeClass("chosen-disabled"),this.search_field[0].disabled=!1,this.is_multiple?void 0:this.selected_item.bind("focus.chosen",this.activate_action))},i.prototype.container_mousedown=function(t){if(!this.is_disabled&&(t&&"mousedown"===t.type&&!this.results_showing&&t.preventDefault(),null==t||!l(t.target).hasClass("search-choice-close")))return this.active_field?this.is_multiple||!t||l(t.target)[0]!==this.selected_item[0]&&!l(t.target).parents("a.chosen-single").length||(t.preventDefault(),this.results_toggle()):(this.is_multiple&&this.search_field.val(""),l(this.container[0].ownerDocument).bind("click.chosen",this.click_test_action),this.results_show()),this.activate_field()},i.prototype.container_mouseup=function(t){if("ABBR"===t.target.nodeName&&!this.is_disabled)return this.results_reset(t)},i.prototype.search_results_mousewheel=function(t){var e;if(t.originalEvent&&(e=-t.originalEvent.wheelDelta||t.originalEvent.detail),null!=e)return t.preventDefault(),"DOMMouseScroll"===t.type&&(e*=40),this.search_results.scrollTop(e+this.search_results.scrollTop())},i.prototype.blur_test=function(t){if(!this.active_field&&this.container.hasClass("chosen-container-active"))return this.close_field()},i.prototype.close_field=function(){return l(this.container[0].ownerDocument).unbind("click.chosen",this.click_test_action),this.active_field=!1,this.results_hide(),this.container.removeClass("chosen-container-active"),this.clear_backstroke(),this.show_search_field_default(),this.search_field_scale()},i.prototype.activate_field=function(){return this.container.addClass("chosen-container-active"),this.active_field=!0,this.search_field.val(this.search_field.val()),this.search_field.focus()},i.prototype.test_active_click=function(t){var e=l(t.target).closest(".chosen-container");return e.length&&this.container[0]===e[0]?this.active_field=!0:this.close_field()},i.prototype.results_build=function(){return this.parsing=!0,this.selected_option_count=null,this.results_data=o.select_to_array(this.form_field),this.is_multiple?this.search_choices.find("li.search-choice").remove():this.is_multiple||(this.single_set_selected_text(),this.disable_search||this.form_field.options.length<=this.disable_search_threshold?(this.search_field[0].readOnly=!0,this.container.addClass("chosen-container-single-nosearch")):(this.search_field[0].readOnly=!1,this.container.removeClass("chosen-container-single-nosearch"))),this.update_results_content(this.results_option_build({first:!0})),this.search_field_disabled(),this.show_search_field_default(),this.search_field_scale(),this.parsing=!1},i.prototype.result_do_highlight=function(t){var e,n,i,s;if(t.length){if(this.result_clear_highlight(),this.result_highlight=t,this.result_highlight.addClass("highlighted"),(i=parseInt(this.search_results.css("maxHeight"),10))+(s=this.search_results.scrollTop())<=(e=(n=this.result_highlight.position().top+this.search_results.scrollTop())+this.result_highlight.outerHeight()))return this.search_results.scrollTop(0<e-i?e-i:0);if(n<s)return this.search_results.scrollTop(n)}},i.prototype.result_clear_highlight=function(){return this.result_highlight&&this.result_highlight.removeClass("highlighted"),this.result_highlight=null},i.prototype.results_show=function(){return this.is_multiple&&this.max_selected_options<=this.choices_count()?(this.form_field_jq.trigger("chosen:maxselected",{chosen:this}),!1):(this.container.addClass("chosen-with-drop"),this.results_showing=!0,this.search_field.focus(),this.search_field.val(this.search_field.val()),this.winnow_results(),this.form_field_jq.trigger("chosen:showing_dropdown",{chosen:this}))},i.prototype.update_results_content=function(t){return this.search_results.html(t)},i.prototype.results_hide=function(){return this.results_showing&&(this.result_clear_highlight(),this.container.removeClass("chosen-with-drop"),this.form_field_jq.trigger("chosen:hiding_dropdown",{chosen:this})),this.results_showing=!1},i.prototype.set_tab_index=function(t){var e;if(this.form_field.tabIndex)return e=this.form_field.tabIndex,this.form_field.tabIndex=-1,this.search_field[0].tabIndex=e},i.prototype.set_label_behavior=function(){var e=this;if(this.form_field_label=this.form_field_jq.parents("label"),!this.form_field_label.length&&this.form_field.id.length&&(this.form_field_label=l("label[for='"+this.form_field.id+"']")),0<this.form_field_label.length)return this.form_field_label.bind("click.chosen",function(t){return e.is_multiple?e.container_mousedown(t):e.activate_field()})},i.prototype.show_search_field_default=function(){return this.is_multiple&&this.choices_count()<1&&!this.active_field?(this.search_field.val(this.default_text),this.search_field.addClass("default")):(this.search_field.val(""),this.search_field.removeClass("default"))},i.prototype.search_results_mouseup=function(t){var e=l(t.target).hasClass("active-result")?l(t.target):l(t.target).parents(".active-result").first();if(e.length)return this.result_highlight=e,this.result_select(t),this.search_field.focus()},i.prototype.search_results_mouseover=function(t){var e=l(t.target).hasClass("active-result")?l(t.target):l(t.target).parents(".active-result").first();if(e)return this.result_do_highlight(e)},i.prototype.search_results_mouseout=function(t){if(l(t.target).hasClass("active-result"))return this.result_clear_highlight()},i.prototype.choice_build=function(t){var e,n=this,i=l("<li />",{class:"search-choice"}).html("<span>"+t.html+"</span>");return t.disabled?i.addClass("search-choice-disabled"):((e=l("<a />",{class:"search-choice-close","data-option-array-index":t.array_index})).bind("click.chosen",function(t){return n.choice_destroy_link_click(t)}),i.append(e)),this.search_container.before(i)},i.prototype.choice_destroy_link_click=function(t){if(t.preventDefault(),t.stopPropagation(),!this.is_disabled)return this.choice_destroy(l(t.target))},i.prototype.choice_destroy=function(t){if(this.result_deselect(t[0].getAttribute("data-option-array-index")))return this.show_search_field_default(),this.is_multiple&&0<this.choices_count()&&this.search_field.val().length<1&&this.results_hide(),t.parents("li").first().remove(),this.search_field_scale()},i.prototype.results_reset=function(){if(this.reset_single_select_options(),this.form_field.options[0].selected=!0,this.single_set_selected_text(),this.show_search_field_default(),this.results_reset_cleanup(),this.form_field_jq.trigger("change"),this.active_field)return this.results_hide()},i.prototype.results_reset_cleanup=function(){return this.current_selectedIndex=this.form_field.selectedIndex,this.selected_item.find("abbr").remove()},i.prototype.result_select=function(t){var e,n;if(this.result_highlight)return e=this.result_highlight,this.result_clear_highlight(),this.is_multiple&&this.max_selected_options<=this.choices_count()?(this.form_field_jq.trigger("chosen:maxselected",{chosen:this}),!1):(this.is_multiple?e.removeClass("active-result"):this.reset_single_select_options(),(n=this.results_data[e[0].getAttribute("data-option-array-index")]).selected=!0,this.form_field.options[n.options_index].selected=!0,this.selected_option_count=null,this.is_multiple?this.choice_build(n):this.single_set_selected_text(n.text),(t.metaKey||t.ctrlKey)&&this.is_multiple||this.results_hide(),this.search_field.val(""),!this.is_multiple&&this.form_field.selectedIndex===this.current_selectedIndex||this.form_field_jq.trigger("change",{selected:this.form_field.options[n.options_index].value}),this.current_selectedIndex=this.form_field.selectedIndex,this.search_field_scale())},i.prototype.single_set_selected_text=function(t){return null==t&&(t=this.default_text),t===this.default_text?this.selected_item.addClass("chosen-default"):(this.single_deselect_control_build(),this.selected_item.removeClass("chosen-default")),this.selected_item.find("span").text(t)},i.prototype.result_deselect=function(t){var e=this.results_data[t];return!this.form_field.options[e.options_index].disabled&&(e.selected=!1,this.form_field.options[e.options_index].selected=!1,this.selected_option_count=null,this.result_clear_highlight(),this.results_showing&&this.winnow_results(),this.form_field_jq.trigger("change",{deselected:this.form_field.options[e.options_index].value}),this.search_field_scale(),!0)},i.prototype.single_deselect_control_build=function(){if(this.allow_single_deselect)return this.selected_item.find("abbr").length||this.selected_item.find("span").first().after('<abbr class="search-choice-close"></abbr>'),this.selected_item.addClass("chosen-single-with-deselect")},i.prototype.get_search_text=function(){return this.search_field.val()===this.default_text?"":l("<div/>").text(l.trim(this.search_field.val())).html()},i.prototype.winnow_results_set_highlight=function(){var t=this.is_multiple?[]:this.search_results.find(".result-selected.active-result"),e=t.length?t.first():this.search_results.find(".active-result").first();if(null!=e)return this.result_do_highlight(e)},i.prototype.no_results=function(t){var e=l('<li class="no-results">'+this.results_none_found+' "<span></span>"</li>');return e.find("span").first().html(t),this.search_results.append(e),this.form_field_jq.trigger("chosen:no_results",{chosen:this})},i.prototype.no_results_clear=function(){return this.search_results.find(".no-results").remove()},i.prototype.keydown_arrow=function(){var t;return this.results_showing&&this.result_highlight?(t=this.result_highlight.nextAll("li.active-result").first())?this.result_do_highlight(t):void 0:this.results_show()},i.prototype.keyup_arrow=function(){var t;return this.results_showing||this.is_multiple?this.result_highlight?(t=this.result_highlight.prevAll("li.active-result")).length?this.result_do_highlight(t.first()):(0<this.choices_count()&&this.results_hide(),this.result_clear_highlight()):void 0:this.results_show()},i.prototype.keydown_backstroke=function(){var t;return this.pending_backstroke?(this.choice_destroy(this.pending_backstroke.find("a").first()),this.clear_backstroke()):(t=this.search_container.siblings("li.search-choice").last()).length&&!t.hasClass("search-choice-disabled")?(this.pending_backstroke=t,this.single_backstroke_delete?this.keydown_backstroke():this.pending_backstroke.addClass("search-choice-focus")):void 0},i.prototype.clear_backstroke=function(){return this.pending_backstroke&&this.pending_backstroke.removeClass("search-choice-focus"),this.pending_backstroke=null},i.prototype.keydown_checker=function(t){var e,n=null!=(e=t.which)?e:t.keyCode;switch(this.search_field_scale(),8!==n&&this.pending_backstroke&&this.clear_backstroke(),n){case 8:this.backstroke_length=this.search_field.val().length;break;case 9:this.results_showing&&!this.is_multiple&&this.result_select(t),this.mouse_on_container=!1;break;case 13:t.preventDefault();break;case 38:t.preventDefault(),this.keyup_arrow();break;case 40:t.preventDefault(),this.keydown_arrow()}},i.prototype.search_field_scale=function(){var t,e,n,i,s,r,o,a;if(this.is_multiple){for(i="position:absolute; left: -1000px; top: -1000px; display:none;",o=r=0,a=(s=["font-size","font-style","font-weight","font-family","line-height","text-transform","letter-spacing"]).length;o<a;o++)i+=(n=s[o])+":"+this.search_field.css(n)+";";return(t=l("<div />",{style:i})).text(this.search_field.val()),l("body").append(t),r=t.width()+25,t.remove(),(e=this.container.outerWidth())-10<r&&(r=e-10),this.search_field.css({width:r+"px"})}},s=i}.call(this),function(e,n){"function"==typeof define&&define.amd?define("bloodhound",["jquery"],function(t){return e.Bloodhound=n()}):"object"==typeof exports?module.exports=n(require("jquery")):e.Bloodhound=n(jQuery)}(this,function(){var u=function(){"use strict";return{isMsie:function(){return!!/(msie|trident)/i.test(navigator.userAgent)&&navigator.userAgent.match(/(msie |rv:)(\d+(.\d+)?)/i)[2]},isBlankString:function(t){return!t||/^\s*$/.test(t)},escapeRegExChars:function(t){return t.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g,"\\$&")},isString:function(t){return"string"==typeof t},isNumber:function(t){return"number"==typeof t},isArray:$.isArray,isFunction:$.isFunction,isObject:$.isPlainObject,isUndefined:function(t){return void 0===t},isElement:function(t){return!(!t||1!==t.nodeType)},isJQuery:function(t){return t instanceof $},toStr:function(t){return u.isUndefined(t)||null===t?"":t+""},bind:$.proxy,each:function(t,n){$.each(t,function(t,e){return n(e,t)})},map:$.map,filter:$.grep,every:function(n,i){var s=!0;return n?($.each(n,function(t,e){if(!(s=i.call(null,e,t,n)))return!1}),!!s):s},some:function(n,i){var s=!1;return n?($.each(n,function(t,e){if(s=i.call(null,e,t,n))return!1}),!!s):s},mixin:$.extend,identity:function(t){return t},clone:function(t){return $.extend(!0,{},t)},getIdGenerator:function(){var t=0;return function(){return t++}},templatify:function(t){return $.isFunction(t)?t:function(){return String(t)}},defer:function(t){setTimeout(t,0)},debounce:function(s,r,o){var a,l;return function(){var t=this,e=arguments,n=function(){a=null,o||(l=s.apply(t,e))},i=o&&!a;return clearTimeout(a),a=setTimeout(n,r),i&&(l=s.apply(t,e)),l}},throttle:function(n,i){var s,r,o,a,l=0,c=function(){l=new Date,o=null,a=n.apply(s,r)};return function(){var t=new Date,e=i-(t-l);return s=this,r=arguments,e<=0?(clearTimeout(o),o=null,l=t,a=n.apply(s,r)):o=o||setTimeout(c,e),a}},stringify:function(t){return u.isString(t)?t:JSON.stringify(t)},noop:function(){}}}(),n=function(){"use strict";return{nonword:e,whitespace:t,obj:{nonword:n(e),whitespace:n(t)}};function t(t){return(t=u.toStr(t))?t.split(/\s+/):[]}function e(t){return(t=u.toStr(t))?t.split(/\W+/):[]}function n(i){return function(){var t=[].slice.call(arguments,0);return function(e){var n=[];return u.each(t,function(t){n=n.concat(i(u.toStr(e[t])))}),n}}}}(),i=function(){"use strict";function t(t){this.maxSize=u.isNumber(t)?t:100,this.reset(),this.maxSize<=0&&(this.set=this.get=$.noop)}function e(){this.head=this.tail=null}function s(t,e){this.key=t,this.val=e,this.prev=this.next=null}return u.mixin(t.prototype,{set:function(t,e){var n,i=this.list.tail;this.size>=this.maxSize&&(this.list.remove(i),delete this.hash[i.key],this.size--),(n=this.hash[t])?(n.val=e,this.list.moveToFront(n)):(n=new s(t,e),this.list.add(n),this.hash[t]=n,this.size++)},get:function(t){var e=this.hash[t];if(e)return this.list.moveToFront(e),e.val},reset:function(){this.size=0,this.hash={},this.list=new e}}),u.mixin(e.prototype,{add:function(t){this.head&&(t.next=this.head,this.head.prev=t),this.head=t,this.tail=this.tail||t},remove:function(t){t.prev?t.prev.next=t.next:this.head=t.next,t.next?t.next.prev=t.prev:this.tail=t.prev},moveToFront:function(t){this.remove(t),this.add(t)}}),t}(),e=function(){"use strict";var n;try{(n=window.localStorage).setItem("~~~","!"),n.removeItem("~~~")}catch(t){n=null}function t(t,e){this.prefix=["__",t,"__"].join(""),this.ttlKey="__ttl__",this.keyMatcher=new RegExp("^"+u.escapeRegExChars(this.prefix)),this.ls=e||n,this.ls&&window.JSON||(this.get=this.set=this.remove=this.clear=this.isExpired=u.noop)}return u.mixin(t.prototype,{_prefix:function(t){return this.prefix+t},_ttlKey:function(t){return this._prefix(t)+this.ttlKey},get:function(t){return this.isExpired(t)&&this.remove(t),r(this.ls.getItem(this._prefix(t)))},set:function(t,e,n){return u.isNumber(n)?this.ls.setItem(this._ttlKey(t),s(i()+n)):this.ls.removeItem(this._ttlKey(t)),this.ls.setItem(this._prefix(t),s(e))},remove:function(t){return this.ls.removeItem(this._ttlKey(t)),this.ls.removeItem(this._prefix(t)),this},clear:function(){for(var t,e=[],n=this.ls.length,i=0;i<n;i++)(t=this.ls.key(i)).match(this.keyMatcher)&&e.push(t.replace(this.keyMatcher,""));for(i=e.length;i--;)this.remove(e[i]);return this},isExpired:function(t){var e=r(this.ls.getItem(this._ttlKey(t)));return!!(u.isNumber(e)&&i()>e)}}),t;function i(){return(new Date).getTime()}function s(t){return JSON.stringify(u.isUndefined(t)?null:t)}function r(t){return $.parseJSON(t)}}(),s=function(){"use strict";var a=0,l={},c=6,e=new i(10);function t(t){t=t||{},this.cancelled=!1,this.lastReq=null,this._send=t.transport,this._get=t.limiter?t.limiter(this._get):this._get,this._cache=!1===t.cache?new i(0):e}return t.setMaxPendingRequests=function(t){c=t},t.resetCache=function(){e.reset()},u.mixin(t.prototype,{_fingerprint:function(t){return(t=t||{}).url+t.type+$.param(t.data||{})},_get:function(t,e){var n,i,s=this;function r(t){e(null,t),s._cache.set(n,t)}function o(){e(!0)}n=this._fingerprint(t),this.cancelled||n!==this.lastReq||((i=l[n])?i.done(r).fail(o):a<c?(a++,l[n]=this._send(t).done(r).fail(o).always(function(){a--,delete l[n],s.onDeckRequestArgs&&(s._get.apply(s,s.onDeckRequestArgs),s.onDeckRequestArgs=null)})):this.onDeckRequestArgs=[].slice.call(arguments,0))},get:function(t,e){var n,i;e=e||$.noop,t=u.isString(t)?{url:t}:t||{},i=this._fingerprint(t),this.cancelled=!1,this.lastReq=i,(n=this._cache.get(i))?e(null,n):this._get(t,e)},cancel:function(){this.cancelled=!0}}),t}(),r=window.SearchIndex=function(){"use strict";var a="c",l="i";function t(t){(t=t||{}).datumTokenizer&&t.queryTokenizer||$.error("datumTokenizer and queryTokenizer are both required"),this.identify=t.identify||u.stringify,this.datumTokenizer=t.datumTokenizer,this.queryTokenizer=t.queryTokenizer,this.reset()}return u.mixin(t.prototype,{bootstrap:function(t){this.datums=t.datums,this.trie=t.trie},add:function(t){var r=this;t=u.isArray(t)?t:[t],u.each(t,function(t){var s,e;r.datums[s=r.identify(t)]=t,e=n(r.datumTokenizer(t)),u.each(e,function(t){for(var e,n=r.trie,i=t.split("");e=i.shift();)(n=n[a][e]||(n[a][e]=o()))[l].push(s)})})},get:function(t){var e=this;return u.map(t,function(t){return e.datums[t]})},search:function(t){var r,o=this,e=n(this.queryTokenizer(t));return u.each(e,function(t){var e,n,i,s;if(r&&0===r.length)return!1;for(e=o.trie,n=t.split("");e&&(i=n.shift());)e=e[a][i];if(!e||0!==n.length)return!(r=[]);s=e[l].slice(0),r=r?function(t,e){var n=0,i=0,s=[];t=t.sort(a),e=e.sort(a);var r=t.length,o=e.length;for(;n<r&&i<o;)t[n]<e[i]?n++:(t[n]>e[i]||(s.push(t[n]),n++),i++);return s;function a(t,e){return t-e}}(r,s):s}),r?u.map(function(t){for(var e={},n=[],i=0,s=t.length;i<s;i++)e[t[i]]||(e[t[i]]=!0,n.push(t[i]));return n}(r),function(t){return o.datums[t]}):[]},all:function(){var t=[];for(var e in this.datums)t.push(this.datums[e]);return t},reset:function(){this.datums={},this.trie=o()},serialize:function(){return{datums:this.datums,trie:this.trie}}}),t;function n(t){return t=u.filter(t,function(t){return!!t}),t=u.map(t,function(t){return t.toLowerCase()})}function o(){var t={};return t[l]=[],t[a]={},t}}(),o=function(){"use strict";var n;function t(t){this.url=t.url,this.ttl=t.ttl,this.cache=t.cache,this.transform=t.transform,this.transport=t.transport,this.thumbprint=t.thumbprint,this.storage=new e(t.cacheKey)}return n={data:"data",protocol:"protocol",thumbprint:"thumbprint"},u.mixin(t.prototype,{_settings:function(){return{url:this.url,type:"GET",dataType:"json"}},store:function(t){this.cache&&(this.storage.set(n.data,t,this.ttl),this.storage.set(n.protocol,location.protocol,this.ttl),this.storage.set(n.thumbprint,this.thumbprint,this.ttl))},fromCache:function(){var t,e={};return this.cache?(e.data=this.storage.get(n.data),e.protocol=this.storage.get(n.protocol),e.thumbprint=this.storage.get(n.thumbprint),t=e.thumbprint!==this.thumbprint||e.protocol!==location.protocol,e.data&&!t?e.data:null):null},fromNetwork:function(e){var n=this;e&&this.transport(this._settings()).fail(function(){e(!0)}).done(function(t){e(null,n.transform(t))})},clear:function(){return this.storage.clear(),this}}),t}(),a=function(){"use strict";function t(t){this.url=t.url,this.prepare=t.prepare,this.transform=t.transform,this.transport=new s({cache:t.cache,limiter:t.limiter,transport:t.transport})}return u.mixin(t.prototype,{_settings:function(){return{url:this.url,type:"GET",dataType:"json"}},get:function(t,n){var e,i=this;if(n)return t=t||"",e=this.prepare(t,this._settings()),this.transport.get(e,function(t,e){n(t?[]:i.transform(e))})},cancelLastRequest:function(){this.transport.cancel()}}),t}(),l=function(){"use strict";return function(t){var e,n,i,s,r,o={initialize:!0,identify:u.stringify,datumTokenizer:null,queryTokenizer:null,sufficient:5,sorter:null,local:[],prefetch:null,remote:null};return(t=u.mixin(o,t||{})).datumTokenizer||$.error("datumTokenizer is required"),t.queryTokenizer||$.error("queryTokenizer is required"),e=t.sorter,t.sorter=e?function(t){return t.sort(e)}:u.identity,t.local=u.isFunction(t.local)?t.local():t.local,t.prefetch=(n=t.prefetch)?(i={url:null,ttl:864e5,cache:!0,cacheKey:null,thumbprint:"",transform:u.identity,transport:null},n=u.isString(n)?{url:n}:n,(n=u.mixin(i,n)).url||$.error("prefetch requires url to be set"),n.transform=n.filter||n.transform,n.cacheKey=n.cacheKey||n.url,n.thumbprint="0.11.0-templating"+n.thumbprint,n.transport=n.transport?a(n.transport):$.ajax,n):null,t.remote=(s=t.remote)?(r={url:null,cache:!0,prepare:null,replace:null,wildcard:null,limiter:null,rateLimitBy:"debounce",rateLimitWait:300,transform:u.identity,transport:null},s=u.isString(s)?{url:s}:s,(s=u.mixin(r,s)).url||$.error("remote requires url to be set"),s.transform=s.filter||s.transform,s.prepare=function(t){var e,n,i;return e=t.prepare,n=t.replace,i=t.wildcard,e||(e=n?function(t,e){return e.url=n(e.url,t),e}:t.wildcard?function(t,e){return e.url=e.url.replace(i,encodeURIComponent(t)),e}:function(t,e){return e})}(s),s.limiter=function(t){var e,n,i;return e=t.limiter,n=t.rateLimitBy,i=t.rateLimitWait,e=e||(/^throttle$/i.test(n)?function(e){return function(t){return u.throttle(t,e)}}:function(e){return function(t){return u.debounce(t,e)}})(i)}(s),s.transport=s.transport?a(s.transport):$.ajax,delete s.replace,delete s.wildcard,delete s.rateLimitBy,delete s.rateLimitWait,s):void 0,t};function a(n){return function(t){var e=$.Deferred();return n(t,function(t){u.defer(function(){e.resolve(t)})},function(t){u.defer(function(){e.reject(t)})}),e}}}();return function(){"use strict";var t;function e(t){t=l(t),this.sorter=t.sorter,this.identify=t.identify,this.sufficient=t.sufficient,this.local=t.local,this.remote=t.remote?new a(t.remote):null,this.prefetch=t.prefetch?new o(t.prefetch):null,this.index=new r({identify:this.identify,datumTokenizer:t.datumTokenizer,queryTokenizer:t.queryTokenizer}),!1!==t.initialize&&this.initialize()}return t=window&&window.Bloodhound,e.noConflict=function(){return window&&(window.Bloodhound=t),e},e.tokenizers=n,u.mixin(e.prototype,{__ttAdapter:function(){var i=this;return this.remote?function(t,e,n){return i.search(t,e,n)}:function(t,e){return i.search(t,e)}},_loadPrefetch:function(){var t,n=this,i=$.Deferred();return this.prefetch?(t=this.prefetch.fromCache())?(this.index.bootstrap(t),i.resolve()):this.prefetch.fromNetwork(function(t,e){if(t)return i.reject();n.add(e),n.prefetch.store(n.index.serialize()),i.resolve()}):i.resolve(),i.promise()},_initialize:function(){var t=this;return this.clear(),(this.initPromise=this._loadPrefetch()).done(function(){t.add(t.local)}),this.initPromise},initialize:function(t){return!this.initPromise||t?this._initialize():this.initPromise},add:function(t){return this.index.add(t),this},get:function(t){return t=u.isArray(t)?t:[].slice.call(arguments),this.index.get(t)},search:function(t,e,i){var s=this,r=this.sorter(this.index.search(t));return e(this.remote?r.slice():r),this.remote&&r.length<this.sufficient?this.remote.get(t,function(t){var n=[];u.each(t,function(e){u.some(r,function(t){return s.identify(e)===s.identify(t)})||n.push(e)}),i&&i(n)}):this.remote&&this.remote.cancelLastRequest(),this},all:function(){return this.index.all()},clear:function(){return this.index.reset(),this},clearPrefetchCache:function(){return this.prefetch&&this.prefetch.clear(),this},clearRemoteCache:function(){return s.resetCache(),this},ttAdapter:function(){return this.__ttAdapter()}}),e}()}),function(e){"function"==typeof define&&define.amd?define("typeahead.js",["jquery"],function(t){return e()}):"object"==typeof exports?module.exports=e(require("jquery")):e(jQuery)}(function(){var m=function(){"use strict";return{isMsie:function(){return!!/(msie|trident)/i.test(navigator.userAgent)&&navigator.userAgent.match(/(msie |rv:)(\d+(.\d+)?)/i)[2]},isBlankString:function(t){return!t||/^\s*$/.test(t)},escapeRegExChars:function(t){return t.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g,"\\$&")},isString:function(t){return"string"==typeof t},isNumber:function(t){return"number"==typeof t},isArray:$.isArray,isFunction:$.isFunction,isObject:$.isPlainObject,isUndefined:function(t){return void 0===t},isElement:function(t){return!(!t||1!==t.nodeType)},isJQuery:function(t){return t instanceof $},toStr:function(t){return m.isUndefined(t)||null===t?"":t+""},bind:$.proxy,each:function(t,n){$.each(t,function(t,e){return n(e,t)})},map:$.map,filter:$.grep,every:function(n,i){var s=!0;return n?($.each(n,function(t,e){if(!(s=i.call(null,e,t,n)))return!1}),!!s):s},some:function(n,i){var s=!1;return n?($.each(n,function(t,e){if(s=i.call(null,e,t,n))return!1}),!!s):s},mixin:$.extend,identity:function(t){return t},clone:function(t){return $.extend(!0,{},t)},getIdGenerator:function(){var t=0;return function(){return t++}},templatify:function(t){return $.isFunction(t)?t:function(){return String(t)}},defer:function(t){setTimeout(t,0)},debounce:function(s,r,o){var a,l;return function(){var t=this,e=arguments,n=function(){a=null,o||(l=s.apply(t,e))},i=o&&!a;return clearTimeout(a),a=setTimeout(n,r),i&&(l=s.apply(t,e)),l}},throttle:function(n,i){var s,r,o,a,l=0,c=function(){l=new Date,o=null,a=n.apply(s,r)};return function(){var t=new Date,e=i-(t-l);return s=this,r=arguments,e<=0?(clearTimeout(o),o=null,l=t,a=n.apply(s,r)):o=o||setTimeout(c,e),a}},stringify:function(t){return m.isString(t)?t:JSON.stringify(t)},noop:function(){}}}(),n=function(){"use strict";var s={wrapper:"twitter-typeahead",input:"tt-input",hint:"tt-hint",menu:"tt-menu",dataset:"tt-dataset",suggestion:"tt-suggestion",selectable:"tt-selectable",empty:"tt-empty",open:"tt-open",cursor:"tt-cursor",highlight:"tt-highlight"},r={wrapper:"<span></span>",menu:"<div></div>",dataset:"<div></div>"};return function(t){var e,n,i;return t=t||{},n=m.mixin({},s,t.classNames),i=m.mixin({},r,t.templates),{css:(e={css:function(){var t={wrapper:{position:"relative",display:"inline-block"},hint:{position:"absolute",top:"0",left:"0",borderColor:"transparent",boxShadow:"none",opacity:"1"},input:{position:"relative",verticalAlign:"top",backgroundColor:"transparent"},inputWithNoHint:{position:"relative",verticalAlign:"top"},menu:{position:"absolute",top:"100%",left:"0",zIndex:"100",display:"none"},ltr:{left:"0",right:"auto"},rtl:{left:"auto",right:" 0"}};m.isMsie()&&m.mixin(t.input,{backgroundImage:"url(data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7)"});m.isMsie()&&m.isMsie()<=7&&m.mixin(t.input,{marginTop:"-1px"});return t}(),classes:n,html:{wrapper:function(){return $(i.wrapper).addClass(n.wrapper)},menu:function(){return $(i.menu).addClass(n.menu)},dataset:function(){return $(i.dataset).addClass(n.dataset)}},selectors:function(t){var n={};return m.each(t,function(t,e){n[e]="."+t}),n}(n)}).css,html:e.html,classes:e.classes,selectors:e.selectors,mixin:function(t){m.mixin(t,e)}}}}(),y=function(){"use strict";var n;function t(t){t&&t.el||$.error("EventBus initialized without el"),this.$el=$(t.el)}return n={render:"rendered",cursorchange:"cursorchanged",select:"selected",autocomplete:"autocompleted"},m.mixin(t.prototype,{_trigger:function(t,e){var n=$.Event("typeahead:"+t);return(e=e||[]).unshift(n),this.$el.trigger.apply(this.$el,e),n},before:function(t){var e=[].slice.call(arguments,1);return this._trigger("before"+t,e).isDefaultPrevented()},trigger:function(t){var e;this._trigger(t,[].slice.call(arguments,1)),(e=n[t])&&this._trigger(e,[].slice.call(arguments,1))}}),t}(),e=function(){"use strict";var a=/\s+/,o=function(){var t;t=window.setImmediate?function(t){setImmediate(function(){t()})}:function(t){setTimeout(function(){t()},0)};return t}();return{onSync:function(t,e,n){return i.call(this,"sync",t,e,n)},onAsync:function(t,e,n){return i.call(this,"async",t,e,n)},off:function(t){var e;if(!this._callbacks)return this;t=t.split(a);for(;e=t.shift();)delete this._callbacks[e];return this},trigger:function(t){var e,n,i,s,r;if(!this._callbacks)return this;t=t.split(a),i=[].slice.call(arguments,1);for(;(e=t.shift())&&(n=this._callbacks[e]);)s=l(n.sync,this,[e].concat(i)),r=l(n.async,this,[e].concat(i)),s()&&o(r);return this}};function i(t,e,n,i){var s,r,o;if(!n)return this;for(e=e.split(a),n=i?(o=i,(r=n).bind?r.bind(o):function(){r.apply(o,[].slice.call(arguments,0))}):n,this._callbacks=this._callbacks||{};s=e.shift();)this._callbacks[s]=this._callbacks[s]||{sync:[],async:[]},this._callbacks[s][t].push(n);return this}function l(i,s,r){return function(){for(var t,e=0,n=i.length;!t&&e<n;e+=1)t=!1===i[e].apply(s,r);return!t}}}(),a=function(o){"use strict";var t={node:null,pattern:null,tagName:"strong",className:null,wordsOnly:!1,caseSensitive:!1};return function(s){var r;(s=m.mixin({},t,s)).node&&s.pattern&&(s.pattern=m.isArray(s.pattern)?s.pattern:[s.pattern],r=function(t,e,n){for(var i,s=[],r=0,o=t.length;r<o;r++)s.push(m.escapeRegExChars(t[r]));return i=n?"\\b("+s.join("|")+")\\b":"("+s.join("|")+")",e?new RegExp(i):new RegExp(i,"i")}(s.pattern,s.caseSensitive,s.wordsOnly),function t(e,n){var i;for(var s=0;s<e.childNodes.length;s++)3===(i=e.childNodes[s]).nodeType?s+=n(i)?1:0:t(i,n)}(s.node,function(t){var e,n,i;(e=r.exec(t.data))&&(i=o.createElement(s.tagName),s.className&&(i.className=s.className),(n=t.splitText(e.index)).splitText(e[0].length),i.appendChild(n.cloneNode(!0)),t.parentNode.replaceChild(i,n));return!!e}))}}(window.document),v=function(){"use strict";var r;function o(t,e){var n;(t=t||{}).input||$.error("input is missing"),e.mixin(this),this.$hint=$(t.hint),this.$input=$(t.input),this.query=this.$input.val(),this.queryWhenFocused=this.hasFocus()?this.query:null,this.$overflowHelper=(n=this.$input,$('<pre aria-hidden="true"></pre>').css({position:"absolute",visibility:"hidden",whiteSpace:"pre",fontFamily:n.css("font-family"),fontSize:n.css("font-size"),fontStyle:n.css("font-style"),fontVariant:n.css("font-variant"),fontWeight:n.css("font-weight"),wordSpacing:n.css("word-spacing"),letterSpacing:n.css("letter-spacing"),textIndent:n.css("text-indent"),textRendering:n.css("text-rendering"),textTransform:n.css("text-transform")}).insertAfter(n)),this._checkLanguageDirection(),0===this.$hint.length&&(this.setHint=this.getHint=this.clearHint=this.clearHintIfInvalid=m.noop)}return r={9:"tab",27:"esc",37:"left",39:"right",13:"enter",38:"up",40:"down"},o.normalizeQuery=function(t){return(t||"").replace(/^\s*/g,"").replace(/\s{2,}/g," ")},m.mixin(o.prototype,e,{_onBlur:function(){this.resetInputValue(),this.trigger("blurred")},_onFocus:function(){this.queryWhenFocused=this.query,this.trigger("focused")},_onKeydown:function(t){var e=r[t.which||t.keyCode];this._managePreventDefault(e,t),e&&this._shouldTrigger(e,t)&&this.trigger(e+"Keyed",t)},_onInput:function(){this._setQuery(this.getInputValue()),this.clearHintIfInvalid(),this._checkLanguageDirection()},_managePreventDefault:function(t,e){var n;switch(t){case"up":case"down":n=!i(e);break;default:n=!1}n&&e.preventDefault()},_shouldTrigger:function(t,e){var n;switch(t){case"tab":n=!i(e);break;default:n=!0}return n},_checkLanguageDirection:function(){var t=(this.$input.css("direction")||"ltr").toLowerCase();this.dir!==t&&(this.dir=t,this.$hint.attr("dir",t),this.trigger("langDirChanged",t))},_setQuery:function(t,e){var n,i,s,r;s=t,r=this.query,i=(n=o.normalizeQuery(s)===o.normalizeQuery(r))&&this.query.length!==t.length,this.query=t,e||n?!e&&i&&this.trigger("whitespaceChanged",this.query):this.trigger("queryChanged",this.query)},bind:function(){var e=this,t=m.bind(this._onBlur,this),n=m.bind(this._onFocus,this),i=m.bind(this._onKeydown,this),s=m.bind(this._onInput,this);return this.$input.on("blur.tt",t).on("focus.tt",n).on("keydown.tt",i),!m.isMsie()||9<m.isMsie()?this.$input.on("input.tt",s):this.$input.on("keydown.tt keypress.tt cut.tt paste.tt",function(t){r[t.which||t.keyCode]||m.defer(m.bind(e._onInput,e,t))}),this},focus:function(){this.$input.focus()},blur:function(){this.$input.blur()},getLangDir:function(){return this.dir},getQuery:function(){return this.query||""},setQuery:function(t,e){this.setInputValue(t),this._setQuery(t,e)},hasQueryChangedSinceLastFocus:function(){return this.query!==this.queryWhenFocused},getInputValue:function(){return this.$input.val()},setInputValue:function(t){this.$input.val(t),this.clearHintIfInvalid(),this._checkLanguageDirection()},resetInputValue:function(){this.setInputValue(this.query)},getHint:function(){return this.$hint.val()},setHint:function(t){this.$hint.val(t)},clearHint:function(){this.setHint("")},clearHintIfInvalid:function(){var t=this.getInputValue(),e=this.getHint(),n=t!==e&&0===e.indexOf(t);""!==t&&n&&!this.hasOverflow()||this.clearHint()},hasFocus:function(){return this.$input.is(":focus")},hasOverflow:function(){var t=this.$input.width()-2;return this.$overflowHelper.text(this.getInputValue()),this.$overflowHelper.width()>=t},isCursorAtEnd:function(){var t,e=this.$input.val().length,n=this.$input[0].selectionStart;return m.isNumber(n)?n===e:!document.selection||((t=document.selection.createRange()).moveStart("character",-e),e===t.text.length)},destroy:function(){this.$hint.off(".tt"),this.$input.off(".tt"),this.$overflowHelper.remove(),this.$hint=this.$input=this.$overflowHelper=null}}),o;function i(t){return t.altKey||t.ctrlKey||t.metaKey||t.shiftKey}}(),s=function(){"use strict";var o,r;function t(t,e){var n,i,s;(t=t||{}).templates=t.templates||{},t.templates.notFound=t.templates.notFound||t.templates.empty,t.source||$.error("missing source"),t.node||$.error("missing node"),t.name&&!/^[_a-zA-Z0-9-]+$/.test(t.name)&&$.error("invalid dataset name: "+t.name),e.mixin(this),this.highlight=!!t.highlight,this.name=t.name||r(),this.limit=t.limit||5,this.displayFn=(n=(n=t.display||t.displayKey)||m.stringify,m.isFunction(n)?n:function(t){return t[n]}),this.templates=(i=t.templates,s=this.displayFn,{notFound:i.notFound&&m.templatify(i.notFound),pending:i.pending&&m.templatify(i.pending),header:i.header&&m.templatify(i.header),footer:i.footer&&m.templatify(i.footer),suggestion:i.suggestion||function(t){return"<div><p>"+s(t)+"</p></div>"}}),this.source=t.source.__ttAdapter?t.source.__ttAdapter():t.source,this.async=m.isUndefined(t.async)?2<this.source.length:!!t.async,this._resetLastSuggestion(),this.$el=$(t.node).addClass(this.classes.dataset).addClass(this.classes.dataset+"-"+this.name)}return o={val:"tt-selectable-display",obj:"tt-selectable-object"},r=m.getIdGenerator(),t.extractData=function(t){var e=$(t);return e.data(o.obj)?{val:e.data(o.val)||"",obj:e.data(o.obj)||null}:null},m.mixin(t.prototype,e,{_overwrite:function(t,e){(e=e||[]).length?this._renderSuggestions(t,e):this.async&&this.templates.pending?this._renderPending(t):!this.async&&this.templates.notFound?this._renderNotFound(t):this._empty(),this.trigger("rendered",this.name,e,!1)},_append:function(t,e){(e=e||[]).length&&this.$lastSuggestion.length?this._appendSuggestions(t,e):e.length?this._renderSuggestions(t,e):!this.$lastSuggestion.length&&this.templates.notFound&&this._renderNotFound(t),this.trigger("rendered",this.name,e,!0)},_renderSuggestions:function(t,e){var n=this._getSuggestionsFragment(t,e);this.$lastSuggestion=n.children().last(),this.$el.html(n).prepend(this._getHeader(t,e)).append(this._getFooter(t,e))},_appendSuggestions:function(t,e){var n=this._getSuggestionsFragment(t,e),i=n.children().last();this.$lastSuggestion.after(n),this.$lastSuggestion=i},_renderPending:function(t){var e=this.templates.pending;this._resetLastSuggestion(),e&&this.$el.html(e({query:t,dataset:this.name}))},_renderNotFound:function(t){var e=this.templates.notFound;this._resetLastSuggestion(),e&&this.$el.html(e({query:t,dataset:this.name}))},_empty:function(){this.$el.empty(),this._resetLastSuggestion()},_getSuggestionsFragment:function(i,t){var s=this,r=document.createDocumentFragment();return m.each(t,function(t){var e=s._injectQuery(i,t),n=$(s.templates.suggestion(e)).data(o.obj,t).data(o.val,s.displayFn(t)).addClass(s.classes.suggestion+" "+s.classes.selectable);r.appendChild(n[0])}),this.highlight&&a({className:this.classes.highlight,node:r,pattern:i}),$(r)},_getFooter:function(t,e){return this.templates.footer?this.templates.footer({query:t,suggestions:e,dataset:this.name}):null},_getHeader:function(t,e){return this.templates.header?this.templates.header({query:t,suggestions:e,dataset:this.name}):null},_resetLastSuggestion:function(){this.$lastSuggestion=$()},_injectQuery:function(t,e){return m.isObject(e)?m.mixin({_query:t},e):e},update:function(e){var n=this,i=!1,s=!1,r=0;function t(t){s||(s=!0,t=(t||[]).slice(0,n.limit),r=t.length,n._overwrite(e,t),r<n.limit&&n.async&&n.trigger("asyncRequested",e))}this.cancel(),this.cancel=function(){i=!0,n.cancel=$.noop,n.async&&n.trigger("asyncCanceled",e)},this.source(e,t,function(t){t=t||[],!i&&r<n.limit&&(n.cancel=$.noop,r+=t.length,n._append(e,t.slice(0,n.limit-r)),n.async&&n.trigger("asyncReceived",e))}),s||t([])},cancel:$.noop,clear:function(){this._empty(),this.cancel(),this.trigger("cleared")},isEmpty:function(){return this.$el.is(":empty")},destroy:function(){this.$el=null}}),t}(),b=function(){"use strict";function t(t,n){var i=this;(t=t||{}).node||$.error("node is required"),n.mixin(this),this.$node=$(t.node),this.query=null,this.datasets=m.map(t.datasets,function(t){var e=i.$node.find(t.node).first();return t.node=e.length?e:$(t.templates.dataset).appendTo(i.$node),new s(t,n)})}return m.mixin(t.prototype,e,{_onSelectableClick:function(t){this.trigger("selectableClicked",$(t.currentTarget))},_onRendered:function(t,e,n,i){this.$node.toggleClass(this.classes.empty,this._allDatasetsEmpty()),this.trigger("datasetRendered",e,n,i)},_onCleared:function(){this.$node.toggleClass(this.classes.empty,this._allDatasetsEmpty()),this.trigger("datasetCleared")},_propagate:function(){this.trigger.apply(this,arguments)},_allDatasetsEmpty:function(){return m.every(this.datasets,function(t){return t.isEmpty()})},_getSelectables:function(){return this.$node.find(this.selectors.selectable)},_removeCursor:function(){var t=this.getActiveSelectable();t&&t.removeClass(this.classes.cursor)},_ensureVisible:function(t){var e=t.position().top,n=e+t.outerHeight(!0),i=this.$node.scrollTop(),s=this.$node.height()+parseInt(this.$node.css("paddingTop"),10)+parseInt(this.$node.css("paddingBottom"),10);e<0?this.$node.scrollTop(i+e):s<n&&this.$node.scrollTop(i+(n-s))},bind:function(){var e=this,t=m.bind(this._onSelectableClick,this);return this.$node.on("click.tt",this.selectors.selectable,t),m.each(this.datasets,function(t){t.onSync("asyncRequested",e._propagate,e).onSync("asyncCanceled",e._propagate,e).onSync("asyncReceived",e._propagate,e).onSync("rendered",e._onRendered,e).onSync("cleared",e._onCleared,e)}),this},isOpen:function(){return this.$node.hasClass(this.classes.open)},open:function(){this.$node.addClass(this.classes.open)},close:function(){this.$node.removeClass(this.classes.open),this._removeCursor()},setLanguageDirection:function(t){this.$node.attr("dir",t)},selectableRelativeToCursor:function(t){var e=this.getActiveSelectable(),n=this._getSelectables(),i=(e?n.index(e):-1)+t;return-1===(i=(i=(i+1)%(n.length+1)-1)<-1?n.length-1:i)?null:n.eq(i)},setCursor:function(t){this._removeCursor(),(t=t&&t.first())&&(t.addClass(this.classes.cursor),this._ensureVisible(t))},getSelectableData:function(t){return t&&t.length?s.extractData(t):null},getActiveSelectable:function(){var t=this._getSelectables().filter(this.selectors.cursor).first();return t.length?t:null},getTopSelectable:function(){var t=this._getSelectables().first();return t.length?t:null},update:function(e){var t=e!==this.query;return t&&(this.query=e,m.each(this.datasets,function(t){t.update(e)})),t},empty:function(){m.each(this.datasets,function(t){t.clear()}),this.query=null,this.$node.addClass(this.classes.empty)},destroy:function(){this.$node.off(".tt"),this.$node=null,m.each(this.datasets,function(t){t.destroy()})}}),t}(),_=function(){"use strict";var e=b.prototype;function t(){b.apply(this,[].slice.call(arguments,0))}return m.mixin(t.prototype,b.prototype,{open:function(){return this._allDatasetsEmpty()||this._show(),e.open.apply(this,[].slice.call(arguments,0))},close:function(){return this._hide(),e.close.apply(this,[].slice.call(arguments,0))},_onRendered:function(){return this._allDatasetsEmpty()?this._hide():this.isOpen()&&this._show(),e._onRendered.apply(this,[].slice.call(arguments,0))},_onCleared:function(){return this._allDatasetsEmpty()?this._hide():this.isOpen()&&this._show(),e._onCleared.apply(this,[].slice.call(arguments,0))},setLanguageDirection:function(t){return this.$node.css("ltr"===t?this.css.ltr:this.css.rtl),e.setLanguageDirection.apply(this,[].slice.call(arguments,0))},_hide:function(){this.$node.hide()},_show:function(){this.$node.css("display","block")}}),t}(),w=function(){"use strict";function t(t,e){var n,i,s,r,o,a,l,c,u,d,h;(t=t||{}).input||$.error("missing input"),t.menu||$.error("missing menu"),t.eventBus||$.error("missing event bus"),e.mixin(this),this.eventBus=t.eventBus,this.minLength=m.isNumber(t.minLength)?t.minLength:1,this.input=t.input,this.menu=t.menu,this.enabled=!0,this.active=!1,this.input.hasFocus()&&this.activate(),this.dir=this.input.getLangDir(),this._hacks(),this.menu.bind().onSync("selectableClicked",this._onSelectableClicked,this).onSync("asyncRequested",this._onAsyncRequested,this).onSync("asyncCanceled",this._onAsyncCanceled,this).onSync("asyncReceived",this._onAsyncReceived,this).onSync("datasetRendered",this._onDatasetRendered,this).onSync("datasetCleared",this._onDatasetCleared,this),n=p(this,"activate","open","_onFocused"),i=p(this,"deactivate","_onBlurred"),s=p(this,"isActive","isOpen","_onEnterKeyed"),r=p(this,"isActive","isOpen","_onTabKeyed"),o=p(this,"isActive","_onEscKeyed"),a=p(this,"isActive","open","_onUpKeyed"),l=p(this,"isActive","open","_onDownKeyed"),c=p(this,"isActive","isOpen","_onLeftKeyed"),u=p(this,"isActive","isOpen","_onRightKeyed"),d=p(this,"_openIfActive","_onQueryChanged"),h=p(this,"_openIfActive","_onWhitespaceChanged"),this.input.bind().onSync("focused",n,this).onSync("blurred",i,this).onSync("enterKeyed",s,this).onSync("tabKeyed",r,this).onSync("escKeyed",o,this).onSync("upKeyed",a,this).onSync("downKeyed",l,this).onSync("leftKeyed",c,this).onSync("rightKeyed",u,this).onSync("queryChanged",d,this).onSync("whitespaceChanged",h,this).onSync("langDirChanged",this._onLangDirChanged,this)}return m.mixin(t.prototype,{_hacks:function(){var s=this.input.$input||$("<div>"),r=this.menu.$node||$("<div>");s.on("blur.tt",function(t){var e=document.activeElement,n=r.is(e),i=0<r.has(e).length;m.isMsie()&&(n||i)&&(t.preventDefault(),t.stopImmediatePropagation(),m.defer(function(){s.focus()}))}),r.on("mousedown.tt",function(t){t.preventDefault()})},_onSelectableClicked:function(t,e){this.select(e)},_onDatasetCleared:function(){this._updateHint()},_onDatasetRendered:function(t,e,n,i){this._updateHint(),this.eventBus.trigger("render",n,i,e)},_onAsyncRequested:function(t,e,n){this.eventBus.trigger("asyncrequest",n,e)},_onAsyncCanceled:function(t,e,n){this.eventBus.trigger("asynccancel",n,e)},_onAsyncReceived:function(t,e,n){this.eventBus.trigger("asyncreceive",n,e)},_onFocused:function(){this._minLengthMet()&&this.menu.update(this.input.getQuery())},_onBlurred:function(){this.input.hasQueryChangedSinceLastFocus()&&this.eventBus.trigger("change",this.input.getQuery())},_onEnterKeyed:function(t,e){var n;(n=this.menu.getActiveSelectable())&&this.select(n)&&e.preventDefault()},_onTabKeyed:function(t,e){var n;(n=this.menu.getActiveSelectable())?this.select(n)&&e.preventDefault():(n=this.menu.getTopSelectable())&&this.autocomplete(n)&&e.preventDefault()},_onEscKeyed:function(){this.close()},_onUpKeyed:function(){this.moveCursor(-1)},_onDownKeyed:function(){this.moveCursor(1)},_onLeftKeyed:function(){"rtl"===this.dir&&this.input.isCursorAtEnd()&&this.autocomplete(this.menu.getTopSelectable())},_onRightKeyed:function(){"ltr"===this.dir&&this.input.isCursorAtEnd()&&this.autocomplete(this.menu.getTopSelectable())},_onQueryChanged:function(t,e){this._minLengthMet(e)?this.menu.update(e):this.menu.empty()},_onWhitespaceChanged:function(){this._updateHint()},_onLangDirChanged:function(t,e){this.dir!==e&&(this.dir=e,this.menu.setLanguageDirection(e))},_openIfActive:function(){this.isActive()&&this.open()},_minLengthMet:function(t){return(t=m.isString(t)?t:this.input.getQuery()||"").length>=this.minLength},_updateHint:function(){var t,e,n,i=this.menu.getTopSelectable(),s=this.menu.getSelectableData(i),r=this.input.getInputValue();!s||m.isBlankString(r)||this.input.hasOverflow()?this.input.clearHint():(t=v.normalizeQuery(r),e=m.escapeRegExChars(t),(n=new RegExp("^(?:"+e+")(.+$)","i").exec(s.val))&&this.input.setHint(r+n[1]))},isEnabled:function(){return this.enabled},enable:function(){this.enabled=!0},disable:function(){this.enabled=!1},isActive:function(){return this.active},activate:function(){return!!this.isActive()||!(!this.isEnabled()||this.eventBus.before("active"))&&(this.active=!0,this.eventBus.trigger("active"),!0)},deactivate:function(){return!this.isActive()||!this.eventBus.before("idle")&&(this.active=!1,this.close(),this.eventBus.trigger("idle"),!0)},isOpen:function(){return this.menu.isOpen()},open:function(){return this.isOpen()||this.eventBus.before("open")||(this.menu.open(),this._updateHint(),this.eventBus.trigger("open")),this.isOpen()},close:function(){return this.isOpen()&&!this.eventBus.before("close")&&(this.menu.close(),this.input.clearHint(),this.input.resetInputValue(),this.eventBus.trigger("close")),!this.isOpen()},setVal:function(t){this.input.setQuery(m.toStr(t))},getVal:function(){return this.input.getQuery()},select:function(t){var e=this.menu.getSelectableData(t);return!(!e||this.eventBus.before("select",e.obj))&&(this.input.setQuery(e.val,!0),this.close(),this.eventBus.trigger("select",e.obj),!0)},autocomplete:function(t){var e=this.input.getQuery(),n=this.menu.getSelectableData(t);return!(!(n&&e!==n.val)||this.eventBus.before("autocomplete",n.obj))&&(this.input.setQuery(n.val),this.eventBus.trigger("autocomplete",n.obj),!0)},moveCursor:function(t){var e=this.input.getQuery(),n=this.menu.selectableRelativeToCursor(t),i=this.menu.getSelectableData(n),s=i?i.obj:null;return!(this._minLengthMet()&&this.menu.update(e))&&!this.eventBus.before("cursorchange",s)&&(this.menu.setCursor(n),i?this.input.setInputValue(i.val):(this.input.resetInputValue(),this._updateHint()),this.eventBus.trigger("cursorchange",s),!0)},destroy:function(){this.input.destroy(),this.menu.destroy()}}),t;function p(n){var t=[].slice.call(arguments,1);return function(){var e=[].slice.call(arguments);m.each(t,function(t){return n[t].apply(n,e)})}}}();!function(){"use strict";var t,f,e;function i(t,n){t.each(function(){var t,e=$(this);(t=e.data(f.typeahead))&&n(t,e)})}function g(t){var e=m.isJQuery(t)||m.isElement(t)?$(t).first():[];return e.length?e:null}t=$.fn.typeahead,f={www:"tt-www",attrs:"tt-attrs",typeahead:"tt-typeahead"},e={initialize:function(d,h){var p;return h=m.isArray(h)?h:[].slice.call(arguments,1),p=n(d=d||{}),this.each(function(){var t,e,n,i,s,r,o,a,l,c,u;m.each(h,function(t){t.highlight=!!d.highlight,t.templates=m.mixin({dataset:p.html.dataset()},t.templates)}),t=$(this),e=p.html.wrapper(),n=g(d.hint),i=g(d.menu),s=!1!==d.hint&&!n,r=!1!==d.menu&&!i,s&&(n=function(t,e){return t.clone().addClass(e.classes.hint).removeData().css(e.css.hint).css(function(t){return{backgroundAttachment:t.css("background-attachment"),backgroundClip:t.css("background-clip"),backgroundColor:t.css("background-color"),backgroundImage:t.css("background-image"),backgroundOrigin:t.css("background-origin"),backgroundPosition:t.css("background-position"),backgroundRepeat:t.css("background-repeat"),backgroundSize:t.css("background-size")}}(t)).prop("readonly",!0).removeAttr("id name placeholder required").attr({autocomplete:"off",spellcheck:"false",tabindex:-1})}(t,p)),r&&(i=p.html.menu().css(p.css.menu)),n&&n.val(""),t=function(t,e){t.data(f.attrs,{dir:t.attr("dir"),autocomplete:t.attr("autocomplete"),spellcheck:t.attr("spellcheck"),style:t.attr("style")}),t.addClass(e.classes.input).attr({autocomplete:"off",spellcheck:!1});try{t.attr("dir")||t.attr("dir","auto")}catch(t){}return t}(t,p),(s||r)&&(e.css(p.css.wrapper),t.css(s?p.css.input:p.css.inputWithNoHint),t.wrap(e).parent().prepend(s?n:null).append(r?i:null));u=r?_:b,o=new y({el:t}),a=new v({hint:n,input:t},p),l=new u({node:i,datasets:h},p),c=new w({input:a,menu:l,eventBus:o,minLength:d.minLength},p),t.data(f.www,p),t.data(f.typeahead,c)})},isEnabled:function(){var e;return i(this.first(),function(t){e=t.isEnabled()}),e},enable:function(){return i(this,function(t){t.enable()}),this},disable:function(){return i(this,function(t){t.disable()}),this},isActive:function(){var e;return i(this.first(),function(t){e=t.isActive()}),e},activate:function(){return i(this,function(t){t.activate()}),this},deactivate:function(){return i(this,function(t){t.deactivate()}),this},isOpen:function(){var e;return i(this.first(),function(t){e=t.isOpen()}),e},open:function(){return i(this,function(t){t.open()}),this},close:function(){return i(this,function(t){t.close()}),this},select:function(t){var e=!1,n=$(t);return i(this.first(),function(t){e=t.select(n)}),e},autocomplete:function(t){var e=!1,n=$(t);return i(this.first(),function(t){e=t.autocomplete(n)}),e},moveCursor:function(e){var n=!1;return i(this.first(),function(t){n=t.moveCursor(e)}),n},val:function(e){var n;return arguments.length?(i(this,function(t){t.setVal(e)}),this):(i(this.first(),function(t){n=t.getVal()}),n)},destroy:function(){return i(this,function(t,e){var n,i,s;i=(n=e).data(f.www),s=n.parent().filter(i.selectors.wrapper),m.each(n.data(f.attrs),function(t,e){m.isUndefined(t)?n.removeAttr(e):n.attr(e,t)}),n.removeData(f.typeahead).removeData(f.www).removeData(f.attr).removeClass(i.classes.input),s.length&&(n.detach().insertAfter(s),s.remove()),t.destroy()}),this}},$.fn.typeahead=function(t){return e[t]?e[t].apply(this,[].slice.call(arguments,1)):e.initialize.apply(this,arguments)},$.fn.typeahead.noConflict=function(){return $.fn.typeahead=t,this}}()}),function(l){"use strict";var c=function(t,e){this.options=l.extend({},c.DEFAULTS,e);var n=this.options.target===c.DEFAULTS.target?l(this.options.target):l(document).find(this.options.target);this.$target=n.on("scroll.bs.affix.data-api",l.proxy(this.checkPosition,this)).on("click.bs.affix.data-api",l.proxy(this.checkPositionWithEventLoop,this)),this.$element=l(t),this.affixed=null,this.unpin=null,this.pinnedOffset=null,this.checkPosition()};function n(i){return this.each(function(){var t=l(this),e=t.data("bs.affix"),n="object"==typeof i&&i;e||t.data("bs.affix",e=new c(this,n)),"string"==typeof i&&e[i]()})}c.VERSION="3.4.1",c.RESET="affix affix-top affix-bottom",c.DEFAULTS={offset:0,target:window},c.prototype.getState=function(t,e,n,i){var s=this.$target.scrollTop(),r=this.$element.offset(),o=this.$target.height();if(null!=n&&"top"==this.affixed)return s<n&&"top";if("bottom"==this.affixed)return null!=n?!(s+this.unpin<=r.top)&&"bottom":!(s+o<=t-i)&&"bottom";var a=null==this.affixed,l=a?s:r.top;return null!=n&&s<=n?"top":null!=i&&t-i<=l+(a?o:e)&&"bottom"},c.prototype.getPinnedOffset=function(){if(this.pinnedOffset)return this.pinnedOffset;this.$element.removeClass(c.RESET).addClass("affix");var t=this.$target.scrollTop(),e=this.$element.offset();return this.pinnedOffset=e.top-t},c.prototype.checkPositionWithEventLoop=function(){setTimeout(l.proxy(this.checkPosition,this),1)},c.prototype.checkPosition=function(){if(this.$element.is(":visible")){var t=this.$element.height(),e=this.options.offset,n=e.top,i=e.bottom,s=Math.max(l(document).height(),l(document.body).height());"object"!=typeof e&&(i=n=e),"function"==typeof n&&(n=e.top(this.$element)),"function"==typeof i&&(i=e.bottom(this.$element));var r=this.getState(s,t,n,i);if(this.affixed!=r){null!=this.unpin&&this.$element.css("top","");var o="affix"+(r?"-"+r:""),a=l.Event(o+".bs.affix");if(this.$element.trigger(a),a.isDefaultPrevented())return;this.affixed=r,this.unpin="bottom"==r?this.getPinnedOffset():null,this.$element.removeClass(c.RESET).addClass(o).trigger(o.replace("affix","affixed")+".bs.affix")}"bottom"==r&&this.$element.offset({top:s-t-i})}};var t=l.fn.affix;l.fn.affix=n,l.fn.affix.Constructor=c,l.fn.affix.noConflict=function(){return l.fn.affix=t,this},l(window).on("load",function(){l('[data-spy="affix"]').each(function(){var t=l(this),e=t.data();e.offset=e.offset||{},null!=e.offsetBottom&&(e.offset.bottom=e.offsetBottom),null!=e.offsetTop&&(e.offset.top=e.offsetTop),n.call(t,e)})})}(jQuery),function(r){"use strict";function o(t){r(t).on("click",e,this.close)}var e='[data-dismiss="alert"]';o.VERSION="3.4.1",o.TRANSITION_DURATION=150,o.prototype.close=function(t){var e=r(this),n=e.attr("data-target");n="#"===(n=n||(n=e.attr("href"))&&n.replace(/.*(?=#[^\s]*$)/,""))?[]:n;var i=r(document).find(n);function s(){i.detach().trigger("closed.bs.alert").remove()}t&&t.preventDefault(),i.length||(i=e.closest(".alert")),i.trigger(t=r.Event("close.bs.alert")),t.isDefaultPrevented()||(i.removeClass("in"),r.support.transition&&i.hasClass("fade")?i.one("bsTransitionEnd",s).emulateTransitionEnd(o.TRANSITION_DURATION):s())};var t=r.fn.alert;r.fn.alert=function(n){return this.each(function(){var t=r(this),e=t.data("bs.alert");e||t.data("bs.alert",e=new o(this)),"string"==typeof n&&e[n].call(t)})},r.fn.alert.Constructor=o,r.fn.alert.noConflict=function(){return r.fn.alert=t,this},r(document).on("click.bs.alert.data-api",e,o.prototype.close)}(jQuery),function(r){"use strict";var s=function(t,e){this.$element=r(t),this.options=r.extend({},s.DEFAULTS,e),this.isLoading=!1};function n(i){return this.each(function(){var t=r(this),e=t.data("bs.button"),n="object"==typeof i&&i;e||t.data("bs.button",e=new s(this,n)),"toggle"==i?e.toggle():i&&e.setState(i)})}s.VERSION="3.4.1",s.DEFAULTS={loadingText:"loading..."},s.prototype.setState=function(t){var e="disabled",n=this.$element,i=n.is("input")?"val":"html",s=n.data();t+="Text",null==s.resetText&&n.data("resetText",n[i]()),setTimeout(r.proxy(function(){n[i](null==s[t]?this.options[t]:s[t]),"loadingText"==t?(this.isLoading=!0,n.addClass(e).attr(e,e).prop(e,!0)):this.isLoading&&(this.isLoading=!1,n.removeClass(e).removeAttr(e).prop(e,!1))},this),0)},s.prototype.toggle=function(){var t,e=!0,n=this.$element.closest('[data-toggle="buttons"]');n.length?("radio"==(t=this.$element.find("input")).prop("type")?(t.prop("checked")&&(e=!1),n.find(".active").removeClass("active"),this.$element.addClass("active")):"checkbox"==t.prop("type")&&(t.prop("checked")!==this.$element.hasClass("active")&&(e=!1),this.$element.toggleClass("active")),t.prop("checked",this.$element.hasClass("active")),e&&t.trigger("change")):(this.$element.attr("aria-pressed",!this.$element.hasClass("active")),this.$element.toggleClass("active"))};var t=r.fn.button;r.fn.button=n,r.fn.button.Constructor=s,r.fn.button.noConflict=function(){return r.fn.button=t,this},r(document).on("click.bs.button.data-api",'[data-toggle^="button"]',function(t){var e=r(t.target).closest(".btn");n.call(e,"toggle"),r(t.target).is('input[type="radio"], input[type="checkbox"]')||(t.preventDefault(),e.is("input,button")?e.trigger("focus"):e.find("input:visible,button:visible").first().trigger("focus"))}).on("focus.bs.button.data-api blur.bs.button.data-api",'[data-toggle^="button"]',function(t){r(t.target).closest(".btn").toggleClass("focus",/^focus(in)?$/.test(t.type))})}(jQuery),function(d){"use strict";function h(t,e){this.$element=d(t),this.$indicators=this.$element.find(".carousel-indicators"),this.options=e,this.paused=null,this.sliding=null,this.interval=null,this.$active=null,this.$items=null,this.options.keyboard&&this.$element.on("keydown.bs.carousel",d.proxy(this.keydown,this)),"hover"!=this.options.pause||"ontouchstart"in document.documentElement||this.$element.on("mouseenter.bs.carousel",d.proxy(this.pause,this)).on("mouseleave.bs.carousel",d.proxy(this.cycle,this))}function a(s){return this.each(function(){var t=d(this),e=t.data("bs.carousel"),n=d.extend({},h.DEFAULTS,t.data(),"object"==typeof s&&s),i="string"==typeof s?s:n.slide;e||t.data("bs.carousel",e=new h(this,n)),"number"==typeof s?e.to(s):i?e[i]():n.interval&&e.pause().cycle()})}h.VERSION="3.4.1",h.TRANSITION_DURATION=600,h.DEFAULTS={interval:5e3,pause:"hover",wrap:!0,keyboard:!0},h.prototype.keydown=function(t){if(!/input|textarea/i.test(t.target.tagName)){switch(t.which){case 37:this.prev();break;case 39:this.next();break;default:return}t.preventDefault()}},h.prototype.cycle=function(t){return t||(this.paused=!1),this.interval&&clearInterval(this.interval),this.options.interval&&!this.paused&&(this.interval=setInterval(d.proxy(this.next,this),this.options.interval)),this},h.prototype.getItemIndex=function(t){return this.$items=t.parent().children(".item"),this.$items.index(t||this.$active)},h.prototype.getItemForDirection=function(t,e){var n=this.getItemIndex(e);if(("prev"==t&&0===n||"next"==t&&n==this.$items.length-1)&&!this.options.wrap)return e;var i=(n+("prev"==t?-1:1))%this.$items.length;return this.$items.eq(i)},h.prototype.to=function(t){var e=this,n=this.getItemIndex(this.$active=this.$element.find(".item.active"));if(!(t>this.$items.length-1||t<0))return this.sliding?this.$element.one("slid.bs.carousel",function(){e.to(t)}):n==t?this.pause().cycle():this.slide(n<t?"next":"prev",this.$items.eq(t))},h.prototype.pause=function(t){return t||(this.paused=!0),this.$element.find(".next, .prev").length&&d.support.transition&&(this.$element.trigger(d.support.transition.end),this.cycle(!0)),this.interval=clearInterval(this.interval),this},h.prototype.next=function(){if(!this.sliding)return this.slide("next")},h.prototype.prev=function(){if(!this.sliding)return this.slide("prev")},h.prototype.slide=function(t,e){var n=this.$element.find(".item.active"),i=e||this.getItemForDirection(t,n),s=this.interval,r="next"==t?"left":"right",o=this;if(i.hasClass("active"))return this.sliding=!1;var a,l=i[0],c=d.Event("slide.bs.carousel",{relatedTarget:l,direction:r});if(this.$element.trigger(c),!c.isDefaultPrevented()){this.sliding=!0,s&&this.pause(),this.$indicators.length&&(this.$indicators.find(".active").removeClass("active"),(a=d(this.$indicators.children()[this.getItemIndex(i)]))&&a.addClass("active"));var u=d.Event("slid.bs.carousel",{relatedTarget:l,direction:r});return d.support.transition&&this.$element.hasClass("slide")?(i.addClass(t),"object"==typeof i&&i.length&&i[0].offsetWidth,n.addClass(r),i.addClass(r),n.one("bsTransitionEnd",function(){i.removeClass([t,r].join(" ")).addClass("active"),n.removeClass(["active",r].join(" ")),o.sliding=!1,setTimeout(function(){o.$element.trigger(u)},0)}).emulateTransitionEnd(h.TRANSITION_DURATION)):(n.removeClass("active"),i.addClass("active"),this.sliding=!1,this.$element.trigger(u)),s&&this.cycle(),this}};var t=d.fn.carousel;d.fn.carousel=a,d.fn.carousel.Constructor=h,d.fn.carousel.noConflict=function(){return d.fn.carousel=t,this};function e(t){var e,n,i=d(this),s=(s=i.attr("href"))&&s.replace(/.*(?=#[^\s]+$)/,""),r=i.attr("data-target")||s,o=d(document).find(r);o.hasClass("carousel")&&(e=d.extend({},o.data(),i.data()),(n=i.attr("data-slide-to"))&&(e.interval=!1),a.call(o,e),n&&o.data("bs.carousel").to(n),t.preventDefault())}d(document).on("click.bs.carousel.data-api","[data-slide]",e).on("click.bs.carousel.data-api","[data-slide-to]",e),d(window).on("load",function(){d('[data-ride="carousel"]').each(function(){var t=d(this);a.call(t,t.data())})})}(jQuery),function(o){"use strict";var a=function(t,e){this.$element=o(t),this.options=o.extend({},a.DEFAULTS,e),this.$trigger=o('[data-toggle="collapse"][href="#'+t.id+'"],[data-toggle="collapse"][data-target="#'+t.id+'"]'),this.transitioning=null,this.options.parent?this.$parent=this.getParent():this.addAriaAndCollapsedClass(this.$element,this.$trigger),this.options.toggle&&this.toggle()};function s(t){var e,n=t.attr("data-target")||(e=t.attr("href"))&&e.replace(/.*(?=#[^\s]+$)/,"");return o(document).find(n)}function l(i){return this.each(function(){var t=o(this),e=t.data("bs.collapse"),n=o.extend({},a.DEFAULTS,t.data(),"object"==typeof i&&i);!e&&n.toggle&&/show|hide/.test(i)&&(n.toggle=!1),e||t.data("bs.collapse",e=new a(this,n)),"string"==typeof i&&e[i]()})}a.VERSION="3.4.1",a.TRANSITION_DURATION=350,a.DEFAULTS={toggle:!0},a.prototype.dimension=function(){return this.$element.hasClass("width")?"width":"height"},a.prototype.show=function(){if(!this.transitioning&&!this.$element.hasClass("in")){var t,e=this.$parent&&this.$parent.children(".panel").children(".in, .collapsing");if(!(e&&e.length&&(t=e.data("bs.collapse"))&&t.transitioning)){var n=o.Event("show.bs.collapse");if(this.$element.trigger(n),!n.isDefaultPrevented()){e&&e.length&&(l.call(e,"hide"),t||e.data("bs.collapse",null));var i=this.dimension();this.$element.removeClass("collapse").addClass("collapsing")[i](0).attr("aria-expanded",!0),this.$trigger.removeClass("collapsed").attr("aria-expanded",!0),this.transitioning=1;var s=function(){this.$element.removeClass("collapsing").addClass("collapse in")[i](""),this.transitioning=0,this.$element.trigger("shown.bs.collapse")};if(!o.support.transition)return s.call(this);var r=o.camelCase(["scroll",i].join("-"));this.$element.one("bsTransitionEnd",o.proxy(s,this)).emulateTransitionEnd(a.TRANSITION_DURATION)[i](this.$element[0][r])}}}},a.prototype.hide=function(){if(!this.transitioning&&this.$element.hasClass("in")){var t=o.Event("hide.bs.collapse");if(this.$element.trigger(t),!t.isDefaultPrevented()){var e=this.dimension();this.$element[e](this.$element[e]())[0].offsetHeight,this.$element.addClass("collapsing").removeClass("collapse in").attr("aria-expanded",!1),this.$trigger.addClass("collapsed").attr("aria-expanded",!1),this.transitioning=1;var n=function(){this.transitioning=0,this.$element.removeClass("collapsing").addClass("collapse").trigger("hidden.bs.collapse")};if(!o.support.transition)return n.call(this);this.$element[e](0).one("bsTransitionEnd",o.proxy(n,this)).emulateTransitionEnd(a.TRANSITION_DURATION)}}},a.prototype.toggle=function(){this[this.$element.hasClass("in")?"hide":"show"]()},a.prototype.getParent=function(){return o(document).find(this.options.parent).find('[data-toggle="collapse"][data-parent="'+this.options.parent+'"]').each(o.proxy(function(t,e){var n=o(e);this.addAriaAndCollapsedClass(s(n),n)},this)).end()},a.prototype.addAriaAndCollapsedClass=function(t,e){var n=t.hasClass("in");t.attr("aria-expanded",n),e.toggleClass("collapsed",!n).attr("aria-expanded",n)};var t=o.fn.collapse;o.fn.collapse=l,o.fn.collapse.Constructor=a,o.fn.collapse.noConflict=function(){return o.fn.collapse=t,this},o(document).on("click.bs.collapse.data-api",'[data-toggle="collapse"]',function(t){var e=o(this);e.attr("data-target")||t.preventDefault();var n=s(e),i=n.data("bs.collapse")?"toggle":e.data();l.call(n,i)})}(jQuery),function(o){"use strict";function i(t){o(t).on("click.bs.dropdown",this.toggle)}var a='[data-toggle="dropdown"]';function l(t){var e=t.attr("data-target"),n="#"!==(e=e||(e=t.attr("href"))&&/#[A-Za-z]/.test(e)&&e.replace(/.*(?=#[^\s]*$)/,""))?o(document).find(e):null;return n&&n.length?n:t.parent()}function r(i){i&&3===i.which||(o(".dropdown-backdrop").remove(),o(a).each(function(){var t=o(this),e=l(t),n={relatedTarget:this};e.hasClass("open")&&(i&&"click"==i.type&&/input|textarea/i.test(i.target.tagName)&&o.contains(e[0],i.target)||(e.trigger(i=o.Event("hide.bs.dropdown",n)),i.isDefaultPrevented()||(t.attr("aria-expanded","false"),e.removeClass("open").trigger(o.Event("hidden.bs.dropdown",n)))))}))}i.VERSION="3.4.1",i.prototype.toggle=function(t){var e=o(this);if(!e.is(".disabled, :disabled")){var n=l(e),i=n.hasClass("open");if(r(),!i){"ontouchstart"in document.documentElement&&!n.closest(".navbar-nav").length&&o(document.createElement("div")).addClass("dropdown-backdrop").insertAfter(o(this)).on("click",r);var s={relatedTarget:this};if(n.trigger(t=o.Event("show.bs.dropdown",s)),t.isDefaultPrevented())return;e.trigger("focus").attr("aria-expanded","true"),n.toggleClass("open").trigger(o.Event("shown.bs.dropdown",s))}return!1}},i.prototype.keydown=function(t){if(/(38|40|27|32)/.test(t.which)&&!/input|textarea/i.test(t.target.tagName)){var e=o(this);if(t.preventDefault(),t.stopPropagation(),!e.is(".disabled, :disabled")){var n=l(e),i=n.hasClass("open");if(!i&&27!=t.which||i&&27==t.which)return 27==t.which&&n.find(a).trigger("focus"),e.trigger("click");var s,r=n.find(".dropdown-menu li:not(.disabled):visible a");r.length&&(s=r.index(t.target),38==t.which&&0<s&&s--,40==t.which&&s<r.length-1&&s++,~s||(s=0),r.eq(s).trigger("focus"))}}};var t=o.fn.dropdown;o.fn.dropdown=function(n){return this.each(function(){var t=o(this),e=t.data("bs.dropdown");e||t.data("bs.dropdown",e=new i(this)),"string"==typeof n&&e[n].call(t)})},o.fn.dropdown.Constructor=i,o.fn.dropdown.noConflict=function(){return o.fn.dropdown=t,this},o(document).on("click.bs.dropdown.data-api",r).on("click.bs.dropdown.data-api",".dropdown form",function(t){t.stopPropagation()}).on("click.bs.dropdown.data-api",a,i.prototype.toggle).on("keydown.bs.dropdown.data-api",a,i.prototype.keydown).on("keydown.bs.dropdown.data-api",".dropdown-menu",i.prototype.keydown)}(jQuery),function(o){"use strict";function r(t,e){this.options=e,this.$body=o(document.body),this.$element=o(t),this.$dialog=this.$element.find(".modal-dialog"),this.$backdrop=null,this.isShown=null,this.originalBodyPad=null,this.scrollbarWidth=0,this.ignoreBackdropClick=!1,this.fixedContent=".navbar-fixed-top, .navbar-fixed-bottom",this.options.remote&&this.$element.find(".modal-content").load(this.options.remote,o.proxy(function(){this.$element.trigger("loaded.bs.modal")},this))}function a(i,s){return this.each(function(){var t=o(this),e=t.data("bs.modal"),n=o.extend({},r.DEFAULTS,t.data(),"object"==typeof i&&i);e||t.data("bs.modal",e=new r(this,n)),"string"==typeof i?e[i](s):n.show&&e.show(s)})}r.VERSION="3.4.1",r.TRANSITION_DURATION=300,r.BACKDROP_TRANSITION_DURATION=150,r.DEFAULTS={backdrop:!0,keyboard:!0,show:!0},r.prototype.toggle=function(t){return this.isShown?this.hide():this.show(t)},r.prototype.show=function(n){var i=this,t=o.Event("show.bs.modal",{relatedTarget:n});this.$element.trigger(t),this.isShown||t.isDefaultPrevented()||(this.isShown=!0,this.checkScrollbar(),this.setScrollbar(),this.$body.addClass("modal-open"),this.escape(),this.resize(),this.$element.on("click.dismiss.bs.modal",'[data-dismiss="modal"]',o.proxy(this.hide,this)),this.$dialog.on("mousedown.dismiss.bs.modal",function(){i.$element.one("mouseup.dismiss.bs.modal",function(t){o(t.target).is(i.$element)&&(i.ignoreBackdropClick=!0)})}),this.backdrop(function(){var t=o.support.transition&&i.$element.hasClass("fade");i.$element.parent().length||i.$element.appendTo(i.$body),i.$element.show().scrollTop(0),i.adjustDialog(),t&&i.$element[0].offsetWidth,i.$element.addClass("in"),i.enforceFocus();var e=o.Event("shown.bs.modal",{relatedTarget:n});t?i.$dialog.one("bsTransitionEnd",function(){i.$element.trigger("focus").trigger(e)}).emulateTransitionEnd(r.TRANSITION_DURATION):i.$element.trigger("focus").trigger(e)}))},r.prototype.hide=function(t){t&&t.preventDefault(),t=o.Event("hide.bs.modal"),this.$element.trigger(t),this.isShown&&!t.isDefaultPrevented()&&(this.isShown=!1,this.escape(),this.resize(),o(document).off("focusin.bs.modal"),this.$element.removeClass("in").off("click.dismiss.bs.modal").off("mouseup.dismiss.bs.modal"),this.$dialog.off("mousedown.dismiss.bs.modal"),o.support.transition&&this.$element.hasClass("fade")?this.$element.one("bsTransitionEnd",o.proxy(this.hideModal,this)).emulateTransitionEnd(r.TRANSITION_DURATION):this.hideModal())},r.prototype.enforceFocus=function(){o(document).off("focusin.bs.modal").on("focusin.bs.modal",o.proxy(function(t){document===t.target||this.$element[0]===t.target||this.$element.has(t.target).length||this.$element.trigger("focus")},this))},r.prototype.escape=function(){this.isShown&&this.options.keyboard?this.$element.on("keydown.dismiss.bs.modal",o.proxy(function(t){27==t.which&&this.hide()},this)):this.isShown||this.$element.off("keydown.dismiss.bs.modal")},r.prototype.resize=function(){this.isShown?o(window).on("resize.bs.modal",o.proxy(this.handleUpdate,this)):o(window).off("resize.bs.modal")},r.prototype.hideModal=function(){var t=this;this.$element.hide(),this.backdrop(function(){t.$body.removeClass("modal-open"),t.resetAdjustments(),t.resetScrollbar(),t.$element.trigger("hidden.bs.modal")})},r.prototype.removeBackdrop=function(){this.$backdrop&&this.$backdrop.remove(),this.$backdrop=null},r.prototype.backdrop=function(t){var e,n=this,i=this.$element.hasClass("fade")?"fade":"";if(this.isShown&&this.options.backdrop){var s=o.support.transition&&i;if(this.$backdrop=o(document.createElement("div")).addClass("modal-backdrop "+i).appendTo(this.$body),this.$element.on("click.dismiss.bs.modal",o.proxy(function(t){this.ignoreBackdropClick?this.ignoreBackdropClick=!1:t.target===t.currentTarget&&("static"==this.options.backdrop?this.$element[0].focus():this.hide())},this)),s&&this.$backdrop[0].offsetWidth,this.$backdrop.addClass("in"),!t)return;s?this.$backdrop.one("bsTransitionEnd",t).emulateTransitionEnd(r.BACKDROP_TRANSITION_DURATION):t()}else{!this.isShown&&this.$backdrop?(this.$backdrop.removeClass("in"),e=function(){n.removeBackdrop(),t&&t()},o.support.transition&&this.$element.hasClass("fade")?this.$backdrop.one("bsTransitionEnd",e).emulateTransitionEnd(r.BACKDROP_TRANSITION_DURATION):e()):t&&t()}},r.prototype.handleUpdate=function(){this.adjustDialog()},r.prototype.adjustDialog=function(){var t=this.$element[0].scrollHeight>document.documentElement.clientHeight;this.$element.css({paddingLeft:!this.bodyIsOverflowing&&t?this.scrollbarWidth:"",paddingRight:this.bodyIsOverflowing&&!t?this.scrollbarWidth:""})},r.prototype.resetAdjustments=function(){this.$element.css({paddingLeft:"",paddingRight:""})},r.prototype.checkScrollbar=function(){var t,e=window.innerWidth;e||(e=(t=document.documentElement.getBoundingClientRect()).right-Math.abs(t.left)),this.bodyIsOverflowing=document.body.clientWidth<e,this.scrollbarWidth=this.measureScrollbar()},r.prototype.setScrollbar=function(){var t=parseInt(this.$body.css("padding-right")||0,10);this.originalBodyPad=document.body.style.paddingRight||"";var s=this.scrollbarWidth;this.bodyIsOverflowing&&(this.$body.css("padding-right",t+s),o(this.fixedContent).each(function(t,e){var n=e.style.paddingRight,i=o(e).css("padding-right");o(e).data("padding-right",n).css("padding-right",parseFloat(i)+s+"px")}))},r.prototype.resetScrollbar=function(){this.$body.css("padding-right",this.originalBodyPad),o(this.fixedContent).each(function(t,e){var n=o(e).data("padding-right");o(e).removeData("padding-right"),e.style.paddingRight=n||""})},r.prototype.measureScrollbar=function(){var t=document.createElement("div");t.className="modal-scrollbar-measure",this.$body.append(t);var e=t.offsetWidth-t.clientWidth;return this.$body[0].removeChild(t),e};var t=o.fn.modal;o.fn.modal=a,o.fn.modal.Constructor=r,o.fn.modal.noConflict=function(){return o.fn.modal=t,this},o(document).on("click.bs.modal.data-api",'[data-toggle="modal"]',function(t){var e=o(this),n=e.attr("href"),i=e.attr("data-target")||n&&n.replace(/.*(?=#[^\s]+$)/,""),s=o(document).find(i),r=s.data("bs.modal")?"toggle":o.extend({remote:!/#/.test(n)&&n},s.data(),e.data());e.is("a")&&t.preventDefault(),s.one("show.bs.modal",function(t){t.isDefaultPrevented()||s.one("hidden.bs.modal",function(){e.is(":visible")&&e.trigger("focus")})}),a.call(s,r,this)})}(jQuery),function(g){"use strict";var i=["sanitize","whiteList","sanitizeFn"],f=["background","cite","href","itemtype","longdesc","poster","src","xlink:href"],t={"*":["class","dir","id","lang","role",/^aria-[\w-]*$/i],a:["target","href","title","rel"],area:[],b:[],br:[],col:[],code:[],div:[],em:[],hr:[],h1:[],h2:[],h3:[],h4:[],h5:[],h6:[],i:[],img:["src","alt","title","width","height"],li:[],ol:[],p:[],pre:[],s:[],small:[],span:[],sub:[],sup:[],strong:[],u:[],ul:[]},m=/^(?:(?:https?|mailto|ftp|tel|file):|[^&:/?#]*(?:[/?#]|$))/gi,y=/^data:(?:image\/(?:bmp|gif|jpeg|jpg|png|tiff|webp)|video\/(?:mpeg|mp4|ogg|webm)|audio\/(?:mp3|oga|ogg|opus));base64,[a-z0-9+/]+=*$/i;function s(t,e,n){if(0===t.length)return t;if(n&&"function"==typeof n)return n(t);if(!document.implementation||!document.implementation.createHTMLDocument)return t;var i=document.implementation.createHTMLDocument("sanitization");i.body.innerHTML=t;for(var s=g.map(e,function(t,e){return e}),r=g(i.body).find("*"),o=0,a=r.length;o<a;o++){var l=r[o],c=l.nodeName.toLowerCase();if(-1!==g.inArray(c,s))for(var u=g.map(l.attributes,function(t){return t}),d=[].concat(e["*"]||[],e[c]||[]),h=0,p=u.length;h<p;h++)!function(t,e){var n=t.nodeName.toLowerCase();if(-1!==g.inArray(n,e))return-1===g.inArray(n,f)||Boolean(t.nodeValue.match(m)||t.nodeValue.match(y));for(var i=g(e).filter(function(t,e){return e instanceof RegExp}),s=0,r=i.length;s<r;s++)if(n.match(i[s]))return 1}(u[h],d)&&l.removeAttribute(u[h].nodeName);else l.parentNode.removeChild(l)}return i.body.innerHTML}function v(t,e){this.type=null,this.options=null,this.enabled=null,this.timeout=null,this.hoverState=null,this.$element=null,this.inState=null,this.init("tooltip",t,e)}v.VERSION="3.4.1",v.TRANSITION_DURATION=150,v.DEFAULTS={animation:!0,placement:"top",selector:!1,template:'<div class="tooltip" role="tooltip"><div class="tooltip-arrow"></div><div class="tooltip-inner"></div></div>',trigger:"hover focus",title:"",delay:0,html:!1,container:!1,viewport:{selector:"body",padding:0},sanitize:!0,sanitizeFn:null,whiteList:t},v.prototype.init=function(t,e,n){if(this.enabled=!0,this.type=t,this.$element=g(e),this.options=this.getOptions(n),this.$viewport=this.options.viewport&&g(document).find(g.isFunction(this.options.viewport)?this.options.viewport.call(this,this.$element):this.options.viewport.selector||this.options.viewport),this.inState={click:!1,hover:!1,focus:!1},this.$element[0]instanceof document.constructor&&!this.options.selector)throw new Error("`selector` option must be specified when initializing "+this.type+" on the window.document object!");for(var i=this.options.trigger.split(" "),s=i.length;s--;){var r,o,a=i[s];"click"==a?this.$element.on("click."+this.type,this.options.selector,g.proxy(this.toggle,this)):"manual"!=a&&(r="hover"==a?"mouseenter":"focusin",o="hover"==a?"mouseleave":"focusout",this.$element.on(r+"."+this.type,this.options.selector,g.proxy(this.enter,this)),this.$element.on(o+"."+this.type,this.options.selector,g.proxy(this.leave,this)))}this.options.selector?this._options=g.extend({},this.options,{trigger:"manual",selector:""}):this.fixTitle()},v.prototype.getDefaults=function(){return v.DEFAULTS},v.prototype.getOptions=function(t){var e=this.$element.data();for(var n in e)e.hasOwnProperty(n)&&-1!==g.inArray(n,i)&&delete e[n];return(t=g.extend({},this.getDefaults(),e,t)).delay&&"number"==typeof t.delay&&(t.delay={show:t.delay,hide:t.delay}),t.sanitize&&(t.template=s(t.template,t.whiteList,t.sanitizeFn)),t},v.prototype.getDelegateOptions=function(){var n={},i=this.getDefaults();return this._options&&g.each(this._options,function(t,e){i[t]!=e&&(n[t]=e)}),n},v.prototype.enter=function(t){var e=t instanceof this.constructor?t:g(t.currentTarget).data("bs."+this.type);if(e||(e=new this.constructor(t.currentTarget,this.getDelegateOptions()),g(t.currentTarget).data("bs."+this.type,e)),t instanceof g.Event&&(e.inState["focusin"==t.type?"focus":"hover"]=!0),e.tip().hasClass("in")||"in"==e.hoverState)e.hoverState="in";else{if(clearTimeout(e.timeout),e.hoverState="in",!e.options.delay||!e.options.delay.show)return e.show();e.timeout=setTimeout(function(){"in"==e.hoverState&&e.show()},e.options.delay.show)}},v.prototype.isInStateTrue=function(){for(var t in this.inState)if(this.inState[t])return!0;return!1},v.prototype.leave=function(t){var e=t instanceof this.constructor?t:g(t.currentTarget).data("bs."+this.type);if(e||(e=new this.constructor(t.currentTarget,this.getDelegateOptions()),g(t.currentTarget).data("bs."+this.type,e)),t instanceof g.Event&&(e.inState["focusout"==t.type?"focus":"hover"]=!1),!e.isInStateTrue()){if(clearTimeout(e.timeout),e.hoverState="out",!e.options.delay||!e.options.delay.hide)return e.hide();e.timeout=setTimeout(function(){"out"==e.hoverState&&e.hide()},e.options.delay.hide)}},v.prototype.show=function(){var t=g.Event("show.bs."+this.type);if(this.hasContent()&&this.enabled){this.$element.trigger(t);var e=g.contains(this.$element[0].ownerDocument.documentElement,this.$element[0]);if(t.isDefaultPrevented()||!e)return;var n=this,i=this.tip(),s=this.getUID(this.type);this.setContent(),i.attr("id",s),this.$element.attr("aria-describedby",s),this.options.animation&&i.addClass("fade");var r="function"==typeof this.options.placement?this.options.placement.call(this,i[0],this.$element[0]):this.options.placement,o=/\s?auto?\s?/i,a=o.test(r);a&&(r=r.replace(o,"")||"top"),i.detach().css({top:0,left:0,display:"block"}).addClass(r).data("bs."+this.type,this),this.options.container?i.appendTo(g(document).find(this.options.container)):i.insertAfter(this.$element),this.$element.trigger("inserted.bs."+this.type);var l,c,u=this.getPosition(),d=i[0].offsetWidth,h=i[0].offsetHeight;a&&(l=r,c=this.getPosition(this.$viewport),r="bottom"==r&&u.bottom+h>c.bottom?"top":"top"==r&&u.top-h<c.top?"bottom":"right"==r&&u.right+d>c.width?"left":"left"==r&&u.left-d<c.left?"right":r,i.removeClass(l).addClass(r));var p=this.getCalculatedOffset(r,u,d,h);this.applyPlacement(p,r);var f=function(){var t=n.hoverState;n.$element.trigger("shown.bs."+n.type),n.hoverState=null,"out"==t&&n.leave(n)};g.support.transition&&this.$tip.hasClass("fade")?i.one("bsTransitionEnd",f).emulateTransitionEnd(v.TRANSITION_DURATION):f()}},v.prototype.applyPlacement=function(t,e){var n=this.tip(),i=n[0].offsetWidth,s=n[0].offsetHeight,r=parseInt(n.css("margin-top"),10),o=parseInt(n.css("margin-left"),10);isNaN(r)&&(r=0),isNaN(o)&&(o=0),t.top+=r,t.left+=o,g.offset.setOffset(n[0],g.extend({using:function(t){n.css({top:Math.round(t.top),left:Math.round(t.left)})}},t),0),n.addClass("in");var a=n[0].offsetWidth,l=n[0].offsetHeight;"top"==e&&l!=s&&(t.top=t.top+s-l);var c=this.getViewportAdjustedDelta(e,t,a,l);c.left?t.left+=c.left:t.top+=c.top;var u=/top|bottom/.test(e),d=u?2*c.left-i+a:2*c.top-s+l,h=u?"offsetWidth":"offsetHeight";n.offset(t),this.replaceArrow(d,n[0][h],u)},v.prototype.replaceArrow=function(t,e,n){this.arrow().css(n?"left":"top",50*(1-t/e)+"%").css(n?"top":"left","")},v.prototype.setContent=function(){var t=this.tip(),e=this.getTitle();this.options.html?(this.options.sanitize&&(e=s(e,this.options.whiteList,this.options.sanitizeFn)),t.find(".tooltip-inner").html(e)):t.find(".tooltip-inner").text(e),t.removeClass("fade in top bottom left right")},v.prototype.hide=function(t){var e=this,n=g(this.$tip),i=g.Event("hide.bs."+this.type);function s(){"in"!=e.hoverState&&n.detach(),e.$element&&e.$element.removeAttr("aria-describedby").trigger("hidden.bs."+e.type),t&&t()}if(this.$element.trigger(i),!i.isDefaultPrevented())return n.removeClass("in"),g.support.transition&&n.hasClass("fade")?n.one("bsTransitionEnd",s).emulateTransitionEnd(v.TRANSITION_DURATION):s(),this.hoverState=null,this},v.prototype.fixTitle=function(){var t=this.$element;!t.attr("title")&&"string"==typeof t.attr("data-original-title")||t.attr("data-original-title",t.attr("title")||"").attr("title","")},v.prototype.hasContent=function(){return this.getTitle()},v.prototype.getPosition=function(t){var e=(t=t||this.$element)[0],n="BODY"==e.tagName,i=e.getBoundingClientRect();null==i.width&&(i=g.extend({},i,{width:i.right-i.left,height:i.bottom-i.top}));var s=window.SVGElement&&e instanceof window.SVGElement,r=n?{top:0,left:0}:s?null:t.offset(),o={scroll:n?document.documentElement.scrollTop||document.body.scrollTop:t.scrollTop()},a=n?{width:g(window).width(),height:g(window).height()}:null;return g.extend({},i,o,a,r)},v.prototype.getCalculatedOffset=function(t,e,n,i){return"bottom"==t?{top:e.top+e.height,left:e.left+e.width/2-n/2}:"top"==t?{top:e.top-i,left:e.left+e.width/2-n/2}:"left"==t?{top:e.top+e.height/2-i/2,left:e.left-n}:{top:e.top+e.height/2-i/2,left:e.left+e.width}},v.prototype.getViewportAdjustedDelta=function(t,e,n,i){var s={top:0,left:0};if(!this.$viewport)return s;var r,o,a,l,c=this.options.viewport&&this.options.viewport.padding||0,u=this.getPosition(this.$viewport);return/right|left/.test(t)?(r=e.top-c-u.scroll,o=e.top+c-u.scroll+i,r<u.top?s.top=u.top-r:o>u.top+u.height&&(s.top=u.top+u.height-o)):(a=e.left-c,l=e.left+c+n,a<u.left?s.left=u.left-a:l>u.right&&(s.left=u.left+u.width-l)),s},v.prototype.getTitle=function(){var t=this.$element,e=this.options;return t.attr("data-original-title")||("function"==typeof e.title?e.title.call(t[0]):e.title)},v.prototype.getUID=function(t){for(;t+=~~(1e6*Math.random()),document.getElementById(t););return t},v.prototype.tip=function(){if(!this.$tip&&(this.$tip=g(this.options.template),1!=this.$tip.length))throw new Error(this.type+" `template` option must consist of exactly 1 top-level element!");return this.$tip},v.prototype.arrow=function(){return this.$arrow=this.$arrow||this.tip().find(".tooltip-arrow")},v.prototype.enable=function(){this.enabled=!0},v.prototype.disable=function(){this.enabled=!1},v.prototype.toggleEnabled=function(){this.enabled=!this.enabled},v.prototype.toggle=function(t){var e=this;t&&((e=g(t.currentTarget).data("bs."+this.type))||(e=new this.constructor(t.currentTarget,this.getDelegateOptions()),g(t.currentTarget).data("bs."+this.type,e))),t?(e.inState.click=!e.inState.click,e.isInStateTrue()?e.enter(e):e.leave(e)):e.tip().hasClass("in")?e.leave(e):e.enter(e)},v.prototype.destroy=function(){var t=this;clearTimeout(this.timeout),this.hide(function(){t.$element.off("."+t.type).removeData("bs."+t.type),t.$tip&&t.$tip.detach(),t.$tip=null,t.$arrow=null,t.$viewport=null,t.$element=null})},v.prototype.sanitizeHtml=function(t){return s(t,this.options.whiteList,this.options.sanitizeFn)};var e=g.fn.tooltip;g.fn.tooltip=function(i){return this.each(function(){var t=g(this),e=t.data("bs.tooltip"),n="object"==typeof i&&i;!e&&/destroy|hide/.test(i)||(e||t.data("bs.tooltip",e=new v(this,n)),"string"==typeof i&&e[i]())})},g.fn.tooltip.Constructor=v,g.fn.tooltip.noConflict=function(){return g.fn.tooltip=e,this}}(jQuery),function(s){"use strict";function r(t,e){this.init("popover",t,e)}if(!s.fn.tooltip)throw new Error("Popover requires tooltip.js");r.VERSION="3.4.1",r.DEFAULTS=s.extend({},s.fn.tooltip.Constructor.DEFAULTS,{placement:"right",trigger:"click",content:"",template:'<div class="popover" role="tooltip"><div class="arrow"></div><h3 class="popover-title"></h3><div class="popover-content"></div></div>'}),((r.prototype=s.extend({},s.fn.tooltip.Constructor.prototype)).constructor=r).prototype.getDefaults=function(){return r.DEFAULTS},r.prototype.setContent=function(){var t,e=this.tip(),n=this.getTitle(),i=this.getContent();this.options.html?(t=typeof i,this.options.sanitize&&(n=this.sanitizeHtml(n),"string"==t&&(i=this.sanitizeHtml(i))),e.find(".popover-title").html(n),e.find(".popover-content").children().detach().end()["string"==t?"html":"append"](i)):(e.find(".popover-title").text(n),e.find(".popover-content").children().detach().end().text(i)),e.removeClass("fade top bottom left right in"),e.find(".popover-title").html()||e.find(".popover-title").hide()},r.prototype.hasContent=function(){return this.getTitle()||this.getContent()},r.prototype.getContent=function(){var t=this.$element,e=this.options;return t.attr("data-content")||("function"==typeof e.content?e.content.call(t[0]):e.content)},r.prototype.arrow=function(){return this.$arrow=this.$arrow||this.tip().find(".arrow")};var t=s.fn.popover;s.fn.popover=function(i){return this.each(function(){var t=s(this),e=t.data("bs.popover"),n="object"==typeof i&&i;!e&&/destroy|hide/.test(i)||(e||t.data("bs.popover",e=new r(this,n)),"string"==typeof i&&e[i]())})},s.fn.popover.Constructor=r,s.fn.popover.noConflict=function(){return s.fn.popover=t,this}}(jQuery),function(r){"use strict";function s(t,e){this.$body=r(document.body),this.$scrollElement=r(t).is(document.body)?r(window):r(t),this.options=r.extend({},s.DEFAULTS,e),this.selector=(this.options.target||"")+" .nav li > a",this.offsets=[],this.targets=[],this.activeTarget=null,this.scrollHeight=0,this.$scrollElement.on("scroll.bs.scrollspy",r.proxy(this.process,this)),this.refresh(),this.process()}function e(i){return this.each(function(){var t=r(this),e=t.data("bs.scrollspy"),n="object"==typeof i&&i;e||t.data("bs.scrollspy",e=new s(this,n)),"string"==typeof i&&e[i]()})}s.VERSION="3.4.1",s.DEFAULTS={offset:10},s.prototype.getScrollHeight=function(){return this.$scrollElement[0].scrollHeight||Math.max(this.$body[0].scrollHeight,document.documentElement.scrollHeight)},s.prototype.refresh=function(){var t=this,i="offset",s=0;this.offsets=[],this.targets=[],this.scrollHeight=this.getScrollHeight(),r.isWindow(this.$scrollElement[0])||(i="position",s=this.$scrollElement.scrollTop()),this.$body.find(this.selector).map(function(){var t=r(this),e=t.data("target")||t.attr("href"),n=/^#./.test(e)&&r(e);return n&&n.length&&n.is(":visible")?[[n[i]().top+s,e]]:null}).sort(function(t,e){return t[0]-e[0]}).each(function(){t.offsets.push(this[0]),t.targets.push(this[1])})},s.prototype.process=function(){var t,e=this.$scrollElement.scrollTop()+this.options.offset,n=this.getScrollHeight(),i=this.options.offset+n-this.$scrollElement.height(),s=this.offsets,r=this.targets,o=this.activeTarget;if(this.scrollHeight!=n&&this.refresh(),i<=e)return o!=(t=r[r.length-1])&&this.activate(t);if(o&&e<s[0])return this.activeTarget=null,this.clear();for(t=s.length;t--;)o!=r[t]&&e>=s[t]&&(void 0===s[t+1]||e<s[t+1])&&this.activate(r[t])},s.prototype.activate=function(t){this.activeTarget=t,this.clear();var e=this.selector+'[data-target="'+t+'"],'+this.selector+'[href="'+t+'"]',n=r(e).parents("li").addClass("active");n.parent(".dropdown-menu").length&&(n=n.closest("li.dropdown").addClass("active")),n.trigger("activate.bs.scrollspy")},s.prototype.clear=function(){r(this.selector).parentsUntil(this.options.target,".active").removeClass("active")};var t=r.fn.scrollspy;r.fn.scrollspy=e,r.fn.scrollspy.Constructor=s,r.fn.scrollspy.noConflict=function(){return r.fn.scrollspy=t,this},r(window).on("load.bs.scrollspy.data-api",function(){r('[data-spy="scroll"]').each(function(){var t=r(this);e.call(t,t.data())})})}(jQuery),function(a){"use strict";function o(t){this.element=a(t)}function e(n){return this.each(function(){var t=a(this),e=t.data("bs.tab");e||t.data("bs.tab",e=new o(this)),"string"==typeof n&&e[n]()})}o.VERSION="3.4.1",o.TRANSITION_DURATION=150,o.prototype.show=function(){var t,e,n,i,s=this.element,r=s.closest("ul:not(.dropdown-menu)"),o=(o=s.data("target"))||(o=s.attr("href"))&&o.replace(/.*(?=#[^\s]*$)/,"");s.parent("li").hasClass("active")||(t=r.find(".active:last a"),e=a.Event("hide.bs.tab",{relatedTarget:s[0]}),n=a.Event("show.bs.tab",{relatedTarget:t[0]}),t.trigger(e),s.trigger(n),n.isDefaultPrevented()||e.isDefaultPrevented()||(i=a(document).find(o),this.activate(s.closest("li"),r),this.activate(i,i.parent(),function(){t.trigger({type:"hidden.bs.tab",relatedTarget:s[0]}),s.trigger({type:"shown.bs.tab",relatedTarget:t[0]})})))},o.prototype.activate=function(t,e,n){var i=e.find("> .active"),s=n&&a.support.transition&&(i.length&&i.hasClass("fade")||!!e.find("> .fade").length);function r(){i.removeClass("active").find("> .dropdown-menu > .active").removeClass("active").end().find('[data-toggle="tab"]').attr("aria-expanded",!1),t.addClass("active").find('[data-toggle="tab"]').attr("aria-expanded",!0),s?(t[0].offsetWidth,t.addClass("in")):t.removeClass("fade"),t.parent(".dropdown-menu").length&&t.closest("li.dropdown").addClass("active").end().find('[data-toggle="tab"]').attr("aria-expanded",!0),n&&n()}i.length&&s?i.one("bsTransitionEnd",r).emulateTransitionEnd(o.TRANSITION_DURATION):r(),i.removeClass("in")};var t=a.fn.tab;a.fn.tab=e,a.fn.tab.Constructor=o,a.fn.tab.noConflict=function(){return a.fn.tab=t,this};function n(t){t.preventDefault(),e.call(a(this),"show")}a(document).on("click.bs.tab.data-api",'[data-toggle="tab"]',n).on("click.bs.tab.data-api",'[data-toggle="pill"]',n)}(jQuery),function(i){"use strict";i.fn.emulateTransitionEnd=function(t){var e=!1,n=this;i(this).one("bsTransitionEnd",function(){e=!0});return setTimeout(function(){e||i(n).trigger(i.support.transition.end)},t),this},i(function(){i.support.transition=function(){var t=document.createElement("bootstrap"),e={WebkitTransition:"webkitTransitionEnd",MozTransition:"transitionend",OTransition:"oTransitionEnd otransitionend",transition:"transitionend"};for(var n in e)if(void 0!==t.style[n])return{end:e[n]};return!1}(),i.support.transition&&(i.event.special.bsTransitionEnd={bindType:i.support.transition.end,delegateType:i.support.transition.end,handle:function(t){if(i(t.target).is(this))return t.handleObj.handler.apply(this,arguments)}})})}(jQuery),function(l){"use strict";function o(t){return(t||"ui-id")+"-"+Math.floor(1e3*Math.random()+1)}function t(t,e,n){var i=(t.attr(e)||"").split(/\s+/),s=l.inArray(n,i);-1!==s&&i.splice(s,1),(i=l.trim(i.join(" ")))?t.attr(e,i):t.removeAttr(e)}l(".alert").attr("role","alert"),l(".close").removeAttr("aria-hidden").wrapInner('<span aria-hidden="true"></span>').append('<span class="sr-only">Close</span>');var n=l.fn.tooltip.Constructor.prototype.show,e=l.fn.tooltip.Constructor.prototype.hide;l.fn.tooltip.Constructor.prototype.show=function(){n.apply(this,arguments);var t=this.tip(),e=t.attr("id")||o("ui-tooltip");t.attr({role:"tooltip",id:e}),this.$element.attr("aria-describedby",e)},l.fn.tooltip.Constructor.prototype.hide=function(){return e.apply(this,arguments),t(this.$element,"aria-describedby",this.tip().attr("id")),this};var i=l.fn.popover.Constructor.prototype.setContent,s=l.fn.popover.Constructor.prototype.hide;l.fn.popover.Constructor.prototype.setContent=function(){i.apply(this,arguments);var t=this.tip(),e=t.attr("id")||o("ui-tooltip");t.attr({role:"alert",id:e}),this.$element.attr("aria-describedby",e),this.$element.focus()},l.fn.popover.Constructor.prototype.hide=function(){return s.apply(this,arguments),t(this.$element,"aria-describedby",this.tip().attr("id")),this},l(".modal-dialog").attr({role:"document"});var r=l.fn.modal.Constructor.prototype.hide;l.fn.modal.Constructor.prototype.hide=function(){var t=this.$element.parent().find('[data-target="#'+this.$element.attr("id")+'"]');r.apply(this,arguments),t.focus()};var a="[data-toggle=dropdown]";l(a).parent().find("ul").attr("role","menu").find("li").attr("role","presentation").find("a").attr({role:"menuitem",tabIndex:"-1"}),l(a).attr({"aria-haspopup":"true","aria-expanded":"false"}),l(a).parent().on("shown.bs.dropdown",function(t){l(this).find(a).attr("aria-expanded","true")}),l(a).parent().on("hidden.bs.dropdown",function(t){l(this).find(a).attr("aria-expanded","false")}),l.fn.dropdown.Constructor.prototype.keydown=function(t){/(32)/.test(t.keyCode)&&(l(this).parent(),l(this).trigger("click"),t.preventDefault()&&t.stopPropagation())};var c=l(".nav-tabs, .nav-pills"),u=c.children("li"),d=c.find('[data-toggle="tab"], [data-toggle="pill"]');c.attr("role","tablist"),u.attr("role","presentation"),d.attr("role","tab"),d.each(function(t){var e=l(l(this).attr("href")),n=l(this),i=n.attr("id")||o("ui-tab");n.attr("id",i),n.parent().hasClass("active")?(n.attr({tabIndex:"0","aria-selected":"true","aria-controls":n.attr("href").substr(1)}),e.attr({role:"tabpanel","aria-hidden":"false","aria-labelledby":i})):(n.attr({tabIndex:"-1","aria-selected":"false","aria-controls":n.attr("href").substr(1)}),e.attr({role:"tabpanel","aria-hidden":"true","aria-labelledby":i}))}),l.fn.tab.Constructor.prototype.keydown=function(t){var e,n,i,s=l(this).closest("ul[role=tablist] "),r=t.which||t.keyCode;l(this);/(37|38|39|40)/.test(r)&&(n=(e=s.find("[role=tab]:visible")).index(e.filter(":focus")),38!=r&&37!=r||n--,39!=r&&40!=r||n++,n<0&&(n=e.length-1),n==e.length&&(n=0),"tab"===(i=e.eq(n)).attr("role")&&i.focus(),t.preventDefault(),t.stopPropagation())},l(document).on("keydown.tab.data-api",'[data-toggle="tab"], [data-toggle="pill"]',l.fn.tab.Constructor.prototype.keydown);var h=l.fn.tab.Constructor.prototype.activate;l.fn.tab.Constructor.prototype.activate=function(t,e,n){var i=e.find("> .active");i.find("[data-toggle=tab], [data-toggle=pill]").attr({tabIndex:"-1","aria-selected":!1}),i.filter(".tab-pane").attr({"aria-hidden":!0}),h.apply(this,arguments),t.addClass("active"),t.find("[data-toggle=tab], [data-toggle=pill]").attr({tabIndex:"0","aria-selected":!0}),t.filter(".tab-pane").attr({"aria-hidden":!1})};var p=l('[data-toggle="collapse"]');p.attr({role:"tab","aria-selected":"false","aria-expanded":"false"}),p.each(function(t){var e=l(this),n=e.attr("data-target")?l(e.attr("data-target")):l(e.attr("href")),i=e.attr("data-parent"),s=i&&l(i),r=e.attr("id")||o("ui-collapse");l(s).find("div:not(.collapse,.panel-body), h4").attr("role","presentation"),e.attr("id",r),s&&(s.attr({role:"tablist","aria-multiselectable":"true"}),n.hasClass("in")?(e.attr({"aria-controls":e.attr("href").substr(1),"aria-selected":"true","aria-expanded":"true",tabindex:"0"}),n.attr({role:"tabpanel",tabindex:"0","aria-labelledby":r,"aria-hidden":"false"})):(e.attr({"aria-controls":e.attr("href").substr(1),tabindex:"-1"}),n.attr({role:"tabpanel",tabindex:"-1","aria-labelledby":r,"aria-hidden":"true"})))});var f=l.fn.collapse.Constructor.prototype.toggle;l.fn.collapse.Constructor.prototype.toggle=function(){var t,e,n,i,s,r=this.$parent&&this.$parent.find('[aria-expanded="true"]');r?(e=r.attr("data-target")||(t=r.attr("href"))&&t.replace(/.*(?=#[^\s]+$)/,""),n=l(e),i=this.$element,this.$parent,this.$parent&&(s=this.$parent.find('[data-toggle=collapse][href="#'+this.$element.attr("id")+'"]')),f.apply(this,arguments),l.support.transition&&this.$element.one(l.support.transition.end,function(){r.attr({"aria-selected":"false","aria-expanded":"false",tabIndex:"-1"}),n.attr({"aria-hidden":"true",tabIndex:"-1"}),s.attr({"aria-selected":"true","aria-expanded":"true",tabIndex:"0"}),i.hasClass("in")?i.attr({"aria-hidden":"false",tabIndex:"0"}):(s.attr({"aria-selected":"false","aria-expanded":"false"}),i.attr({"aria-hidden":"true",tabIndex:"-1"}))})):f.apply(this,arguments)},l.fn.collapse.Constructor.prototype.keydown=function(t){var e,n,i=(r=l(this)).closest("div[role=tablist] "),s=t.which||t.keyCode,r=l(this);/(32|37|38|39|40)/.test(s)&&(32==s&&r.click(),n=(e=i.find("[role=tab]")).index(e.filter(":focus")),38!=s&&37!=s||n--,39!=s&&40!=s||n++,n<0&&(n=e.length-1),n==e.length&&(n=0),e.eq(n).focus(),t.preventDefault(),t.stopPropagation())},l(document).on("keydown.collapse.data-api",'[data-toggle="collapse"]',l.fn.collapse.Constructor.prototype.keydown),l(".carousel").each(function(t){var e=l(this),n=e.find('[data-slide="prev"]'),i=e.find('[data-slide="next"]'),s=e.find(".item"),r=s.parent();e.attr({"data-interval":"false","data-wrap":"false"}),r.attr("role","listbox"),s.attr("role","option");var o=document.createElement("span");o.setAttribute("class","sr-only"),o.innerHTML="Previous";var a=document.createElement("span");a.setAttribute("class","sr-only"),a.innerHTML="Next",n.attr("role","button"),i.attr("role","button"),n.append(o),i.append(a),s.each(function(){var t=l(this);t.hasClass("active")?t.attr({"aria-selected":"true",tabindex:"0"}):t.attr({"aria-selected":"false",tabindex:"-1"})})});var g=l.fn.carousel.Constructor.prototype.slide;l.fn.carousel.Constructor.prototype.slide=function(t,e){var n=this.$element.find(".item.active"),i=e||n[t]();g.apply(this,arguments),n.one(l.support.transition.end,function(){n.attr({"aria-selected":!1,tabIndex:"-1"}),i.attr({"aria-selected":!0,tabIndex:"0"})})},l.fn.carousel.Constructor.prototype.keydown=function(t){var e,n=l(this),i=n.closest("div[role=listbox]"),s=i.find("[role=option]"),r=i.parent(),o=t.which||t.keyCode;/(37|38|39|40)/.test(o)&&(e=s.index(s.filter(".active")),37!=o&&38!=o||(r.carousel("prev"),--e<0?e=s.length-1:n.prev().focus()),39!=o&&40!=o||(r.carousel("next"),++e==s.length?e=0:n.one(l.support.transition.end,function(){n.next().focus()})),t.preventDefault(),t.stopPropagation())},l(document).on("keydown.carousel.data-api","div[role=option]",l.fn.carousel.Constructor.prototype.keydown)}(jQuery),function(t){"function"==typeof define&&define.amd?define(["jquery"],t):"object"==typeof module&&"object"==typeof module.exports?module.exports=t(require("jquery")):t(jQuery)}(function(t){return function(E){"use strict";var N=E.tablesorter={version:"2.31.3",parsers:[],widgets:[],defaults:{theme:"default",widthFixed:!1,showProcessing:!1,headerTemplate:"{content}",onRenderTemplate:null,onRenderHeader:null,cancelSelection:!0,tabIndex:!0,dateFormat:"mmddyyyy",sortMultiSortKey:"shiftKey",sortResetKey:"ctrlKey",usNumberFormat:!0,delayInit:!1,serverSideSorting:!1,resort:!0,headers:{},ignoreCase:!0,sortForce:null,sortList:[],sortAppend:null,sortStable:!1,sortInitialOrder:"asc",sortLocaleCompare:!1,sortReset:!1,sortRestart:!1,emptyTo:"bottom",stringTo:"max",duplicateSpan:!0,textExtraction:"basic",textAttribute:"data-text",textSorter:null,numberSorter:null,initWidgets:!0,widgetClass:"widget-{name}",widgets:[],widgetOptions:{zebra:["even","odd"]},initialized:null,tableClass:"",cssAsc:"",cssDesc:"",cssNone:"",cssHeader:"",cssHeaderRow:"",cssProcessing:"",cssChildRow:"tablesorter-childRow",cssInfoBlock:"tablesorter-infoOnly",cssNoSort:"tablesorter-noSort",cssIgnoreRow:"tablesorter-ignoreRow",cssIcon:"tablesorter-icon",cssIconNone:"",cssIconAsc:"",cssIconDesc:"",cssIconDisabled:"",pointerClick:"click",pointerDown:"mousedown",pointerUp:"mouseup",selectorHeaders:"> thead th, > thead td",selectorSort:"th, td",selectorRemove:".remove-me",debug:!1,headerList:[],empties:{},strings:{},parsers:[],globalize:0,imgAttr:0},css:{table:"tablesorter",cssHasChild:"tablesorter-hasChildRow",childRow:"tablesorter-childRow",colgroup:"tablesorter-colgroup",header:"tablesorter-header",headerRow:"tablesorter-headerRow",headerIn:"tablesorter-header-inner",icon:"tablesorter-icon",processing:"tablesorter-processing",sortAsc:"tablesorter-headerAsc",sortDesc:"tablesorter-headerDesc",sortNone:"tablesorter-headerUnSorted"},language:{sortAsc:"Ascending sort applied, ",sortDesc:"Descending sort applied, ",sortNone:"No sort applied, ",sortDisabled:"sorting is disabled",nextAsc:"activate to apply an ascending sort",nextDesc:"activate to apply a descending sort",nextNone:"activate to remove the sort"},regex:{templateContent:/\{content\}/g,templateIcon:/\{icon\}/g,templateName:/\{name\}/i,spaces:/\s+/g,nonWord:/\W/g,formElements:/(input|select|button|textarea)/i,chunk:/(^([+\-]?(?:\d*)(?:\.\d*)?(?:[eE][+\-]?\d+)?)?$|^0x[0-9a-f]+$|\d+)/gi,chunks:/(^\\0|\\0$)/,hex:/^0x[0-9a-f]+$/i,comma:/,/g,digitNonUS:/[\s|\.]/g,digitNegativeTest:/^\s*\([.\d]+\)/,digitNegativeReplace:/^\s*\(([.\d]+)\)/,digitTest:/^[\-+(]?\d+[)]?$/,digitReplace:/[,.'"\s]/g},string:{max:1,min:-1,emptymin:1,emptymax:-1,zero:0,none:0,null:0,top:!0,bottom:!1},keyCodes:{enter:13},dates:{},instanceMethods:{},setup:function(e,n){var t,i,s,r;e&&e.tHead&&0!==e.tBodies.length&&!0!==e.hasInitialized?(t="",i=E(e),s=E.metadata,e.hasInitialized=!1,e.isProcessing=!0,e.config=n,E.data(e,"tablesorter",n),N.debug(n,"core")&&(console[console.group?"group":"log"]("Initializing tablesorter v"+N.version),E.data(e,"startoveralltimer",new Date)),n.supportsDataObject=((r=E.fn.jquery.split("."))[0]=parseInt(r[0],10),1<r[0]||1===r[0]&&4<=parseInt(r[1],10)),n.emptyTo=n.emptyTo.toLowerCase(),n.stringTo=n.stringTo.toLowerCase(),n.last={sortList:[],clickedIndex:-1},/tablesorter\-/.test(i.attr("class"))||(t=""!==n.theme?" tablesorter-"+n.theme:""),n.namespace?n.namespace="."+n.namespace.replace(N.regex.nonWord,""):n.namespace=".tablesorter"+Math.random().toString(16).slice(2),n.table=e,n.$table=i.addClass(N.css.table+" "+n.tableClass+t+" "+n.namespace.slice(1)).attr("role","grid"),n.$headers=i.find(n.selectorHeaders),n.$table.children().children("tr").attr("role","row"),n.$tbodies=i.children("tbody:not(."+n.cssInfoBlock+")").attr({"aria-live":"polite","aria-relevant":"all"}),n.$table.children("caption").length&&((t=n.$table.children("caption")[0]).id||(t.id=n.namespace.slice(1)+"caption"),n.$table.attr("aria-labelledby",t.id)),n.widgetInit={},n.textExtraction=n.$table.attr("data-text-extraction")||n.textExtraction||"basic",N.buildHeaders(n),N.fixColumnWidth(e),N.addWidgetFromClass(e),N.applyWidgetOptions(e),N.setupParsers(n),n.totalRows=0,n.debug&&N.validateOptions(n),n.delayInit||N.buildCache(n),N.bindEvents(e,n.$headers,!0),N.bindMethods(n),n.supportsDataObject&&void 0!==i.data().sortlist?n.sortList=i.data().sortlist:s&&i.metadata()&&i.metadata().sortlist&&(n.sortList=i.metadata().sortlist),N.applyWidget(e,!0),0<n.sortList.length?(n.last.sortList=n.sortList,N.sortOn(n,n.sortList,{},!n.initWidgets)):(N.setHeadersCss(n),n.initWidgets&&N.applyWidget(e,!1)),n.showProcessing&&i.unbind("sortBegin"+n.namespace+" sortEnd"+n.namespace).bind("sortBegin"+n.namespace+" sortEnd"+n.namespace,function(t){clearTimeout(n.timerProcessing),N.isProcessing(e),"sortBegin"===t.type&&(n.timerProcessing=setTimeout(function(){N.isProcessing(e,!0)},500))}),e.hasInitialized=!0,e.isProcessing=!1,N.debug(n,"core")&&(console.log("Overall initialization time:"+N.benchmark(E.data(e,"startoveralltimer"))),N.debug(n,"core")&&console.groupEnd&&console.groupEnd()),i.triggerHandler("tablesorter-initialized",e),"function"==typeof n.initialized&&n.initialized(e)):N.debug(n,"core")&&(e.hasInitialized?console.warn("Stopping initialization. Tablesorter has already been initialized"):console.error("Stopping initialization! No table, thead or tbody",e))},bindMethods:function(n){var t=n.$table,e=n.namespace,i="sortReset update updateRows updateAll updateHeaders addRows updateCell updateComplete sorton appendCache updateCache applyWidgetId applyWidgets refreshWidgets destroy mouseup mouseleave ".split(" ").join(e+" ");t.unbind(i.replace(N.regex.spaces," ")).bind("sortReset"+e,function(t,e){t.stopPropagation(),N.sortReset(this.config,function(t){t.isApplyingWidgets?setTimeout(function(){N.applyWidget(t,"",e)},100):N.applyWidget(t,"",e)})}).bind("updateAll"+e,function(t,e,n){t.stopPropagation(),N.updateAll(this.config,e,n)}).bind("update"+e+" updateRows"+e,function(t,e,n){t.stopPropagation(),N.update(this.config,e,n)}).bind("updateHeaders"+e,function(t,e){t.stopPropagation(),N.updateHeaders(this.config,e)}).bind("updateCell"+e,function(t,e,n,i){t.stopPropagation(),N.updateCell(this.config,e,n,i)}).bind("addRows"+e,function(t,e,n,i){t.stopPropagation(),N.addRows(this.config,e,n,i)}).bind("updateComplete"+e,function(){this.isUpdating=!1}).bind("sorton"+e,function(t,e,n,i){t.stopPropagation(),N.sortOn(this.config,e,n,i)}).bind("appendCache"+e,function(t,e,n){t.stopPropagation(),N.appendCache(this.config,n),E.isFunction(e)&&e(this)}).bind("updateCache"+e,function(t,e,n){t.stopPropagation(),N.updateCache(this.config,e,n)}).bind("applyWidgetId"+e,function(t,e){t.stopPropagation(),N.applyWidgetId(this,e)}).bind("applyWidgets"+e,function(t,e){t.stopPropagation(),N.applyWidget(this,!1,e)}).bind("refreshWidgets"+e,function(t,e,n){t.stopPropagation(),N.refreshWidgets(this,e,n)}).bind("removeWidget"+e,function(t,e,n){t.stopPropagation(),N.removeWidget(this,e,n)}).bind("destroy"+e,function(t,e,n){t.stopPropagation(),N.destroy(this,e,n)}).bind("resetToLoadState"+e,function(t){t.stopPropagation(),N.removeWidget(this,!0,!1);var e=E.extend(!0,{},n.originalSettings);(n=E.extend(!0,{},N.defaults,e)).originalSettings=e,this.hasInitialized=!1,N.setup(this,n)})},bindEvents:function(t,e,n){var i,a=(t=E(t)[0]).config,s=a.namespace,l=null;!0!==n&&(e.addClass(s.slice(1)+"_extra_headers"),(i=N.getClosest(e,"table")).length&&"TABLE"===i[0].nodeName&&i[0]!==t&&E(i[0]).addClass(s.slice(1)+"_extra_table")),i=(a.pointerDown+" "+a.pointerUp+" "+a.pointerClick+" sort keyup ").replace(N.regex.spaces," ").split(" ").join(s+" "),e.find(a.selectorSort).add(e.filter(a.selectorSort)).unbind(i).bind(i,function(t,e){var n,i,s,r=E(t.target),o=" "+t.type+" ";if(!(1!==(t.which||t.button)&&!o.match(" "+a.pointerClick+" | sort | keyup ")||" keyup "===o&&t.which!==N.keyCodes.enter||o.match(" "+a.pointerClick+" ")&&void 0!==t.which||o.match(" "+a.pointerUp+" ")&&l!==t.target&&!0!==e)){if(o.match(" "+a.pointerDown+" "))return l=t.target,void("1"===(s=r.jquery.split("."))[0]&&s[1]<4&&t.preventDefault());if(l=null,n=N.getClosest(E(this),"."+N.css.header),N.regex.formElements.test(t.target.nodeName)||r.hasClass(a.cssNoSort)||0<r.parents("."+a.cssNoSort).length||n.hasClass("sorter-false")||0<r.parents("button").length)return!a.cancelSelection;a.delayInit&&N.isEmptyObject(a.cache)&&N.buildCache(a),a.last.clickedIndex=n.attr("data-column")||n.index(),(i=a.$headerIndexed[a.last.clickedIndex][0])&&!i.sortDisabled&&N.initSort(a,i,t)}}),a.cancelSelection&&e.attr("unselectable","on").bind("selectstart",!1).css({"user-select":"none",MozUserSelect:"none"})},buildHeaders:function(l){var t,c,e,n;for(l.headerList=[],l.headerContent=[],l.sortVars=[],N.debug(l,"core")&&(e=new Date),l.columns=N.computeColumnIndex(l.$table.children("thead, tfoot").children("tr")),c=l.cssIcon?'<i class="'+(l.cssIcon===N.css.icon?N.css.icon:l.cssIcon+" "+N.css.icon)+'"></i>':"",l.$headers=E(E.map(l.$table.find(l.selectorHeaders),function(t,e){var n,i,s,r,o,a=E(t);if(!N.getClosest(a,"tr").hasClass(l.cssIgnoreRow))return/(th|td)/i.test(t.nodeName)||(o=N.getClosest(a,"th, td"),a.attr("data-column",o.attr("data-column"))),n=N.getColumnData(l.table,l.headers,e,!0),l.headerContent[e]=a.html(),""===l.headerTemplate||a.find("."+N.css.headerIn).length||(r=l.headerTemplate.replace(N.regex.templateContent,a.html()).replace(N.regex.templateIcon,a.find("."+N.css.icon).length?"":c),l.onRenderTemplate&&(i=l.onRenderTemplate.apply(a,[e,r]))&&"string"==typeof i&&(r=i),a.html('<div class="'+N.css.headerIn+'">'+r+"</div>")),l.onRenderHeader&&l.onRenderHeader.apply(a,[e,l,l.$table]),s=parseInt(a.attr("data-column"),10),t.column=s,o=N.getOrder(N.getData(a,n,"sortInitialOrder")||l.sortInitialOrder),l.sortVars[s]={count:-1,order:o?l.sortReset?[1,0,2]:[1,0]:l.sortReset?[0,1,2]:[0,1],lockedOrder:!1,sortedBy:""},void 0!==(o=N.getData(a,n,"lockedOrder")||!1)&&!1!==o&&(l.sortVars[s].lockedOrder=!0,l.sortVars[s].order=N.getOrder(o)?[1,1]:[0,0]),l.headerList[e]=t,a.addClass(N.css.header+" "+l.cssHeader),N.getClosest(a,"tr").addClass(N.css.headerRow+" "+l.cssHeaderRow).attr("role","row"),l.tabIndex&&a.attr("tabindex",0),t})),l.$headerIndexed=[],n=0;n<l.columns;n++)N.isEmptyObject(l.sortVars[n])&&(l.sortVars[n]={}),t=l.$headers.filter('[data-column="'+n+'"]'),l.$headerIndexed[n]=t.length?t.not(".sorter-false").length?t.not(".sorter-false").filter(":last"):t.filter(":last"):E();l.$table.find(l.selectorHeaders).attr({scope:"col",role:"columnheader"}),N.updateHeader(l),N.debug(l,"core")&&(console.log("Built headers:"+N.benchmark(e)),console.log(l.$headers))},addInstanceMethods:function(t){E.extend(N.instanceMethods,t)},setupParsers:function(t,e){var n,i,s,r,o,a,l,c,u,d,h,p,f,g,m=t.table,y=0,v=N.debug(t,"core"),b={};if(t.$tbodies=t.$table.children("tbody:not(."+t.cssInfoBlock+")"),0===(g=(f=void 0===e?t.$tbodies:e).length))return v?console.warn("Warning: *Empty table!* Not building a parser cache"):"";for(v&&(p=new Date,console[console.group?"group":"log"]("Detecting parsers for each column")),i={extractors:[],parsers:[]};y<g;){if((n=f[y].rows).length)for(o=0,r=t.columns,a=0;a<r;a++){if((l=t.$headerIndexed[o])&&l.length&&(c=N.getColumnData(m,t.headers,o),h=N.getParserById(N.getData(l,c,"extractor")),d=N.getParserById(N.getData(l,c,"sorter")),u="false"===N.getData(l,c,"parser"),t.empties[o]=(N.getData(l,c,"empty")||t.emptyTo||(t.emptyToBottom?"bottom":"top")).toLowerCase(),t.strings[o]=(N.getData(l,c,"string")||t.stringTo||"max").toLowerCase(),u&&(d=N.getParserById("no-parser")),h=h||!1,d=d||N.detectParserForColumn(t,n,-1,o),v&&(b["("+o+") "+l.text()]={parser:d.id,extractor:h?h.id:"none",string:t.strings[o],empty:t.empties[o]}),i.parsers[o]=d,i.extractors[o]=h,0<(s=l[0].colSpan-1)))for(o+=s,r+=s;0<s+1;)i.parsers[o-s]=d,i.extractors[o-s]=h,s--;o++}y+=i.parsers.length?g:1}v&&(N.isEmptyObject(b)?console.warn("  No parsers detected!"):console[console.table?"table":"log"](b),console.log("Completed detecting parsers"+N.benchmark(p)),console.groupEnd&&console.groupEnd()),t.parsers=i.parsers,t.extractors=i.extractors},addParser:function(t){for(var e=N.parsers.length,n=!0,i=0;i<e;i++)N.parsers[i].id.toLowerCase()===t.id.toLowerCase()&&(n=!1);n&&(N.parsers[N.parsers.length]=t)},getParserById:function(t){if("false"==t)return!1;for(var e=N.parsers.length,n=0;n<e;n++)if(N.parsers[n].id.toLowerCase()===t.toString().toLowerCase())return N.parsers[n];return!1},detectParserForColumn:function(t,e,n,i){for(var s,r,o,a=N.parsers.length,l=!1,c="",u=N.debug(t,"core"),d=!0;""===c&&d;)(o=e[++n])&&n<50?o.className.indexOf(N.cssIgnoreRow)<0&&(l=e[n].cells[i],c=N.getElementText(t,l,i),r=E(l),u&&console.log("Checking if value was empty on row "+n+", column: "+i+': "'+c+'"')):d=!1;for(;0<=--a;)if((s=N.parsers[a])&&"text"!==s.id&&s.is&&s.is(c,t.table,l,r))return s;return N.getParserById("text")},getElementText:function(t,e,n){if(!e)return"";var i,s=t.textExtraction||"",r=e.jquery?e:E(e);return"string"==typeof s?"basic"===s&&void 0!==(i=r.attr(t.textAttribute))?E.trim(i):E.trim(e.textContent||r.text()):"function"==typeof s?E.trim(s(r[0],t.table,n)):"function"==typeof(i=N.getColumnData(t.table,s,n))?E.trim(i(r[0],t.table,n)):E.trim(r[0].textContent||r.text())},getParsedText:function(t,e,n,i){void 0===i&&(i=N.getElementText(t,e,n));var s=""+i,r=t.parsers[n],o=t.extractors[n];return r&&(o&&"function"==typeof o.format&&(i=o.format(i,t.table,e,n)),s="no-parser"===r.id?"":r.format(""+i,t.table,e,n),t.ignoreCase&&"string"==typeof s&&(s=s.toLowerCase())),s},buildCache:function(t,e,n){var i,s,r,o,a,l,c,u,d,h,p,f,g,m,y,v,b,_,w,x,C,k,S=t.table,T=t.parsers,D=N.debug(t,"core");if(t.$tbodies=t.$table.children("tbody:not(."+t.cssInfoBlock+")"),c=void 0===n?t.$tbodies:n,t.cache={},t.totalRows=0,!T)return D?console.warn("Warning: *Empty table!* Not building a cache"):"";for(D&&(f=new Date),t.showProcessing&&N.isProcessing(S,!0),l=0;l<c.length;l++){for(v=[],i=t.cache[l]={normalized:[]},g=c[l]&&c[l].rows.length||0,o=0;o<g;++o)if(m={child:[],raw:[]},d=[],!(u=E(c[l].rows[o])).hasClass(t.selectorRemove.slice(1)))if(u.hasClass(t.cssChildRow)&&0!==o)for(C=i.normalized.length-1,(y=i.normalized[C][t.columns]).$row=y.$row.add(u),u.prev().hasClass(t.cssChildRow)||u.prev().addClass(N.css.cssHasChild),h=u.children("th, td"),C=y.child.length,y.child[C]=[],_=0,x=t.columns,a=0;a<x;a++)(p=h[a])&&(y.child[C][a]=N.getParsedText(t,p,a),0<(b=h[a].colSpan-1)&&(_+=b,x+=b)),_++;else{for(m.$row=u,m.order=o,_=0,x=t.columns,a=0;a<x;++a){if((p=u[0].cells[a])&&_<t.columns&&(!(w=void 0!==T[_])&&D&&console.warn("No parser found for row: "+o+", column: "+a+'; cell containing: "'+E(p).text()+'"; does it have a header?'),s=N.getElementText(t,p,_),m.raw[_]=s,r=N.getParsedText(t,p,_,s),d[_]=r,w&&"numeric"===(T[_].type||"").toLowerCase()&&(v[_]=Math.max(Math.abs(r)||0,v[_]||0)),0<(b=p.colSpan-1))){for(k=0;k<=b;)r=t.duplicateSpan||0===k?r:"string"!=typeof t.textExtraction&&N.getElementText(t,p,_+k)||"",m.raw[_+k]=r,d[_+k]=r,k++;_+=b,x+=b}_++}d[t.columns]=m,i.normalized[i.normalized.length]=d}i.colMax=v,t.totalRows+=i.normalized.length}if(t.showProcessing&&N.isProcessing(S),D){for(C=Math.min(5,t.cache[0].normalized.length),console[console.group?"group":"log"]("Building cache for "+t.totalRows+" rows (showing "+C+" rows in log) and "+t.columns+" columns"+N.benchmark(f)),s={},a=0;a<t.columns;a++)for(_=0;_<C;_++)s["row: "+_]||(s["row: "+_]={}),s["row: "+_][t.$headerIndexed[a].text()]=t.cache[0].normalized[_][a];console[console.table?"table":"log"](s),console.groupEnd&&console.groupEnd()}E.isFunction(e)&&e(S)},getColumnText:function(t,e,n,i){var s,r,o,a,l,c,u,d,h,p,f="function"==typeof n,g="all"===e,m={raw:[],parsed:[],$cell:[]},y=(t=E(t)[0]).config;if(!N.isEmptyObject(y)){for(l=y.$tbodies.length,s=0;s<l;s++)for(c=(o=y.cache[s].normalized).length,r=0;r<c;r++)a=o[r],i&&!a[y.columns].$row.is(i)||(p=!0,d=g?a.slice(0,y.columns):a[e],a=a[y.columns],u=g?a.raw:a.raw[e],h=g?a.$row.children():a.$row.children().eq(e),f&&(p=n({tbodyIndex:s,rowIndex:r,parsed:d,raw:u,$row:a.$row,$cell:h})),!1!==p&&(m.parsed[m.parsed.length]=d,m.raw[m.raw.length]=u,m.$cell[m.$cell.length]=h));return m}N.debug(y,"core")&&console.warn("No cache found - aborting getColumnText function!")},setHeadersCss:function(r){function t(t,e){t.removeClass(o).addClass(a[e]).attr("aria-sort",c[e]).find("."+N.css.icon).removeClass(l[2]).addClass(l[e])}var e,n,i=r.sortList,s=i.length,o=N.css.sortNone+" "+r.cssNone,a=[N.css.sortAsc+" "+r.cssAsc,N.css.sortDesc+" "+r.cssDesc],l=[r.cssIconAsc,r.cssIconDesc,r.cssIconNone],c=["ascending","descending"],u=r.$table.find("tfoot tr").children("td, th").add(E(r.namespace+"_extra_headers")).removeClass(a.join(" ")),d=r.$headers.add(E("thead "+r.namespace+"_extra_headers")).removeClass(a.join(" ")).addClass(o).attr("aria-sort","none").find("."+N.css.icon).removeClass(l.join(" ")).end();for(d.not(".sorter-false").find("."+N.css.icon).addClass(l[2]),r.cssIconDisabled&&d.filter(".sorter-false").find("."+N.css.icon).addClass(r.cssIconDisabled),e=0;e<s;e++)if(2!==i[e][1]){if((d=(d=r.$headers.filter(function(t){for(var e=!0,n=r.$headers.eq(t),i=parseInt(n.attr("data-column"),10),s=i+N.getClosest(n,"th, td")[0].colSpan;i<s;i++)e=!!e&&(e||-1<N.isValueInArray(i,r.sortList));return e})).not(".sorter-false").filter('[data-column="'+i[e][0]+'"]'+(1===s?":last":""))).length)for(n=0;n<d.length;n++)d[n].sortDisabled||t(d.eq(n),i[e][1]);u.length&&t(u.filter('[data-column="'+i[e][0]+'"]'),i[e][1])}for(s=r.$headers.length,e=0;e<s;e++)N.setColumnAriaLabel(r,r.$headers.eq(e))},getClosest:function(t,e){return E.fn.closest?t.closest(e):t.is(e)?t:t.parents(e).filter(":first")},setColumnAriaLabel:function(t,e,n){var i,s,r,o;e.length&&(i=parseInt(e.attr("data-column"),10),s=t.sortVars[i],r=e.hasClass(N.css.sortAsc)?"sortAsc":e.hasClass(N.css.sortDesc)?"sortDesc":"sortNone",o=E.trim(e.text())+": "+N.language[r],e.hasClass("sorter-false")||!1===n?o+=N.language.sortDisabled:(r=(s.count+1)%s.order.length,n=s.order[r],o+=N.language[0===n?"nextAsc":1===n?"nextDesc":"nextNone"]),e.attr("aria-label",o),s.sortedBy?e.attr("data-sortedBy",s.sortedBy):e.removeAttr("data-sortedBy"))},updateHeader:function(t){for(var e,n,i,s=t.table,r=t.$headers.length,o=0;o<r;o++)n=t.$headers.eq(o),i=N.getColumnData(s,t.headers,o,!0),e="false"===N.getData(n,i,"sorter")||"false"===N.getData(n,i,"parser"),N.setColumnSort(t,n,e)},setColumnSort:function(t,e,n){var i=t.table.id;e[0].sortDisabled=n,e[n?"addClass":"removeClass"]("sorter-false").attr("aria-disabled",""+n),t.tabIndex&&(n?e.removeAttr("tabindex"):e.attr("tabindex","0")),i&&(n?e.removeAttr("aria-controls"):e.attr("aria-controls",i))},updateHeaderSortCount:function(t,e){var n,i,s,r,o,a,l,c,u=e||t.sortList,d=u.length;for(t.sortList=[],r=0;r<d;r++)if(l=u[r],(n=parseInt(l[0],10))<t.columns){switch(t.sortVars[n].order||(c=N.getOrder(t.sortInitialOrder)?t.sortReset?[1,0,2]:[1,0]:t.sortReset?[0,1,2]:[0,1],t.sortVars[n].order=c,t.sortVars[n].count=0),c=t.sortVars[n].order,i=(i=(""+l[1]).match(/^(1|d|s|o|n)/))?i[0]:""){case"1":case"d":i=1;break;case"s":i=o||0;break;case"o":i=0===(a=c[(o||0)%c.length])?1:1===a?0:2;break;case"n":i=c[++t.sortVars[n].count%c.length];break;default:i=0}o=0===r?i:o,s=[n,parseInt(i,10)||0],t.sortList[t.sortList.length]=s,i=E.inArray(s[1],c),t.sortVars[n].count=0<=i?i:s[1]%c.length}},updateAll:function(t,e,n){var i=t.table;i.isUpdating=!0,N.refreshWidgets(i,!0,!0),N.buildHeaders(t),N.bindEvents(i,t.$headers,!0),N.bindMethods(t),N.commonUpdate(t,e,n)},update:function(t,e,n){t.table.isUpdating=!0,N.updateHeader(t),N.commonUpdate(t,e,n)},updateHeaders:function(t,e){t.table.isUpdating=!0,N.buildHeaders(t),N.bindEvents(t.table,t.$headers,!0),N.resortComplete(t,e)},updateCell:function(t,e,n,i){if(E(e).closest("tr").hasClass(t.cssChildRow))console.warn('Tablesorter Warning! "updateCell" for child row content has been disabled, use "update" instead');else{if(N.isEmptyObject(t.cache))return N.updateHeader(t),void N.commonUpdate(t,n,i);t.table.isUpdating=!0,t.$table.find(t.selectorRemove).remove();var s,r,o,a,l,c,u=t.$tbodies,d=E(e),h=u.index(N.getClosest(d,"tbody")),p=t.cache[h],f=N.getClosest(d,"tr");if(e=d[0],u.length&&0<=h){if(o=u.eq(h).find("tr").not("."+t.cssChildRow).index(f),l=p.normalized[o],(c=f[0].cells.length)!==t.columns)for(s=!1,r=a=0;r<c;r++)s||f[0].cells[r]===e?s=!0:a+=f[0].cells[r].colSpan;else a=d.index();s=N.getElementText(t,e,a),l[t.columns].raw[a]=s,s=N.getParsedText(t,e,a,s),l[a]=s,"numeric"===(t.parsers[a].type||"").toLowerCase()&&(p.colMax[a]=Math.max(Math.abs(s)||0,p.colMax[a]||0)),!1!==(s="undefined"!==n?n:t.resort)?N.checkResort(t,s,i):N.resortComplete(t,i)}else N.debug(t,"core")&&console.error("updateCell aborted, tbody missing or not within the indicated table"),t.table.isUpdating=!1}},addRows:function(t,e,n,i){var s,r,o,a,l,c,u,d,h,p,f,g,m,y="string"==typeof e&&1===t.$tbodies.length&&/<tr/.test(e||""),v=t.table;if(y)e=E(e),t.$tbodies.append(e);else if(!(e&&e instanceof E&&N.getClosest(e,"table")[0]===t.table))return N.debug(t,"core")&&console.error("addRows method requires (1) a jQuery selector reference to rows that have already been added to the table, or (2) row HTML string to be added to a table with only one tbody"),!1;if(v.isUpdating=!0,N.isEmptyObject(t.cache))N.updateHeader(t),N.commonUpdate(t,n,i);else{for(l=e.filter("tr").attr("role","row").length,o=t.$tbodies.index(e.parents("tbody").filter(":first")),t.parsers&&t.parsers.length||N.setupParsers(t),a=0;a<l;a++){for(h=0,u=e[a].cells.length,d=t.cache[o].normalized.length,f=[],p={child:[],raw:[],$row:e.eq(a),order:d},c=0;c<u;c++)g=e[a].cells[c],s=N.getElementText(t,g,h),p.raw[h]=s,r=N.getParsedText(t,g,h,s),f[h]=r,"numeric"===(t.parsers[h].type||"").toLowerCase()&&(t.cache[o].colMax[h]=Math.max(Math.abs(r)||0,t.cache[o].colMax[h]||0)),0<(m=g.colSpan-1)&&(h+=m),h++;f[t.columns]=p,t.cache[o].normalized[d]=f}N.checkResort(t,n,i)}},updateCache:function(t,e,n){t.parsers&&t.parsers.length||N.setupParsers(t,n),N.buildCache(t,e,n)},appendCache:function(t,e){var n,i,s,r,o,a,l,c=t.table,u=t.$tbodies,d=[],h=t.cache;if(N.isEmptyObject(h))return t.appender?t.appender(c,d):c.isUpdating?t.$table.triggerHandler("updateComplete",c):"";for(N.debug(t,"core")&&(l=new Date),a=0;a<u.length;a++)if((s=u.eq(a)).length){for(r=N.processTbody(c,s,!0),i=(n=h[a].normalized).length,o=0;o<i;o++)d[d.length]=n[o][t.columns].$row,t.appender&&(!t.pager||t.pager.removeRows||t.pager.ajax)||r.append(n[o][t.columns].$row);N.processTbody(c,r,!1)}t.appender&&t.appender(c,d),N.debug(t,"core")&&console.log("Rebuilt table"+N.benchmark(l)),e||t.appender||N.applyWidget(c),c.isUpdating&&t.$table.triggerHandler("updateComplete",c)},commonUpdate:function(t,e,n){t.$table.find(t.selectorRemove).remove(),N.setupParsers(t),N.buildCache(t),N.checkResort(t,e,n)},initSort:function(e,t,n){if(e.table.isUpdating)return setTimeout(function(){N.initSort(e,t,n)},50);var i,s,r,o,a,l,c,u=!n[e.sortMultiSortKey],d=e.table,h=e.$headers.length,p=N.getClosest(E(t),"th, td"),f=parseInt(p.attr("data-column"),10),g="mouseup"===n.type?"user":n.type,m=e.sortVars[f].order,p=p[0];if(e.$table.triggerHandler("sortStart",d),l=(e.sortVars[f].count+1)%m.length,e.sortVars[f].count=n[e.sortResetKey]?2:l,e.sortRestart)for(r=0;r<h;r++)c=e.$headers.eq(r),f!==(l=parseInt(c.attr("data-column"),10))&&(u||c.hasClass(N.css.sortNone))&&(e.sortVars[l].count=-1);if(u){if(E.each(e.sortVars,function(t){e.sortVars[t].sortedBy=""}),e.sortList=[],e.last.sortList=[],null!==e.sortForce)for(i=e.sortForce,s=0;s<i.length;s++)i[s][0]!==f&&(e.sortList[e.sortList.length]=i[s],e.sortVars[i[s][0]].sortedBy="sortForce");if((o=m[e.sortVars[f].count])<2&&(e.sortList[e.sortList.length]=[f,o],e.sortVars[f].sortedBy=g,1<p.colSpan))for(s=1;s<p.colSpan;s++)e.sortList[e.sortList.length]=[f+s,o],e.sortVars[f+s].count=E.inArray(o,m),e.sortVars[f+s].sortedBy=g}else if(e.sortList=E.extend([],e.last.sortList),0<=N.isValueInArray(f,e.sortList))for(e.sortVars[f].sortedBy=g,s=0;s<e.sortList.length;s++)(l=e.sortList[s])[0]===f&&(l[1]=m[e.sortVars[f].count],2===l[1]&&(e.sortList.splice(s,1),e.sortVars[f].count=-1));else if(o=m[e.sortVars[f].count],e.sortVars[f].sortedBy=g,o<2&&(e.sortList[e.sortList.length]=[f,o],1<p.colSpan))for(s=1;s<p.colSpan;s++)e.sortList[e.sortList.length]=[f+s,o],e.sortVars[f+s].count=E.inArray(o,m),e.sortVars[f+s].sortedBy=g;if(e.last.sortList=E.extend([],e.sortList),e.sortList.length&&e.sortAppend&&(i=E.isArray(e.sortAppend)?e.sortAppend:e.sortAppend[e.sortList[0][0]],!N.isEmptyObject(i)))for(s=0;s<i.length;s++)if(i[s][0]!==f&&N.isValueInArray(i[s][0],e.sortList)<0){if(a=(""+(o=i[s][1])).match(/^(a|d|s|o|n)/))switch(l=e.sortList[0][1],a[0]){case"d":o=1;break;case"s":o=l;break;case"o":o=0===l?1:0;break;case"n":o=(l+1)%m.length;break;default:o=0}e.sortList[e.sortList.length]=[i[s][0],o],e.sortVars[i[s][0]].sortedBy="sortAppend"}e.$table.triggerHandler("sortBegin",d),setTimeout(function(){N.setHeadersCss(e),N.multisort(e),N.appendCache(e),e.$table.triggerHandler("sortBeforeEnd",d),e.$table.triggerHandler("sortEnd",d)},1)},multisort:function(c){var t,e,u,n,d,h=c.table,p=[],f=c.textSorter||"",g=c.sortList,m=g.length,i=c.$tbodies.length;if(!c.serverSideSorting&&!N.isEmptyObject(c.cache)){if(N.debug(c,"core")&&(e=new Date),"object"==typeof f)for(u=c.columns;u--;)"function"==typeof(n=N.getColumnData(h,f,u))&&(p[u]=n);for(t=0;t<i;t++)u=c.cache[t].colMax,c.cache[t].normalized.sort(function(t,e){for(var n,i,s,r,o,a,l=0;l<m;l++){if(i=g[l][0],s=g[l][1],d=0===s,c.sortStable&&t[i]===e[i]&&1===m)return t[c.columns].order-e[c.columns].order;if(r=(n=/n/i.test(N.getSortType(c.parsers,i)))&&c.strings[i]?(n="boolean"==typeof N.string[c.strings[i]]?(d?1:-1)*(N.string[c.strings[i]]?-1:1):c.strings[i]&&N.string[c.strings[i]]||0,c.numberSorter?c.numberSorter(t[i],e[i],d,u[i],h):N["sortNumeric"+(d?"Asc":"Desc")](t[i],e[i],n,u[i],i,c)):(o=d?t:e,a=d?e:t,"function"==typeof f?f(o[i],a[i],d,i,h):"function"==typeof p[i]?p[i](o[i],a[i],d,i,h):N["sortNatural"+(d?"Asc":"Desc")](t[i]||"",e[i]||"",i,c)))return r}return t[c.columns].order-e[c.columns].order});N.debug(c,"core")&&console.log("Applying sort "+g.toString()+N.benchmark(e))}},resortComplete:function(t,e){t.table.isUpdating&&t.$table.triggerHandler("updateComplete",t.table),E.isFunction(e)&&e(t.table)},checkResort:function(t,e,n){var i=E.isArray(e)?e:t.sortList;!1===(void 0===e?t.resort:e)||t.serverSideSorting||t.table.isProcessing?(N.resortComplete(t,n),N.applyWidget(t.table,!1)):i.length?N.sortOn(t,i,function(){N.resortComplete(t,n)},!0):N.sortReset(t,function(){N.resortComplete(t,n),N.applyWidget(t.table,!1)})},sortOn:function(t,e,n,i){var s,r=t.table;for(t.$table.triggerHandler("sortStart",r),s=0;s<t.columns;s++)t.sortVars[s].sortedBy=-1<N.isValueInArray(s,e)?"sorton":"";N.updateHeaderSortCount(t,e),N.setHeadersCss(t),t.delayInit&&N.isEmptyObject(t.cache)&&N.buildCache(t),t.$table.triggerHandler("sortBegin",r),N.multisort(t),N.appendCache(t,i),t.$table.triggerHandler("sortBeforeEnd",r),t.$table.triggerHandler("sortEnd",r),N.applyWidget(r),E.isFunction(n)&&n(r)},sortReset:function(t,e){var n;for(t.sortList=[],n=0;n<t.columns;n++)t.sortVars[n].count=-1,t.sortVars[n].sortedBy="";N.setHeadersCss(t),N.multisort(t),N.appendCache(t),E.isFunction(e)&&e(t.table)},getSortType:function(t,e){return t&&t[e]&&t[e].type||""},getOrder:function(t){return/^d/i.test(t)||1===t},sortNatural:function(t,e){if(t===e)return 0;t=(t||"").toString(),e=(e||"").toString();var n,i,s,r,o,a,l=N.regex;if(l.hex.test(e)){if((n=parseInt(t.match(l.hex),16))<(i=parseInt(e.match(l.hex),16)))return-1;if(i<n)return 1}for(n=t.replace(l.chunk,"\\0$1\\0").replace(l.chunks,"").split("\\0"),i=e.replace(l.chunk,"\\0$1\\0").replace(l.chunks,"").split("\\0"),a=Math.max(n.length,i.length),o=0;o<a;o++){if(s=isNaN(n[o])?n[o]||0:parseFloat(n[o])||0,r=isNaN(i[o])?i[o]||0:parseFloat(i[o])||0,isNaN(s)!==isNaN(r))return isNaN(s)?1:-1;if(typeof s!=typeof r&&(s+="",r+=""),s<r)return-1;if(r<s)return 1}return 0},sortNaturalAsc:function(t,e,n,i){if(t===e)return 0;var s=N.string[i.empties[n]||i.emptyTo];return""===t&&0!==s?"boolean"==typeof s?s?-1:1:-s||-1:""===e&&0!==s?"boolean"==typeof s?s?1:-1:s||1:N.sortNatural(t,e)},sortNaturalDesc:function(t,e,n,i){if(t===e)return 0;var s=N.string[i.empties[n]||i.emptyTo];return""===t&&0!==s?"boolean"==typeof s?s?-1:1:s||1:""===e&&0!==s?"boolean"==typeof s?s?1:-1:-s||-1:N.sortNatural(e,t)},sortText:function(t,e){return e<t?1:t<e?-1:0},getTextValue:function(t,e,n){if(n){for(var i=t?t.length:0,s=n+e,r=0;r<i;r++)s+=t.charCodeAt(r);return e*s}return 0},sortNumericAsc:function(t,e,n,i,s,r){if(t===e)return 0;var o=N.string[r.empties[s]||r.emptyTo];return""===t&&0!==o?"boolean"==typeof o?o?-1:1:-o||-1:""===e&&0!==o?"boolean"==typeof o?o?1:-1:o||1:(isNaN(t)&&(t=N.getTextValue(t,n,i)),isNaN(e)&&(e=N.getTextValue(e,n,i)),t-e)},sortNumericDesc:function(t,e,n,i,s,r){if(t===e)return 0;var o=N.string[r.empties[s]||r.emptyTo];return""===t&&0!==o?"boolean"==typeof o?o?-1:1:o||1:""===e&&0!==o?"boolean"==typeof o?o?1:-1:-o||-1:(isNaN(t)&&(t=N.getTextValue(t,n,i)),isNaN(e)&&(e=N.getTextValue(e,n,i)),e-t)},sortNumeric:function(t,e){return t-e},addWidget:function(t){t.id&&!N.isEmptyObject(N.getWidgetById(t.id))&&console.warn('"'+t.id+'" widget was loaded more than once!'),N.widgets[N.widgets.length]=t},hasWidget:function(t,e){return(t=E(t)).length&&t[0].config&&t[0].config.widgetInit[e]||!1},getWidgetById:function(t){for(var e,n=N.widgets.length,i=0;i<n;i++)if((e=N.widgets[i])&&e.id&&e.id.toLowerCase()===t.toLowerCase())return e},applyWidgetOptions:function(t){var e,n,i,s=t.config,r=s.widgets.length;if(r)for(e=0;e<r;e++)(n=N.getWidgetById(s.widgets[e]))&&n.options&&(i=E.extend(!0,{},n.options),s.widgetOptions=E.extend(!0,i,s.widgetOptions),E.extend(!0,N.defaults.widgetOptions,n.options))},addWidgetFromClass:function(t){var e,n,i=t.config,s="^"+i.widgetClass.replace(N.regex.templateName,"(\\S+)+")+"$",r=new RegExp(s,"g"),o=(t.className||"").split(N.regex.spaces);if(o.length)for(e=o.length,n=0;n<e;n++)o[n].match(r)&&(i.widgets[i.widgets.length]=o[n].replace(r,"$1"))},applyWidgetId:function(t,e,n){var i,s,r,o=(t=E(t)[0]).config,a=o.widgetOptions,l=N.debug(o,"core"),c=N.getWidgetById(e);c&&(r=c.id,i=!1,E.inArray(r,o.widgets)<0&&(o.widgets[o.widgets.length]=r),l&&(s=new Date),!n&&o.widgetInit[r]||(o.widgetInit[r]=!0,t.hasInitialized&&N.applyWidgetOptions(t),"function"==typeof c.init&&(i=!0,l&&console[console.group?"group":"log"]("Initializing "+r+" widget"),c.init(t,c,o,a))),n||"function"!=typeof c.format||(i=!0,l&&console[console.group?"group":"log"]("Updating "+r+" widget"),c.format(t,o,a,!1)),l&&i&&(console.log("Completed "+(n?"initializing ":"applying ")+r+" widget"+N.benchmark(s)),console.groupEnd&&console.groupEnd()))},applyWidget:function(t,e,n){var i,s,r,o,a,l=(t=E(t)[0]).config,c=N.debug(l,"core"),u=[];if(!1===e||!t.hasInitialized||!t.isApplyingWidgets&&!t.isUpdating){if(c&&(a=new Date),N.addWidgetFromClass(t),clearTimeout(l.timerReady),l.widgets.length){for(t.isApplyingWidgets=!0,l.widgets=E.grep(l.widgets,function(t,e){return E.inArray(t,l.widgets)===e}),s=(r=l.widgets||[]).length,i=0;i<s;i++)(o=N.getWidgetById(r[i]))&&o.id?(o.priority||(o.priority=10),u[i]=o):c&&console.warn('"'+r[i]+'" was enabled, but the widget code has not been loaded!');for(u.sort(function(t,e){return t.priority<e.priority?-1:t.priority===e.priority?0:1}),s=u.length,c&&console[console.group?"group":"log"]("Start "+(e?"initializing":"applying")+" widgets"),i=0;i<s;i++)(o=u[i])&&o.id&&N.applyWidgetId(t,o.id,e);c&&console.groupEnd&&console.groupEnd()}l.timerReady=setTimeout(function(){t.isApplyingWidgets=!1,E.data(t,"lastWidgetApplication",new Date),l.$table.triggerHandler("tablesorter-ready"),e||"function"!=typeof n||n(t),c&&(o=l.widgets.length,console.log("Completed "+(!0===e?"initializing ":"applying ")+o+" widget"+(1!==o?"s":"")+N.benchmark(a)))},10)}},removeWidget:function(t,e,n){var i,s,r,o,a=(t=E(t)[0]).config;if(!0===e)for(e=[],o=N.widgets.length,r=0;r<o;r++)(s=N.widgets[r])&&s.id&&(e[e.length]=s.id);else e=(E.isArray(e)?e.join(","):e||"").toLowerCase().split(/[\s,]+/);for(o=e.length,i=0;i<o;i++)s=N.getWidgetById(e[i]),0<=(r=E.inArray(e[i],a.widgets))&&!0!==n&&a.widgets.splice(r,1),s&&s.remove&&(N.debug(a,"core")&&console.log((n?"Refreshing":"Removing")+' "'+e[i]+'" widget'),s.remove(t,a,a.widgetOptions,n),a.widgetInit[e[i]]=!1);a.$table.triggerHandler("widgetRemoveEnd",t)},refreshWidgets:function(t,e,n){for(var i,s=(t=E(t)[0]).config.widgets,r=N.widgets,o=r.length,a=[],l=function(t){E(t).triggerHandler("refreshComplete")},c=0;c<o;c++)(i=r[c])&&i.id&&(e||E.inArray(i.id,s)<0)&&(a[a.length]=i.id);N.removeWidget(t,a.join(","),!0),!0!==n?(N.applyWidget(t,e||!1,l),e&&N.applyWidget(t,!1,l)):l(t)},benchmark:function(t){return" ("+((new Date).getTime()-t.getTime())+" ms)"},log:function(){console.log(arguments)},debug:function(t,e){return t&&(!0===t.debug||"string"==typeof t.debug&&-1<t.debug.indexOf(e))},isEmptyObject:function(t){for(var e in t)return!1;return!0},isValueInArray:function(t,e){for(var n=e&&e.length||0,i=0;i<n;i++)if(e[i][0]===t)return i;return-1},formatFloat:function(t,e){return"string"!=typeof t||""===t?t:(t=(e&&e.config?!1!==e.config.usNumberFormat:void 0===e||e)?t.replace(N.regex.comma,""):t.replace(N.regex.digitNonUS,"").replace(N.regex.comma,"."),N.regex.digitNegativeTest.test(t)&&(t=t.replace(N.regex.digitNegativeReplace,"-$1")),n=parseFloat(t),isNaN(n)?E.trim(t):n);var n},isDigit:function(t){return isNaN(t)?N.regex.digitTest.test(t.toString().replace(N.regex.digitReplace,"")):""!==t},computeColumnIndex:function(t,e){for(var n,i,s,r,o,a,l,c,u,d=e&&e.columns||0,h=[],p=new Array(d),f=0;f<t.length;f++)for(o=t[f].cells,n=0;n<o.length;n++){for(a=f,l=(r=o[n]).rowSpan||1,c=r.colSpan||1,void 0===h[a]&&(h[a]=[]),i=0;i<h[a].length+1;i++)if(void 0===h[a][i]){u=i;break}for(d&&r.cellIndex===u||(r.setAttribute?r.setAttribute("data-column",u):E(r).attr("data-column",u)),i=a;i<a+l;i++)for(void 0===h[i]&&(h[i]=[]),p=h[i],s=u;s<u+c;s++)p[s]="x"}return N.checkColumnCount(t,h,p.length),p.length},checkColumnCount:function(t,e,n){for(var i,s=!0,r=[],o=0;o<e.length;o++)if(e[o]&&(i=e[o].length,e[o].length!==n)){s=!1;break}s||(t.each(function(t,e){var n=e.parentElement.nodeName;r.indexOf(n)<0&&r.push(n)}),console.error("Invalid or incorrect number of columns in the "+r.join(" or ")+"; expected "+n+", but found "+i+" columns"))},fixColumnWidth:function(t){var e,n,i,s,r,o=(t=E(t)[0]).config,a=o.$table.children("colgroup");if(a.length&&a.hasClass(N.css.colgroup)&&a.remove(),o.widthFixed&&0===o.$table.children("colgroup").length){for(a=E('<colgroup class="'+N.css.colgroup+'">'),e=o.$table.width(),s=(i=o.$tbodies.find("tr:first").children(":visible")).length,r=0;r<s;r++)n=parseInt(i.eq(r).width()/e*1e3,10)/10+"%",a.append(E("<col>").css("width",n));o.$table.prepend(a)}},getData:function(t,e,n){var i,s,r="",o=E(t);return o.length?(i=!!E.metadata&&o.metadata(),s=" "+(o.attr("class")||""),void 0!==o.data(n)||void 0!==o.data(n.toLowerCase())?r+=o.data(n)||o.data(n.toLowerCase()):i&&void 0!==i[n]?r+=i[n]:e&&void 0!==e[n]?r+=e[n]:" "!==s&&s.match(" "+n+"-")&&(r=s.match(new RegExp("\\s"+n+"-([\\w-]+)"))[1]||""),E.trim(r)):""},getColumnData:function(t,e,n,i,s){if("object"!=typeof e||null===e)return e;var r,o=(t=E(t)[0]).config,a=s||o.$headers,l=o.$headerIndexed&&o.$headerIndexed[n]||a.find('[data-column="'+n+'"]:last');if(void 0!==e[n])return i?e[n]:e[a.index(l)];for(r in e)if("string"==typeof r&&l.filter(r).add(l.find(r)).length)return e[r]},isProcessing:function(t,e,n){var i=(t=E(t))[0].config,s=n||t.find("."+N.css.header);e?(void 0!==n&&0<i.sortList.length&&(s=s.filter(function(){return!this.sortDisabled&&0<=N.isValueInArray(parseFloat(E(this).attr("data-column")),i.sortList)})),t.add(s).addClass(N.css.processing+" "+i.cssProcessing)):t.add(s).removeClass(N.css.processing+" "+i.cssProcessing)},processTbody:function(t,e,n){if(t=E(t)[0],n)return t.isProcessing=!0,e.before('<colgroup class="tablesorter-savemyplace"/>'),E.fn.detach?e.detach():e.remove();var i=E(t).find("colgroup.tablesorter-savemyplace");e.insertAfter(i),i.remove(),t.isProcessing=!1},clearTableBody:function(t){E(t)[0].config.$tbodies.children().detach()},characterEquivalents:{a:"áàâãäąå",A:"ÁÀÂÃÄĄÅ",c:"çćč",C:"ÇĆČ",e:"éèêëěę",E:"ÉÈÊËĚĘ",i:"íìİîïı",I:"ÍÌİÎÏ",o:"óòôõöō",O:"ÓÒÔÕÖŌ",ss:"ß",SS:"ẞ",u:"úùûüů",U:"ÚÙÛÜŮ"},replaceAccents:function(t){var e,n="[",i=N.characterEquivalents;if(!N.characterRegex){for(e in N.characterRegexArray={},i)"string"==typeof e&&(n+=i[e],N.characterRegexArray[e]=new RegExp("["+i[e]+"]","g"));N.characterRegex=new RegExp(n+"]")}if(N.characterRegex.test(t))for(e in i)"string"==typeof e&&(t=t.replace(N.characterRegexArray[e],e));return t},validateOptions:function(t){var e,n,i,s,r="headers sortForce sortList sortAppend widgets".split(" "),o=t.originalSettings;if(o){for(e in N.debug(t,"core")&&(s=new Date),o)if("undefined"===(i=typeof N.defaults[e]))console.warn('Tablesorter Warning! "table.config.'+e+'" option not recognized');else if("object"===i)for(n in o[e])i=N.defaults[e]&&typeof N.defaults[e][n],E.inArray(e,r)<0&&"undefined"===i&&console.warn('Tablesorter Warning! "table.config.'+e+"."+n+'" option not recognized');N.debug(t,"core")&&console.log("validate options time:"+N.benchmark(s))}},restoreHeaders:function(t){for(var e,n=E(t)[0].config,i=n.$table.find(n.selectorHeaders),s=i.length,r=0;r<s;r++)(e=i.eq(r)).find("."+N.css.headerIn).length&&e.html(n.headerContent[r])},destroy:function(t,e,n){var i,s,r,o,a,l;(t=E(t)[0]).hasInitialized&&(N.removeWidget(t,!0,!1),s=E(t),r=t.config,a=(o=s.find("thead:first")).find("tr."+N.css.headerRow).removeClass(N.css.headerRow+" "+r.cssHeaderRow),l=s.find("tfoot:first > tr").children("th, td"),!1===e&&0<=E.inArray("uitheme",r.widgets)&&(s.triggerHandler("applyWidgetId",["uitheme"]),s.triggerHandler("applyWidgetId",["zebra"])),o.find("tr").not(a).remove(),i="sortReset update updateRows updateAll updateHeaders updateCell addRows updateComplete sorton appendCache updateCache applyWidgetId applyWidgets refreshWidgets removeWidget destroy mouseup mouseleave "+"keypress sortBegin sortEnd resetToLoadState ".split(" ").join(r.namespace+" "),s.removeData("tablesorter").unbind(i.replace(N.regex.spaces," ")),r.$headers.add(l).removeClass([N.css.header,r.cssHeader,r.cssAsc,r.cssDesc,N.css.sortAsc,N.css.sortDesc,N.css.sortNone].join(" ")).removeAttr("data-column").removeAttr("aria-label").attr("aria-disabled","true"),a.find(r.selectorSort).unbind("mousedown mouseup keypress ".split(" ").join(r.namespace+" ").replace(N.regex.spaces," ")),N.restoreHeaders(t),s.toggleClass(N.css.table+" "+r.tableClass+" tablesorter-"+r.theme,!1===e),s.removeClass(r.namespace.slice(1)),t.hasInitialized=!1,delete t.config.cache,"function"==typeof n&&n(t),N.debug(r,"core")&&console.log("tablesorter has been removed"))}};E.fn.tablesorter=function(e){return this.each(function(){var t=E.extend(!0,{},N.defaults,e,N.instanceMethods);t.originalSettings=e,!this.hasInitialized&&N.buildTable&&"TABLE"!==this.nodeName?N.buildTable(this,t):N.setup(this,t)})},window.console&&window.console.log||(N.logs=[],console={},console.log=console.warn=console.error=console.table=function(){var t=1<arguments.length?arguments:arguments[0];N.logs[N.logs.length]={date:Date.now(),log:t}}),N.addParser({id:"no-parser",is:function(){return!1},format:function(){return""},type:"text"}),N.addParser({id:"text",is:function(){return!0},format:function(t,e){var n=e.config;return t&&(t=E.trim(n.ignoreCase?t.toLocaleLowerCase():t),t=n.sortLocaleCompare?N.replaceAccents(t):t),t},type:"text"}),N.regex.nondigit=/[^\w,. \-()]/g,N.addParser({id:"digit",is:function(t){return N.isDigit(t)},format:function(t,e){var n=N.formatFloat((t||"").replace(N.regex.nondigit,""),e);return t&&"number"==typeof n?n:t?E.trim(t&&e.config.ignoreCase?t.toLocaleLowerCase():t):t},type:"numeric"}),N.regex.currencyReplace=/[+\-,. ]/g,N.regex.currencyTest=/^\(?\d+[\u00a3$\u20ac\u00a4\u00a5\u00a2?.]|[\u00a3$\u20ac\u00a4\u00a5\u00a2?.]\d+\)?$/,N.addParser({id:"currency",is:function(t){return t=(t||"").replace(N.regex.currencyReplace,""),N.regex.currencyTest.test(t)},format:function(t,e){var n=N.formatFloat((t||"").replace(N.regex.nondigit,""),e);return t&&"number"==typeof n?n:t?E.trim(t&&e.config.ignoreCase?t.toLocaleLowerCase():t):t},type:"numeric"}),N.regex.urlProtocolTest=/^(https?|ftp|file):\/\//,N.regex.urlProtocolReplace=/(https?|ftp|file):\/\/(www\.)?/,N.addParser({id:"url",is:function(t){return N.regex.urlProtocolTest.test(t)},format:function(t){return t?E.trim(t.replace(N.regex.urlProtocolReplace,"")):t},type:"text"}),N.regex.dash=/-/g,N.regex.isoDate=/^\d{4}[\/\-]\d{1,2}[\/\-]\d{1,2}/,N.addParser({id:"isoDate",is:function(t){return N.regex.isoDate.test(t)},format:function(t){var e=t?new Date(t.replace(N.regex.dash,"/")):t;return e instanceof Date&&isFinite(e)?e.getTime():t},type:"numeric"}),N.regex.percent=/%/g,N.regex.percentTest=/(\d\s*?%|%\s*?\d)/,N.addParser({id:"percent",is:function(t){return N.regex.percentTest.test(t)&&t.length<15},format:function(t,e){return t?N.formatFloat(t.replace(N.regex.percent,""),e):t},type:"numeric"}),N.addParser({id:"image",is:function(t,e,n,i){return 0<i.find("img").length},format:function(t,e,n){return E(n).find("img").attr(e.config.imgAttr||"alt")||t},parsed:!0,type:"text"}),N.regex.dateReplace=/(\S)([AP]M)$/i,N.regex.usLongDateTest1=/^[A-Z]{3,10}\.?\s+\d{1,2},?\s+(\d{4})(\s+\d{1,2}:\d{2}(:\d{2})?(\s+[AP]M)?)?$/i,N.regex.usLongDateTest2=/^\d{1,2}\s+[A-Z]{3,10}\s+\d{4}/i,N.addParser({id:"usLongDate",is:function(t){return N.regex.usLongDateTest1.test(t)||N.regex.usLongDateTest2.test(t)},format:function(t){var e=t?new Date(t.replace(N.regex.dateReplace,"$1 $2")):t;return e instanceof Date&&isFinite(e)?e.getTime():t},type:"numeric"}),N.regex.shortDateTest=/(^\d{1,2}[\/\s]\d{1,2}[\/\s]\d{4})|(^\d{4}[\/\s]\d{1,2}[\/\s]\d{1,2})/,N.regex.shortDateReplace=/[\-.,]/g,N.regex.shortDateXXY=/(\d{1,2})[\/\s](\d{1,2})[\/\s](\d{4})/,N.regex.shortDateYMD=/(\d{4})[\/\s](\d{1,2})[\/\s](\d{1,2})/,N.convertFormat=function(t,e){t=(t||"").replace(N.regex.spaces," ").replace(N.regex.shortDateReplace,"/"),"mmddyyyy"===e?t=t.replace(N.regex.shortDateXXY,"$3/$1/$2"):"ddmmyyyy"===e?t=t.replace(N.regex.shortDateXXY,"$3/$2/$1"):"yyyymmdd"===e&&(t=t.replace(N.regex.shortDateYMD,"$1/$2/$3"));var n=new Date(t);return n instanceof Date&&isFinite(n)?n.getTime():""},N.addParser({id:"shortDate",is:function(t){return t=(t||"").replace(N.regex.spaces," ").replace(N.regex.shortDateReplace,"/"),N.regex.shortDateTest.test(t)},format:function(t,e,n,i){if(t){var s=e.config,r=s.$headerIndexed[i],o=r.length&&r.data("dateFormat")||N.getData(r,N.getColumnData(e,s.headers,i),"dateFormat")||s.dateFormat;return r.length&&r.data("dateFormat",o),N.convertFormat(t,o)||t}return t},type:"numeric"}),N.regex.timeTest=/^(0?[1-9]|1[0-2]):([0-5]\d)(\s[AP]M)$|^((?:[01]\d|[2][0-4]):[0-5]\d)$/i,N.regex.timeMatch=/(0?[1-9]|1[0-2]):([0-5]\d)(\s[AP]M)|((?:[01]\d|[2][0-4]):[0-5]\d)/i,N.addParser({id:"time",is:function(t){return N.regex.timeTest.test(t)},format:function(t){var e=(t||"").match(N.regex.timeMatch),n=new Date(t),i=t&&(null!==e?e[0]:"00:00 AM"),s=i?new Date("2000/01/01 "+i.replace(N.regex.dateReplace,"$1 $2")):i;return s instanceof Date&&isFinite(s)?(n instanceof Date&&isFinite(n)?n.getTime():0)?parseFloat(s.getTime()+"."+n.getTime()):s.getTime():t},type:"numeric"}),N.addParser({id:"metadata",is:function(){return!1},format:function(t,e,n){var i=e.config,s=i.parserMetadataName?i.parserMetadataName:"sortValue";return E(n).metadata()[s]},type:"numeric"}),N.addWidget({id:"zebra",priority:90,format:function(t,e,n){for(var i,s,r,o,a,l,c=new RegExp(e.cssChildRow,"i"),u=e.$tbodies.add(E(e.namespace+"_extra_table").children("tbody:not(."+e.cssInfoBlock+")")),d=0;d<u.length;d++)for(r=0,l=(i=u.eq(d).children("tr:visible").not(e.selectorRemove)).length,a=0;a<l;a++)s=i.eq(a),c.test(s[0].className)||r++,o=r%2==0,s.removeClass(n.zebra[o?1:0]).addClass(n.zebra[o?0:1])},remove:function(t,e,n,i){if(!i)for(var s,r=e.$tbodies,o=(n.zebra||["even","odd"]).join(" "),a=0;a<r.length;a++)(s=N.processTbody(t,r.eq(a),!0)).children().removeClass(o),N.processTbody(t,s,!1)}})}(t),t.tablesorter}),function(t){"function"==typeof define&&define.amd?define(["jquery"],t):"object"==typeof exports?module.exports=t(require("jquery")):t(jQuery)}(function(i,s){"use strict";var r="drilldown",o="data-next-parent",a={event:"click",selector:"a",speed:100,cssClass:{container:r+"-container",root:r+"-root",sub:r+"-sub",back:r+"-back"}},l=(t.prototype={destroy:function(){this.reset(),this.$element.off(this.options.event+"."+r,this.options.selector)},reset:function(){for(var t=this._history.length;0<t;t--)c.call(this,{speed:0});this._history=[],this._css={float:"left",width:null}}},t);function t(t,e){var n=this;this._name=r,this._defaults=a,this.element=t,this.$element=i(t),this.options=i.extend({},a,e),this._history=[],this._css={float:"left",width:null},this.$container=this.$element.find("."+this.options.cssClass.container),this.$element.on(this.options.event+"."+r,this.options.selector,function(t){(function(t,e){var n=e.nextAll("."+this.options.cssClass.sub),i=!0;n.length?function(e,t){var n=t&&t.speed!==s?t.speed:this.options.speed;if(!e.length)return;this._css.width=this.$element.outerWidth(),this.$container.width(2*this._css.width),e.parent().attr(o,!0),e=e.removeClass(this.options.cssClass.sub).addClass(this.options.cssClass.root),this.$container.append(e),u.call(this,{marginLeft:-1*this._css.width,speed:n},function(){var t=e.prev();this._history.push(t.detach()),d.call(this,e)}.bind(this))}.call(this,n):e.closest("."+this.options.cssClass.back).length?c.call(this):i=!1;i&&"A"===e.prop("tagName")&&t.preventDefault()}).call(n,t,i(this))})}function c(t){var e=t&&t.speed!==s?t.speed:this.options.speed,n=this._history.pop();this._css.width=this.$element.outerWidth(),this.$container.width(2*this._css.width),this.$container.prepend(n),u.call(this,{marginLeft:0,speed:e},function(){var t=n.next();t.addClass(this.options.cssClass.sub).removeClass(this.options.cssClass.root),this.$container.find("["+o+"]").last().removeAttr(o).append(t),d.call(this,n)}.bind(this))}function u(t,e){var n=this.$container.children("."+this.options.cssClass.root);n.css(this._css),n.first().animate({marginLeft:t.marginLeft},t.speed,e)}function d(t){t.css({float:"",width:"",marginLeft:""}),this.$container.css("width","")}i.fn[r]=function(n){return this.each(function(){var t=i.data(this,r),e=n;t?"string"==typeof e&&("destroy"===e&&i.removeData(this,r),"function"==typeof t[e]&&t[e]()):i.data(this,r,new l(this,n))})}}),function(s,r,o,a){function l(){var t=s(this);t[a]()||(t.addClass(r),"password"===t.attr("type")&&(t.attr("type","text"),t.data(r+"-pwd",!0)),t[a](t.attr(o)))}function c(){var t=s(this);t.removeClass(r),t.data(r+"-pwd")&&t.attr("type","password"),t[a]()===t.attr(o)&&t[a]("")}function e(){s(this).find("["+o+"]").each(function(){s(this).data(r)&&c.call(this)})}s.fn.placeholdr=function(){return o in document.createElement("input")||(s(this).find("["+o+"]").each(function(){var t=s(this);t.data(r)||(t.data(r,!0),l.call(this),t.focus(c),t.blur(l))}),s(this).find("form").each(function(){var t=s(this);t.data(r)||(t.data(r,!0),t.submit(e))})),this},s.fn[a]=s.fn.val,s.fn.val=function(t){var e=s(this);if("undefined"===s.type(t)&&e.data(r)&&e[a]()===e.attr(o))return"";var n="string"===s.type(t);n&&c.call(this);var i=s.fn[a].apply(this,arguments);return n&&!t&&l.call(this),i},s(function(){s(document).placeholdr()}),document.write("<style>.placeholdr{color:#AAA;}</style>")}(jQuery,"placeholdr","placeholder","placeholdrVal"),function(t){"use strict";"function"==typeof define&&define.amd?define(["./blueimp-helper"],t):(window.blueimp=window.blueimp||{},window.blueimp.Gallery=t(window.blueimp.helper||window.jQuery))}(function(u){"use strict";function n(t,e){return void 0===document.body.style.maxHeight?null:this&&this.options===n.prototype.options?void(t&&t.length?(this.list=t,this.num=t.length,this.initOptions(e),this.initialize()):this.console.log("blueimp Gallery: No or empty list provided as first argument.",t)):new n(t,e)}return u.extend(n.prototype,{options:{container:"#blueimp-gallery",slidesContainer:"div",titleElement:"h3",displayClass:"blueimp-gallery-display",controlsClass:"blueimp-gallery-controls",singleClass:"blueimp-gallery-single",leftEdgeClass:"blueimp-gallery-left",rightEdgeClass:"blueimp-gallery-right",playingClass:"blueimp-gallery-playing",slideClass:"slide",slideLoadingClass:"slide-loading",slideErrorClass:"slide-error",slideContentClass:"slide-content",toggleClass:"toggle",prevClass:"prev",nextClass:"next",closeClass:"close",playPauseClass:"play-pause",typeProperty:"type",titleProperty:"title",altTextProperty:"alt",urlProperty:"href",srcsetProperty:"urlset",displayTransition:!0,clearSlides:!0,stretchImages:!1,toggleControlsOnReturn:!0,toggleControlsOnSlideClick:!0,toggleSlideshowOnSpace:!0,enableKeyboardNavigation:!0,closeOnEscape:!0,closeOnSlideClick:!0,closeOnSwipeUpOrDown:!0,closeOnHashChange:!0,emulateTouchEvents:!0,stopTouchEventsPropagation:!1,hidePageScrollbars:!0,disableScroll:!0,carousel:!1,continuous:!0,unloadElements:!0,startSlideshow:!1,slideshowInterval:5e3,slideshowDirection:"ltr",index:0,preloadRange:2,transitionDuration:300,slideshowTransitionDuration:500,event:void 0,onopen:void 0,onopened:void 0,onslide:void 0,onslideend:void 0,onslidecomplete:void 0,onclose:void 0,onclosed:void 0},carouselOptions:{hidePageScrollbars:!1,toggleControlsOnReturn:!1,toggleSlideshowOnSpace:!1,enableKeyboardNavigation:!1,closeOnEscape:!1,closeOnSlideClick:!1,closeOnSwipeUpOrDown:!1,disableScroll:!1,startSlideshow:!0},console:window.console&&"function"==typeof window.console.log?window.console:{log:function(){}},support:function(i){var t,s={touch:void 0!==window.ontouchstart||window.DocumentTouch&&document instanceof DocumentTouch},e={webkitTransition:{end:"webkitTransitionEnd",prefix:"-webkit-"},MozTransition:{end:"transitionend",prefix:"-moz-"},OTransition:{end:"otransitionend",prefix:"-o-"},transition:{end:"transitionend",prefix:""}};for(t in e)if(Object.prototype.hasOwnProperty.call(e,t)&&void 0!==i.style[t]){s.transition=e[t],s.transition.name=t;break}function n(){var t,e,n=s.transition;document.body.appendChild(i),n&&(t=n.name.slice(0,-9)+"ransform",void 0!==i.style[t]&&(i.style[t]="translateZ(0)",e=window.getComputedStyle(i).getPropertyValue(n.prefix+"transform"),s.transform={prefix:n.prefix,name:t,translate:!0,translateZ:!!e&&"none"!==e})),void 0!==i.style.backgroundSize&&(s.backgroundSize={},i.style.backgroundSize="contain",s.backgroundSize.contain="contain"===window.getComputedStyle(i).getPropertyValue("background-size"),i.style.backgroundSize="cover",s.backgroundSize.cover="cover"===window.getComputedStyle(i).getPropertyValue("background-size")),document.body.removeChild(i)}return document.body?n():u(document).on("DOMContentLoaded",n),s}(document.createElement("div")),requestAnimationFrame:window.requestAnimationFrame||window.webkitRequestAnimationFrame||window.mozRequestAnimationFrame,cancelAnimationFrame:window.cancelAnimationFrame||window.webkitCancelRequestAnimationFrame||window.webkitCancelAnimationFrame||window.mozCancelAnimationFrame,initialize:function(){if(this.initStartIndex(),!1===this.initWidget())return!1;this.initEventListeners(),this.onslide(this.index),this.ontransitionend(),this.options.startSlideshow&&this.play()},slide:function(t,e){window.clearTimeout(this.timeout);var n,i,s,r=this.index;if(r!==t&&1!==this.num){if(e=e||this.options.transitionDuration,this.support.transform){for(this.options.continuous||(t=this.circle(t)),n=Math.abs(r-t)/(r-t),this.options.continuous&&(i=n,(n=-this.positions[this.circle(t)]/this.slideWidth)!==i&&(t=-n*this.num+t)),s=Math.abs(r-t)-1;s;)--s,this.move(this.circle((r<t?t:r)-s-1),this.slideWidth*n,0);t=this.circle(t),this.move(r,this.slideWidth*n,e),this.move(t,0,e),this.options.continuous&&this.move(this.circle(t-n),-this.slideWidth*n,0)}else t=this.circle(t),this.animate(r*-this.slideWidth,t*-this.slideWidth,e);this.onslide(t)}},getIndex:function(){return this.index},getNumber:function(){return this.num},prev:function(){(this.options.continuous||this.index)&&this.slide(this.index-1)},next:function(){(this.options.continuous||this.index<this.num-1)&&this.slide(this.index+1)},play:function(t){var n=this,e=this.index+("rtl"===this.options.slideshowDirection?-1:1);window.clearTimeout(this.timeout),this.interval=t||this.options.slideshowInterval,1<this.elements[this.index]&&(this.timeout=this.setTimeout(!this.requestAnimationFrame&&this.slide||function(t,e){n.animationFrameId=n.requestAnimationFrame.call(window,function(){n.slide(t,e)})},[e,this.options.slideshowTransitionDuration],this.interval)),this.container.addClass(this.options.playingClass)},pause:function(){window.clearTimeout(this.timeout),this.interval=null,this.cancelAnimationFrame&&(this.cancelAnimationFrame.call(window,this.animationFrameId),this.animationFrameId=null),this.container.removeClass(this.options.playingClass)},add:function(t){var e;for(t.concat||(t=Array.prototype.slice.call(t)),this.list.concat||(this.list=Array.prototype.slice.call(this.list)),this.list=this.list.concat(t),this.num=this.list.length,2<this.num&&null===this.options.continuous&&(this.options.continuous=!0,this.container.removeClass(this.options.leftEdgeClass)),this.container.removeClass(this.options.rightEdgeClass).removeClass(this.options.singleClass),e=this.num-t.length;e<this.num;e+=1)this.addSlide(e),this.positionSlide(e);this.positions.length=this.num,this.initSlides(!0)},resetSlides:function(){this.slidesContainer.empty(),this.unloadAllSlides(),this.slides=[]},handleClose:function(){var t=this.options;this.destroyEventListeners(),this.pause(),this.container[0].style.display="none",this.container.removeClass(t.displayClass).removeClass(t.singleClass).removeClass(t.leftEdgeClass).removeClass(t.rightEdgeClass),t.hidePageScrollbars&&(document.body.style.overflow=this.bodyOverflowStyle),this.options.clearSlides&&this.resetSlides(),this.options.onclosed&&this.options.onclosed.call(this)},close:function(){var n=this;this.options.onclose&&this.options.onclose.call(this),this.support.transition&&this.options.displayTransition?(this.container.on(this.support.transition.end,function t(e){e.target===n.container[0]&&(n.container.off(n.support.transition.end,t),n.handleClose())}),this.container.removeClass(this.options.displayClass)):this.handleClose()},circle:function(t){return(this.num+t%this.num)%this.num},move:function(t,e,n){this.translateX(t,e,n),this.positions[t]=e},translate:function(t,e,n,i){var s,r,o;this.slides[t]&&(s=this.slides[t].style,r=this.support.transition,o=this.support.transform,s[r.name+"Duration"]=i+"ms",s[o.name]="translate("+e+"px, "+n+"px)"+(o.translateZ?" translateZ(0)":""))},translateX:function(t,e,n){this.translate(t,e,0,n)},translateY:function(t,e,n){this.translate(t,0,e,n)},animate:function(e,n,i){var s,r,o;i?(s=this,r=(new Date).getTime(),o=window.setInterval(function(){var t=(new Date).getTime()-r;if(i<t)return s.slidesContainer[0].style.left=n+"px",s.ontransitionend(),void window.clearInterval(o);s.slidesContainer[0].style.left=(n-e)*(Math.floor(t/i*100)/100)+e+"px"},4)):this.slidesContainer[0].style.left=n+"px"},preventDefault:function(t){t.preventDefault?t.preventDefault():t.returnValue=!1},stopPropagation:function(t){t.stopPropagation?t.stopPropagation():t.cancelBubble=!0},onresize:function(){this.initSlides(!0)},onhashchange:function(){this.options.closeOnHashChange&&this.close()},onmousedown:function(t){t.which&&1===t.which&&"VIDEO"!==t.target.nodeName&&"AUDIO"!==t.target.nodeName&&(t.preventDefault(),(t.originalEvent||t).touches=[{pageX:t.pageX,pageY:t.pageY}],this.ontouchstart(t))},onmousemove:function(t){this.touchStart&&((t.originalEvent||t).touches=[{pageX:t.pageX,pageY:t.pageY}],this.ontouchmove(t))},onmouseup:function(t){this.touchStart&&(this.ontouchend(t),delete this.touchStart)},onmouseout:function(t){var e,n;this.touchStart&&(e=t.target,(n=t.relatedTarget)&&(n===e||u.contains(e,n))||this.onmouseup(t))},ontouchstart:function(t){this.options.stopTouchEventsPropagation&&this.stopPropagation(t);var e=(t.originalEvent||t).touches[0];this.touchStart={x:e.pageX,y:e.pageY,time:Date.now()},this.isScrolling=void 0,this.touchDelta={}},ontouchmove:function(t){this.options.stopTouchEventsPropagation&&this.stopPropagation(t);var e,n,i=(t.originalEvent||t).touches,s=i[0],r=(t.originalEvent||t).scale,o=this.index;if(!(1<i.length||r&&1!==r))if(this.options.disableScroll&&t.preventDefault(),this.touchDelta={x:s.pageX-this.touchStart.x,y:s.pageY-this.touchStart.y},e=this.touchDelta.x,void 0===this.isScrolling&&(this.isScrolling=this.isScrolling||Math.abs(e)<Math.abs(this.touchDelta.y)),this.isScrolling)this.options.carousel||this.translateY(o,this.touchDelta.y+this.positions[o],0);else for(t.preventDefault(),window.clearTimeout(this.timeout),this.options.continuous?n=[this.circle(o+1),o,this.circle(o-1)]:(this.touchDelta.x=e/=!o&&0<e||o===this.num-1&&e<0?Math.abs(e)/this.slideWidth+1:1,n=[o],o&&n.push(o-1),o<this.num-1&&n.unshift(o+1));n.length;)o=n.pop(),this.translateX(o,e+this.positions[o],0)},ontouchend:function(t){this.options.stopTouchEventsPropagation&&this.stopPropagation(t);var e,n,i,s,r,o=this.index,a=Math.abs(this.touchDelta.x),l=this.slideWidth,c=Math.ceil(this.options.transitionDuration*(1-a/l)/2),u=20<a,d=!o&&0<this.touchDelta.x||o===this.num-1&&this.touchDelta.x<0,h=!u&&this.options.closeOnSwipeUpOrDown&&20<Math.abs(this.touchDelta.y);this.options.continuous&&(d=!1),e=this.touchDelta.x<0?-1:1,this.isScrolling?h?this.close():this.translateY(o,0,c):u&&!d?(n=o+e,i=o-e,s=l*e,r=-l*e,this.options.continuous?(this.move(this.circle(n),s,0),this.move(this.circle(o-2*e),r,0)):0<=n&&n<this.num&&this.move(n,s,0),this.move(o,this.positions[o]+s,c),this.move(this.circle(i),this.positions[this.circle(i)]+s,c),o=this.circle(i),this.onslide(o)):this.options.continuous?(this.move(this.circle(o-1),-l,c),this.move(o,0,c),this.move(this.circle(o+1),l,c)):(o&&this.move(o-1,-l,c),this.move(o,0,c),o<this.num-1&&this.move(o+1,l,c))},ontouchcancel:function(t){this.touchStart&&(this.ontouchend(t),delete this.touchStart)},ontransitionend:function(t){var e=this.slides[this.index];t&&e!==t.target||(this.interval&&this.play(),this.setTimeout(this.options.onslideend,[this.index,e]))},oncomplete:function(t){var e,n=t.target||t.srcElement,i=n&&n.parentNode;n&&i&&(e=this.getNodeIndex(i),u(i).removeClass(this.options.slideLoadingClass),"error"===t.type?(u(i).addClass(this.options.slideErrorClass),this.elements[e]=3):this.elements[e]=2,n.clientHeight>this.container[0].clientHeight&&(n.style.maxHeight=this.container[0].clientHeight),this.interval&&this.slides[this.index]===i&&this.play(),this.setTimeout(this.options.onslidecomplete,[e,i]))},onload:function(t){this.oncomplete(t)},onerror:function(t){this.oncomplete(t)},onkeydown:function(t){switch(t.which||t.keyCode){case 13:this.options.toggleControlsOnReturn&&(this.preventDefault(t),this.toggleControls());break;case 27:this.options.closeOnEscape&&(this.close(),t.stopImmediatePropagation());break;case 32:this.options.toggleSlideshowOnSpace&&(this.preventDefault(t),this.toggleSlideshow());break;case 37:this.options.enableKeyboardNavigation&&(this.preventDefault(t),this.prev());break;case 39:this.options.enableKeyboardNavigation&&(this.preventDefault(t),this.next())}},handleClick:function(t){var e=this.options,n=t.target||t.srcElement,i=n.parentNode;function s(t){return u(n).hasClass(t)||u(i).hasClass(t)}s(e.toggleClass)?(this.preventDefault(t),this.toggleControls()):s(e.prevClass)?(this.preventDefault(t),this.prev()):s(e.nextClass)?(this.preventDefault(t),this.next()):s(e.closeClass)?(this.preventDefault(t),this.close()):s(e.playPauseClass)?(this.preventDefault(t),this.toggleSlideshow()):i===this.slidesContainer[0]?e.closeOnSlideClick?(this.preventDefault(t),this.close()):e.toggleControlsOnSlideClick&&(this.preventDefault(t),this.toggleControls()):i.parentNode&&i.parentNode===this.slidesContainer[0]&&e.toggleControlsOnSlideClick&&(this.preventDefault(t),this.toggleControls())},onclick:function(t){if(!(this.options.emulateTouchEvents&&this.touchDelta&&(20<Math.abs(this.touchDelta.x)||20<Math.abs(this.touchDelta.y))))return this.handleClick(t);delete this.touchDelta},updateEdgeClasses:function(t){t?this.container.removeClass(this.options.leftEdgeClass):this.container.addClass(this.options.leftEdgeClass),t===this.num-1?this.container.addClass(this.options.rightEdgeClass):this.container.removeClass(this.options.rightEdgeClass)},handleSlide:function(t){this.options.continuous||this.updateEdgeClasses(t),this.loadElements(t),this.options.unloadElements&&this.unloadElements(t),this.setTitle(t)},onslide:function(t){this.index=t,this.handleSlide(t),this.setTimeout(this.options.onslide,[t,this.slides[t]])},setTitle:function(t){var e=this.slides[t].firstChild,n=e.title||e.alt,i=this.titleElement;i.length&&(this.titleElement.empty(),n&&i[0].appendChild(document.createTextNode(n)))},setTimeout:function(t,e,n){var i=this;return t&&window.setTimeout(function(){t.apply(i,e||[])},n||0)},imageFactory:function(t,n){var i,s,e,r,o=this,a=this.imagePrototype.cloneNode(!1),l=t,c=this.options.stretchImages;return"string"!=typeof l&&(l=this.getItemProperty(t,this.options.urlProperty),e=this.getItemProperty(t,this.options.titleProperty),r=this.getItemProperty(t,this.options.altTextProperty)||e),!0===c&&(c="contain"),(c=this.support.backgroundSize&&this.support.backgroundSize[c]&&c)?s=this.elementPrototype.cloneNode(!1):(s=a).draggable=!1,e&&(s.title=e),r&&(s.alt=r),u(a).on("load error",function t(e){if(!i){if(e={type:e.type,target:s},!s.parentNode)return o.setTimeout(t,[e]);i=!0,u(a).off("load error",t),c&&"load"===e.type&&(s.style.background='url("'+l+'") center no-repeat',s.style.backgroundSize=c),n(e)}}),a.src=l,s},createElement:function(t,e){var n=t&&this.getItemProperty(t,this.options.typeProperty),i=n&&this[n.split("/")[0]+"Factory"]||this.imageFactory,s=t&&i.call(this,t,e),r=this.getItemProperty(t,this.options.srcsetProperty);return s||(s=this.elementPrototype.cloneNode(!1),this.setTimeout(e,[{type:"error",target:s}])),r&&s.setAttribute("srcset",r),u(s).addClass(this.options.slideContentClass),s},loadElement:function(t){this.elements[t]||(this.slides[t].firstChild?this.elements[t]=u(this.slides[t]).hasClass(this.options.slideErrorClass)?3:2:(this.elements[t]=1,u(this.slides[t]).addClass(this.options.slideLoadingClass),this.slides[t].appendChild(this.createElement(this.list[t],this.proxyListener))))},loadElements:function(t){for(var e=Math.min(this.num,2*this.options.preloadRange+1),n=t,i=0;i<e;i+=1)n+=i*(i%2==0?-1:1),n=this.circle(n),this.loadElement(n)},unloadElements:function(t){var e,n;for(e in this.elements)Object.prototype.hasOwnProperty.call(this.elements,e)&&(n=Math.abs(t-e))>this.options.preloadRange&&n+this.options.preloadRange<this.num&&(this.unloadSlide(e),delete this.elements[e])},addSlide:function(t){var e=this.slidePrototype.cloneNode(!1);e.setAttribute("data-index",t),this.slidesContainer[0].appendChild(e),this.slides.push(e)},positionSlide:function(t){var e=this.slides[t];e.style.width=this.slideWidth+"px",this.support.transform&&(e.style.left=t*-this.slideWidth+"px",this.move(t,this.index>t?-this.slideWidth:this.index<t?this.slideWidth:0,0))},initSlides:function(t){var e,n;for(t||(this.positions=[],this.positions.length=this.num,this.elements={},this.imagePrototype=document.createElement("img"),this.elementPrototype=document.createElement("div"),this.slidePrototype=document.createElement("div"),u(this.slidePrototype).addClass(this.options.slideClass),this.slides=this.slidesContainer[0].children,e=this.options.clearSlides||this.slides.length!==this.num),this.slideWidth=this.container[0].clientWidth,this.slideHeight=this.container[0].clientHeight,this.slidesContainer[0].style.width=this.num*this.slideWidth+"px",e&&this.resetSlides(),n=0;n<this.num;n+=1)e&&this.addSlide(n),this.positionSlide(n);this.options.continuous&&this.support.transform&&(this.move(this.circle(this.index-1),-this.slideWidth,0),this.move(this.circle(this.index+1),this.slideWidth,0)),this.support.transform||(this.slidesContainer[0].style.left=this.index*-this.slideWidth+"px")},unloadSlide:function(t){var e=this.slides[t],n=e.firstChild;null!==n&&e.removeChild(n)},unloadAllSlides:function(){for(var t=0,e=this.slides.length;t<e;t++)this.unloadSlide(t)},toggleControls:function(){var t=this.options.controlsClass;this.container.hasClass(t)?this.container.removeClass(t):this.container.addClass(t)},toggleSlideshow:function(){this.interval?this.pause():this.play()},getNodeIndex:function(t){return parseInt(t.getAttribute("data-index"),10)},getNestedProperty:function(o,t){return t.replace(/\[(?:'([^']+)'|"([^"]+)"|(\d+))\]|(?:(?:^|\.)([^\.\[]+))/g,function(t,e,n,i,s){var r=s||e||n||i&&parseInt(i,10);t&&o&&(o=o[r])}),o},getDataProperty:function(t,e){var n,i;if(t.dataset?(n=e.replace(/-([a-z])/g,function(t,e){return e.toUpperCase()}),i=t.dataset[n]):t.getAttribute&&(i=t.getAttribute("data-"+e.replace(/([A-Z])/g,"-$1").toLowerCase())),"string"==typeof i){if(/^(true|false|null|-?\d+(\.\d+)?|\{[\s\S]*\}|\[[\s\S]*\])$/.test(i))try{return u.parseJSON(i)}catch(t){}return i}},getItemProperty:function(t,e){var n=this.getDataProperty(t,e);return void 0===n&&(n=t[e]),void 0===n&&(n=this.getNestedProperty(t,e)),n},initStartIndex:function(){var t,e=this.options.index,n=this.options.urlProperty;if(e&&"number"!=typeof e)for(t=0;t<this.num;t+=1)if(this.list[t]===e||this.getItemProperty(this.list[t],n)===this.getItemProperty(e,n)){e=t;break}this.index=this.circle(parseInt(e,10)||0)},initEventListeners:function(){var n=this,t=this.slidesContainer;function e(t){var e=n.support.transition&&n.support.transition.end===t.type?"transitionend":t.type;n["on"+e](t)}u(window).on("resize",e),u(window).on("hashchange",e),u(document.body).on("keydown",e),this.container.on("click",e),this.support.touch?t.on("touchstart touchmove touchend touchcancel",e):this.options.emulateTouchEvents&&this.support.transition&&t.on("mousedown mousemove mouseup mouseout",e),this.support.transition&&t.on(this.support.transition.end,e),this.proxyListener=e},destroyEventListeners:function(){var t=this.slidesContainer,e=this.proxyListener;u(window).off("resize",e),u(document.body).off("keydown",e),this.container.off("click",e),this.support.touch?t.off("touchstart touchmove touchend touchcancel",e):this.options.emulateTouchEvents&&this.support.transition&&t.off("mousedown mousemove mouseup mouseout",e),this.support.transition&&t.off(this.support.transition.end,e)},handleOpen:function(){this.options.onopened&&this.options.onopened.call(this)},initWidget:function(){var n=this;return this.container=u(this.options.container),this.container.length?(this.slidesContainer=this.container.find(this.options.slidesContainer).first(),this.slidesContainer.length?(this.titleElement=this.container.find(this.options.titleElement).first(),1===this.num&&this.container.addClass(this.options.singleClass),this.options.onopen&&this.options.onopen.call(this),this.support.transition&&this.options.displayTransition?this.container.on(this.support.transition.end,function t(e){e.target===n.container[0]&&(n.container.off(n.support.transition.end,t),n.handleOpen())}):this.handleOpen(),this.options.hidePageScrollbars&&(this.bodyOverflowStyle=document.body.style.overflow,document.body.style.overflow="hidden"),this.container[0].style.display="block",this.initSlides(),void this.container.addClass(this.options.displayClass)):(this.console.log("blueimp Gallery: Slides container not found.",this.options.slidesContainer),!1)):(this.console.log("blueimp Gallery: Widget container not found.",this.options.container),!1)},initOptions:function(t){this.options=u.extend({},this.options),(t&&t.carousel||this.options.carousel&&(!t||!1!==t.carousel))&&u.extend(this.options,this.carouselOptions),u.extend(this.options,t),this.num<3&&(this.options.continuous=!!this.options.continuous&&null),this.support.transition||(this.options.emulateTouchEvents=!1),this.options.event&&this.preventDefault(this.options.event)}}),n}),function(t){"use strict";"function"==typeof define&&define.amd?define(["./blueimp-helper","./blueimp-gallery"],t):t(window.blueimp.helper||window.jQuery,window.blueimp.Gallery)}(function(t,e){"use strict";var n=e.prototype;t.extend(n.options,{fullScreen:!1});var i=n.initialize,s=n.close;return t.extend(n,{getFullScreenElement:function(){return document.fullscreenElement||document.webkitFullscreenElement||document.mozFullScreenElement||document.msFullscreenElement},requestFullScreen:function(t){t.requestFullscreen?t.requestFullscreen():t.webkitRequestFullscreen?t.webkitRequestFullscreen():t.mozRequestFullScreen?t.mozRequestFullScreen():t.msRequestFullscreen&&t.msRequestFullscreen()},exitFullScreen:function(){document.exitFullscreen?document.exitFullscreen():document.webkitCancelFullScreen?document.webkitCancelFullScreen():document.mozCancelFullScreen?document.mozCancelFullScreen():document.msExitFullscreen&&document.msExitFullscreen()},initialize:function(){i.call(this),this.options.fullScreen&&!this.getFullScreenElement()&&this.requestFullScreen(this.container[0])},close:function(){this.getFullScreenElement()===this.container[0]&&this.exitFullScreen(),s.call(this)}}),e}),function(t){"use strict";"function"==typeof define&&define.amd?define(["./blueimp-helper","./blueimp-gallery"],t):t(window.blueimp.helper||window.jQuery,window.blueimp.Gallery)}(function(o,t){"use strict";var e=t.prototype;o.extend(e.options,{indicatorContainer:"ol",activeIndicatorClass:"active",thumbnailProperty:"thumbnail",thumbnailIndicators:!0});var n=e.initSlides,i=e.addSlide,s=e.resetSlides,r=e.handleClick,a=e.handleSlide,l=e.handleClose;return o.extend(e,{createIndicator:function(t){var e,n,i=this.indicatorPrototype.cloneNode(!1),s=this.getItemProperty(t,this.options.titleProperty),r=this.options.thumbnailProperty;return this.options.thumbnailIndicators&&(r&&(e=this.getItemProperty(t,r)),void 0===e&&(n=t.getElementsByTagName&&o(t).find("img")[0])&&(e=n.src),e&&(i.style.backgroundImage='url("'+e+'")')),s&&(i.title=s),i},addIndicator:function(t){var e;this.indicatorContainer.length&&((e=this.createIndicator(this.list[t])).setAttribute("data-index",t),this.indicatorContainer[0].appendChild(e),this.indicators.push(e))},setActiveIndicator:function(t){this.indicators&&(this.activeIndicator&&this.activeIndicator.removeClass(this.options.activeIndicatorClass),this.activeIndicator=o(this.indicators[t]),this.activeIndicator.addClass(this.options.activeIndicatorClass))},initSlides:function(t){t||(this.indicatorContainer=this.container.find(this.options.indicatorContainer),this.indicatorContainer.length&&(this.indicatorPrototype=document.createElement("li"),this.indicators=this.indicatorContainer[0].children)),n.call(this,t)},addSlide:function(t){i.call(this,t),this.addIndicator(t)},resetSlides:function(){s.call(this),this.indicatorContainer.empty(),this.indicators=[]},handleClick:function(t){var e=t.target||t.srcElement,n=e.parentNode;if(n===this.indicatorContainer[0])this.preventDefault(t),this.slide(this.getNodeIndex(e));else{if(n.parentNode!==this.indicatorContainer[0])return r.call(this,t);this.preventDefault(t),this.slide(this.getNodeIndex(n))}},handleSlide:function(t){a.call(this,t),this.setActiveIndicator(t)},handleClose:function(){this.activeIndicator&&this.activeIndicator.removeClass(this.options.activeIndicatorClass),l.call(this)}}),t}),function(t){"use strict";"function"==typeof define&&define.amd?define(["./blueimp-helper","./blueimp-gallery"],t):t(window.blueimp.helper||window.jQuery,window.blueimp.Gallery)}(function(_,t){"use strict";var e=t.prototype;_.extend(e.options,{videoContentClass:"video-content",videoLoadingClass:"video-loading",videoPlayingClass:"video-playing",videoPosterProperty:"poster",videoSourcesProperty:"sources"});var n=e.handleSlide;return _.extend(e,{handleSlide:function(t){n.call(this,t),this.playingVideo&&this.playingVideo.pause()},videoFactory:function(t,e,n){var i,s,r,o,a,l=this,c=this.options,u=this.elementPrototype.cloneNode(!1),d=_(u),h=[{type:"error",target:u}],p=n||document.createElement("video"),f=this.getItemProperty(t,c.urlProperty),g=this.getItemProperty(t,c.typeProperty),m=this.getItemProperty(t,c.titleProperty),y=this.getItemProperty(t,this.options.altTextProperty)||m,v=this.getItemProperty(t,c.videoPosterProperty),b=this.getItemProperty(t,c.videoSourcesProperty);if(d.addClass(c.videoContentClass),m&&(u.title=m),p.canPlayType)if(f&&g&&p.canPlayType(g))p.src=f;else if(b)for(;b.length;)if(s=b.shift(),f=this.getItemProperty(s,c.urlProperty),g=this.getItemProperty(s,c.typeProperty),f&&g&&p.canPlayType(g)){p.src=f;break}return v&&(p.poster=v,i=this.imagePrototype.cloneNode(!1),_(i).addClass(c.toggleClass),i.src=v,i.draggable=!1,i.alt=y,u.appendChild(i)),(r=document.createElement("a")).setAttribute("target","_blank"),n||r.setAttribute("download",m),r.href=f,p.src&&(p.controls=!0,(n||_(p)).on("error",function(){l.setTimeout(e,h)}).on("pause",function(){p.seeking||(o=!1,d.removeClass(l.options.videoLoadingClass).removeClass(l.options.videoPlayingClass),a&&l.container.addClass(l.options.controlsClass),delete l.playingVideo,l.interval&&l.play())}).on("playing",function(){o=!1,d.removeClass(l.options.videoLoadingClass).addClass(l.options.videoPlayingClass),l.container.hasClass(l.options.controlsClass)?(a=!0,l.container.removeClass(l.options.controlsClass)):a=!1}).on("play",function(){window.clearTimeout(l.timeout),o=!0,d.addClass(l.options.videoLoadingClass),l.playingVideo=p}),_(r).on("click",function(t){l.preventDefault(t),o?p.pause():p.play()}),u.appendChild(n&&n.element||p)),u.appendChild(r),this.setTimeout(e,[{type:"load",target:u}]),u}}),t}),function(t){"use strict";"function"==typeof define&&define.amd?define(["./blueimp-helper","./blueimp-gallery-video"],t):t(window.blueimp.helper||window.jQuery,window.blueimp.Gallery)}(function(a,t){"use strict";if(!window.postMessage)return t;var e=t.prototype;a.extend(e.options,{vimeoVideoIdProperty:"vimeo",vimeoPlayerUrl:"//player.vimeo.com/video/VIDEO_ID?api=1&player_id=PLAYER_ID",vimeoPlayerIdPrefix:"vimeo-player-",vimeoClickToPlay:!0});function s(t,e,n,i){this.url=t,this.videoId=e,this.playerId=n,this.clickToPlay=i,this.element=document.createElement("div"),this.listeners={}}var r=e.textFactory||e.imageFactory,o=0;return a.extend(s.prototype,{canPlayType:function(){return!0},on:function(t,e){return this.listeners[t]=e,this},loadAPI:function(){var t,e,n=this,i="//f.vimeocdn.com/js/froogaloop2.min.js",s=document.getElementsByTagName("script"),r=s.length;function o(){!e&&n.playOnReady&&n.play(),e=!0}for(;r;)if(s[--r].src===i){t=s[r];break}t||((t=document.createElement("script")).src=i),a(t).on("load",o),s[0].parentNode.insertBefore(t,s[0]),/loaded|complete/.test(t.readyState)&&o()},onReady:function(){var t=this;this.ready=!0,this.player.addEvent("play",function(){t.hasPlayed=!0,t.onPlaying()}),this.player.addEvent("pause",function(){t.onPause()}),this.player.addEvent("finish",function(){t.onPause()}),this.playOnReady&&this.play()},onPlaying:function(){this.playStatus<2&&(this.listeners.playing(),this.playStatus=2)},onPause:function(){this.listeners.pause(),delete this.playStatus},insertIframe:function(){var t=document.createElement("iframe");t.src=this.url.replace("VIDEO_ID",this.videoId).replace("PLAYER_ID",this.playerId),t.id=this.playerId,this.element.parentNode.replaceChild(t,this.element),this.element=t},play:function(){var t=this;this.playStatus||(this.listeners.play(),this.playStatus=1),this.ready?!this.hasPlayed&&(this.clickToPlay||window.navigator&&/iP(hone|od|ad)/.test(window.navigator.platform))?this.onPlaying():this.player.api("play"):(this.playOnReady=!0,window.$f?this.player||(this.insertIframe(),this.player=$f(this.element),this.player.addEvent("ready",function(){t.onReady()})):this.loadAPI())},pause:function(){this.ready?this.player.api("pause"):this.playStatus&&(delete this.playOnReady,this.listeners.pause(),delete this.playStatus)}}),a.extend(e,{VimeoPlayer:s,textFactory:function(t,e){var n=this.options,i=this.getItemProperty(t,n.vimeoVideoIdProperty);return i?(void 0===this.getItemProperty(t,n.urlProperty)&&(t[n.urlProperty]="//vimeo.com/"+i),o+=1,this.videoFactory(t,e,new s(n.vimeoPlayerUrl,i,n.vimeoPlayerIdPrefix+o,n.vimeoClickToPlay))):r.call(this,t,e)}}),t}),function(t){"use strict";"function"==typeof define&&define.amd?define(["./blueimp-helper","./blueimp-gallery-video"],t):t(window.blueimp.helper||window.jQuery,window.blueimp.Gallery)}(function(t,e){"use strict";if(!window.postMessage)return e;var n=e.prototype;t.extend(n.options,{youTubeVideoIdProperty:"youtube",youTubePlayerVars:{wmode:"transparent"},youTubeClickToPlay:!0});function s(t,e,n){this.videoId=t,this.playerVars=e,this.clickToPlay=n,this.element=document.createElement("div"),this.listeners={}}var r=n.textFactory||n.imageFactory;return t.extend(s.prototype,{canPlayType:function(){return!0},on:function(t,e){return this.listeners[t]=e,this},loadAPI:function(){var t,e=this,n=window.onYouTubeIframeAPIReady,i="//www.youtube.com/iframe_api",s=document.getElementsByTagName("script"),r=s.length;for(window.onYouTubeIframeAPIReady=function(){n&&n.apply(this),e.playOnReady&&e.play()};r;)if(s[--r].src===i)return;(t=document.createElement("script")).src=i,s[0].parentNode.insertBefore(t,s[0])},onReady:function(){this.ready=!0,this.playOnReady&&this.play()},onPlaying:function(){this.playStatus<2&&(this.listeners.playing(),this.playStatus=2)},onPause:function(){n.setTimeout.call(this,this.checkSeek,null,2e3)},checkSeek:function(){this.stateChange!==YT.PlayerState.PAUSED&&this.stateChange!==YT.PlayerState.ENDED||(this.listeners.pause(),delete this.playStatus)},onStateChange:function(t){switch(t.data){case YT.PlayerState.PLAYING:this.hasPlayed=!0,this.onPlaying();break;case YT.PlayerState.PAUSED:case YT.PlayerState.ENDED:this.onPause()}this.stateChange=t.data},onError:function(t){this.listeners.error(t)},play:function(){var e=this;this.playStatus||(this.listeners.play(),this.playStatus=1),this.ready?!this.hasPlayed&&(this.clickToPlay||window.navigator&&/iP(hone|od|ad)/.test(window.navigator.platform))?this.onPlaying():this.player.playVideo():(this.playOnReady=!0,window.YT&&YT.Player?this.player||(this.player=new YT.Player(this.element,{videoId:this.videoId,playerVars:this.playerVars,events:{onReady:function(){e.onReady()},onStateChange:function(t){e.onStateChange(t)},onError:function(t){e.onError(t)}}})):this.loadAPI())},pause:function(){this.ready?this.player.pauseVideo():this.playStatus&&(delete this.playOnReady,this.listeners.pause(),delete this.playStatus)}}),t.extend(n,{YouTubePlayer:s,textFactory:function(t,e){var n=this.options,i=this.getItemProperty(t,n.youTubeVideoIdProperty);return i?(void 0===this.getItemProperty(t,n.urlProperty)&&(t[n.urlProperty]="//www.youtube.com/watch?v="+i),void 0===this.getItemProperty(t,n.videoPosterProperty)&&(t[n.videoPosterProperty]="//img.youtube.com/vi/"+i+"/maxresdefault.jpg"),this.videoFactory(t,e,new s(i,n.youTubePlayerVars,n.youTubeClickToPlay))):r.call(this,t,e)}}),e}),function(t){"use strict";"function"==typeof define&&define.amd?define(["jquery","./blueimp-gallery"],t):t(window.jQuery,window.blueimp.Gallery)}(function(a,l){"use strict";a(document).on("click","[data-gallery]",function(t){var e=a(this).data("gallery"),n=a(e),i=n.length&&n||a(l.prototype.options.container),s={onopen:function(){i.data("gallery",this).trigger("open")},onopened:function(){i.trigger("opened")},onslide:function(){i.trigger("slide",arguments)},onslideend:function(){i.trigger("slideend",arguments)},onslidecomplete:function(){i.trigger("slidecomplete",arguments)},onclose:function(){i.trigger("close")},onclosed:function(){i.trigger("closed").removeData("gallery")}},r=a.extend(i.data(),{container:i[0],index:this,event:t},s),o=a(this).closest("[data-gallery-group], body").find('[data-gallery="'+e+'"]');return r.filter&&(o=o.filter(r.filter)),new l(o,r)})}),function(t){"use strict";"function"==typeof define&&define.amd?define(["jquery","./blueimp-gallery"],t):t(window.jQuery,window.blueimp.Gallery)}(function(t,e){"use strict";t.extend(e.prototype.options,{useBootstrapModal:!0});var n=e.prototype.close,i=e.prototype.imageFactory,s=e.prototype.videoFactory,r=e.prototype.textFactory;t.extend(e.prototype,{modalFactory:function(t,e,n,i){if(!this.options.useBootstrapModal||n)return i.call(this,t,e,n);var s=this,r=this.container.children(".modal").clone().show().on("click",function(t){t.target!==r[0]&&t.target!==r.children()[0]||(t.preventDefault(),t.stopPropagation(),s.close())}),o=i.call(this,t,function(t){e({type:t.type,target:r[0]}),r.addClass("in")},n);return r.find(".modal-title").text(o.title||String.fromCharCode(160)),r.find(".modal-body").append(o),r[0]},imageFactory:function(t,e,n){return this.modalFactory(t,e,n,i)},videoFactory:function(t,e,n){return this.modalFactory(t,e,n,s)},textFactory:function(t,e,n){return this.modalFactory(t,e,n,r)},close:function(){this.container.find(".modal").removeClass("in"),n.call(this)}})}),function(t,e){"object"==typeof exports&&"undefined"!=typeof module?module.exports=e():"function"==typeof define&&define.amd?define(e):t.moment=e()}(this,function(){"use strict";var t,s;function p(){return t.apply(null,arguments)}function a(t){return t instanceof Array||"[object Array]"===Object.prototype.toString.call(t)}function l(t){return null!=t&&"[object Object]"===Object.prototype.toString.call(t)}function f(t,e){return Object.prototype.hasOwnProperty.call(t,e)}function c(t){if(Object.getOwnPropertyNames)return 0===Object.getOwnPropertyNames(t).length;var e;for(e in t)if(f(t,e))return;return 1}function r(t){return void 0===t}function u(t){return"number"==typeof t||"[object Number]"===Object.prototype.toString.call(t)}function o(t){return t instanceof Date||"[object Date]"===Object.prototype.toString.call(t)}function d(t,e){for(var n=[],i=0;i<t.length;++i)n.push(e(t[i],i));return n}function h(t,e){for(var n in e)f(e,n)&&(t[n]=e[n]);return f(e,"toString")&&(t.toString=e.toString),f(e,"valueOf")&&(t.valueOf=e.valueOf),t}function g(t,e,n,i){return Ee(t,e,n,i,!0).utc()}function m(t){return null==t._pf&&(t._pf={empty:!1,unusedTokens:[],unusedInput:[],overflow:-2,charsLeftOver:0,nullInput:!1,invalidEra:null,invalidMonth:null,invalidFormat:!1,userInvalidated:!1,iso:!1,parsedDateParts:[],era:null,meridiem:null,rfc2822:!1,weekdayMismatch:!1}),t._pf}function y(t){if(null==t._isValid){var e=m(t),n=s.call(e.parsedDateParts,function(t){return null!=t}),i=!isNaN(t._d.getTime())&&e.overflow<0&&!e.empty&&!e.invalidEra&&!e.invalidMonth&&!e.invalidWeekday&&!e.weekdayMismatch&&!e.nullInput&&!e.invalidFormat&&!e.userInvalidated&&(!e.meridiem||e.meridiem&&n);if(t._strict&&(i=i&&0===e.charsLeftOver&&0===e.unusedTokens.length&&void 0===e.bigHour),null!=Object.isFrozen&&Object.isFrozen(t))return i;t._isValid=i}return t._isValid}function v(t){var e=g(NaN);return null!=t?h(m(e),t):m(e).userInvalidated=!0,e}s=Array.prototype.some?Array.prototype.some:function(t){for(var e=Object(this),n=e.length>>>0,i=0;i<n;i++)if(i in e&&t.call(this,e[i],i,e))return!0;return!1};var b=p.momentProperties=[],e=!1;function _(t,e){var n,i,s;if(r(e._isAMomentObject)||(t._isAMomentObject=e._isAMomentObject),r(e._i)||(t._i=e._i),r(e._f)||(t._f=e._f),r(e._l)||(t._l=e._l),r(e._strict)||(t._strict=e._strict),r(e._tzm)||(t._tzm=e._tzm),r(e._isUTC)||(t._isUTC=e._isUTC),r(e._offset)||(t._offset=e._offset),r(e._pf)||(t._pf=m(e)),r(e._locale)||(t._locale=e._locale),0<b.length)for(n=0;n<b.length;n++)r(s=e[i=b[n]])||(t[i]=s);return t}function w(t){_(this,t),this._d=new Date(null!=t._d?t._d.getTime():NaN),this.isValid()||(this._d=new Date(NaN)),!1===e&&(e=!0,p.updateOffset(this),e=!1)}function x(t){return t instanceof w||null!=t&&null!=t._isAMomentObject}function C(t){!1===p.suppressDeprecationWarnings&&"undefined"!=typeof console&&console.warn&&console.warn("Deprecation warning: "+t)}function n(s,r){var o=!0;return h(function(){if(null!=p.deprecationHandler&&p.deprecationHandler(null,s),o){for(var t,e,n=[],i=0;i<arguments.length;i++){if(t="","object"==typeof arguments[i]){for(e in t+="\n["+i+"] ",arguments[0])f(arguments[0],e)&&(t+=e+": "+arguments[0][e]+", ");t=t.slice(0,-2)}else t=arguments[i];n.push(t)}C(s+"\nArguments: "+Array.prototype.slice.call(n).join("")+"\n"+(new Error).stack),o=!1}return r.apply(this,arguments)},r)}var i,k={};function S(t,e){null!=p.deprecationHandler&&p.deprecationHandler(t,e),k[t]||(C(e),k[t]=!0)}function T(t){return"undefined"!=typeof Function&&t instanceof Function||"[object Function]"===Object.prototype.toString.call(t)}function D(t,e){var n,i=h({},t);for(n in e)f(e,n)&&(l(t[n])&&l(e[n])?(i[n]={},h(i[n],t[n]),h(i[n],e[n])):null!=e[n]?i[n]=e[n]:delete i[n]);for(n in t)f(t,n)&&!f(e,n)&&l(t[n])&&(i[n]=h({},i[n]));return i}function E(t){null!=t&&this.set(t)}p.suppressDeprecationWarnings=!1,p.deprecationHandler=null,i=Object.keys?Object.keys:function(t){var e,n=[];for(e in t)f(t,e)&&n.push(e);return n};function N(t,e,n){var i=""+Math.abs(t),s=e-i.length;return(0<=t?n?"+":"":"-")+Math.pow(10,Math.max(0,s)).toString().substr(1)+i}var $=/(\[[^\[]*\])|(\\)?([Hh]mm(ss)?|Mo|MM?M?M?|Do|DDDo|DD?D?D?|ddd?d?|do?|w[o|w]?|W[o|W]?|Qo?|N{1,5}|YYYYYY|YYYYY|YYYY|YY|y{2,4}|yo?|gg(ggg?)?|GG(GGG?)?|e|E|a|A|hh?|HH?|kk?|mm?|ss?|S{1,9}|x|X|zz?|ZZ?|.)/g,A=/(\[[^\[]*\])|(\\)?(LTS|LT|LL?L?L?|l{1,4})/g,M={},I={};function O(t,e,n,i){var s="string"==typeof i?function(){return this[i]()}:i;t&&(I[t]=s),e&&(I[e[0]]=function(){return N(s.apply(this,arguments),e[1],e[2])}),n&&(I[n]=function(){return this.localeData().ordinal(s.apply(this,arguments),t)})}function P(t,e){return t.isValid()?(e=R(e,t.localeData()),M[e]=M[e]||function(i){for(var t,s=i.match($),e=0,r=s.length;e<r;e++)I[s[e]]?s[e]=I[s[e]]:s[e]=(t=s[e]).match(/\[[\s\S]/)?t.replace(/^\[|\]$/g,""):t.replace(/\\/g,"");return function(t){for(var e="",n=0;n<r;n++)e+=T(s[n])?s[n].call(t,i):s[n];return e}}(e),M[e](t)):t.localeData().invalidDate()}function R(t,e){var n=5;function i(t){return e.longDateFormat(t)||t}for(A.lastIndex=0;0<=n&&A.test(t);)t=t.replace(A,i),A.lastIndex=0,--n;return t}var L={};function j(t,e){var n=t.toLowerCase();L[n]=L[n+"s"]=L[e]=t}function H(t){return"string"==typeof t?L[t]||L[t.toLowerCase()]:void 0}function F(t){var e,n,i={};for(n in t)f(t,n)&&(e=H(n))&&(i[e]=t[n]);return i}var W={};function Y(t,e){W[t]=e}function q(t){return t%4==0&&t%100!=0||t%400==0}function z(t){return t<0?Math.ceil(t)||0:Math.floor(t)}function B(t){var e=+t,n=0;return 0!=e&&isFinite(e)&&(n=z(e)),n}function V(e,n){return function(t){return null!=t?(G(this,e,t),p.updateOffset(this,n),this):U(this,e)}}function U(t,e){return t.isValid()?t._d["get"+(t._isUTC?"UTC":"")+e]():NaN}function G(t,e,n){t.isValid()&&!isNaN(n)&&("FullYear"===e&&q(t.year())&&1===t.month()&&29===t.date()?(n=B(n),t._d["set"+(t._isUTC?"UTC":"")+e](n,t.month(),Et(n,t.month()))):t._d["set"+(t._isUTC?"UTC":"")+e](n))}var Q,K=/\d/,X=/\d\d/,Z=/\d{3}/,J=/\d{4}/,tt=/[+-]?\d{6}/,et=/\d\d?/,nt=/\d\d\d\d?/,it=/\d\d\d\d\d\d?/,st=/\d{1,3}/,rt=/\d{1,4}/,ot=/[+-]?\d{1,6}/,at=/\d+/,lt=/[+-]?\d+/,ct=/Z|[+-]\d\d:?\d\d/gi,ut=/Z|[+-]\d\d(?::?\d\d)?/gi,dt=/[0-9]{0,256}['a-z\u00A0-\u05FF\u0700-\uD7FF\uF900-\uFDCF\uFDF0-\uFF07\uFF10-\uFFEF]{1,256}|[\u0600-\u06FF\/]{1,256}(\s*?[\u0600-\u06FF]{1,256}){1,2}/i;function ht(t,n,i){Q[t]=T(n)?n:function(t,e){return t&&i?i:n}}function pt(t,e){return f(Q,t)?Q[t](e._strict,e._locale):new RegExp(ft(t.replace("\\","").replace(/\\(\[)|\\(\])|\[([^\]\[]*)\]|\\(.)/g,function(t,e,n,i,s){return e||n||i||s})))}function ft(t){return t.replace(/[-\/\\^$*+?.()|[\]{}]/g,"\\$&")}Q={};var gt={};function mt(t,n){var e,i=n;for("string"==typeof t&&(t=[t]),u(n)&&(i=function(t,e){e[n]=B(t)}),e=0;e<t.length;e++)gt[t[e]]=i}function yt(t,s){mt(t,function(t,e,n,i){n._w=n._w||{},s(t,n._w,n,i)})}var vt,bt=0,_t=1,wt=2,xt=3,Ct=4,kt=5,St=6,Tt=7,Dt=8;function Et(t,e){if(isNaN(t)||isNaN(e))return NaN;var n,i=(e%(n=12)+n)%n;return t+=(e-i)/12,1==i?q(t)?29:28:31-i%7%2}vt=Array.prototype.indexOf?Array.prototype.indexOf:function(t){for(var e=0;e<this.length;++e)if(this[e]===t)return e;return-1},O("M",["MM",2],"Mo",function(){return this.month()+1}),O("MMM",0,0,function(t){return this.localeData().monthsShort(this,t)}),O("MMMM",0,0,function(t){return this.localeData().months(this,t)}),j("month","M"),Y("month",8),ht("M",et),ht("MM",et,X),ht("MMM",function(t,e){return e.monthsShortRegex(t)}),ht("MMMM",function(t,e){return e.monthsRegex(t)}),mt(["M","MM"],function(t,e){e[_t]=B(t)-1}),mt(["MMM","MMMM"],function(t,e,n,i){var s=n._locale.monthsParse(t,i,n._strict);null!=s?e[_t]=s:m(n).invalidMonth=t});var Nt="January_February_March_April_May_June_July_August_September_October_November_December".split("_"),$t="Jan_Feb_Mar_Apr_May_Jun_Jul_Aug_Sep_Oct_Nov_Dec".split("_"),At=/D[oD]?(\[[^\[\]]*\]|\s)+MMMM?/,Mt=dt,It=dt;function Ot(t,e){var n;if(!t.isValid())return t;if("string"==typeof e)if(/^\d+$/.test(e))e=B(e);else if(!u(e=t.localeData().monthsParse(e)))return t;return n=Math.min(t.date(),Et(t.year(),e)),t._d["set"+(t._isUTC?"UTC":"")+"Month"](e,n),t}function Pt(t){return null!=t?(Ot(this,t),p.updateOffset(this,!0),this):U(this,"Month")}function Rt(){function t(t,e){return e.length-t.length}for(var e,n=[],i=[],s=[],r=0;r<12;r++)e=g([2e3,r]),n.push(this.monthsShort(e,"")),i.push(this.months(e,"")),s.push(this.months(e,"")),s.push(this.monthsShort(e,""));for(n.sort(t),i.sort(t),s.sort(t),r=0;r<12;r++)n[r]=ft(n[r]),i[r]=ft(i[r]);for(r=0;r<24;r++)s[r]=ft(s[r]);this._monthsRegex=new RegExp("^("+s.join("|")+")","i"),this._monthsShortRegex=this._monthsRegex,this._monthsStrictRegex=new RegExp("^("+i.join("|")+")","i"),this._monthsShortStrictRegex=new RegExp("^("+n.join("|")+")","i")}function Lt(t){return q(t)?366:365}O("Y",0,0,function(){var t=this.year();return t<=9999?N(t,4):"+"+t}),O(0,["YY",2],0,function(){return this.year()%100}),O(0,["YYYY",4],0,"year"),O(0,["YYYYY",5],0,"year"),O(0,["YYYYYY",6,!0],0,"year"),j("year","y"),Y("year",1),ht("Y",lt),ht("YY",et,X),ht("YYYY",rt,J),ht("YYYYY",ot,tt),ht("YYYYYY",ot,tt),mt(["YYYYY","YYYYYY"],bt),mt("YYYY",function(t,e){e[bt]=2===t.length?p.parseTwoDigitYear(t):B(t)}),mt("YY",function(t,e){e[bt]=p.parseTwoDigitYear(t)}),mt("Y",function(t,e){e[bt]=parseInt(t,10)}),p.parseTwoDigitYear=function(t){return B(t)+(68<B(t)?1900:2e3)};var jt=V("FullYear",!0);function Ht(t){var e,n;return t<100&&0<=t?((n=Array.prototype.slice.call(arguments))[0]=t+400,e=new Date(Date.UTC.apply(null,n)),isFinite(e.getUTCFullYear())&&e.setUTCFullYear(t)):e=new Date(Date.UTC.apply(null,arguments)),e}function Ft(t,e,n){var i=7+e-n;return i-(7+Ht(t,0,i).getUTCDay()-e)%7-1}function Wt(t,e,n,i,s){var r,o=1+7*(e-1)+(7+n-i)%7+Ft(t,i,s),a=o<=0?Lt(r=t-1)+o:o>Lt(t)?(r=t+1,o-Lt(t)):(r=t,o);return{year:r,dayOfYear:a}}function Yt(t,e,n){var i,s,r=Ft(t.year(),e,n),o=Math.floor((t.dayOfYear()-r-1)/7)+1;return o<1?i=o+qt(s=t.year()-1,e,n):o>qt(t.year(),e,n)?(i=o-qt(t.year(),e,n),s=t.year()+1):(s=t.year(),i=o),{week:i,year:s}}function qt(t,e,n){var i=Ft(t,e,n),s=Ft(t+1,e,n);return(Lt(t)-i+s)/7}O("w",["ww",2],"wo","week"),O("W",["WW",2],"Wo","isoWeek"),j("week","w"),j("isoWeek","W"),Y("week",5),Y("isoWeek",5),ht("w",et),ht("ww",et,X),ht("W",et),ht("WW",et,X),yt(["w","ww","W","WW"],function(t,e,n,i){e[i.substr(0,1)]=B(t)});function zt(t,e){return t.slice(e,7).concat(t.slice(0,e))}O("d",0,"do","day"),O("dd",0,0,function(t){return this.localeData().weekdaysMin(this,t)}),O("ddd",0,0,function(t){return this.localeData().weekdaysShort(this,t)}),O("dddd",0,0,function(t){return this.localeData().weekdays(this,t)}),O("e",0,0,"weekday"),O("E",0,0,"isoWeekday"),j("day","d"),j("weekday","e"),j("isoWeekday","E"),Y("day",11),Y("weekday",11),Y("isoWeekday",11),ht("d",et),ht("e",et),ht("E",et),ht("dd",function(t,e){return e.weekdaysMinRegex(t)}),ht("ddd",function(t,e){return e.weekdaysShortRegex(t)}),ht("dddd",function(t,e){return e.weekdaysRegex(t)}),yt(["dd","ddd","dddd"],function(t,e,n,i){var s=n._locale.weekdaysParse(t,i,n._strict);null!=s?e.d=s:m(n).invalidWeekday=t}),yt(["d","e","E"],function(t,e,n,i){e[i]=B(t)});var Bt="Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"),Vt="Sun_Mon_Tue_Wed_Thu_Fri_Sat".split("_"),Ut="Su_Mo_Tu_We_Th_Fr_Sa".split("_"),Gt=dt,Qt=dt,Kt=dt;function Xt(){function t(t,e){return e.length-t.length}for(var e,n,i,s,r=[],o=[],a=[],l=[],c=0;c<7;c++)e=g([2e3,1]).day(c),n=ft(this.weekdaysMin(e,"")),i=ft(this.weekdaysShort(e,"")),s=ft(this.weekdays(e,"")),r.push(n),o.push(i),a.push(s),l.push(n),l.push(i),l.push(s);r.sort(t),o.sort(t),a.sort(t),l.sort(t),this._weekdaysRegex=new RegExp("^("+l.join("|")+")","i"),this._weekdaysShortRegex=this._weekdaysRegex,this._weekdaysMinRegex=this._weekdaysRegex,this._weekdaysStrictRegex=new RegExp("^("+a.join("|")+")","i"),this._weekdaysShortStrictRegex=new RegExp("^("+o.join("|")+")","i"),this._weekdaysMinStrictRegex=new RegExp("^("+r.join("|")+")","i")}function Zt(){return this.hours()%12||12}function Jt(t,e){O(t,0,0,function(){return this.localeData().meridiem(this.hours(),this.minutes(),e)})}function te(t,e){return e._meridiemParse}O("H",["HH",2],0,"hour"),O("h",["hh",2],0,Zt),O("k",["kk",2],0,function(){return this.hours()||24}),O("hmm",0,0,function(){return""+Zt.apply(this)+N(this.minutes(),2)}),O("hmmss",0,0,function(){return""+Zt.apply(this)+N(this.minutes(),2)+N(this.seconds(),2)}),O("Hmm",0,0,function(){return""+this.hours()+N(this.minutes(),2)}),O("Hmmss",0,0,function(){return""+this.hours()+N(this.minutes(),2)+N(this.seconds(),2)}),Jt("a",!0),Jt("A",!1),j("hour","h"),Y("hour",13),ht("a",te),ht("A",te),ht("H",et),ht("h",et),ht("k",et),ht("HH",et,X),ht("hh",et,X),ht("kk",et,X),ht("hmm",nt),ht("hmmss",it),ht("Hmm",nt),ht("Hmmss",it),mt(["H","HH"],xt),mt(["k","kk"],function(t,e,n){var i=B(t);e[xt]=24===i?0:i}),mt(["a","A"],function(t,e,n){n._isPm=n._locale.isPM(t),n._meridiem=t}),mt(["h","hh"],function(t,e,n){e[xt]=B(t),m(n).bigHour=!0}),mt("hmm",function(t,e,n){var i=t.length-2;e[xt]=B(t.substr(0,i)),e[Ct]=B(t.substr(i)),m(n).bigHour=!0}),mt("hmmss",function(t,e,n){var i=t.length-4,s=t.length-2;e[xt]=B(t.substr(0,i)),e[Ct]=B(t.substr(i,2)),e[kt]=B(t.substr(s)),m(n).bigHour=!0}),mt("Hmm",function(t,e,n){var i=t.length-2;e[xt]=B(t.substr(0,i)),e[Ct]=B(t.substr(i))}),mt("Hmmss",function(t,e,n){var i=t.length-4,s=t.length-2;e[xt]=B(t.substr(0,i)),e[Ct]=B(t.substr(i,2)),e[kt]=B(t.substr(s))});var ee=V("Hours",!0);var ne,ie={calendar:{sameDay:"[Today at] LT",nextDay:"[Tomorrow at] LT",nextWeek:"dddd [at] LT",lastDay:"[Yesterday at] LT",lastWeek:"[Last] dddd [at] LT",sameElse:"L"},longDateFormat:{LTS:"h:mm:ss A",LT:"h:mm A",L:"MM/DD/YYYY",LL:"MMMM D, YYYY",LLL:"MMMM D, YYYY h:mm A",LLLL:"dddd, MMMM D, YYYY h:mm A"},invalidDate:"Invalid date",ordinal:"%d",dayOfMonthOrdinalParse:/\d{1,2}/,relativeTime:{future:"in %s",past:"%s ago",s:"a few seconds",ss:"%d seconds",m:"a minute",mm:"%d minutes",h:"an hour",hh:"%d hours",d:"a day",dd:"%d days",w:"a week",ww:"%d weeks",M:"a month",MM:"%d months",y:"a year",yy:"%d years"},months:Nt,monthsShort:$t,week:{dow:0,doy:6},weekdays:Bt,weekdaysMin:Ut,weekdaysShort:Vt,meridiemParse:/[ap]\.?m?\.?/i},se={},re={};function oe(t){return t?t.toLowerCase().replace("_","-"):t}function ae(t){for(var e,n,i,s,r=0;r<t.length;){for(e=(s=oe(t[r]).split("-")).length,n=(n=oe(t[r+1]))?n.split("-"):null;0<e;){if(i=le(s.slice(0,e).join("-")))return i;if(n&&n.length>=e&&function(t,e){for(var n=Math.min(t.length,e.length),i=0;i<n;i+=1)if(t[i]!==e[i])return i;return n}(s,n)>=e-1)break;e--}r++}return ne}function le(e){var t;if(void 0===se[e]&&"undefined"!=typeof module&&module&&module.exports)try{t=ne._abbr,require("./locale/"+e),ce(t)}catch(t){se[e]=null}return se[e]}function ce(t,e){var n;return t&&((n=r(e)?de(t):ue(t,e))?ne=n:"undefined"!=typeof console&&console.warn&&console.warn("Locale "+t+" not found. Did you forget to load it?")),ne._abbr}function ue(t,e){if(null===e)return delete se[t],null;var n,i=ie;if(e.abbr=t,null!=se[t])S("defineLocaleOverride","use moment.updateLocale(localeName, config) to change an existing locale. moment.defineLocale(localeName, config) should only be used for creating a new locale See http://momentjs.com/guides/#/warnings/define-locale/ for more info."),i=se[t]._config;else if(null!=e.parentLocale)if(null!=se[e.parentLocale])i=se[e.parentLocale]._config;else{if(null==(n=le(e.parentLocale)))return re[e.parentLocale]||(re[e.parentLocale]=[]),re[e.parentLocale].push({name:t,config:e}),null;i=n._config}return se[t]=new E(D(i,e)),re[t]&&re[t].forEach(function(t){ue(t.name,t.config)}),ce(t),se[t]}function de(t){var e;if(t&&t._locale&&t._locale._abbr&&(t=t._locale._abbr),!t)return ne;if(!a(t)){if(e=le(t))return e;t=[t]}return ae(t)}function he(t){var e,n=t._a;return n&&-2===m(t).overflow&&(e=n[_t]<0||11<n[_t]?_t:n[wt]<1||n[wt]>Et(n[bt],n[_t])?wt:n[xt]<0||24<n[xt]||24===n[xt]&&(0!==n[Ct]||0!==n[kt]||0!==n[St])?xt:n[Ct]<0||59<n[Ct]?Ct:n[kt]<0||59<n[kt]?kt:n[St]<0||999<n[St]?St:-1,m(t)._overflowDayOfYear&&(e<bt||wt<e)&&(e=wt),m(t)._overflowWeeks&&-1===e&&(e=Tt),m(t)._overflowWeekday&&-1===e&&(e=Dt),m(t).overflow=e),t}var pe=/^\s*((?:[+-]\d{6}|\d{4})-(?:\d\d-\d\d|W\d\d-\d|W\d\d|\d\d\d|\d\d))(?:(T| )(\d\d(?::\d\d(?::\d\d(?:[.,]\d+)?)?)?)([+-]\d\d(?::?\d\d)?|\s*Z)?)?$/,fe=/^\s*((?:[+-]\d{6}|\d{4})(?:\d\d\d\d|W\d\d\d|W\d\d|\d\d\d|\d\d|))(?:(T| )(\d\d(?:\d\d(?:\d\d(?:[.,]\d+)?)?)?)([+-]\d\d(?::?\d\d)?|\s*Z)?)?$/,ge=/Z|[+-]\d\d(?::?\d\d)?/,me=[["YYYYYY-MM-DD",/[+-]\d{6}-\d\d-\d\d/],["YYYY-MM-DD",/\d{4}-\d\d-\d\d/],["GGGG-[W]WW-E",/\d{4}-W\d\d-\d/],["GGGG-[W]WW",/\d{4}-W\d\d/,!1],["YYYY-DDD",/\d{4}-\d{3}/],["YYYY-MM",/\d{4}-\d\d/,!1],["YYYYYYMMDD",/[+-]\d{10}/],["YYYYMMDD",/\d{8}/],["GGGG[W]WWE",/\d{4}W\d{3}/],["GGGG[W]WW",/\d{4}W\d{2}/,!1],["YYYYDDD",/\d{7}/],["YYYYMM",/\d{6}/,!1],["YYYY",/\d{4}/,!1]],ye=[["HH:mm:ss.SSSS",/\d\d:\d\d:\d\d\.\d+/],["HH:mm:ss,SSSS",/\d\d:\d\d:\d\d,\d+/],["HH:mm:ss",/\d\d:\d\d:\d\d/],["HH:mm",/\d\d:\d\d/],["HHmmss.SSSS",/\d\d\d\d\d\d\.\d+/],["HHmmss,SSSS",/\d\d\d\d\d\d,\d+/],["HHmmss",/\d\d\d\d\d\d/],["HHmm",/\d\d\d\d/],["HH",/\d\d/]],ve=/^\/?Date\((-?\d+)/i,be=/^(?:(Mon|Tue|Wed|Thu|Fri|Sat|Sun),?\s)?(\d{1,2})\s(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s(\d{2,4})\s(\d\d):(\d\d)(?::(\d\d))?\s(?:(UT|GMT|[ECMP][SD]T)|([Zz])|([+-]\d{4}))$/,_e={UT:0,GMT:0,EDT:-240,EST:-300,CDT:-300,CST:-360,MDT:-360,MST:-420,PDT:-420,PST:-480};function we(t){var e,n,i,s,r,o,a=t._i,l=pe.exec(a)||fe.exec(a);if(l){for(m(t).iso=!0,e=0,n=me.length;e<n;e++)if(me[e][1].exec(l[1])){s=me[e][0],i=!1!==me[e][2];break}if(null==s)return void(t._isValid=!1);if(l[3]){for(e=0,n=ye.length;e<n;e++)if(ye[e][1].exec(l[3])){r=(l[2]||" ")+ye[e][0];break}if(null==r)return void(t._isValid=!1)}if(!i&&null!=r)return void(t._isValid=!1);if(l[4]){if(!ge.exec(l[4]))return void(t._isValid=!1);o="Z"}t._f=s+(r||"")+(o||""),Te(t)}else t._isValid=!1}function xe(t,e,n,i,s,r){var o=[function(t){var e=parseInt(t,10);{if(e<=49)return 2e3+e;if(e<=999)return 1900+e}return e}(t),$t.indexOf(e),parseInt(n,10),parseInt(i,10),parseInt(s,10)];return r&&o.push(parseInt(r,10)),o}function Ce(t){var e,n,i,s,r=be.exec(t._i.replace(/\([^)]*\)|[\n\t]/g," ").replace(/(\s\s+)/g," ").replace(/^\s\s*/,"").replace(/\s\s*$/,""));if(r){if(e=xe(r[4],r[3],r[2],r[5],r[6],r[7]),n=r[1],i=e,s=t,n&&Vt.indexOf(n)!==new Date(i[0],i[1],i[2]).getDay()&&(m(s).weekdayMismatch=!0,!void(s._isValid=!1)))return;t._a=e,t._tzm=function(t,e,n){if(t)return _e[t];if(e)return 0;var i=parseInt(n,10),s=i%100;return 60*((i-s)/100)+s}(r[8],r[9],r[10]),t._d=Ht.apply(null,t._a),t._d.setUTCMinutes(t._d.getUTCMinutes()-t._tzm),m(t).rfc2822=!0}else t._isValid=!1}function ke(t,e,n){return null!=t?t:null!=e?e:n}function Se(t){var e,n,i,s,r,o,a,l=[];if(!t._d){for(o=t,a=new Date(p.now()),i=o._useUTC?[a.getUTCFullYear(),a.getUTCMonth(),a.getUTCDate()]:[a.getFullYear(),a.getMonth(),a.getDate()],t._w&&null==t._a[wt]&&null==t._a[_t]&&function(t){var e,n,i,s,r,o,a,l,c;null!=(e=t._w).GG||null!=e.W||null!=e.E?(r=1,o=4,n=ke(e.GG,t._a[bt],Yt(Ne(),1,4).year),i=ke(e.W,1),((s=ke(e.E,1))<1||7<s)&&(l=!0)):(r=t._locale._week.dow,o=t._locale._week.doy,c=Yt(Ne(),r,o),n=ke(e.gg,t._a[bt],c.year),i=ke(e.w,c.week),null!=e.d?((s=e.d)<0||6<s)&&(l=!0):null!=e.e?(s=e.e+r,(e.e<0||6<e.e)&&(l=!0)):s=r);i<1||i>qt(n,r,o)?m(t)._overflowWeeks=!0:null!=l?m(t)._overflowWeekday=!0:(a=Wt(n,i,s,r,o),t._a[bt]=a.year,t._dayOfYear=a.dayOfYear)}(t),null!=t._dayOfYear&&(r=ke(t._a[bt],i[bt]),(t._dayOfYear>Lt(r)||0===t._dayOfYear)&&(m(t)._overflowDayOfYear=!0),n=Ht(r,0,t._dayOfYear),t._a[_t]=n.getUTCMonth(),t._a[wt]=n.getUTCDate()),e=0;e<3&&null==t._a[e];++e)t._a[e]=l[e]=i[e];for(;e<7;e++)t._a[e]=l[e]=null==t._a[e]?2===e?1:0:t._a[e];24===t._a[xt]&&0===t._a[Ct]&&0===t._a[kt]&&0===t._a[St]&&(t._nextDay=!0,t._a[xt]=0),t._d=(t._useUTC?Ht:function(t,e,n,i,s,r,o){var a;return t<100&&0<=t?(a=new Date(t+400,e,n,i,s,r,o),isFinite(a.getFullYear())&&a.setFullYear(t)):a=new Date(t,e,n,i,s,r,o),a}).apply(null,l),s=t._useUTC?t._d.getUTCDay():t._d.getDay(),null!=t._tzm&&t._d.setUTCMinutes(t._d.getUTCMinutes()-t._tzm),t._nextDay&&(t._a[xt]=24),t._w&&void 0!==t._w.d&&t._w.d!==s&&(m(t).weekdayMismatch=!0)}}function Te(t){if(t._f!==p.ISO_8601)if(t._f!==p.RFC_2822){t._a=[],m(t).empty=!0;for(var e,n,i,s,r,o,a,l=""+t._i,c=l.length,u=0,d=R(t._f,t._locale).match($)||[],h=0;h<d.length;h++)n=d[h],(e=(l.match(pt(n,t))||[])[0])&&(0<(i=l.substr(0,l.indexOf(e))).length&&m(t).unusedInput.push(i),l=l.slice(l.indexOf(e)+e.length),u+=e.length),I[n]?(e?m(t).empty=!1:m(t).unusedTokens.push(n),r=n,a=t,null!=(o=e)&&f(gt,r)&&gt[r](o,a._a,a,r)):t._strict&&!e&&m(t).unusedTokens.push(n);m(t).charsLeftOver=c-u,0<l.length&&m(t).unusedInput.push(l),t._a[xt]<=12&&!0===m(t).bigHour&&0<t._a[xt]&&(m(t).bigHour=void 0),m(t).parsedDateParts=t._a.slice(0),m(t).meridiem=t._meridiem,t._a[xt]=function(t,e,n){var i;if(null==n)return e;return null!=t.meridiemHour?t.meridiemHour(e,n):(null!=t.isPM&&((i=t.isPM(n))&&e<12&&(e+=12),i||12!==e||(e=0)),e)}(t._locale,t._a[xt],t._meridiem),null!==(s=m(t).era)&&(t._a[bt]=t._locale.erasConvertYear(s,t._a[bt])),Se(t),he(t)}else Ce(t);else we(t)}function De(t){var e,n,i=t._i,s=t._f;return t._locale=t._locale||de(t._l),null===i||void 0===s&&""===i?v({nullInput:!0}):("string"==typeof i&&(t._i=i=t._locale.preparse(i)),x(i)?new w(he(i)):(o(i)?t._d=i:a(s)?function(t){var e,n,i,s,r,o,a=!1;if(0===t._f.length)return m(t).invalidFormat=!0,t._d=new Date(NaN);for(s=0;s<t._f.length;s++)r=0,o=!1,e=_({},t),null!=t._useUTC&&(e._useUTC=t._useUTC),e._f=t._f[s],Te(e),y(e)&&(o=!0),r+=m(e).charsLeftOver,r+=10*m(e).unusedTokens.length,m(e).score=r,a?r<i&&(i=r,n=e):(null==i||r<i||o)&&(i=r,n=e,o&&(a=!0));h(t,n||e)}(t):s?Te(t):r(n=(e=t)._i)?e._d=new Date(p.now()):o(n)?e._d=new Date(n.valueOf()):"string"==typeof n?function(t){var e=ve.exec(t._i);null===e?(we(t),!1===t._isValid&&(delete t._isValid,Ce(t),!1===t._isValid&&(delete t._isValid,t._strict?t._isValid=!1:p.createFromInputFallback(t)))):t._d=new Date(+e[1])}(e):a(n)?(e._a=d(n.slice(0),function(t){return parseInt(t,10)}),Se(e)):l(n)?function(t){var e,n;t._d||(n=void 0===(e=F(t._i)).day?e.date:e.day,t._a=d([e.year,e.month,n,e.hour,e.minute,e.second,e.millisecond],function(t){return t&&parseInt(t,10)}),Se(t))}(e):u(n)?e._d=new Date(n):p.createFromInputFallback(e),y(t)||(t._d=null),t))}function Ee(t,e,n,i,s){var r,o={};return!0!==e&&!1!==e||(i=e,e=void 0),!0!==n&&!1!==n||(i=n,n=void 0),(l(t)&&c(t)||a(t)&&0===t.length)&&(t=void 0),o._isAMomentObject=!0,o._useUTC=o._isUTC=s,o._l=n,o._i=t,o._f=e,o._strict=i,(r=new w(he(De(o))))._nextDay&&(r.add(1,"d"),r._nextDay=void 0),r}function Ne(t,e,n,i){return Ee(t,e,n,i,!1)}p.createFromInputFallback=n("value provided is not in a recognized RFC2822 or ISO format. moment construction falls back to js Date(), which is not reliable across all browsers and versions. Non RFC2822/ISO date formats are discouraged and will be removed in an upcoming major release. Please refer to http://momentjs.com/guides/#/warnings/js-date/ for more info.",function(t){t._d=new Date(t._i+(t._useUTC?" UTC":""))}),p.ISO_8601=function(){},p.RFC_2822=function(){};var $e=n("moment().min is deprecated, use moment.max instead. http://momentjs.com/guides/#/warnings/min-max/",function(){var t=Ne.apply(null,arguments);return this.isValid()&&t.isValid()?t<this?this:t:v()}),Ae=n("moment().max is deprecated, use moment.min instead. http://momentjs.com/guides/#/warnings/min-max/",function(){var t=Ne.apply(null,arguments);return this.isValid()&&t.isValid()?this<t?this:t:v()});function Me(t,e){var n,i;if(1===e.length&&a(e[0])&&(e=e[0]),!e.length)return Ne();for(n=e[0],i=1;i<e.length;++i)e[i].isValid()&&!e[i][t](n)||(n=e[i]);return n}var Ie=["year","quarter","month","week","day","hour","minute","second","millisecond"];function Oe(t){var e=F(t),n=e.year||0,i=e.quarter||0,s=e.month||0,r=e.week||e.isoWeek||0,o=e.day||0,a=e.hour||0,l=e.minute||0,c=e.second||0,u=e.millisecond||0;this._isValid=function(t){var e,n,i=!1;for(e in t)if(f(t,e)&&(-1===vt.call(Ie,e)||null!=t[e]&&isNaN(t[e])))return!1;for(n=0;n<Ie.length;++n)if(t[Ie[n]]){if(i)return!1;parseFloat(t[Ie[n]])!==B(t[Ie[n]])&&(i=!0)}return!0}(e),this._milliseconds=+u+1e3*c+6e4*l+1e3*a*60*60,this._days=+o+7*r,this._months=+s+3*i+12*n,this._data={},this._locale=de(),this._bubble()}function Pe(t){return t instanceof Oe}function Re(t){return t<0?-1*Math.round(-1*t):Math.round(t)}function Le(t,n){O(t,0,0,function(){var t=this.utcOffset(),e="+";return t<0&&(t=-t,e="-"),e+N(~~(t/60),2)+n+N(~~t%60,2)})}Le("Z",":"),Le("ZZ",""),ht("Z",ut),ht("ZZ",ut),mt(["Z","ZZ"],function(t,e,n){n._useUTC=!0,n._tzm=He(ut,t)});var je=/([\+\-]|\d\d)/gi;function He(t,e){var n,i,s=(e||"").match(t);return null===s?null:0===(i=60*(n=((s[s.length-1]||[])+"").match(je)||["-",0,0])[1]+B(n[2]))?0:"+"===n[0]?i:-i}function Fe(t,e){var n,i;return e._isUTC?(n=e.clone(),i=(x(t)||o(t)?t.valueOf():Ne(t).valueOf())-n.valueOf(),n._d.setTime(n._d.valueOf()+i),p.updateOffset(n,!1),n):Ne(t).local()}function We(t){return-Math.round(t._d.getTimezoneOffset())}function Ye(){return!!this.isValid()&&(this._isUTC&&0===this._offset)}p.updateOffset=function(){};var qe=/^(-|\+)?(?:(\d*)[. ])?(\d+):(\d+)(?::(\d+)(\.\d*)?)?$/,ze=/^(-|\+)?P(?:([-+]?[0-9,.]*)Y)?(?:([-+]?[0-9,.]*)M)?(?:([-+]?[0-9,.]*)W)?(?:([-+]?[0-9,.]*)D)?(?:T(?:([-+]?[0-9,.]*)H)?(?:([-+]?[0-9,.]*)M)?(?:([-+]?[0-9,.]*)S)?)?$/;function Be(t,e){var n,i,s,r=t,o=null;return Pe(t)?r={ms:t._milliseconds,d:t._days,M:t._months}:u(t)||!isNaN(+t)?(r={},e?r[e]=+t:r.milliseconds=+t):(o=qe.exec(t))?(n="-"===o[1]?-1:1,r={y:0,d:B(o[wt])*n,h:B(o[xt])*n,m:B(o[Ct])*n,s:B(o[kt])*n,ms:B(Re(1e3*o[St]))*n}):(o=ze.exec(t))?(n="-"===o[1]?-1:1,r={y:Ve(o[2],n),M:Ve(o[3],n),w:Ve(o[4],n),d:Ve(o[5],n),h:Ve(o[6],n),m:Ve(o[7],n),s:Ve(o[8],n)}):null==r?r={}:"object"==typeof r&&("from"in r||"to"in r)&&(s=function(t,e){var n;if(!t.isValid()||!e.isValid())return{milliseconds:0,months:0};e=Fe(e,t),t.isBefore(e)?n=Ue(t,e):((n=Ue(e,t)).milliseconds=-n.milliseconds,n.months=-n.months);return n}(Ne(r.from),Ne(r.to)),(r={}).ms=s.milliseconds,r.M=s.months),i=new Oe(r),Pe(t)&&f(t,"_locale")&&(i._locale=t._locale),Pe(t)&&f(t,"_isValid")&&(i._isValid=t._isValid),i}function Ve(t,e){var n=t&&parseFloat(t.replace(",","."));return(isNaN(n)?0:n)*e}function Ue(t,e){var n={};return n.months=e.month()-t.month()+12*(e.year()-t.year()),t.clone().add(n.months,"M").isAfter(e)&&--n.months,n.milliseconds=e-t.clone().add(n.months,"M"),n}function Ge(i,s){return function(t,e){var n;return null===e||isNaN(+e)||(S(s,"moment()."+s+"(period, number) is deprecated. Please use moment()."+s+"(number, period). See http://momentjs.com/guides/#/warnings/add-inverted-param/ for more info."),n=t,t=e,e=n),Qe(this,Be(t,e),i),this}}function Qe(t,e,n,i){var s=e._milliseconds,r=Re(e._days),o=Re(e._months);t.isValid()&&(i=null==i||i,o&&Ot(t,U(t,"Month")+o*n),r&&G(t,"Date",U(t,"Date")+r*n),s&&t._d.setTime(t._d.valueOf()+s*n),i&&p.updateOffset(t,r||o))}Be.fn=Oe.prototype,Be.invalid=function(){return Be(NaN)};var Ke=Ge(1,"add"),Xe=Ge(-1,"subtract");function Ze(t){return"string"==typeof t||t instanceof String}function Je(t){return x(t)||o(t)||Ze(t)||u(t)||function(e){var t=a(e),n=!1;t&&(n=0===e.filter(function(t){return!u(t)&&Ze(e)}).length);return t&&n}(t)||function(t){var e,n,i=l(t)&&!c(t),s=!1,r=["years","year","y","months","month","M","days","day","d","dates","date","D","hours","hour","h","minutes","minute","m","seconds","second","s","milliseconds","millisecond","ms"];for(e=0;e<r.length;e+=1)n=r[e],s=s||f(t,n);return i&&s}(t)||null==t}function tn(t,e){if(t.date()<e.date())return-tn(e,t);var n=12*(e.year()-t.year())+(e.month()-t.month()),i=t.clone().add(n,"months"),s=e-i<0?(e-i)/(i-t.clone().add(n-1,"months")):(e-i)/(t.clone().add(1+n,"months")-i);return-(n+s)||0}function en(t){var e;return void 0===t?this._locale._abbr:(null!=(e=de(t))&&(this._locale=e),this)}p.defaultFormat="YYYY-MM-DDTHH:mm:ssZ",p.defaultFormatUtc="YYYY-MM-DDTHH:mm:ss[Z]";var nn=n("moment().lang() is deprecated. Instead, use moment().localeData() to get the language configuration. Use moment().locale() to change languages.",function(t){return void 0===t?this.localeData():this.locale(t)});function sn(){return this._locale}var rn=126227808e5;function on(t,e){return(t%e+e)%e}function an(t,e,n){return t<100&&0<=t?new Date(t+400,e,n)-rn:new Date(t,e,n).valueOf()}function ln(t,e,n){return t<100&&0<=t?Date.UTC(t+400,e,n)-rn:Date.UTC(t,e,n)}function cn(t,e){return e.erasAbbrRegex(t)}function un(){for(var t=[],e=[],n=[],i=[],s=this.eras(),r=0,o=s.length;r<o;++r)e.push(ft(s[r].name)),t.push(ft(s[r].abbr)),n.push(ft(s[r].narrow)),i.push(ft(s[r].name)),i.push(ft(s[r].abbr)),i.push(ft(s[r].narrow));this._erasRegex=new RegExp("^("+i.join("|")+")","i"),this._erasNameRegex=new RegExp("^("+e.join("|")+")","i"),this._erasAbbrRegex=new RegExp("^("+t.join("|")+")","i"),this._erasNarrowRegex=new RegExp("^("+n.join("|")+")","i")}function dn(t,e){O(0,[t,t.length],0,e)}function hn(t,e,n,i,s){var r;return null==t?Yt(this,i,s).year:((r=qt(t,i,s))<e&&(e=r),function(t,e,n,i,s){var r=Wt(t,e,n,i,s),o=Ht(r.year,0,r.dayOfYear);return this.year(o.getUTCFullYear()),this.month(o.getUTCMonth()),this.date(o.getUTCDate()),this}.call(this,t,e,n,i,s))}O("N",0,0,"eraAbbr"),O("NN",0,0,"eraAbbr"),O("NNN",0,0,"eraAbbr"),O("NNNN",0,0,"eraName"),O("NNNNN",0,0,"eraNarrow"),O("y",["y",1],"yo","eraYear"),O("y",["yy",2],0,"eraYear"),O("y",["yyy",3],0,"eraYear"),O("y",["yyyy",4],0,"eraYear"),ht("N",cn),ht("NN",cn),ht("NNN",cn),ht("NNNN",function(t,e){return e.erasNameRegex(t)}),ht("NNNNN",function(t,e){return e.erasNarrowRegex(t)}),mt(["N","NN","NNN","NNNN","NNNNN"],function(t,e,n,i){var s=n._locale.erasParse(t,i,n._strict);s?m(n).era=s:m(n).invalidEra=t}),ht("y",at),ht("yy",at),ht("yyy",at),ht("yyyy",at),ht("yo",function(t,e){return e._eraYearOrdinalRegex||at}),mt(["y","yy","yyy","yyyy"],bt),mt(["yo"],function(t,e,n,i){var s;n._locale._eraYearOrdinalRegex&&(s=t.match(n._locale._eraYearOrdinalRegex)),n._locale.eraYearOrdinalParse?e[bt]=n._locale.eraYearOrdinalParse(t,s):e[bt]=parseInt(t,10)}),O(0,["gg",2],0,function(){return this.weekYear()%100}),O(0,["GG",2],0,function(){return this.isoWeekYear()%100}),dn("gggg","weekYear"),dn("ggggg","weekYear"),dn("GGGG","isoWeekYear"),dn("GGGGG","isoWeekYear"),j("weekYear","gg"),j("isoWeekYear","GG"),Y("weekYear",1),Y("isoWeekYear",1),ht("G",lt),ht("g",lt),ht("GG",et,X),ht("gg",et,X),ht("GGGG",rt,J),ht("gggg",rt,J),ht("GGGGG",ot,tt),ht("ggggg",ot,tt),yt(["gggg","ggggg","GGGG","GGGGG"],function(t,e,n,i){e[i.substr(0,2)]=B(t)}),yt(["gg","GG"],function(t,e,n,i){e[i]=p.parseTwoDigitYear(t)}),O("Q",0,"Qo","quarter"),j("quarter","Q"),Y("quarter",7),ht("Q",K),mt("Q",function(t,e){e[_t]=3*(B(t)-1)}),O("D",["DD",2],"Do","date"),j("date","D"),Y("date",9),ht("D",et),ht("DD",et,X),ht("Do",function(t,e){return t?e._dayOfMonthOrdinalParse||e._ordinalParse:e._dayOfMonthOrdinalParseLenient}),mt(["D","DD"],wt),mt("Do",function(t,e){e[wt]=B(t.match(et)[0])});var pn=V("Date",!0);O("DDD",["DDDD",3],"DDDo","dayOfYear"),j("dayOfYear","DDD"),Y("dayOfYear",4),ht("DDD",st),ht("DDDD",Z),mt(["DDD","DDDD"],function(t,e,n){n._dayOfYear=B(t)}),O("m",["mm",2],0,"minute"),j("minute","m"),Y("minute",14),ht("m",et),ht("mm",et,X),mt(["m","mm"],Ct);var fn=V("Minutes",!1);O("s",["ss",2],0,"second"),j("second","s"),Y("second",15),ht("s",et),ht("ss",et,X),mt(["s","ss"],kt);var gn,mn,yn=V("Seconds",!1);for(O("S",0,0,function(){return~~(this.millisecond()/100)}),O(0,["SS",2],0,function(){return~~(this.millisecond()/10)}),O(0,["SSS",3],0,"millisecond"),O(0,["SSSS",4],0,function(){return 10*this.millisecond()}),O(0,["SSSSS",5],0,function(){return 100*this.millisecond()}),O(0,["SSSSSS",6],0,function(){return 1e3*this.millisecond()}),O(0,["SSSSSSS",7],0,function(){return 1e4*this.millisecond()}),O(0,["SSSSSSSS",8],0,function(){return 1e5*this.millisecond()}),O(0,["SSSSSSSSS",9],0,function(){return 1e6*this.millisecond()}),j("millisecond","ms"),Y("millisecond",16),ht("S",st,K),ht("SS",st,X),ht("SSS",st,Z),gn="SSSS";gn.length<=9;gn+="S")ht(gn,at);function vn(t,e){e[St]=B(1e3*("0."+t))}for(gn="S";gn.length<=9;gn+="S")mt(gn,vn);mn=V("Milliseconds",!1),O("z",0,0,"zoneAbbr"),O("zz",0,0,"zoneName");var bn=w.prototype;function _n(t){return t}bn.add=Ke,bn.calendar=function(t,e){1===arguments.length&&(Je(arguments[0])?(t=arguments[0],e=void 0):function(t){for(var e=l(t)&&!c(t),n=!1,i=["sameDay","nextDay","lastDay","nextWeek","lastWeek","sameElse"],s=0;s<i.length;s+=1)n=n||f(t,i[s]);return e&&n}(arguments[0])&&(e=arguments[0],t=void 0));var n=t||Ne(),i=Fe(n,this).startOf("day"),s=p.calendarFormat(this,i)||"sameElse",r=e&&(T(e[s])?e[s].call(this,n):e[s]);return this.format(r||this.localeData().calendar(s,this,Ne(n)))},bn.clone=function(){return new w(this)},bn.diff=function(t,e,n){var i,s,r;if(!this.isValid())return NaN;if(!(i=Fe(t,this)).isValid())return NaN;switch(s=6e4*(i.utcOffset()-this.utcOffset()),e=H(e)){case"year":r=tn(this,i)/12;break;case"month":r=tn(this,i);break;case"quarter":r=tn(this,i)/3;break;case"second":r=(this-i)/1e3;break;case"minute":r=(this-i)/6e4;break;case"hour":r=(this-i)/36e5;break;case"day":r=(this-i-s)/864e5;break;case"week":r=(this-i-s)/6048e5;break;default:r=this-i}return n?r:z(r)},bn.endOf=function(t){var e,n;if(void 0===(t=H(t))||"millisecond"===t||!this.isValid())return this;switch(n=this._isUTC?ln:an,t){case"year":e=n(this.year()+1,0,1)-1;break;case"quarter":e=n(this.year(),this.month()-this.month()%3+3,1)-1;break;case"month":e=n(this.year(),this.month()+1,1)-1;break;case"week":e=n(this.year(),this.month(),this.date()-this.weekday()+7)-1;break;case"isoWeek":e=n(this.year(),this.month(),this.date()-(this.isoWeekday()-1)+7)-1;break;case"day":case"date":e=n(this.year(),this.month(),this.date()+1)-1;break;case"hour":e=this._d.valueOf(),e+=36e5-on(e+(this._isUTC?0:6e4*this.utcOffset()),36e5)-1;break;case"minute":e=this._d.valueOf(),e+=6e4-on(e,6e4)-1;break;case"second":e=this._d.valueOf(),e+=1e3-on(e,1e3)-1}return this._d.setTime(e),p.updateOffset(this,!0),this},bn.format=function(t){t=t||(this.isUtc()?p.defaultFormatUtc:p.defaultFormat);var e=P(this,t);return this.localeData().postformat(e)},bn.from=function(t,e){return this.isValid()&&(x(t)&&t.isValid()||Ne(t).isValid())?Be({to:this,from:t}).locale(this.locale()).humanize(!e):this.localeData().invalidDate()},bn.fromNow=function(t){return this.from(Ne(),t)},bn.to=function(t,e){return this.isValid()&&(x(t)&&t.isValid()||Ne(t).isValid())?Be({from:this,to:t}).locale(this.locale()).humanize(!e):this.localeData().invalidDate()},bn.toNow=function(t){return this.to(Ne(),t)},bn.get=function(t){return T(this[t=H(t)])?this[t]():this},bn.invalidAt=function(){return m(this).overflow},bn.isAfter=function(t,e){var n=x(t)?t:Ne(t);return!(!this.isValid()||!n.isValid())&&("millisecond"===(e=H(e)||"millisecond")?this.valueOf()>n.valueOf():n.valueOf()<this.clone().startOf(e).valueOf())},bn.isBefore=function(t,e){var n=x(t)?t:Ne(t);return!(!this.isValid()||!n.isValid())&&("millisecond"===(e=H(e)||"millisecond")?this.valueOf()<n.valueOf():this.clone().endOf(e).valueOf()<n.valueOf())},bn.isBetween=function(t,e,n,i){var s=x(t)?t:Ne(t),r=x(e)?e:Ne(e);return!!(this.isValid()&&s.isValid()&&r.isValid())&&(("("===(i=i||"()")[0]?this.isAfter(s,n):!this.isBefore(s,n))&&(")"===i[1]?this.isBefore(r,n):!this.isAfter(r,n)))},bn.isSame=function(t,e){var n,i=x(t)?t:Ne(t);return!(!this.isValid()||!i.isValid())&&("millisecond"===(e=H(e)||"millisecond")?this.valueOf()===i.valueOf():(n=i.valueOf(),this.clone().startOf(e).valueOf()<=n&&n<=this.clone().endOf(e).valueOf()))},bn.isSameOrAfter=function(t,e){return this.isSame(t,e)||this.isAfter(t,e)},bn.isSameOrBefore=function(t,e){return this.isSame(t,e)||this.isBefore(t,e)},bn.isValid=function(){return y(this)},bn.lang=nn,bn.locale=en,bn.localeData=sn,bn.max=Ae,bn.min=$e,bn.parsingFlags=function(){return h({},m(this))},bn.set=function(t,e){if("object"==typeof t)for(var n=function(t){var e,n=[];for(e in t)f(t,e)&&n.push({unit:e,priority:W[e]});return n.sort(function(t,e){return t.priority-e.priority}),n}(t=F(t)),i=0;i<n.length;i++)this[n[i].unit](t[n[i].unit]);else if(T(this[t=H(t)]))return this[t](e);return this},bn.startOf=function(t){var e,n;if(void 0===(t=H(t))||"millisecond"===t||!this.isValid())return this;switch(n=this._isUTC?ln:an,t){case"year":e=n(this.year(),0,1);break;case"quarter":e=n(this.year(),this.month()-this.month()%3,1);break;case"month":e=n(this.year(),this.month(),1);break;case"week":e=n(this.year(),this.month(),this.date()-this.weekday());break;case"isoWeek":e=n(this.year(),this.month(),this.date()-(this.isoWeekday()-1));break;case"day":case"date":e=n(this.year(),this.month(),this.date());break;case"hour":e=this._d.valueOf(),e-=on(e+(this._isUTC?0:6e4*this.utcOffset()),36e5);break;case"minute":e=this._d.valueOf(),e-=on(e,6e4);break;case"second":e=this._d.valueOf(),e-=on(e,1e3)}return this._d.setTime(e),p.updateOffset(this,!0),this},bn.subtract=Xe,bn.toArray=function(){return[this.year(),this.month(),this.date(),this.hour(),this.minute(),this.second(),this.millisecond()]},bn.toObject=function(){return{years:this.year(),months:this.month(),date:this.date(),hours:this.hours(),minutes:this.minutes(),seconds:this.seconds(),milliseconds:this.milliseconds()}},bn.toDate=function(){return new Date(this.valueOf())},bn.toISOString=function(t){if(!this.isValid())return null;var e=!0!==t,n=e?this.clone().utc():this;return n.year()<0||9999<n.year()?P(n,e?"YYYYYY-MM-DD[T]HH:mm:ss.SSS[Z]":"YYYYYY-MM-DD[T]HH:mm:ss.SSSZ"):T(Date.prototype.toISOString)?e?this.toDate().toISOString():new Date(this.valueOf()+60*this.utcOffset()*1e3).toISOString().replace("Z",P(n,"Z")):P(n,e?"YYYY-MM-DD[T]HH:mm:ss.SSS[Z]":"YYYY-MM-DD[T]HH:mm:ss.SSSZ")},bn.inspect=function(){if(!this.isValid())return"moment.invalid(/* "+this._i+" */)";var t,e,n,i="moment",s="";return this.isLocal()||(i=0===this.utcOffset()?"moment.utc":"moment.parseZone",s="Z"),t="["+i+'("]',e=0<=this.year()&&this.year()<=9999?"YYYY":"YYYYYY",n=s+'[")]',this.format(t+e+"-MM-DD[T]HH:mm:ss.SSS"+n)},"undefined"!=typeof Symbol&&null!=Symbol.for&&(bn[Symbol.for("nodejs.util.inspect.custom")]=function(){return"Moment<"+this.format()+">"}),bn.toJSON=function(){return this.isValid()?this.toISOString():null},bn.toString=function(){return this.clone().locale("en").format("ddd MMM DD YYYY HH:mm:ss [GMT]ZZ")},bn.unix=function(){return Math.floor(this.valueOf()/1e3)},bn.valueOf=function(){return this._d.valueOf()-6e4*(this._offset||0)},bn.creationData=function(){return{input:this._i,format:this._f,locale:this._locale,isUTC:this._isUTC,strict:this._strict}},bn.eraName=function(){for(var t,e=this.localeData().eras(),n=0,i=e.length;n<i;++n){if(t=this.startOf("day").valueOf(),e[n].since<=t&&t<=e[n].until)return e[n].name;if(e[n].until<=t&&t<=e[n].since)return e[n].name}return""},bn.eraNarrow=function(){for(var t,e=this.localeData().eras(),n=0,i=e.length;n<i;++n){if(t=this.startOf("day").valueOf(),e[n].since<=t&&t<=e[n].until)return e[n].narrow;if(e[n].until<=t&&t<=e[n].since)return e[n].narrow}return""},bn.eraAbbr=function(){for(var t,e=this.localeData().eras(),n=0,i=e.length;n<i;++n){if(t=this.startOf("day").valueOf(),e[n].since<=t&&t<=e[n].until)return e[n].abbr;if(e[n].until<=t&&t<=e[n].since)return e[n].abbr}return""},bn.eraYear=function(){for(var t,e,n=this.localeData().eras(),i=0,s=n.length;i<s;++i)if(t=n[i].since<=n[i].until?1:-1,e=this.startOf("day").valueOf(),n[i].since<=e&&e<=n[i].until||n[i].until<=e&&e<=n[i].since)return(this.year()-p(n[i].since).year())*t+n[i].offset;return this.year()},bn.year=jt,bn.isLeapYear=function(){return q(this.year())},bn.weekYear=function(t){return hn.call(this,t,this.week(),this.weekday(),this.localeData()._week.dow,this.localeData()._week.doy)},bn.isoWeekYear=function(t){return hn.call(this,t,this.isoWeek(),this.isoWeekday(),1,4)},bn.quarter=bn.quarters=function(t){return null==t?Math.ceil((this.month()+1)/3):this.month(3*(t-1)+this.month()%3)},bn.month=Pt,bn.daysInMonth=function(){return Et(this.year(),this.month())},bn.week=bn.weeks=function(t){var e=this.localeData().week(this);return null==t?e:this.add(7*(t-e),"d")},bn.isoWeek=bn.isoWeeks=function(t){var e=Yt(this,1,4).week;return null==t?e:this.add(7*(t-e),"d")},bn.weeksInYear=function(){var t=this.localeData()._week;return qt(this.year(),t.dow,t.doy)},bn.weeksInWeekYear=function(){var t=this.localeData()._week;return qt(this.weekYear(),t.dow,t.doy)},bn.isoWeeksInYear=function(){return qt(this.year(),1,4)},bn.isoWeeksInISOWeekYear=function(){return qt(this.isoWeekYear(),1,4)},bn.date=pn,bn.day=bn.days=function(t){if(!this.isValid())return null!=t?this:NaN;var e,n,i=this._isUTC?this._d.getUTCDay():this._d.getDay();return null!=t?(e=t,n=this.localeData(),t="string"!=typeof e?e:isNaN(e)?"number"==typeof(e=n.weekdaysParse(e))?e:null:parseInt(e,10),this.add(t-i,"d")):i},bn.weekday=function(t){if(!this.isValid())return null!=t?this:NaN;var e=(this.day()+7-this.localeData()._week.dow)%7;return null==t?e:this.add(t-e,"d")},bn.isoWeekday=function(t){if(!this.isValid())return null!=t?this:NaN;if(null==t)return this.day()||7;var e,n,i=(e=t,n=this.localeData(),"string"==typeof e?n.weekdaysParse(e)%7||7:isNaN(e)?null:e);return this.day(this.day()%7?i:i-7)},bn.dayOfYear=function(t){var e=Math.round((this.clone().startOf("day")-this.clone().startOf("year"))/864e5)+1;return null==t?e:this.add(t-e,"d")},bn.hour=bn.hours=ee,bn.minute=bn.minutes=fn,bn.second=bn.seconds=yn,bn.millisecond=bn.milliseconds=mn,bn.utcOffset=function(t,e,n){var i,s=this._offset||0;if(!this.isValid())return null!=t?this:NaN;if(null==t)return this._isUTC?s:We(this);if("string"==typeof t){if(null===(t=He(ut,t)))return this}else Math.abs(t)<16&&!n&&(t*=60);return!this._isUTC&&e&&(i=We(this)),this._offset=t,this._isUTC=!0,null!=i&&this.add(i,"m"),s!==t&&(!e||this._changeInProgress?Qe(this,Be(t-s,"m"),1,!1):this._changeInProgress||(this._changeInProgress=!0,p.updateOffset(this,!0),this._changeInProgress=null)),this},bn.utc=function(t){return this.utcOffset(0,t)},bn.local=function(t){return this._isUTC&&(this.utcOffset(0,t),this._isUTC=!1,t&&this.subtract(We(this),"m")),this},bn.parseZone=function(){var t;return null!=this._tzm?this.utcOffset(this._tzm,!1,!0):"string"==typeof this._i&&(null!=(t=He(ct,this._i))?this.utcOffset(t):this.utcOffset(0,!0)),this},bn.hasAlignedHourOffset=function(t){return!!this.isValid()&&(t=t?Ne(t).utcOffset():0,(this.utcOffset()-t)%60==0)},bn.isDST=function(){return this.utcOffset()>this.clone().month(0).utcOffset()||this.utcOffset()>this.clone().month(5).utcOffset()},bn.isLocal=function(){return!!this.isValid()&&!this._isUTC},bn.isUtcOffset=function(){return!!this.isValid()&&this._isUTC},bn.isUtc=Ye,bn.isUTC=Ye,bn.zoneAbbr=function(){return this._isUTC?"UTC":""},bn.zoneName=function(){return this._isUTC?"Coordinated Universal Time":""},bn.dates=n("dates accessor is deprecated. Use date instead.",pn),bn.months=n("months accessor is deprecated. Use month instead",Pt),bn.years=n("years accessor is deprecated. Use year instead",jt),bn.zone=n("moment().zone is deprecated, use moment().utcOffset instead. http://momentjs.com/guides/#/warnings/zone/",function(t,e){return null!=t?("string"!=typeof t&&(t=-t),this.utcOffset(t,e),this):-this.utcOffset()}),bn.isDSTShifted=n("isDSTShifted is deprecated. See http://momentjs.com/guides/#/warnings/dst-shifted/ for more information",function(){if(!r(this._isDSTShifted))return this._isDSTShifted;var t,e={};return _(e,this),(e=De(e))._a?(t=(e._isUTC?g:Ne)(e._a),this._isDSTShifted=this.isValid()&&0<function(t,e,n){for(var i=Math.min(t.length,e.length),s=Math.abs(t.length-e.length),r=0,o=0;o<i;o++)(n&&t[o]!==e[o]||!n&&B(t[o])!==B(e[o]))&&r++;return r+s}(e._a,t.toArray())):this._isDSTShifted=!1,this._isDSTShifted});var wn=E.prototype;function xn(t,e,n,i){var s=de(),r=g().set(i,e);return s[n](r,t)}function Cn(t,e,n){if(u(t)&&(e=t,t=void 0),t=t||"",null!=e)return xn(t,e,n,"month");for(var i=[],s=0;s<12;s++)i[s]=xn(t,s,n,"month");return i}function kn(t,e,n,i){e=("boolean"==typeof t?u(e)&&(n=e,e=void 0):(e=t,t=!1,u(n=e)&&(n=e,e=void 0)),e||"");var s,r=de(),o=t?r._week.dow:0,a=[];if(null!=n)return xn(e,(n+o)%7,i,"day");for(s=0;s<7;s++)a[s]=xn(e,(s+o)%7,i,"day");return a}wn.calendar=function(t,e,n){var i=this._calendar[t]||this._calendar.sameElse;return T(i)?i.call(e,n):i},wn.longDateFormat=function(t){var e=this._longDateFormat[t],n=this._longDateFormat[t.toUpperCase()];return e||!n?e:(this._longDateFormat[t]=n.match($).map(function(t){return"MMMM"===t||"MM"===t||"DD"===t||"dddd"===t?t.slice(1):t}).join(""),this._longDateFormat[t])},wn.invalidDate=function(){return this._invalidDate},wn.ordinal=function(t){return this._ordinal.replace("%d",t)},wn.preparse=_n,wn.postformat=_n,wn.relativeTime=function(t,e,n,i){var s=this._relativeTime[n];return T(s)?s(t,e,n,i):s.replace(/%d/i,t)},wn.pastFuture=function(t,e){var n=this._relativeTime[0<t?"future":"past"];return T(n)?n(e):n.replace(/%s/i,e)},wn.set=function(t){var e,n;for(n in t)f(t,n)&&(T(e=t[n])?this[n]=e:this["_"+n]=e);this._config=t,this._dayOfMonthOrdinalParseLenient=new RegExp((this._dayOfMonthOrdinalParse.source||this._ordinalParse.source)+"|"+/\d{1,2}/.source)},wn.eras=function(t,e){for(var n,i=this._eras||de("en")._eras,s=0,r=i.length;s<r;++s){switch(typeof i[s].since){case"string":n=p(i[s].since).startOf("day"),i[s].since=n.valueOf()}switch(typeof i[s].until){case"undefined":i[s].until=1/0;break;case"string":n=p(i[s].until).startOf("day").valueOf(),i[s].until=n.valueOf()}}return i},wn.erasParse=function(t,e,n){var i,s,r,o,a,l=this.eras();for(t=t.toUpperCase(),i=0,s=l.length;i<s;++i)if(r=l[i].name.toUpperCase(),o=l[i].abbr.toUpperCase(),a=l[i].narrow.toUpperCase(),n)switch(e){case"N":case"NN":case"NNN":if(o===t)return l[i];break;case"NNNN":if(r===t)return l[i];break;case"NNNNN":if(a===t)return l[i]}else if(0<=[r,o,a].indexOf(t))return l[i]},wn.erasConvertYear=function(t,e){var n=t.since<=t.until?1:-1;return void 0===e?p(t.since).year():p(t.since).year()+(e-t.offset)*n},wn.erasAbbrRegex=function(t){return f(this,"_erasAbbrRegex")||un.call(this),t?this._erasAbbrRegex:this._erasRegex},wn.erasNameRegex=function(t){return f(this,"_erasNameRegex")||un.call(this),t?this._erasNameRegex:this._erasRegex},wn.erasNarrowRegex=function(t){return f(this,"_erasNarrowRegex")||un.call(this),t?this._erasNarrowRegex:this._erasRegex},wn.months=function(t,e){return t?a(this._months)?this._months[t.month()]:this._months[(this._months.isFormat||At).test(e)?"format":"standalone"][t.month()]:a(this._months)?this._months:this._months.standalone},wn.monthsShort=function(t,e){return t?a(this._monthsShort)?this._monthsShort[t.month()]:this._monthsShort[At.test(e)?"format":"standalone"][t.month()]:a(this._monthsShort)?this._monthsShort:this._monthsShort.standalone},wn.monthsParse=function(t,e,n){var i,s,r;if(this._monthsParseExact)return function(t,e,n){var i,s,r,o=t.toLocaleLowerCase();if(!this._monthsParse)for(this._monthsParse=[],this._longMonthsParse=[],this._shortMonthsParse=[],i=0;i<12;++i)r=g([2e3,i]),this._shortMonthsParse[i]=this.monthsShort(r,"").toLocaleLowerCase(),this._longMonthsParse[i]=this.months(r,"").toLocaleLowerCase();return n?"MMM"===e?-1!==(s=vt.call(this._shortMonthsParse,o))?s:null:-1!==(s=vt.call(this._longMonthsParse,o))?s:null:"MMM"===e?-1!==(s=vt.call(this._shortMonthsParse,o))||-1!==(s=vt.call(this._longMonthsParse,o))?s:null:-1!==(s=vt.call(this._longMonthsParse,o))||-1!==(s=vt.call(this._shortMonthsParse,o))?s:null}.call(this,t,e,n);for(this._monthsParse||(this._monthsParse=[],this._longMonthsParse=[],this._shortMonthsParse=[]),i=0;i<12;i++){if(s=g([2e3,i]),n&&!this._longMonthsParse[i]&&(this._longMonthsParse[i]=new RegExp("^"+this.months(s,"").replace(".","")+"$","i"),this._shortMonthsParse[i]=new RegExp("^"+this.monthsShort(s,"").replace(".","")+"$","i")),n||this._monthsParse[i]||(r="^"+this.months(s,"")+"|^"+this.monthsShort(s,""),this._monthsParse[i]=new RegExp(r.replace(".",""),"i")),n&&"MMMM"===e&&this._longMonthsParse[i].test(t))return i;if(n&&"MMM"===e&&this._shortMonthsParse[i].test(t))return i;if(!n&&this._monthsParse[i].test(t))return i}},wn.monthsRegex=function(t){return this._monthsParseExact?(f(this,"_monthsRegex")||Rt.call(this),t?this._monthsStrictRegex:this._monthsRegex):(f(this,"_monthsRegex")||(this._monthsRegex=It),this._monthsStrictRegex&&t?this._monthsStrictRegex:this._monthsRegex)},wn.monthsShortRegex=function(t){return this._monthsParseExact?(f(this,"_monthsRegex")||Rt.call(this),t?this._monthsShortStrictRegex:this._monthsShortRegex):(f(this,"_monthsShortRegex")||(this._monthsShortRegex=Mt),this._monthsShortStrictRegex&&t?this._monthsShortStrictRegex:this._monthsShortRegex)},wn.week=function(t){return Yt(t,this._week.dow,this._week.doy).week},wn.firstDayOfYear=function(){return this._week.doy},wn.firstDayOfWeek=function(){return this._week.dow},wn.weekdays=function(t,e){var n=a(this._weekdays)?this._weekdays:this._weekdays[t&&!0!==t&&this._weekdays.isFormat.test(e)?"format":"standalone"];return!0===t?zt(n,this._week.dow):t?n[t.day()]:n},wn.weekdaysMin=function(t){return!0===t?zt(this._weekdaysMin,this._week.dow):t?this._weekdaysMin[t.day()]:this._weekdaysMin},wn.weekdaysShort=function(t){return!0===t?zt(this._weekdaysShort,this._week.dow):t?this._weekdaysShort[t.day()]:this._weekdaysShort},wn.weekdaysParse=function(t,e,n){var i,s,r;if(this._weekdaysParseExact)return function(t,e,n){var i,s,r,o=t.toLocaleLowerCase();if(!this._weekdaysParse)for(this._weekdaysParse=[],this._shortWeekdaysParse=[],this._minWeekdaysParse=[],i=0;i<7;++i)r=g([2e3,1]).day(i),this._minWeekdaysParse[i]=this.weekdaysMin(r,"").toLocaleLowerCase(),this._shortWeekdaysParse[i]=this.weekdaysShort(r,"").toLocaleLowerCase(),this._weekdaysParse[i]=this.weekdays(r,"").toLocaleLowerCase();return n?"dddd"===e?-1!==(s=vt.call(this._weekdaysParse,o))?s:null:"ddd"===e?-1!==(s=vt.call(this._shortWeekdaysParse,o))?s:null:-1!==(s=vt.call(this._minWeekdaysParse,o))?s:null:"dddd"===e?-1!==(s=vt.call(this._weekdaysParse,o))||-1!==(s=vt.call(this._shortWeekdaysParse,o))||-1!==(s=vt.call(this._minWeekdaysParse,o))?s:null:"ddd"===e?-1!==(s=vt.call(this._shortWeekdaysParse,o))||-1!==(s=vt.call(this._weekdaysParse,o))||-1!==(s=vt.call(this._minWeekdaysParse,o))?s:null:-1!==(s=vt.call(this._minWeekdaysParse,o))||-1!==(s=vt.call(this._weekdaysParse,o))||-1!==(s=vt.call(this._shortWeekdaysParse,o))?s:null}.call(this,t,e,n);for(this._weekdaysParse||(this._weekdaysParse=[],this._minWeekdaysParse=[],this._shortWeekdaysParse=[],this._fullWeekdaysParse=[]),i=0;i<7;i++){if(s=g([2e3,1]).day(i),n&&!this._fullWeekdaysParse[i]&&(this._fullWeekdaysParse[i]=new RegExp("^"+this.weekdays(s,"").replace(".","\\.?")+"$","i"),this._shortWeekdaysParse[i]=new RegExp("^"+this.weekdaysShort(s,"").replace(".","\\.?")+"$","i"),this._minWeekdaysParse[i]=new RegExp("^"+this.weekdaysMin(s,"").replace(".","\\.?")+"$","i")),this._weekdaysParse[i]||(r="^"+this.weekdays(s,"")+"|^"+this.weekdaysShort(s,"")+"|^"+this.weekdaysMin(s,""),this._weekdaysParse[i]=new RegExp(r.replace(".",""),"i")),n&&"dddd"===e&&this._fullWeekdaysParse[i].test(t))return i;if(n&&"ddd"===e&&this._shortWeekdaysParse[i].test(t))return i;if(n&&"dd"===e&&this._minWeekdaysParse[i].test(t))return i;if(!n&&this._weekdaysParse[i].test(t))return i}},wn.weekdaysRegex=function(t){return this._weekdaysParseExact?(f(this,"_weekdaysRegex")||Xt.call(this),t?this._weekdaysStrictRegex:this._weekdaysRegex):(f(this,"_weekdaysRegex")||(this._weekdaysRegex=Gt),this._weekdaysStrictRegex&&t?this._weekdaysStrictRegex:this._weekdaysRegex)},wn.weekdaysShortRegex=function(t){return this._weekdaysParseExact?(f(this,"_weekdaysRegex")||Xt.call(this),t?this._weekdaysShortStrictRegex:this._weekdaysShortRegex):(f(this,"_weekdaysShortRegex")||(this._weekdaysShortRegex=Qt),this._weekdaysShortStrictRegex&&t?this._weekdaysShortStrictRegex:this._weekdaysShortRegex)},wn.weekdaysMinRegex=function(t){return this._weekdaysParseExact?(f(this,"_weekdaysRegex")||Xt.call(this),t?this._weekdaysMinStrictRegex:this._weekdaysMinRegex):(f(this,"_weekdaysMinRegex")||(this._weekdaysMinRegex=Kt),this._weekdaysMinStrictRegex&&t?this._weekdaysMinStrictRegex:this._weekdaysMinRegex)},wn.isPM=function(t){return"p"===(t+"").toLowerCase().charAt(0)},wn.meridiem=function(t,e,n){return 11<t?n?"pm":"PM":n?"am":"AM"},ce("en",{eras:[{since:"0001-01-01",until:1/0,offset:1,name:"Anno Domini",narrow:"AD",abbr:"AD"},{since:"0000-12-31",until:-1/0,offset:1,name:"Before Christ",narrow:"BC",abbr:"BC"}],dayOfMonthOrdinalParse:/\d{1,2}(th|st|nd|rd)/,ordinal:function(t){var e=t%10;return t+(1===B(t%100/10)?"th":1==e?"st":2==e?"nd":3==e?"rd":"th")}}),p.lang=n("moment.lang is deprecated. Use moment.locale instead.",ce),p.langData=n("moment.langData is deprecated. Use moment.localeData instead.",de);var Sn=Math.abs;function Tn(t,e,n,i){var s=Be(e,n);return t._milliseconds+=i*s._milliseconds,t._days+=i*s._days,t._months+=i*s._months,t._bubble()}function Dn(t){return t<0?Math.floor(t):Math.ceil(t)}function En(t){return 4800*t/146097}function Nn(t){return 146097*t/4800}function $n(t){return function(){return this.as(t)}}var An=$n("ms"),Mn=$n("s"),In=$n("m"),On=$n("h"),Pn=$n("d"),Rn=$n("w"),Ln=$n("M"),jn=$n("Q"),Hn=$n("y");function Fn(t){return function(){return this.isValid()?this._data[t]:NaN}}var Wn=Fn("milliseconds"),Yn=Fn("seconds"),qn=Fn("minutes"),zn=Fn("hours"),Bn=Fn("days"),Vn=Fn("months"),Un=Fn("years");var Gn=Math.round,Qn={ss:44,s:45,m:45,h:22,d:26,w:null,M:11};function Kn(t,e,n,i){var s=Be(t).abs(),r=Gn(s.as("s")),o=Gn(s.as("m")),a=Gn(s.as("h")),l=Gn(s.as("d")),c=Gn(s.as("M")),u=Gn(s.as("w")),d=Gn(s.as("y")),h=(r<=n.ss?["s",r]:r<n.s&&["ss",r])||o<=1&&["m"]||o<n.m&&["mm",o]||a<=1&&["h"]||a<n.h&&["hh",a]||l<=1&&["d"]||l<n.d&&["dd",l];return null!=n.w&&(h=h||u<=1&&["w"]||u<n.w&&["ww",u]),(h=h||c<=1&&["M"]||c<n.M&&["MM",c]||d<=1&&["y"]||["yy",d])[2]=e,h[3]=0<+t,h[4]=i,function(t,e,n,i,s){return s.relativeTime(e||1,!!n,t,i)}.apply(null,h)}var Xn=Math.abs;function Zn(t){return(0<t)-(t<0)||+t}function Jn(){if(!this.isValid())return this.localeData().invalidDate();var t,e,n,i,s,r,o,a,l=Xn(this._milliseconds)/1e3,c=Xn(this._days),u=Xn(this._months),d=this.asSeconds();return d?(t=z(l/60),e=z(t/60),l%=60,t%=60,n=z(u/12),u%=12,i=l?l.toFixed(3).replace(/\.?0+$/,""):"",s=d<0?"-":"",r=Zn(this._months)!==Zn(d)?"-":"",o=Zn(this._days)!==Zn(d)?"-":"",a=Zn(this._milliseconds)!==Zn(d)?"-":"",s+"P"+(n?r+n+"Y":"")+(u?r+u+"M":"")+(c?o+c+"D":"")+(e||t||l?"T":"")+(e?a+e+"H":"")+(t?a+t+"M":"")+(l?a+i+"S":"")):"P0D"}var ti=Oe.prototype;return ti.isValid=function(){return this._isValid},ti.abs=function(){var t=this._data;return this._milliseconds=Sn(this._milliseconds),this._days=Sn(this._days),this._months=Sn(this._months),t.milliseconds=Sn(t.milliseconds),t.seconds=Sn(t.seconds),t.minutes=Sn(t.minutes),t.hours=Sn(t.hours),t.months=Sn(t.months),t.years=Sn(t.years),this},ti.add=function(t,e){return Tn(this,t,e,1)},ti.subtract=function(t,e){return Tn(this,t,e,-1)},ti.as=function(t){if(!this.isValid())return NaN;var e,n,i=this._milliseconds;if("month"===(t=H(t))||"quarter"===t||"year"===t)switch(e=this._days+i/864e5,n=this._months+En(e),t){case"month":return n;case"quarter":return n/3;case"year":return n/12}else switch(e=this._days+Math.round(Nn(this._months)),t){case"week":return e/7+i/6048e5;case"day":return e+i/864e5;case"hour":return 24*e+i/36e5;case"minute":return 1440*e+i/6e4;case"second":return 86400*e+i/1e3;case"millisecond":return Math.floor(864e5*e)+i;default:throw new Error("Unknown unit "+t)}},ti.asMilliseconds=An,ti.asSeconds=Mn,ti.asMinutes=In,ti.asHours=On,ti.asDays=Pn,ti.asWeeks=Rn,ti.asMonths=Ln,ti.asQuarters=jn,ti.asYears=Hn,ti.valueOf=function(){return this.isValid()?this._milliseconds+864e5*this._days+this._months%12*2592e6+31536e6*B(this._months/12):NaN},ti._bubble=function(){var t,e,n,i,s,r=this._milliseconds,o=this._days,a=this._months,l=this._data;return 0<=r&&0<=o&&0<=a||r<=0&&o<=0&&a<=0||(r+=864e5*Dn(Nn(a)+o),a=o=0),l.milliseconds=r%1e3,t=z(r/1e3),l.seconds=t%60,e=z(t/60),l.minutes=e%60,n=z(e/60),l.hours=n%24,o+=z(n/24),a+=s=z(En(o)),o-=Dn(Nn(s)),i=z(a/12),a%=12,l.days=o,l.months=a,l.years=i,this},ti.clone=function(){return Be(this)},ti.get=function(t){return t=H(t),this.isValid()?this[t+"s"]():NaN},ti.milliseconds=Wn,ti.seconds=Yn,ti.minutes=qn,ti.hours=zn,ti.days=Bn,ti.weeks=function(){return z(this.days()/7)},ti.months=Vn,ti.years=Un,ti.humanize=function(t,e){if(!this.isValid())return this.localeData().invalidDate();var n,i,s=!1,r=Qn;return"object"==typeof t&&(e=t,t=!1),"boolean"==typeof t&&(s=t),"object"==typeof e&&(r=Object.assign({},Qn,e),null!=e.s&&null==e.ss&&(r.ss=e.s-1)),n=this.localeData(),i=Kn(this,!s,r,n),s&&(i=n.pastFuture(+this,i)),n.postformat(i)},ti.toISOString=Jn,ti.toString=Jn,ti.toJSON=Jn,ti.locale=en,ti.localeData=sn,ti.toIsoString=n("toIsoString() is deprecated. Please use toISOString() instead (notice the capitals)",Jn),ti.lang=nn,O("X",0,0,"unix"),O("x",0,0,"valueOf"),ht("x",lt),ht("X",/[+-]?\d+(\.\d{1,3})?/),mt("X",function(t,e,n){n._d=new Date(1e3*parseFloat(t))}),mt("x",function(t,e,n){n._d=new Date(B(t))}),p.version="2.27.0",t=Ne,p.fn=bn,p.min=function(){return Me("isBefore",[].slice.call(arguments,0))},p.max=function(){return Me("isAfter",[].slice.call(arguments,0))},p.now=function(){return Date.now?Date.now():+new Date},p.utc=g,p.unix=function(t){return Ne(1e3*t)},p.months=function(t,e){return Cn(t,e,"months")},p.isDate=o,p.locale=ce,p.invalid=v,p.duration=Be,p.isMoment=x,p.weekdays=function(t,e,n){return kn(t,e,n,"weekdays")},p.parseZone=function(){return Ne.apply(null,arguments).parseZone()},p.localeData=de,p.isDuration=Pe,p.monthsShort=function(t,e){return Cn(t,e,"monthsShort")},p.weekdaysMin=function(t,e,n){return kn(t,e,n,"weekdaysMin")},p.defineLocale=ue,p.updateLocale=function(t,e){var n,i,s;return null!=e?(s=ie,null!=se[t]&&null!=se[t].parentLocale?se[t].set(D(se[t]._config,e)):(null!=(i=le(t))&&(s=i._config),e=D(s,e),null==i&&(e.abbr=t),(n=new E(e)).parentLocale=se[t],se[t]=n),ce(t)):null!=se[t]&&(null!=se[t].parentLocale?(se[t]=se[t].parentLocale,t===ce()&&ce(t)):null!=se[t]&&delete se[t]),se[t]},p.locales=function(){return i(se)},p.weekdaysShort=function(t,e,n){return kn(t,e,n,"weekdaysShort")},p.normalizeUnits=H,p.relativeTimeRounding=function(t){return void 0===t?Gn:"function"==typeof t&&(Gn=t,!0)},p.relativeTimeThreshold=function(t,e){return void 0!==Qn[t]&&(void 0===e?Qn[t]:(Qn[t]=e,"s"===t&&(Qn.ss=e-1),!0))},p.calendarFormat=function(t,e){var n=t.diff(e,"days",!0);return n<-6?"sameElse":n<-1?"lastWeek":n<0?"lastDay":n<1?"sameDay":n<2?"nextDay":n<7?"nextWeek":"sameElse"},p.prototype=bn,p.HTML5_FMT={DATETIME_LOCAL:"YYYY-MM-DDTHH:mm",DATETIME_LOCAL_SECONDS:"YYYY-MM-DDTHH:mm:ss",DATETIME_LOCAL_MS:"YYYY-MM-DDTHH:mm:ss.SSS",DATE:"YYYY-MM-DD",TIME:"HH:mm",TIME_SECONDS:"HH:mm:ss",TIME_MS:"HH:mm:ss.SSS",WEEK:"GGGG-[W]WW",MONTH:"YYYY-MM"},p}),function(t,e){"use strict";var n;if("object"==typeof exports){try{n=require("moment")}catch(t){}module.exports=e(n)}else"function"==typeof define&&define.amd?define(function(t){try{n=t("moment")}catch(t){}return e(n)}):t.Pikaday=e(t.moment)}(this,function(n){"use strict";function r(t,e,n,i){c?t.addEventListener(e,n,!!i):t.attachEvent("on"+e,n)}function e(t,e,n,i){c?t.removeEventListener(e,n,!!i):t.detachEvent("on"+e,n)}function o(t,e){return-1!==(" "+t.className+" ").indexOf(" "+e+" ")}function h(t,e){o(t,e)||(t.className=""===t.className?e:t.className+" "+e)}function p(t,e){var n;t.className=(n=(" "+t.className+" ").replace(" "+e+" "," ")).trim?n.trim():n.replace(/^\s+|\s+$/g,"")}function y(t){return/Array/.test(Object.prototype.toString.call(t))}function j(t){return/Date/.test(Object.prototype.toString.call(t))&&!isNaN(t.getTime())}function H(t,e){return[31,(n=t)%4==0&&n%100!=0||n%400==0?29:28,31,30,31,30,31,31,30,31,30,31][e];var n}function F(t){j(t)&&t.setHours(0,0,0,0)}function W(t,e){return t.getTime()===e.getTime()}function s(t,e,n){var i;f.createEvent?((i=f.createEvent("HTMLEvents")).initEvent(e,!0,!1),i=d(i,n),t.dispatchEvent(i)):f.createEventObject&&(i=f.createEventObject(),i=d(i,n),t.fireEvent("on"+e,i))}function i(t){return t.month<0&&(t.year-=Math.ceil(Math.abs(t.month)/12),t.month+=12),11<t.month&&(t.year+=Math.floor(Math.abs(t.month)/12),t.month-=12),t}function a(t,e,n){for(e+=t.firstDay;7<=e;)e-=7;return n?t.i18n.weekdaysShort[e]:t.i18n.weekdays[e]}function Y(t,e,n){return'<table cellpadding="0" cellspacing="0" class="pika-table" role="grid" aria-labelledby="'+n+'">'+function(t){var e,n=[];for(t.showWeekNumber&&n.push("<th></th>"),e=0;e<7;e++)n.push('<th scope="col"><abbr title="'+a(t,e)+'">'+a(t,e,!0)+"</abbr></th>");return"<thead><tr>"+(t.isRTL?n.reverse():n).join("")+"</tr></thead>"}(t)+"<tbody>"+e.join("")+"</tbody></table>"}function t(t){var i=this,s=i.config(t);i._onMouseDown=function(t){if(i._v){var e=(t=t||window.event).target||t.srcElement;if(e)if(o(e,"is-disabled")||(!o(e,"pika-button")||o(e,"is-empty")||o(e.parentNode,"is-disabled")?o(e,"pika-prev")?i.prevMonth():o(e,"pika-next")&&i.nextMonth():(i.setDate(new Date(e.getAttribute("data-pika-year"),e.getAttribute("data-pika-month"),e.getAttribute("data-pika-day"))),s.bound&&u(function(){i.hide(),s.blurFieldOnSelect&&s.field&&s.field.blur()},100))),o(e,"pika-select"))i._c=!0;else{if(!t.preventDefault)return t.returnValue=!1;t.preventDefault()}}},i._onChange=function(t){var e=(t=t||window.event).target||t.srcElement;e&&(o(e,"pika-select-month")?i.gotoMonth(e.value):o(e,"pika-select-year")&&i.gotoYear(e.value))},i._onKeyChange=function(t){if(t=t||window.event,i.isVisible())switch(t.keyCode){case 13:case 27:s.field&&s.field.blur();break;case 37:t.preventDefault(),i.adjustDate("subtract",1);break;case 38:i.adjustDate("subtract",7);break;case 39:i.adjustDate("add",1);break;case 40:i.adjustDate("add",7)}},i._onInputChange=function(t){var e;t.firedBy!==i&&(e=s.parse?s.parse(s.field.value,s.format):l?(e=n(s.field.value,s.format,s.formatStrict))&&e.isValid()?e.toDate():null:new Date(Date.parse(s.field.value)),j(e)&&i.setDate(e),i._v||i.show())},i._onInputFocus=function(){i.show()},i._onInputClick=function(){i.show()},i._onInputBlur=function(){var t=f.activeElement;do{if(o(t,"pika-single"))return}while(t=t.parentNode);i._c||(i._b=u(function(){i.hide()},50)),i._c=!1},i._onClick=function(t){var e=(t=t||window.event).target||t.srcElement,n=e;if(e){!c&&o(e,"pika-select")&&(e.onchange||(e.setAttribute("onchange","return;"),r(e,"change",i._onChange)));do{if(o(n,"pika-single")||n===s.trigger)return}while(n=n.parentNode);i._v&&e!==s.trigger&&n!==s.trigger&&i.hide()}},i.el=f.createElement("div"),i.el.className="pika-single"+(s.isRTL?" is-rtl":"")+(s.theme?" "+s.theme:""),r(i.el,"mousedown",i._onMouseDown,!0),r(i.el,"touchend",i._onMouseDown,!0),r(i.el,"change",i._onChange),s.keyboardInput&&r(f,"keydown",i._onKeyChange),s.field&&(s.container?s.container.appendChild(i.el):s.bound?f.body.appendChild(i.el):s.field.parentNode.insertBefore(i.el,s.field.nextSibling),r(s.field,"change",i._onInputChange),s.defaultDate||(l&&s.field.value?s.defaultDate=n(s.field.value,s.format).toDate():s.defaultDate=new Date(Date.parse(s.field.value)),s.setDefaultDate=!0));var e=s.defaultDate;j(e)?s.setDefaultDate?i.setDate(e,!0):i.gotoDate(e):i.gotoDate(new Date),s.bound?(this.hide(),i.el.className+=" is-bound",r(s.trigger,"click",i._onInputClick),r(s.trigger,"focus",i._onInputFocus),r(s.trigger,"blur",i._onInputBlur)):this.show()}var l="function"==typeof n,c=!!window.addEventListener,f=window.document,u=window.setTimeout,d=function(t,e,n){var i,s;for(i in e)(s=void 0!==t[i])&&"object"==typeof e[i]&&null!==e[i]&&void 0===e[i].nodeName?j(e[i])?n&&(t[i]=new Date(e[i].getTime())):y(e[i])?n&&(t[i]=e[i].slice(0)):t[i]=d({},e[i],n):!n&&s||(t[i]=e[i]);return t},g={field:null,bound:void 0,ariaLabel:"Use the arrow keys to pick a date",position:"bottom left",reposition:!0,format:"YYYY-MM-DD",toString:null,parse:null,defaultDate:null,setDefaultDate:!1,firstDay:0,formatStrict:!1,minDate:null,maxDate:null,yearRange:10,showWeekNumber:!1,pickWholeWeek:!1,minYear:0,maxYear:9999,minMonth:void 0,maxMonth:void 0,startRange:null,endRange:null,isRTL:!1,yearSuffix:"",showMonthAfterYear:!1,showDaysInNextAndPreviousMonths:!1,enableSelectionDaysInNextAndPreviousMonths:!1,numberOfMonths:1,mainCalendar:"left",container:void 0,blurFieldOnSelect:!0,i18n:{previousMonth:"Previous Month",nextMonth:"Next Month",months:["January","February","March","April","May","June","July","August","September","October","November","December"],weekdays:["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],weekdaysShort:["Sun","Mon","Tue","Wed","Thu","Fri","Sat"]},theme:null,events:[],onSelect:null,onOpen:null,onClose:null,onDraw:null,keyboardInput:!0};return t.prototype={config:function(t){this._o||(this._o=d({},g,!0));var e=d(this._o,t,!0);e.isRTL=!!e.isRTL,e.field=e.field&&e.field.nodeName?e.field:null,e.theme="string"==typeof e.theme&&e.theme?e.theme:null,e.bound=!!(void 0!==e.bound?e.field&&e.bound:e.field),e.trigger=e.trigger&&e.trigger.nodeName?e.trigger:e.field,e.disableWeekends=!!e.disableWeekends,e.disableDayFn="function"==typeof e.disableDayFn?e.disableDayFn:null;var n,i=parseInt(e.numberOfMonths,10)||1;return e.numberOfMonths=4<i?4:i,j(e.minDate)||(e.minDate=!1),j(e.maxDate)||(e.maxDate=!1),e.minDate&&e.maxDate&&e.maxDate<e.minDate&&(e.maxDate=e.minDate=!1),e.minDate&&this.setMinDate(e.minDate),e.maxDate&&this.setMaxDate(e.maxDate),y(e.yearRange)?(n=(new Date).getFullYear()-10,e.yearRange[0]=parseInt(e.yearRange[0],10)||n,e.yearRange[1]=parseInt(e.yearRange[1],10)||n):(e.yearRange=Math.abs(parseInt(e.yearRange,10))||g.yearRange,100<e.yearRange&&(e.yearRange=100)),e},toString:function(t){return t=t||this._o.format,j(this._d)?this._o.toString?this._o.toString(this._d,t):l?n(this._d).format(t):this._d.toDateString():""},getMoment:function(){return l?n(this._d):null},setMoment:function(t,e){l&&n.isMoment(t)&&this.setDate(t.toDate(),e)},getDate:function(){return j(this._d)?new Date(this._d.getTime()):null},setDate:function(t,e){if(!t)return this._d=null,this._o.field&&(this._o.field.value="",s(this._o.field,"change",{firedBy:this})),this.draw();var n,i;"string"==typeof t&&(t=new Date(Date.parse(t))),j(t)&&(n=this._o.minDate,i=this._o.maxDate,j(n)&&t<n?t=n:j(i)&&i<t&&(t=i),this._d=new Date(t.getTime()),F(this._d),this.gotoDate(this._d),this._o.field&&(this._o.field.value=this.toString(),s(this._o.field,"change",{firedBy:this})),e||"function"!=typeof this._o.onSelect||this._o.onSelect.call(this,this.getDate()))},gotoDate:function(t){var e,n,i,s=!0;j(t)&&(this.calendars&&(e=new Date(this.calendars[0].year,this.calendars[0].month,1),n=new Date(this.calendars[this.calendars.length-1].year,this.calendars[this.calendars.length-1].month,1),i=t.getTime(),n.setMonth(n.getMonth()+1),n.setDate(n.getDate()-1),s=i<e.getTime()||n.getTime()<i),s&&(this.calendars=[{month:t.getMonth(),year:t.getFullYear()}],"right"===this._o.mainCalendar&&(this.calendars[0].month+=1-this._o.numberOfMonths)),this.adjustCalendars())},adjustDate:function(t,e){var n,i=this.getDate()||new Date,s=24*parseInt(e)*60*60*1e3;"add"===t?n=new Date(i.valueOf()+s):"subtract"===t&&(n=new Date(i.valueOf()-s)),this.setDate(n)},adjustCalendars:function(){this.calendars[0]=i(this.calendars[0]);for(var t=1;t<this._o.numberOfMonths;t++)this.calendars[t]=i({month:this.calendars[0].month+t,year:this.calendars[0].year});this.draw()},gotoToday:function(){this.gotoDate(new Date)},gotoMonth:function(t){isNaN(t)||(this.calendars[0].month=parseInt(t,10),this.adjustCalendars())},nextMonth:function(){this.calendars[0].month++,this.adjustCalendars()},prevMonth:function(){this.calendars[0].month--,this.adjustCalendars()},gotoYear:function(t){isNaN(t)||(this.calendars[0].year=parseInt(t,10),this.adjustCalendars())},setMinDate:function(t){t instanceof Date?(F(t),this._o.minDate=t,this._o.minYear=t.getFullYear(),this._o.minMonth=t.getMonth()):(this._o.minDate=g.minDate,this._o.minYear=g.minYear,this._o.minMonth=g.minMonth,this._o.startRange=g.startRange),this.draw()},setMaxDate:function(t){t instanceof Date?(F(t),this._o.maxDate=t,this._o.maxYear=t.getFullYear(),this._o.maxMonth=t.getMonth()):(this._o.maxDate=g.maxDate,this._o.maxYear=g.maxYear,this._o.maxMonth=g.maxMonth,this._o.endRange=g.endRange),this.draw()},setStartRange:function(t){this._o.startRange=t},setEndRange:function(t){this._o.endRange=t},draw:function(t){if(this._v||t){var e,n=this._o,i=n.minYear,s=n.maxYear,r=n.minMonth,o=n.maxMonth,a="";this._y<=i&&(this._y=i,!isNaN(r)&&this._m<r&&(this._m=r)),this._y>=s&&(this._y=s,!isNaN(o)&&this._m>o&&(this._m=o)),e="pika-title-"+Math.random().toString(36).replace(/[^a-z]+/g,"").substr(0,2);for(var l=0;l<n.numberOfMonths;l++)a+='<div class="pika-lendar">'+function(t,e,n,i,s,r){for(var o,a,l,c=t._o,u=n===c.minYear,d=n===c.maxYear,h='<div id="'+r+'" class="pika-title" role="heading" aria-live="assertive">',p=!0,f=!0,g=[],m=0;m<12;m++)g.push('<option value="'+(n===s?m-e:12+m-e)+'"'+(m===i?' selected="selected"':"")+(u&&m<c.minMonth||d&&m>c.maxMonth?'disabled="disabled"':"")+">"+c.i18n.months[m]+"</option>");for(a='<div class="pika-label">'+c.i18n.months[i]+'<select class="pika-select pika-select-month" tabindex="-1">'+g.join("")+"</select></div>",o=y(c.yearRange)?(m=c.yearRange[0],c.yearRange[1]+1):(m=n-c.yearRange,1+n+c.yearRange),g=[];m<o&&m<=c.maxYear;m++)m>=c.minYear&&g.push('<option value="'+m+'"'+(m===n?' selected="selected"':"")+">"+m+"</option>");return l='<div class="pika-label">'+n+c.yearSuffix+'<select class="pika-select pika-select-year" tabindex="-1">'+g.join("")+"</select></div>",c.showMonthAfterYear?h+=l+a:h+=a+l,u&&(0===i||c.minMonth>=i)&&(p=!1),d&&(11===i||c.maxMonth<=i)&&(f=!1),0===e&&(h+='<button class="pika-prev'+(p?"":" is-disabled")+'" type="button">'+c.i18n.previousMonth+"</button>"),e===t._o.numberOfMonths-1&&(h+='<button class="pika-next'+(f?"":" is-disabled")+'" type="button">'+c.i18n.nextMonth+"</button>"),h+"</div>"}(this,l,this.calendars[l].year,this.calendars[l].month,this.calendars[0].year,e)+this.render(this.calendars[l].year,this.calendars[l].month,e)+"</div>";this.el.innerHTML=a,n.bound&&"hidden"!==n.field.type&&u(function(){n.trigger.focus()},1),"function"==typeof this._o.onDraw&&this._o.onDraw(this),n.bound&&n.field.setAttribute("aria-label",n.ariaLabel)}},adjustPosition:function(){var t,e,n,i,s,r,o,a,l,c,u,d;if(!this._o.container){if(this.el.style.position="absolute",e=t=this._o.trigger,n=this.el.offsetWidth,i=this.el.offsetHeight,s=window.innerWidth||f.documentElement.clientWidth,r=window.innerHeight||f.documentElement.clientHeight,o=window.pageYOffset||f.body.scrollTop||f.documentElement.scrollTop,d=u=!0,"function"==typeof t.getBoundingClientRect)a=(c=t.getBoundingClientRect()).left+window.pageXOffset,l=c.bottom+window.pageYOffset;else for(a=e.offsetLeft,l=e.offsetTop+e.offsetHeight;e=e.offsetParent;)a+=e.offsetLeft,l+=e.offsetTop;(this._o.reposition&&s<a+n||-1<this._o.position.indexOf("right")&&0<a-n+t.offsetWidth)&&(a=a-n+t.offsetWidth,u=!1),(this._o.reposition&&r+o<l+i||-1<this._o.position.indexOf("top")&&0<l-i-t.offsetHeight)&&(l=l-i-t.offsetHeight,d=!1),this.el.style.left=a+"px",this.el.style.top=l+"px",h(this.el,u?"left-aligned":"right-aligned"),h(this.el,d?"bottom-aligned":"top-aligned"),p(this.el,u?"right-aligned":"left-aligned"),p(this.el,d?"top-aligned":"bottom-aligned")}},render:function(t,e,n){var i=this._o,s=new Date,r=H(t,e),o=new Date(t,e,1).getDay(),a=[],l=[];F(s),0<i.firstDay&&(o-=i.firstDay)<0&&(o+=7);for(var c=0===e?11:e-1,u=11===e?0:e+1,d=0===e?t-1:t,h=11===e?t+1:t,p=H(d,c),f=r+o,g=f;7<g;)g-=7;f+=7-g;for(var m,y,v,b,_,w,x,C=!1,k=0,S=0;k<f;k++){var T=new Date(t,e,k-o+1),D=!!j(this._d)&&W(T,this._d),E=W(T,s),N=-1!==i.events.indexOf(T.toDateString()),$=k<o||r+o<=k,A=k-o+1,M=e,I=t,O=i.startRange&&W(i.startRange,T),P=i.endRange&&W(i.endRange,T),R=i.startRange&&i.endRange&&i.startRange<T&&T<i.endRange;$&&(I=k<o?(A=p+A,M=c,d):(A-=r,M=u,h));var L={day:A,month:M,year:I,hasEvent:N,isSelected:D,isToday:E,isDisabled:i.minDate&&T<i.minDate||i.maxDate&&T>i.maxDate||i.disableWeekends&&(x=void 0,0===(x=T.getDay())||6===x)||i.disableDayFn&&i.disableDayFn(T),isEmpty:$,isStartRange:O,isEndRange:P,isInRange:R,showDaysInNextAndPreviousMonths:i.showDaysInNextAndPreviousMonths,enableSelectionDaysInNextAndPreviousMonths:i.enableSelectionDaysInNextAndPreviousMonths};i.pickWholeWeek&&D&&(C=!0),l.push(function(t){var e=[],n="false";if(t.isEmpty){if(!t.showDaysInNextAndPreviousMonths)return'<td class="is-empty"></td>';e.push("is-outside-current-month"),t.enableSelectionDaysInNextAndPreviousMonths||e.push("is-selection-disabled")}return t.isDisabled&&e.push("is-disabled"),t.isToday&&e.push("is-today"),t.isSelected&&(e.push("is-selected"),n="true"),t.hasEvent&&e.push("has-event"),t.isInRange&&e.push("is-inrange"),t.isStartRange&&e.push("is-startrange"),t.isEndRange&&e.push("is-endrange"),'<td data-day="'+t.day+'" class="'+e.join(" ")+'" aria-selected="'+n+'"><button class="pika-button pika-day" type="button" data-pika-year="'+t.year+'" data-pika-month="'+t.month+'" data-pika-day="'+t.day+'">'+t.day+"</button></td>"}(L)),7==++S&&(i.showWeekNumber&&l.unshift((v=k-o,b=e,_=t,w=void 0,w=new Date(_,0,1),'<td class="pika-week">'+Math.ceil(((new Date(_,b,v)-w)/864e5+w.getDay()+1)/7)+"</td>")),a.push((m=l,y=i.isRTL,'<tr class="pika-row'+(i.pickWholeWeek?" pick-whole-week":"")+(C?" is-selected":"")+'">'+(y?m.reverse():m).join("")+"</tr>")),S=0,C=!(l=[]))}return Y(i,a,n)},isVisible:function(){return this._v},show:function(){this.isVisible()||(this._v=!0,this.draw(),p(this.el,"is-hidden"),this._o.bound&&(r(f,"click",this._onClick),this.adjustPosition()),"function"==typeof this._o.onOpen&&this._o.onOpen.call(this))},hide:function(){var t=this._v;!1!==t&&(this._o.bound&&e(f,"click",this._onClick),this.el.style.position="static",this.el.style.left="auto",this.el.style.top="auto",h(this.el,"is-hidden"),this._v=!1,void 0!==t&&"function"==typeof this._o.onClose&&this._o.onClose.call(this))},destroy:function(){var t=this._o;this.hide(),e(this.el,"mousedown",this._onMouseDown,!0),e(this.el,"touchend",this._onMouseDown,!0),e(this.el,"change",this._onChange),t.keyboardInput&&e(f,"keydown",this._onKeyChange),t.field&&(e(t.field,"change",this._onInputChange),t.bound&&(e(t.trigger,"click",this._onInputClick),e(t.trigger,"focus",this._onInputFocus),e(t.trigger,"blur",this._onInputBlur))),this.el.parentNode&&this.el.parentNode.removeChild(this.el)}},t}),function(s,n,O,h){"use strict";function p(t){return t&&t.hasOwnProperty&&t instanceof O}function f(t){return t&&"string"===O.type(t)}function P(t){return f(t)&&0<t.indexOf("%")}function R(t,e){var n=parseInt(t,10)||0;return e&&P(t)&&(n=j.getViewport()[e]/100*n),Math.ceil(n)}function L(t,e){return R(t,e)+"px"}var r=O("html"),o=O(s),c=O(n),j=O.fancybox=function(){j.open.apply(this,arguments)},a=navigator.userAgent.match(/msie/i),l=null,u=n.createTouch!==h;O.extend(j,{version:"2.1.5",defaults:{padding:15,margin:20,width:800,height:600,minWidth:100,minHeight:100,maxWidth:9999,maxHeight:9999,pixelRatio:1,autoSize:!0,autoHeight:!1,autoWidth:!1,autoResize:!0,autoCenter:!u,fitToView:!0,aspectRatio:!1,topRatio:.5,leftRatio:.5,scrolling:"auto",wrapCSS:"",arrows:!0,closeBtn:!0,closeClick:!1,nextClick:!1,mouseWheel:!0,autoPlay:!1,playSpeed:3e3,preload:3,modal:!1,loop:!0,ajax:{dataType:"html",headers:{"X-fancyBox":!0}},iframe:{scrolling:"auto",preload:!0},swf:{wmode:"transparent",allowfullscreen:"true",allowscriptaccess:"always"},keys:{next:{13:"left",34:"up",39:"left",40:"up"},prev:{8:"right",33:"down",37:"right",38:"down"},close:[27],play:[32],toggle:[70]},direction:{next:"left",prev:"right"},scrollOutside:!0,index:0,type:null,href:null,content:null,title:null,tpl:{wrap:'<div class="fancybox-wrap" tabIndex="-1"><div class="fancybox-skin"><div class="fancybox-outer"><div class="fancybox-inner"></div></div></div></div>',image:'<img class="fancybox-image" src="{href}" alt="" />',iframe:'<iframe id="fancybox-frame{rnd}" name="fancybox-frame{rnd}" class="fancybox-iframe" frameborder="0" vspace="0" hspace="0" webkitAllowFullScreen mozallowfullscreen allowFullScreen'+(a?' allowtransparency="true"':"")+"></iframe>",error:'<p class="fancybox-error">The requested content cannot be loaded.<br/>Please try again later.</p>',closeBtn:'<a title="Close" class="fancybox-item fancybox-close" href="javascript:;"></a>',next:'<a title="Next" class="fancybox-nav fancybox-next" href="javascript:;"><span></span></a>',prev:'<a title="Previous" class="fancybox-nav fancybox-prev" href="javascript:;"><span></span></a>'},openEffect:"fade",openSpeed:250,openEasing:"swing",openOpacity:!0,openMethod:"zoomIn",closeEffect:"fade",closeSpeed:250,closeEasing:"swing",closeOpacity:!0,closeMethod:"zoomOut",nextEffect:"elastic",nextSpeed:250,nextEasing:"swing",nextMethod:"changeIn",prevEffect:"elastic",prevSpeed:250,prevEasing:"swing",prevMethod:"changeOut",helpers:{overlay:!0,title:!0},onCancel:O.noop,beforeLoad:O.noop,afterLoad:O.noop,beforeShow:O.noop,afterShow:O.noop,beforeChange:O.noop,beforeClose:O.noop,afterClose:O.noop},group:{},opts:{},previous:null,coming:null,current:null,isActive:!1,isOpen:!1,isOpened:!1,wrap:null,skin:null,outer:null,inner:null,player:{timer:null,isActive:!1},ajaxLoad:null,imgPreload:null,transitions:{},helpers:{},open:function(u,d){if(u&&(O.isPlainObject(d)||(d={}),!1!==j.close(!0)))return O.isArray(u)||(u=p(u)?O(u).get():[u]),O.each(u,function(t,e){var n,i,s,r,o,a,l,c={};"object"===O.type(e)&&(e.nodeType&&(e=O(e)),p(e)?(c={href:e.data("fancybox-href")||e.attr("href"),title:e.data("fancybox-title")||e.attr("title"),isDom:!0,element:e},O.metadata&&O.extend(!0,c,e.metadata())):c=e),n=d.href||c.href||(f(e)?e:null),i=d.title!==h?d.title:c.title||"",!(r=(s=d.content||c.content)?"html":d.type||c.type)&&c.isDom&&(r=(r=e.data("fancybox-type"))||((o=e.prop("class").match(/fancybox\.(\w+)/))?o[1]:null)),f(n)&&(r||(j.isImage(n)?r="image":j.isSWF(n)?r="swf":"#"===n.charAt(0)?r="inline":f(e)&&(r="html",s=e)),"ajax"===r&&(n=(a=n.split(/\s+/,2)).shift(),l=a.shift())),s||("inline"===r?n?s=O(f(n)?n.replace(/.*(?=#[^\s]+$)/,""):n):c.isDom&&(s=e):"html"===r?s=n:r||n||!c.isDom||(r="inline",s=e)),O.extend(c,{href:n,type:r,content:s,title:i,selector:l}),u[t]=c}),j.opts=O.extend(!0,{},j.defaults,d),d.keys!==h&&(j.opts.keys=!!d.keys&&O.extend({},j.defaults.keys,d.keys)),j.group=u,j._start(j.opts.index)},cancel:function(){var t=j.coming;t&&!1!==j.trigger("onCancel")&&(j.hideLoading(),j.ajaxLoad&&j.ajaxLoad.abort(),j.ajaxLoad=null,j.imgPreload&&(j.imgPreload.onload=j.imgPreload.onerror=null),t.wrap&&t.wrap.stop(!0,!0).trigger("onReset").remove(),j.coming=null,j.current||j._afterZoomOut(t))},close:function(t){j.cancel(),!1!==j.trigger("beforeClose")&&(j.unbindEvents(),j.isActive&&(j.isOpen&&!0!==t?(j.isOpen=j.isOpened=!1,j.isClosing=!0,O(".fancybox-item, .fancybox-nav").remove(),j.wrap.stop(!0,!0).removeClass("fancybox-opened"),j.transitions[j.current.closeMethod]()):(O(".fancybox-wrap").stop(!0).trigger("onReset").remove(),j._afterZoomOut())))},play:function(t){function e(){clearTimeout(j.player.timer)}function n(){e(),j.current&&j.player.isActive&&(j.player.timer=setTimeout(j.next,j.current.playSpeed))}function i(){e(),c.unbind(".player"),j.player.isActive=!1,j.trigger("onPlayEnd")}!0===t||!j.player.isActive&&!1!==t?j.current&&(j.current.loop||j.current.index<j.group.length-1)&&(j.player.isActive=!0,c.bind({"onCancel.player beforeClose.player":i,"onUpdate.player":n,"beforeLoad.player":e}),n(),j.trigger("onPlayStart")):i()},next:function(t){var e=j.current;e&&(f(t)||(t=e.direction.next),j.jumpto(e.index+1,t,"next"))},prev:function(t){var e=j.current;e&&(f(t)||(t=e.direction.prev),j.jumpto(e.index-1,t,"prev"))},jumpto:function(t,e,n){var i=j.current;i&&(t=R(t),j.direction=e||i.direction[t>=i.index?"next":"prev"],j.router=n||"jumpto",i.loop&&(t<0&&(t=i.group.length+t%i.group.length),t%=i.group.length),i.group[t]!==h&&(j.cancel(),j._start(t)))},reposition:function(t,e){var n,i=j.current,s=i?i.wrap:null;s&&(n=j._getPosition(e),t&&"scroll"===t.type?(delete n.position,s.stop(!0,!0).animate(n,200)):(s.css(n),i.pos=O.extend({},i.dim,n)))},update:function(e){var n=e&&e.type,i=!n||"orientationchange"===n;i&&(clearTimeout(l),l=null),j.isOpen&&!l&&(l=setTimeout(function(){var t=j.current;t&&!j.isClosing&&(j.wrap.removeClass("fancybox-tmp"),(i||"load"===n||"resize"===n&&t.autoResize)&&j._setDimension(),"scroll"===n&&t.canShrink||j.reposition(e),j.trigger("onUpdate"),l=null)},i&&!u?0:300))},toggle:function(t){j.isOpen&&(j.current.fitToView="boolean"===O.type(t)?t:!j.current.fitToView,u&&(j.wrap.removeAttr("style").addClass("fancybox-tmp"),j.trigger("onUpdate")),j.update())},hideLoading:function(){c.unbind(".loading"),O("#fancybox-loading").remove()},showLoading:function(){var t,e;j.hideLoading(),t=O('<div id="fancybox-loading"><div></div></div>').click(j.cancel).appendTo("body"),c.bind("keydown.loading",function(t){27===(t.which||t.keyCode)&&(t.preventDefault(),j.cancel())}),j.defaults.fixed||(e=j.getViewport(),t.css({position:"absolute",top:.5*e.h+e.y,left:.5*e.w+e.x}))},getViewport:function(){var t=j.current&&j.current.locked||!1,e={x:o.scrollLeft(),y:o.scrollTop()};return t?(e.w=t[0].clientWidth,e.h=t[0].clientHeight):(e.w=u&&s.innerWidth?s.innerWidth:o.width(),e.h=u&&s.innerHeight?s.innerHeight:o.height()),e},unbindEvents:function(){j.wrap&&p(j.wrap)&&j.wrap.unbind(".fb"),c.unbind(".fb"),o.unbind(".fb")},bindEvents:function(){var e,l=j.current;l&&(o.bind("orientationchange.fb"+(u?"":" resize.fb")+(l.autoCenter&&!l.locked?" scroll.fb":""),j.update),(e=l.keys)&&c.bind("keydown.fb",function(n){var i=n.which||n.keyCode,t=n.target||n.srcElement;if(27===i&&j.coming)return!1;n.ctrlKey||n.altKey||n.shiftKey||n.metaKey||t&&(t.type||O(t).is("[contenteditable]"))||O.each(e,function(t,e){return 1<l.group.length&&e[i]!==h?(j[t](e[i]),n.preventDefault(),!1):-1<O.inArray(i,e)?(j[t](),n.preventDefault(),!1):void 0})}),O.fn.mousewheel&&l.mouseWheel&&j.wrap.bind("mousewheel.fb",function(t,e,n,i){for(var s,r=t.target||null,o=O(r),a=!1;o.length&&!(a||o.is(".fancybox-skin")||o.is(".fancybox-wrap"));)a=(s=o[0])&&!(s.style.overflow&&"hidden"===s.style.overflow)&&(s.clientWidth&&s.scrollWidth>s.clientWidth||s.clientHeight&&s.scrollHeight>s.clientHeight),o=O(o).parent();0===e||a||1<j.group.length&&!l.canShrink&&(0<i||0<n?j.prev(0<i?"down":"left"):(i<0||n<0)&&j.next(i<0?"up":"right"),t.preventDefault())}))},trigger:function(n,t){var e,i=t||j.coming||j.current;if(i){if(O.isFunction(i[n])&&(e=i[n].apply(i,Array.prototype.slice.call(arguments,1))),!1===e)return!1;i.helpers&&O.each(i.helpers,function(t,e){e&&j.helpers[t]&&O.isFunction(j.helpers[t][n])&&j.helpers[t][n](O.extend(!0,{},j.helpers[t].defaults,e),i)}),c.trigger(n)}},isImage:function(t){return f(t)&&t.match(/(^data:image\/.*,)|(\.(jp(e|g|eg)|gif|png|bmp|webp|svg)((\?|#).*)?$)/i)},isSWF:function(t){return f(t)&&t.match(/\.(swf)((\?|#).*)?$/i)},_start:function(t){var e,n,i,s,r,o={};if(t=R(t),!(e=j.group[t]||null))return!1;if(s=(o=O.extend(!0,{},j.opts,e)).margin,r=o.padding,"number"===O.type(s)&&(o.margin=[s,s,s,s]),"number"===O.type(r)&&(o.padding=[r,r,r,r]),o.modal&&O.extend(!0,o,{closeBtn:!1,closeClick:!1,nextClick:!1,arrows:!1,mouseWheel:!1,keys:null,helpers:{overlay:{closeClick:!1}}}),o.autoSize&&(o.autoWidth=o.autoHeight=!0),"auto"===o.width&&(o.autoWidth=!0),"auto"===o.height&&(o.autoHeight=!0),o.group=j.group,o.index=t,j.coming=o,!1!==j.trigger("beforeLoad")){if(i=o.type,n=o.href,!i)return j.coming=null,!(!j.current||!j.router||"jumpto"===j.router)&&(j.current.index=t,j[j.router](j.direction));if(j.isActive=!0,"image"!==i&&"swf"!==i||(o.autoHeight=o.autoWidth=!1,o.scrolling="visible"),"image"===i&&(o.aspectRatio=!0),"iframe"===i&&u&&(o.scrolling="scroll"),o.wrap=O(o.tpl.wrap).addClass("fancybox-"+(u?"mobile":"desktop")+" fancybox-type-"+i+" fancybox-tmp "+o.wrapCSS).appendTo(o.parent||"body"),O.extend(o,{skin:O(".fancybox-skin",o.wrap),outer:O(".fancybox-outer",o.wrap),inner:O(".fancybox-inner",o.wrap)}),O.each(["Top","Right","Bottom","Left"],function(t,e){o.skin.css("padding"+e,L(o.padding[t]))}),j.trigger("onReady"),"inline"===i||"html"===i){if(!o.content||!o.content.length)return j._error("content")}else if(!n)return j._error("href");"image"===i?j._loadImage():"ajax"===i?j._loadAjax():"iframe"===i?j._loadIframe():j._afterLoad()}else j.coming=null},_error:function(t){O.extend(j.coming,{type:"html",autoWidth:!0,autoHeight:!0,minWidth:0,minHeight:0,scrolling:"no",hasError:t,content:j.coming.tpl.error}),j._afterLoad()},_loadImage:function(){var t=j.imgPreload=new Image;t.onload=function(){this.onload=this.onerror=null,j.coming.width=this.width/j.opts.pixelRatio,j.coming.height=this.height/j.opts.pixelRatio,j._afterLoad()},t.onerror=function(){this.onload=this.onerror=null,j._error("image")},t.src=j.coming.href,!0!==t.complete&&j.showLoading()},_loadAjax:function(){var n=j.coming;j.showLoading(),j.ajaxLoad=O.ajax(O.extend({},n.ajax,{url:n.href,error:function(t,e){j.coming&&"abort"!==e?j._error("ajax",t):j.hideLoading()},success:function(t,e){"success"===e&&(n.content=t,j._afterLoad())}}))},_loadIframe:function(){var t=j.coming,e=O(t.tpl.iframe.replace(/\{rnd\}/g,(new Date).getTime())).attr("scrolling",u?"auto":t.iframe.scrolling).attr("src",t.href);O(t.wrap).bind("onReset",function(){try{O(this).find("iframe").hide().attr("src","//about:blank").end().empty()}catch(t){}}),t.iframe.preload&&(j.showLoading(),e.one("load",function(){O(this).data("ready",1),u||O(this).bind("load.fb",j.update),O(this).parents(".fancybox-wrap").width("100%").removeClass("fancybox-tmp").show(),j._afterLoad()})),t.content=e.appendTo(t.inner),t.iframe.preload||j._afterLoad()},_preloadImages:function(){for(var t,e=j.group,n=j.current,i=e.length,s=n.preload?Math.min(n.preload,i-1):0,r=1;r<=s;r+=1)"image"===(t=e[(n.index+r)%i]).type&&t.href&&((new Image).src=t.href)},_afterLoad:function(){var t,n,e,i,s,r,o=j.coming,a=j.current,l="fancybox-placeholder";if(j.hideLoading(),o&&!1!==j.isActive){if(!1===j.trigger("afterLoad",o,a))return o.wrap.stop(!0).trigger("onReset").remove(),void(j.coming=null);switch(a&&(j.trigger("beforeChange",a),a.wrap.stop(!0).removeClass("fancybox-opened").find(".fancybox-item, .fancybox-nav").remove()),j.unbindEvents(),n=(t=o).content,e=o.type,i=o.scrolling,O.extend(j,{wrap:t.wrap,skin:t.skin,outer:t.outer,inner:t.inner,current:t,previous:a}),s=t.href,e){case"inline":case"ajax":case"html":t.selector?n=O("<div>").html(n).find(t.selector):p(n)&&(n.data(l)||n.data(l,O('<div class="'+l+'"></div>').insertAfter(n).hide()),n=n.show().detach(),t.wrap.bind("onReset",function(){O(this).find(n).length&&n.hide().replaceAll(n.data(l)).data(l,!1)}));break;case"image":n=t.tpl.image.replace("{href}",s);break;case"swf":n='<object id="fancybox-swf" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" width="100%" height="100%"><param name="movie" value="'+s+'"></param>',r="",O.each(t.swf,function(t,e){n+='<param name="'+t+'" value="'+e+'"></param>',r+=" "+t+'="'+e+'"'}),n+='<embed src="'+s+'" type="application/x-shockwave-flash" width="100%" height="100%"'+r+"></embed></object>"}p(n)&&n.parent().is(t.inner)||t.inner.append(n),j.trigger("beforeShow"),t.inner.css("overflow","yes"===i?"scroll":"no"===i?"hidden":i),j._setDimension(),j.reposition(),j.isOpen=!1,j.coming=null,j.bindEvents(),j.isOpened?a.prevMethod&&j.transitions[a.prevMethod]():O(".fancybox-wrap").not(t.wrap).stop(!0).trigger("onReset").remove(),j.transitions[j.isOpened?t.nextMethod:t.openMethod](),j._preloadImages()}},_setDimension:function(){var t,e,n,i,s,r,o,a,l,c,u,d,h,p,f,g,m,y=j.getViewport(),v=0,b=j.wrap,_=j.skin,w=j.inner,x=j.current,C=x.width,k=x.height,S=x.minWidth,T=x.minHeight,D=x.maxWidth,E=x.maxHeight,N=x.scrolling,$=x.scrollOutside?x.scrollbarWidth:0,A=x.margin,M=R(A[1]+A[3]),I=R(A[0]+A[2]);if(b.add(_).add(w).width("auto").height("auto").removeClass("fancybox-tmp"),s=M+(n=R(_.outerWidth(!0)-_.width())),r=I+(i=R(_.outerHeight(!0)-_.height())),o=P(C)?(y.w-s)*R(C)/100:C,a=P(k)?(y.h-r)*R(k)/100:k,"iframe"===x.type){if(g=x.content,x.autoHeight&&1===g.data("ready"))try{g[0].contentWindow.document.location&&(w.width(o).height(9999),m=g.contents().find("body"),$&&m.css("overflow-x","hidden"),a=m.outerHeight(!0))}catch(t){}}else(x.autoWidth||x.autoHeight)&&(w.addClass("fancybox-tmp"),x.autoWidth||w.width(o),x.autoHeight||w.height(a),x.autoWidth&&(o=w.width()),x.autoHeight&&(a=w.height()),w.removeClass("fancybox-tmp"));if(C=R(o),k=R(a),u=o/a,S=R(P(S)?R(S,"w")-s:S),D=R(P(D)?R(D,"w")-s:D),T=R(P(T)?R(T,"h")-r:T),l=D,c=E=R(P(E)?R(E,"h")-r:E),x.fitToView&&(D=Math.min(y.w-s,D),E=Math.min(y.h-r,E)),p=y.w-M,f=y.h-I,x.aspectRatio?(D<C&&(k=R((C=D)/u)),E<k&&(C=R((k=E)*u)),C<S&&(k=R((C=S)/u)),k<T&&(C=R((k=T)*u))):(C=Math.max(S,Math.min(C,D)),x.autoHeight&&"iframe"!==x.type&&(w.width(C),k=w.height()),k=Math.max(T,Math.min(k,E))),x.fitToView)if(w.width(C).height(k),b.width(C+n),d=b.width(),h=b.height(),x.aspectRatio)for(;(p<d||f<h)&&S<C&&T<k&&!(19<v++);)k=Math.max(T,Math.min(E,k-10)),(C=R(k*u))<S&&(k=R((C=S)/u)),D<C&&(k=R((C=D)/u)),w.width(C).height(k),b.width(C+n),d=b.width(),h=b.height();else C=Math.max(S,Math.min(C,C-(d-p))),k=Math.max(T,Math.min(k,k-(h-f)));$&&"auto"===N&&k<a&&C+n+$<p&&(C+=$),w.width(C).height(k),b.width(C+n),d=b.width(),h=b.height(),t=(p<d||f<h)&&S<C&&T<k,e=x.aspectRatio?C<l&&k<c&&C<o&&k<a:(C<l||k<c)&&(C<o||k<a),O.extend(x,{dim:{width:L(d),height:L(h)},origWidth:o,origHeight:a,canShrink:t,canExpand:e,wPadding:n,hPadding:i,wrapSpace:h-_.outerHeight(!0),skinSpace:_.height()-k}),!g&&x.autoHeight&&T<k&&k<E&&!e&&w.height("auto")},_getPosition:function(t){var e=j.current,n=j.getViewport(),i=e.margin,s=j.wrap.width()+i[1]+i[3],r=j.wrap.height()+i[0]+i[2],o={position:"absolute",top:i[0],left:i[3]};return e.autoCenter&&e.fixed&&!t&&r<=n.h&&s<=n.w?o.position="fixed":e.locked||(o.top+=n.y,o.left+=n.x),o.top=L(Math.max(o.top,o.top+(n.h-r)*e.topRatio)),o.left=L(Math.max(o.left,o.left+(n.w-s)*e.leftRatio)),o},_afterZoomIn:function(){var e=j.current;e&&(j.isOpen=j.isOpened=!0,j.wrap.css("overflow","visible").addClass("fancybox-opened"),j.update(),(e.closeClick||e.nextClick&&1<j.group.length)&&j.inner.css("cursor","pointer").bind("click.fb",function(t){O(t.target).is("a")||O(t.target).parent().is("a")||(t.preventDefault(),j[e.closeClick?"close":"next"]())}),e.closeBtn&&O(e.tpl.closeBtn).appendTo(j.skin).bind("click.fb",function(t){t.preventDefault(),j.close()}),e.arrows&&1<j.group.length&&((e.loop||0<e.index)&&O(e.tpl.prev).appendTo(j.outer).bind("click.fb",j.prev),(e.loop||e.index<j.group.length-1)&&O(e.tpl.next).appendTo(j.outer).bind("click.fb",j.next)),j.trigger("afterShow"),e.loop||e.index!==e.group.length-1?j.opts.autoPlay&&!j.player.isActive&&(j.opts.autoPlay=!1,j.play()):j.play(!1))},_afterZoomOut:function(t){t=t||j.current,O(".fancybox-wrap").trigger("onReset").remove(),O.extend(j,{group:{},opts:{},router:!1,current:null,isActive:!1,isOpened:!1,isOpen:!1,isClosing:!1,wrap:null,skin:null,outer:null,inner:null}),j.trigger("afterClose",t)}}),j.transitions={getOrigPosition:function(){var t=j.current,e=t.element,n=t.orig,i={},s=50,r=50,o=t.hPadding,a=t.wPadding,l=j.getViewport();return!n&&t.isDom&&e.is(":visible")&&((n=e.find("img:first")).length||(n=e)),p(n)?(i=n.offset(),n.is("img")&&(s=n.outerWidth(),r=n.outerHeight())):(i.top=l.y+(l.h-r)*t.topRatio,i.left=l.x+(l.w-s)*t.leftRatio),"fixed"!==j.wrap.css("position")&&!t.locked||(i.top-=l.y,i.left-=l.x),i={top:L(i.top-o*t.topRatio),left:L(i.left-a*t.leftRatio),width:L(s+a),height:L(r+o)}},step:function(t,e){var n,i,s=e.prop,r=j.current,o=r.wrapSpace,a=r.skinSpace;"width"!==s&&"height"!==s||(n=e.end===e.start?1:(t-e.start)/(e.end-e.start),j.isClosing&&(n=1-n),i=t-("width"===s?r.wPadding:r.hPadding),j.skin[s](R("width"===s?i:i-o*n)),j.inner[s](R("width"===s?i:i-o*n-a*n)))},zoomIn:function(){var t=j.current,e=t.pos,n=t.openEffect,i="elastic"===n,s=O.extend({opacity:1},e);delete s.position,i?(e=this.getOrigPosition(),t.openOpacity&&(e.opacity=.1)):"fade"===n&&(e.opacity=.1),j.wrap.css(e).animate(s,{duration:"none"===n?0:t.openSpeed,easing:t.openEasing,step:i?this.step:null,complete:j._afterZoomIn})},zoomOut:function(){var t=j.current,e=t.closeEffect,n="elastic"===e,i={opacity:.1};n&&(i=this.getOrigPosition(),t.closeOpacity&&(i.opacity=.1)),j.wrap.animate(i,{duration:"none"===e?0:t.closeSpeed,easing:t.closeEasing,step:n?this.step:null,complete:j._afterZoomOut})},changeIn:function(){var t,e=j.current,n=e.nextEffect,i=e.pos,s={opacity:1},r=j.direction;i.opacity=.1,"elastic"===n&&(t="down"===r||"up"===r?"top":"left","down"===r||"right"===r?(i[t]=L(R(i[t])-200),s[t]="+=200px"):(i[t]=L(R(i[t])+200),s[t]="-=200px")),"none"===n?j._afterZoomIn():j.wrap.css(i).animate(s,{duration:e.nextSpeed,easing:e.nextEasing,complete:j._afterZoomIn})},changeOut:function(){var t=j.previous,e=t.prevEffect,n={opacity:.1},i=j.direction;"elastic"===e&&(n["down"===i||"up"===i?"top":"left"]=("up"===i||"left"===i?"-":"+")+"=200px"),t.wrap.animate(n,{duration:"none"===e?0:t.prevSpeed,easing:t.prevEasing,complete:function(){O(this).trigger("onReset").remove()}})}},j.helpers.overlay={defaults:{closeClick:!0,speedOut:200,showEarly:!0,css:{},locked:!u,fixed:!0},overlay:null,fixed:!1,el:O("html"),create:function(t){t=O.extend({},this.defaults,t),this.overlay&&this.close(),this.overlay=O('<div class="fancybox-overlay"></div>').appendTo(j.coming?j.coming.parent:t.parent),this.fixed=!1,t.fixed&&j.defaults.fixed&&(this.overlay.addClass("fancybox-overlay-fixed"),this.fixed=!0)},open:function(t){var e=this;t=O.extend({},this.defaults,t),this.overlay?this.overlay.unbind(".overlay").width("auto").height("auto"):this.create(t),this.fixed||(o.bind("resize.overlay",O.proxy(this.update,this)),this.update()),t.closeClick&&this.overlay.bind("click.overlay",function(t){if(O(t.target).hasClass("fancybox-overlay"))return j.isActive?j.close():e.close(),!1}),this.overlay.css(t.css).show()},close:function(){var t,e;o.unbind("resize.overlay"),this.el.hasClass("fancybox-lock")&&(O(".fancybox-margin").removeClass("fancybox-margin"),t=o.scrollTop(),e=o.scrollLeft(),this.el.removeClass("fancybox-lock"),o.scrollTop(t).scrollLeft(e)),O(".fancybox-overlay").remove().hide(),O.extend(this,{overlay:null,fixed:!1})},update:function(){var t,e="100%";this.overlay.width(e).height("100%"),a?(t=Math.max(n.documentElement.offsetWidth,n.body.offsetWidth),c.width()>t&&(e=c.width())):c.width()>o.width()&&(e=c.width()),this.overlay.width(e).height(c.height())},onReady:function(t,e){var n=this.overlay;O(".fancybox-overlay").stop(!0,!0),n||this.create(t),t.locked&&this.fixed&&e.fixed&&(n||(this.margin=c.height()>o.height()&&O("html").css("margin-right").replace("px","")),e.locked=this.overlay.append(e.wrap),e.fixed=!1),!0===t.showEarly&&this.beforeShow.apply(this,arguments)},beforeShow:function(t,e){var n,i;e.locked&&(!1!==this.margin&&(O("*").filter(function(){return"fixed"===O(this).css("position")&&!O(this).hasClass("fancybox-overlay")&&!O(this).hasClass("fancybox-wrap")}).addClass("fancybox-margin"),this.el.addClass("fancybox-margin")),n=o.scrollTop(),i=o.scrollLeft(),this.el.addClass("fancybox-lock"),o.scrollTop(n).scrollLeft(i)),this.open(t)},onUpdate:function(){this.fixed||this.update()},afterClose:function(t){this.overlay&&!j.coming&&this.overlay.fadeOut(t.speedOut,O.proxy(this.close,this))}},j.helpers.title={defaults:{type:"float",position:"bottom"},beforeShow:function(t){var e,n,i=j.current,s=i.title,r=t.type;if(O.isFunction(s)&&(s=s.call(i.element,i)),f(s)&&""!==O.trim(s)){switch(e=O('<div class="fancybox-title fancybox-title-'+r+'-wrap">'+s+"</div>"),r){case"inside":n=j.skin;break;case"outside":n=j.wrap;break;case"over":n=j.inner;break;default:n=j.skin,e.appendTo("body"),a&&e.width(e.width()),e.wrapInner('<span class="child"></span>'),j.current.margin[2]+=Math.abs(R(e.css("margin-bottom")))}e["top"===t.position?"prependTo":"appendTo"](n)}}},O.fn.fancybox=function(r){function t(t){var e,n,i=O(this).blur(),s=l;t.ctrlKey||t.altKey||t.shiftKey||t.metaKey||i.is(".fancybox-wrap")||(e=r.groupAttr||"data-fancybox-group",(n=i.attr(e))||(e="rel",n=i.get(0)[e]),n&&""!==n&&"nofollow"!==n&&(s=(i=(i=a.length?O(a):o).filter("["+e+'="'+n+'"]')).index(this)),r.index=s,!1!==j.open(i,r)&&t.preventDefault())}var o=O(this),a=this.selector||"",l=(r=r||{}).index||0;return a&&!1!==r.live?c.undelegate(a,"click.fb-start").delegate(a+":not('.fancybox-item, .fancybox-nav')","click.fb-start",t):o.unbind("click.fb-start").bind("click.fb-start",t),this.filter("[data-fancybox-start=1]").trigger("click"),this},c.ready(function(){var t,e,n,i;O.scrollbarWidth===h&&(O.scrollbarWidth=function(){var t=O('<div style="width:50px;height:50px;overflow:auto"><div/></div>').appendTo("body"),e=t.children(),n=e.innerWidth()-e.height(99).innerWidth();return t.remove(),n}),O.support.fixedPosition===h&&(O.support.fixedPosition=(n=O('<div style="position:fixed;top:20px;"></div>').appendTo("body"),i=20===n[0].offsetTop||15===n[0].offsetTop,n.remove(),i)),O.extend(j.defaults,{scrollbarWidth:O.scrollbarWidth(),fixed:O.support.fixedPosition,parent:O("body")}),t=O(s).width(),r.addClass("fancybox-lock-test"),e=O(s).width(),r.removeClass("fancybox-lock-test"),O("<style type='text/css'>.fancybox-margin{margin-right:"+(e-t)+"px;}</style>").appendTo("head")})}(window,document,jQuery),function(c){c.fn.rwdImageMaps=function(){var t=this;return c(window).resize(function(){t.each(function(){var n;void 0!==c(this).attr("usemap")&&(n=c(this),c("<img />").load(function(){var t,s=n.attr("width"),r=n.attr("height");s&&r||((t=new Image).src=n.attr("src"),s=s||t.width,r=r||t.height);var o=n.width()/100,a=n.height()/100,e=n.attr("usemap").replace("#",""),l="coords";c('map[name="'+e+'"]').find("area").each(function(){var t=c(this);t.data(l)||t.data(l,t.attr(l));for(var e=t.data(l).split(","),n=new Array(e.length),i=0;i<n.length;++i)n[i]=i%2==0?parseInt(e[i]/s*100*o):parseInt(e[i]/r*100*a);t.attr(l,n.toString())})}).attr("src",n.attr("src")))})}).trigger("resize"),this}}(jQuery);
function subNavInit(e){"use strict";var t=e(".drilldown[class*=col-]"),a=Math.max(window.innerWidth,e(window).width());a<=767&&!t.hasClass("collapse-enabled")?t.addClass("collapse-enabled").find(".drilldown-container").addClass("collapse").attr("id","collapseSubNav"):767<a&&t.hasClass("collapse-enabled")&&t.removeClass("collapse-enabled").find(".drilldown-container").removeClass("collapse in").attr("id","").css({height:"auto"})}function carouselInit(n){"use strict";var e=n(".carousel:not(.carousel-slideshow)");n(".carousel .item:first-child").addClass("first"),n(".carousel .item:last-child").addClass("last"),n(".carousel").each(function(){disableControl(n(this))}),e&&e.each(function(){var e=0,t=n(this).find("h3:first-child").height(),a=n(this).find(".carousel-img").height();n(this).find(".carousel-indicators").css("top",t+a+40),n(this).find(".carousel-control").css("top",t+a+50),n(this).find(".item").each(function(){n(this).height()>=e&&(e=n(this).height())}),n(this).find(".item").height(e)})}function disableControl(e){"use strict";e.find(".first").hasClass("active")?e.find(".left").addClass("disabled").attr("aria-disabled","true"):e.find(".left").removeClass("disabled").attr("aria-disabled","false"),e.find(".last").hasClass("active")?e.find(".right").addClass("disabled").attr("aria-disabled","true"):e.find(".right").removeClass("disabled").attr("aria-disabled","false")}!function(e){"use strict";e(".collapse:not(tbody)").on("show.bs.collapse",function(){e(this).prev().addClass("active icon--root").removeClass("icon--greater").attr({"aria-selected":"true","aria-expanded":"true"})}),e(".collapse:not(tbody)").on("hide.bs.collapse",function(){e(this).prev().removeClass("active icon--root").addClass("icon--greater").attr({"aria-selected":"false","aria-expanded":"false"})}),e("tbody.collapse").on("show.bs.collapse",function(){e(this).prev().find("[data-toggle=collapse]").addClass("active").attr({"aria-selected":"true","aria-expanded":"true"})}),e("tbody.collapse").on("hide.bs.collapse",function(){e(this).prev().find("[data-toggle=collapse]").removeClass("active").attr({"aria-selected":"false","aria-expanded":"false"})}),e('[aria-multiselectable="true"]').each(function(){e(this).find('[data-toggle="collapse"][data-parent]').first().attr({tabindex:0})})}(jQuery),function(){"use strict";jQuery(".drilldown").drilldown({event:"click",selector:"a",speed:100,cssClass:{container:"drilldown-container",root:"nav-page-list",sub:"drilldown-sub",back:"drilldown-back"}})}(),function(e){"use strict";e(window).scroll(function(){36<=e(this).scrollTop()?e(".nav-mobile").hasClass("fixed")||e(".nav-mobile").addClass("fixed").after('<div class="nav-mobile-spacer" id="spacer" style="height:36px;"></div>'):e(".nav-mobile").hasClass("fixed")&&(e(".nav-mobile").removeClass("fixed"),e("#spacer").remove())})}(jQuery),function(a){"use strict";var e=a(".yamm"),n=a(".yamm-close, .yamm-close-bottom"),t=a(".yamm .dropdown"),i=a(".yamm .dropdown-toggle");e.each(function(){var t=a(this);t.on("click",".dropdown-toggle",function(){var e;a(this).parent().hasClass("open")||(e=a(window).height()-49,t.find(".drilldown-container").height(e))})}),t.find("li a").removeAttr("tabindex"),i.on("click",function(){a(this).parents(t).trigger("get.hidden")}),t.on({"shown.bs.dropdown":function(){this.closable=!1},"get.hidden":function(){this.closable=!0}}),a(".dropdown").on("show.bs.dropdown",function(){t.removeClass("open"),e.removeClass("nav-open"),a(this).parents(e).addClass("nav-open")}),t.on("hide.bs.dropdown",function(){return this.closable&&e.removeClass("nav-open"),this.closable}),a(document).on("click",function(e){0<a(".dropdown.open").length&&0===a(e.target).parents(".dropdown").length&&a(".dropdown.open .dropdown-toggle").trigger("click")}),t.each(function(){var t=a(this);t.find(n).click(function(e){e.preventDefault(),t.find(i).trigger("click")})})}(jQuery),function(i){"use strict";var s=[];function e(e){i(".search-input",e).typeahead({hint:!1,highlight:!0,menu:i(".search-results .search-results-list",e),classNames:{suggestion:"",cursor:"active"}},s).on("typeahead:selected",function(e,t){e.preventDefault(),window.location.replace(t.link)}).on("typeahead:open",function(){i(this).closest(".global-search").addClass("focused")}).on("typeahead:close",function(){i(this).closest(".global-search").removeClass("focused")}).on("keyup",function(e){27===e.keyCode?i(this).closest("form").trigger("reset"):i(this).typeahead("val")?i(this).closest(".global-search").addClass("has-input"):i(this).closest(".global-search").removeClass("has-input")}),i("form",e).on("submit",function(){return!1}).on("reset",function(){i(".search-input",this).typeahead("val",""),i(this).closest(".global-search").removeClass("has-input")}),i(".search-reset",e).on("click",function(){i(this).closest("form").trigger("reset"),i(".search-input",e).focus()})}i(".dropdown.yamm-fw").each(function(){var e,t=i(".dropdown-toggle",i(this)).html(),a=i(".dropdown-menu li a",i(this)),n=[];a.each(function(){n.push({title:i(this).html(),link:i(this).attr("href")})}),n.length&&(e=new Bloodhound({initialize:!0,local:n,identify:function(e){return e.link},datumTokenizer:Bloodhound.tokenizers.obj.whitespace("title"),queryTokenizer:Bloodhound.tokenizers.whitespace}),s.push({display:"title",source:e,templates:{empty:function(){return['<li class="search-result-header">',t,"</li>","<li>",window.translations["global-search"]["nothing-found"],"</li>"].join("")},header:function(){return['<li class="search-result-header">',t,"</li>"].join("")},dataset:"<ul><ul>",suggestion:function(e){return'<li><a href="'+e.link+'">'+e.title+"</a></li>"}}}))}),e(i(".global-search-standard")),e(i(".global-search-mobile")),i(".nav-mobile .nav-mobile-menu").parent().on("show.bs.dropdown",function(){setTimeout(function(){i(".nav-mobile .search-input.tt-input").val(null).focus()},100)})}(jQuery),function(e){"use strict";e(document).ready(function(){e("select").chosen({disable_search_threshold:10,width:"auto"})})}(jQuery),function(e){"use strict";e("a.social-sharing-facebook").click(function(){return window.open("https://www.facebook.com/sharer/sharer.php?u="+encodeURIComponent(location.href),"facebook-share-dialog","width=626,height=436"),!1}),e("a.social-sharing-twitter").click(function(){return window.open("http://twitter.com/share?url="+encodeURIComponent(location.href),"twitter-share-dialog","width=626,height=436"),!1}),e("a.social-sharing-google").click(function(){return window.open("https://plus.google.com/share?url="+encodeURIComponent(location.href),"google-share-dialog","menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600"),!1}),e("a.social-sharing-xing").click(function(){return window.open("https://www.xing.com/spi/shares/new?url="+encodeURIComponent(location.href),"xing-share-dialog","width=626,height=436"),!1}),e("a.social-sharing-linkedin").click(function(){return window.open("https://www.linkedin.com/cws/share?url="+encodeURIComponent(location.href),"linkedin-share-dialog","width=626,height=436"),!1})}(jQuery),function(e){"use strict";subNavInit(jQuery),e(window).resize(function(){subNavInit(jQuery)}),e('a[href="#collapseSubNav"]').on("click",function(){e(this).attr("aria-expanded","true"===e(this).attr("aria-expanded")?"false":"true")})}(jQuery),function(){"use strict";jQuery(".table-sort").tablesorter({sortLocaleCompare:!0})}(),function(n){"use strict";n(".treecrumb").each(function(){var a=n(this);a.on("hide.bs.dropdown",function(){a.find(".dropdown-toggle span").removeClass("icon--bottom"),a.find(".dropdown-toggle span").addClass("icon--right")}),a.on("show.bs.dropdown",function(e){var t=e.relatedTarget;a.find(".dropdown-toggle span").removeClass("icon--bottom"),a.find(".dropdown-toggle span").addClass("icon--right"),n(t).find("span").removeClass("icon--right"),n(t).find("span").addClass("icon--bottom")})})}(jQuery),function(d){"use strict";var e,s={aria:function(){d("#ariaGallery").ariaLightbox({imageArray:"a.thumbnail-aria",altText:function(){return d(this).find("img").attr("alt")},descText:function(){return d(this).find("img").attr("title")},useDimmer:!0,pos:"auto",titleText:function(){return d(this).find("img").attr("alt")},em:!1})},getBreakPoint:function(){return window.getComputedStyle(document.querySelector("body"),":before").getPropertyValue("content").replace(/\"/g,"")},thumbnailResolution:function(e){var t=d(e).find("img[data-src]");"smartphone"===this.getBreakPoint()&&0<t.length&&(t.each(function(e,t){t.src=t.getAttribute("data-src")}),d(e).addClass("bigthumbs"))},waitAndCallThumbnailResolution:function(e,t){for(var a=e,n=0,i=0;i<a.length;i++)-1<a[i].className.indexOf("done")&&-1===a[i].className.indexOf("bigthumbs")&&(s.thumbnailResolution(a[i]),n+=1);a.length===n&&t()},on:function(){d(".mod.mod-ws_composed_gallery").find(".fancybox-buttons").fancybox({type:"image",closeBtn:!0,arrows:!0,nextClick:!0,helpers:{title:{type:"inside"},media:{},buttons:{}},afterLoad:function(){var e="";e=(e=d(".js-detail-link"+d(this.element).data("id")).html()).replace("##pos##",this.index+1).replace("##length##",this.group.length).replace("##title##",this.title||"").replace("##url##",d(this.element).data("detail-url")||""),this.title=e}})},after:function(){function e(c){var e=d(".mod-ws_composed_gallery figcaption");e&&e.each(function(e,t){var a=d(t),n=a.text(),i=a.attr("text-save"),s=parseInt(a.width()),o=parseInt(a.height()),r=parseFloat(a.css("lineHeight")),l=s<100?45:53;c?(a.removeClass("height"),a.text(i),r=parseFloat(a.css("lineHeight")),o=parseInt(a.height()),n=i):a.attr("text-save",n),o>Math.ceil(4*r)?a.html("<h5>"+n.substr(0,l).replace("...","")+"...</h5>"):a.html("<h5>"+n+"</h5>"),a.addClass("height")})}e(),d(window).resize(function(){clearTimeout(void 0);window.setTimeout(function(){e(!0)},500)})}},t=setInterval(function(){var e=document.getElementsByClassName("mod-dynamic")[0];e&&0<e.className.indexOf(" done")&&(s.on(),clearInterval(t))},100);s.after(),document.getElementsByClassName("mod-dynamic").length&&(e=window.setInterval(function(){s.waitAndCallThumbnailResolution(document.getElementsByClassName("mod-dynamic"),function(){window.clearInterval(e)})},10))}(jQuery),function(i){"use strict";function a(e){var t,a,n;e.preventDefault(),"keypress"===e.type&&13!==e.keyCode||(t=e.target,c=document.querySelector(s+'[data-component-id="'+function(e){for(;e.parentNode;){if(e.hasAttribute("data-component-id"))return e.getAttribute("data-component-id");e=e.parentNode}return null}(t)+'"]'),null!=(a=i(e.target,c).data("collaps-id"))&&(n=a,i(e.target,c).toggleClass(r),i(o+'[data-collaps-id="'+n+'"]',c).toggleClass(l)))}var s=".js-aramis",o=".js-collapsable-area",r="m-aramis__legend-collapsable--open",l="m-aramis__collapsable-area--open",c=null;i(".js-attach-listener").each(function(e,t){i(t).on("click.aramis",a),i(t).on("keypress.aramis",a)});var n=new MutationObserver(function(e){e.forEach(function(a){Array.prototype.slice.call(a.addedNodes).forEach(function(e){var t=a.target.lastChild.previousSibling;d(t)})})}),d=function(e){var t,a,n,i,s,o;e&&(t=e,a=parseInt(t.lastChild.dataset.optionArrayIndex),i=(n=t.parentNode.parentNode.previousSibling.options[a]).dataset.fcolor,s=n.dataset.bgcolor,(o=n.dataset.abbr||!1)&&(t.childNodes[0].innerHTML=o),t.style.color=i,t.style.backgroundColor=s)},u={childList:!0,subtree:!1,attributes:!1,characterData:!1};window.setTimeout(function(){jQuery(".chosen-choices").each(function(e,t){i(t).find(".search-choice").each(function(e,t){d(t)}),n.observe(t,u)})},300)}(jQuery),function(o,r){"use strict";o(".form-search, .mod-searchfield-mobile").each(function(e,t){var a,n=o(t),i=o(".js-form-control",n),s=(i.attr("placeholder"),i.hasClass("type-ahead"));r&&s&&((a=new Bloodhound({datumTokenizer:Bloodhound.tokenizers.obj.whitespace("value"),queryTokenizer:Bloodhound.tokenizers.whitespace,local:o.map(r,function(e){return{value:e}})})).initialize(),i.typeahead({hint:!0,highlight:!0,minLength:1},{name:"search",displayKey:"value",source:a.ttAdapter()})),n.find(".icon--close").click(function(){var e=o(this).parent().find(".form-control");return e.focus(),s?e.typeahead("val","dd"):e[0].value="",!1})})}(jQuery,"undefined"!=typeof searchData&&searchData),function(r){"use strict";r(window).load(function(){carouselInit(jQuery)});var l=0;r(".carousel-slideshow").each(function(e,t){l=r(t).find(".item").length,r(t).find(".carousel-total").text(l)}),r(".carousel-slideshow").on("slid.bs.carousel",function(){var e=r(this),t=e.find(".carousel-controls"),a=e.find(".carousel-inner .item.active");0===a.nextAll().length?t.find(".right").addClass("disabled").attr("aria-disabled","true"):t.find(".right").removeClass("disabled").attr("aria-disabled","false"),0===a.prevAll().length?t.find(".left").addClass("disabled").attr("aria-disabled","true"):t.find(".left").removeClass("disabled").attr("aria-disabled","false"),r(this).find(".carousel-total").text(l);var n=e.data("bs.carousel"),i=n.getItemIndex(n.$element.find(".item.active")),s=n.$items.length,o=i+1;e.find(".carousel-index").text(o),e.find(".carousel-total").text(s),disableControl(e)})}(jQuery),function(a){"use strict";function e(e,t){i?a.addEventListener(e,t):a.attachEvent("on"+e,t)}function t(e){n.styleSheet?n.styleSheet.cssText=e:n.innerHTML=e}var n=a.createElement("STYLE"),i="addEventListener"in a;a.getElementsByTagName("HEAD")[0].appendChild(n),e("mousedown",function(){t(".chosen-container-active .chosen-single,:focus{outline:0!important}::-moz-focus-inner,.chosen-container-active .chosen-single{border:0!important}")}),e("mousemove",function(){t(".chosen-container-active .chosen-single:focus,:focus{outline:0!important}::-moz-focus-inner,.chosen-container-active .chosen-single:focus {border:0!important}")}),e("keydown",function(){t("")})}(document),function(l){"use strict";var e=l("body"),c=null,d=l("#content textarea"),u=e.find(".nav-mobile, textarea, .drilldown, .nav-main, .header-separator, .nav-service, .nav-lang, .form-search, .yamm--select, footer, .alert, .icon--print, .social-sharing, .nav-process, .carousel-indicators, .carousel-control, .breadcrumb, .pagination-container");l.fn.printPreview=function(){return this},l.printPreview={printPreview:function(e){var t,a=l("body"),n=l(".container-main"),i=l("#content"),s="",o=0;c=l('<div class="container container-main print-element"></div>'),u.hide(),e&&(e=l("[data-print="+e+"]").clone(),l("header").clone(),t=e.attr("data-title")?"<h1>"+e.attr("data-title")+"</h1>":"",c.html("").append(t,e),c.insertBefore(n),n.hide()),a.addClass("print-preview");var r=l('<div class="row" id="print-settings"><div class="col-sm-12"><nav class="pagination-container clearfix"><span class="pull-left"><input type="checkbox" id="footnote-links">&nbsp;&nbsp;<label for="footnote-links">Links as footnotes</label>&nbsp;&nbsp;&nbsp;&nbsp;<input type="checkbox" id="text-links">&nbsp;&nbsp;<label for="text-links">Links in text</label></span><ul class="pull-right"><li><button id="print-button" title="print" class="btn"><span class="icon icon--print"></span></button>&nbsp;&nbsp;<button id="close-button" title="close" class="btn btn-secondary"><span class="icon icon--close"></span></button></li></ul></nav></div></div>');n.prepend(r),e&&c.prepend(r),l("#print-button").click(function(){l.printPreview.printProcess()}),l("#close-button").click(function(){l.printPreview.printClose()}),l("#content a").not(".access-keys a").each(function(){var e=l(this).attr("href");"undefined"!==(e=String(e))&&0===e.indexOf("http")&&(s+="<li>"+e+"</li>",l('<sup class="link-ref print-only">('+ ++o+")</sup>").insertAfter(this))}),l("#footnote-links").change(function(){this.checked?(n.append('<div id="footnote-links-wrapper" class="row footnote-links-wrapper"><div class="col-sm-12"><h3>Page Links</h3><hr><ol>'+s+"</ol></div></div>"),a.addClass("print-footnotes")):(l("#footnote-links-wrapper").remove(),a.removeClass("print-footnotes"))}),l("#text-links").change(function(){this.checked?i.addClass("show-link-urls"):i.removeClass("show-link-urls")}),d.each(function(){l('<div class="textarea-style print-only">'+l(this).val()+"</div>").insertBefore(l(this))})},printProcess:function(){window.print()},printClose:function(){l("#print-settings, #footnote-links-wrapper").remove(),l("#content").removeClass("show-link-urls"),e.removeClass("print-preview"),e.find(".print-only").remove(),c.remove(),l(".container-main").css("display",""),u.css("display","")}}}(jQuery),function(r){"use strict";r(document).ready(function(){var e,o=!1,n=!1;function t(){a(),i()}function a(){var e,t,a,i,n=r(".tab-focus"),s=0;n&&r(window).width()<=767&&!o?(o=!0,0<=(a=(e=document.location.pathname).substring(e.indexOf(".html"))).toLowerCase().indexOf("/teaserfocus")&&(t=a.lastIndexOf("/")+1,i=(a=a.substring(t)).substring(0,a.indexOf(".html"))),n.each(function(){var e=r(this),t=-1;s+=1,e.attr("id","tab-focus-"+s),e.next(".nav-tabs").hide(),e.addClass("carousel slide").removeClass("tab-content tab-border").attr("data-interval",0),e.wrapInner('<div class="carousel-inner"></div>'),e.prepend('<ol class="carousel-indicators"></ol>');var a,n=-1;null!==i&&(a=e.find('.carousel-inner div[id*="'+i+'"]')).length&&1===a.length&&(n=a.index()-1),e.find(".tab-pane").each(function(){t+=1,r(this).removeClass("tab-pane in active").addClass("item"),-1!==n&&t===n?e.find(".carousel-indicators").append('<li class="active" data-target="#tab-focus-'+s+'" data-slide-to="'+t+'"></li>'):e.find(".carousel-indicators").append('<li data-target="#tab-focus-'+s+'" data-slide-to="'+t+'"></li>')}),a.length?a.addClass("active"):(e.find(".item:first").addClass("active"),e.find(".carousel-indicators li:first-child").addClass("active")),e.append('<a class="left carousel-control icon icon--before icon--less" href="#tab-focus-'+s+'" data-slide="prev" aria-label="previous"></a><a class="right carousel-control icon icon--before icon--greater" href="#tab-focus-'+s+'" data-slide="next" aria-label="next"></a>')})):n&&767<r(window).width()&&o&&(o=!1,n.each(function(){var e=r(this);--s,e.attr("id",""),e.next(".nav-tabs-focus").css("display","flex"),e.removeClass("carousel slide").addClass("tab-content tab-border"),e.find("ol.carousel-indicators").remove(),e.find(".item").each(function(){r(this).addClass("tab-pane").removeClass("item"),r(this).css("height","auto")}),e.find(".tab-pane:first-child").addClass("active in"),e.find(".tab-pane").parent().hasClass("carousel-inner")&&e.find(".tab-pane").unwrap(),e.find(".carousel-control").remove()}))}function i(){var e=r(".nav-tabs:not(.focus)"),t=r(".collapsify"),a=0;e&&r(window).width()<=767&&!n?(n=!0,e.not(".tab-focus").each(function(){var e=r(this);e.removeClass("nav-tabs").addClass("collapsify"),e.next(".tab-content").hide(),e.find("a").each(function(){var e=r(this).attr("href");a+=1,r(this).unwrap(),r('<div class="collapse" id="collapse-'+a+'">'+r(e).html()+"</div>").insertAfter(this),r(this).attr("data-toggle","collapse"),r(this).attr("data-target","#collapse-"+a),r(this).addClass("collapse-closed"),r(this).click(function(){r(this).toggleClass("collapse-closed")})})})):t&&767<r(window).width()&&n&&(n=!1,t.each(function(){var e=r(this);e.addClass("nav-tabs").removeClass("collapsify"),e.next(".tab-content").show(),e.find("a").each(function(){--a,r(this).wrap("<li></li>"),r(this).parent().next(".collapse").remove(),r(this).attr("data-toggle","tab"),r(this).attr("data-target",""),r(this).removeClass("collapse-closed")}),e.find("li a").each(function(){var e=r(this).attr("href");r(e).hasClass("active")&&r(this).parent().addClass("active")})}))}a(),i(),r(window).resize(function(){clearTimeout(e),e=setTimeout(t,500)})})}(jQuery),function(t){"use strict";function e(e){this.$wrapper=t(e).parent(),this.domNodes=".tab-focus, .nav-tabs-focus",this.delay=t(e).data("interval")||0,this.playing=null,this.interval=null,this.$wrapper.on("click",".nav-tabs-focus",function(){this.pause(null,!0)}.bind(this)).on("click",".tab-focus-control",function(){this.playing?this.pause(null,!0):this.play(null,!0)}.bind(this)),this.play(null,!0)}e.prototype={addListeners:function(){this.$wrapper.on("mouseenter.tabfocus focus.tabfocus",this.domNodes,this.pause.bind(this)).on("mouseleave.tabfocus blur.tabfocus",this.domNodes,this.play.bind(this))},removeListeners:function(){this.$wrapper.off("mouseenter.tabfocus focus.tabfocus",this.domNodes).off("mouseleave.tabfocus blur.tabfocus",this.domNodes)},play:function(e,t){this.interval&&clearInterval(this.interval),0<this.delay&&(this.interval=setInterval(this.slide.bind(this),this.delay)),t&&(this.playing=!0,this.addListeners(),this.$wrapper.find(".tab-focus-control .icon").removeClass("icon--play").addClass("icon--pause"))},pause:function(e,t){clearInterval(this.interval),t&&(this.playing=!1,this.removeListeners(),this.$wrapper.find(".tab-focus-control .icon").removeClass("icon--pause").addClass("icon--play"))},slide:function(){var e,t,a=this.$wrapper.find(".nav-tabs-focus");if(a.is(":hidden"))return this.pause(null,!0);a.find("> li").length&&((t=(e=this.$wrapper.find(".nav-tabs-focus > li")).filter(".active").next("li")).length?t.find("a"):e.eq(0).find("a")).tab("show")}},t.fn.tabFocus=function(){return this.each(function(){t.data(this,"TabFocus")||t.data(this,"TabFocus",new e(this))})},t(".tab-focus").tabFocus()}(jQuery),function(t){"use strict";var a={en:{previousMonth:"Previous Month",nextMonth:"Next Month",months:["January","February","March","April","May","June","July","August","September","October","November","December"],weekdays:["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],weekdaysShort:["Sun","Mon","Tue","Wed","Thu","Fri","Sat"]},de:{previousMonth:"Vorheriger Monat",nextMonth:"Nächster Monat",months:["Januar","Februar","M&auml;rz","April","Mai","Juni","Juli","August","September","Oktober","November","Dezember"],weekdays:["Sonntag","Montag","Dienstag","Mittwoch","Donnerstag","Freitag","Samstag"],weekdaysShort:["So.","Mo.","Di.","Mi.","Do.","Fr.","Sa."]},fr:{previousMonth:"Pr&eacute;c&eacute;dent",nextMonth:"Suivant",months:["janvier","f&eacute;vrier","mars","avril","mai","juin","juillet","ao&ucirc;t","septembre","octobre","novembre","d&eacute;cembre"],weekdays:["dimanche","lundi","mardi","mercredi","jeudi","vendredi","samedi"],weekdaysShort:["dim.","lun.","mar.","mer.","jeu.","ven.","sam."]},it:{previousMonth:"&#x3C;Prec",nextMonth:"Succ&#x3E;",months:["Gennaio","Febbraio","Marzo","Aprile","Maggio","Giugno","Luglio","Agosto","Settembre","Ottobre","Novembre","Dicembre"],weekdays:["Domenica","Luned&igrave;","Marted&igrave;","Mercoled&igrave;","Gioved&igrave;","Venerd&igrave;","Sabato"],weekdaysShort:["Dom","Lun","Mar","Mer","Gio","Ven","Sab"]}},e=t("input.datumfeld, .js-datepicker, .js-datepicker-to, .js-datepicker-from"),n=t("html").attr("lang")||"en";e.each(function(){var e=t(this).data("format")||"DD.MM.YYYY";t(this).attr("title","Format "+e.toLowerCase());new Pikaday({field:t(this)[0],i18n:a[n],format:e});t(this).data("picker-instance")})}(jQuery),function(u){"use strict";u(document).ready(function(){u(".js-expandable").each(function(e,t){var a,n,i,s,o,r=u(this),l=r.data("expandable-ellipsis")||"...",c=r.data("expandable-ellipsis-prefix")||"",d=parseInt(r.data("expandable-lines")||3);n=l,i=c,s=function(e,t){return parseInt(e.css("line-height"),10)*t}(a=r,d),o=a.attr("style"),a.show().dotdotdot({ellipsis:i,wrap:"word",fallbackToLetter:!0,height:s,after:u('<a href="#" class="expandableClickHandler">'+n+"</a>"),callback:function(e,t){u(".expandableClickHandler",a).on("click",function(e){e.preventDefault(),a.trigger("destroy.dot"),a.attr("style",o).show(300)})}})})})}(jQuery),function(e){e(function(){e("img[usemap]").length&&e("img[usemap]").rwdImageMaps()})}(jQuery),function(c){"use strict";var a={on:function(e){var t=c(e),a=this;a.checkRecentIcon(),t.find(".table-sort").each(function(e,t){a.removeEmptyCells(t)})},after:function(){},checkRecentIcon:function(){c(this).find("[data-recent-until]").each(function(){var e=c(this),t=c(this).siblings("span"),a=e.data("recent-until"),n=(new Date).getTime();0!==a.length&&a<n&&(e.remove(),t.remove())})},removeEmptyCells:function(e){for(var t=c(e),a=t.find("thead"),n=t.find("tbody"),i="",s="",o=new Array(0),r=1;r<n.find("tr:nth(0) td").length+1;r++)o[r]=!0;n.find("td").each(function(){var e=c(this);0===e.html().trim().length&&o[e.index()]?o[e.index()]=!0:o[e.index()]=!1});for(var l=1;l<o.length+1;l++)o[l]&&(i+="th:nth-child("+(parseInt(l,10)+1)+"),",s+="td:nth-child("+(parseInt(l,10)+1)+"),");a.find(i.slice(0,-1)).remove(),n.find(s.slice(0,-1)).remove()}};c(".mod.mod-indicator_table").each(function(e,t){a.on(t)})}(jQuery),jQuery;
/*!
 * jQuery Validation Plugin v1.13.1
 *
 * http://jqueryvalidation.org/
 *
 * Copyright (c) 2014 Jörn Zaefferer
 * Released under the MIT license
 */
(function( factory ) {
	if ( typeof define === "function" && define.amd ) {
		define( ["jquery"], factory );
	} else {
		factory( jQuery );
	}
}(function( $ ) {

$.extend($.fn, {
	// http://jqueryvalidation.org/validate/
	validate: function( options ) {

		// if nothing is selected, return nothing; can't chain anyway
		if ( !this.length ) {
			if ( options && options.debug && window.console ) {
				console.warn( "Nothing selected, can't validate, returning nothing." );
			}
			return;
		}

		// check if a validator for this form was already created
		var validator = $.data( this[ 0 ], "validator" );
		if ( validator ) {
			return validator;
		}

		// Add novalidate tag if HTML5.
		this.attr( "novalidate", "novalidate" );

		validator = new $.validator( options, this[ 0 ] );
		$.data( this[ 0 ], "validator", validator );

		if ( validator.settings.onsubmit ) {

			this.validateDelegate( ":submit", "click", function( event ) {
				if ( validator.settings.submitHandler ) {
					validator.submitButton = event.target;
				}
				// allow suppressing validation by adding a cancel class to the submit button
				if ( $( event.target ).hasClass( "cancel" ) ) {
					validator.cancelSubmit = true;
				}

				// allow suppressing validation by adding the html5 formnovalidate attribute to the submit button
				if ( $( event.target ).attr( "formnovalidate" ) !== undefined ) {
					validator.cancelSubmit = true;
				}
			});

			// validate the form on submit
			this.submit( function( event ) {
				if ( validator.settings.debug ) {
					// prevent form submit to be able to see console output
					event.preventDefault();
				}
				function handle() {
					var hidden, result;
					if ( validator.settings.submitHandler ) {
						if ( validator.submitButton ) {
							// insert a hidden input as a replacement for the missing submit button
							hidden = $( "<input type='hidden'/>" )
								.attr( "name", validator.submitButton.name )
								.val( $( validator.submitButton ).val() )
								.appendTo( validator.currentForm );
						}
						result = validator.settings.submitHandler.call( validator, validator.currentForm, event );
						if ( validator.submitButton ) {
							// and clean up afterwards; thanks to no-block-scope, hidden can be referenced
							hidden.remove();
						}
						if ( result !== undefined ) {
							return result;
						}
						return false;
					}
					return true;
				}

				// prevent submit for invalid forms or custom submit handlers
				if ( validator.cancelSubmit ) {
					validator.cancelSubmit = false;
					return handle();
				}
				if ( validator.form() ) {
					if ( validator.pendingRequest ) {
						validator.formSubmitted = true;
						return false;
					}
					return handle();
				} else {
					validator.focusInvalid();
					return false;
				}
			});
		}

		return validator;
	},
	// http://jqueryvalidation.org/valid/
	valid: function() {
		var valid, validator;

		if ( $( this[ 0 ] ).is( "form" ) ) {
			valid = this.validate().form();
		} else {
			valid = true;
			validator = $( this[ 0 ].form ).validate();
			this.each( function() {
				valid = validator.element( this ) && valid;
			});
		}
		return valid;
	},
	// attributes: space separated list of attributes to retrieve and remove
	removeAttrs: function( attributes ) {
		var result = {},
			$element = this;
		$.each( attributes.split( /\s/ ), function( index, value ) {
			result[ value ] = $element.attr( value );
			$element.removeAttr( value );
		});
		return result;
	},
	// http://jqueryvalidation.org/rules/
	rules: function( command, argument ) {
		var element = this[ 0 ],
			settings, staticRules, existingRules, data, param, filtered;

		if ( command ) {
			settings = $.data( element.form, "validator" ).settings;
			staticRules = settings.rules;
			existingRules = $.validator.staticRules( element );
			switch ( command ) {
			case "add":
				$.extend( existingRules, $.validator.normalizeRule( argument ) );
				// remove messages from rules, but allow them to be set separately
				delete existingRules.messages;
				staticRules[ element.name ] = existingRules;
				if ( argument.messages ) {
					settings.messages[ element.name ] = $.extend( settings.messages[ element.name ], argument.messages );
				}
				break;
			case "remove":
				if ( !argument ) {
					delete staticRules[ element.name ];
					return existingRules;
				}
				filtered = {};
				$.each( argument.split( /\s/ ), function( index, method ) {
					filtered[ method ] = existingRules[ method ];
					delete existingRules[ method ];
					if ( method === "required" ) {
						$( element ).removeAttr( "aria-required" );
					}
				});
				return filtered;
			}
		}

		data = $.validator.normalizeRules(
		$.extend(
			{},
			$.validator.classRules( element ),
			$.validator.attributeRules( element ),
			$.validator.dataRules( element ),
			$.validator.staticRules( element )
		), element );

		// make sure required is at front
		if ( data.required ) {
			param = data.required;
			delete data.required;
			data = $.extend( { required: param }, data );
			$( element ).attr( "aria-required", "true" );
		}

		// make sure remote is at back
		if ( data.remote ) {
			param = data.remote;
			delete data.remote;
			data = $.extend( data, { remote: param });
		}

		return data;
	}
});

// Custom selectors
$.extend( $.expr[ ":" ], {
	// http://jqueryvalidation.org/blank-selector/
	blank: function( a ) {
		return !$.trim( "" + $( a ).val() );
	},
	// http://jqueryvalidation.org/filled-selector/
	filled: function( a ) {
		return !!$.trim( "" + $( a ).val() );
	},
	// http://jqueryvalidation.org/unchecked-selector/
	unchecked: function( a ) {
		return !$( a ).prop( "checked" );
	}
});

// constructor for validator
$.validator = function( options, form ) {
	this.settings = $.extend( true, {}, $.validator.defaults, options );
	this.currentForm = form;
	this.init();
};

// http://jqueryvalidation.org/jQuery.validator.format/
$.validator.format = function( source, params ) {
	if ( arguments.length === 1 ) {
		return function() {
			var args = $.makeArray( arguments );
			args.unshift( source );
			return $.validator.format.apply( this, args );
		};
	}
	if ( arguments.length > 2 && params.constructor !== Array  ) {
		params = $.makeArray( arguments ).slice( 1 );
	}
	if ( params.constructor !== Array ) {
		params = [ params ];
	}
	$.each( params, function( i, n ) {
		source = source.replace( new RegExp( "\\{" + i + "\\}", "g" ), function() {
			return n;
		});
	});
	return source;
};

$.extend( $.validator, {

	defaults: {
		messages: {},
		groups: {},
		rules: {},
		errorClass: "error",
		validClass: "valid",
		errorElement: "label",
		focusCleanup: false,
		focusInvalid: true,
		errorContainer: $( [] ),
		errorLabelContainer: $( [] ),
		onsubmit: true,
		ignore: ":hidden",
		ignoreTitle: false,
		onfocusin: function( element ) {
			this.lastActive = element;

			// Hide error label and remove error class on focus if enabled
			if ( this.settings.focusCleanup ) {
				if ( this.settings.unhighlight ) {
					this.settings.unhighlight.call( this, element, this.settings.errorClass, this.settings.validClass );
				}
				this.hideThese( this.errorsFor( element ) );
			}
		},
		onfocusout: function( element ) {
			if ( !this.checkable( element ) && ( element.name in this.submitted || !this.optional( element ) ) ) {
				this.element( element );
			}
		},
		onkeyup: function( element, event ) {
			if ( event.which === 9 && this.elementValue( element ) === "" ) {
				return;
			} else if ( element.name in this.submitted || element === this.lastElement ) {
				this.element( element );
			}
		},
		onclick: function( element ) {
			// click on selects, radiobuttons and checkboxes
			if ( element.name in this.submitted ) {
				this.element( element );

			// or option elements, check parent select in that case
			} else if ( element.parentNode.name in this.submitted ) {
				this.element( element.parentNode );
			}
		},
		highlight: function( element, errorClass, validClass ) {
			if ( element.type === "radio" ) {
				this.findByName( element.name ).addClass( errorClass ).removeClass( validClass );
			} else {
				$( element ).addClass( errorClass ).removeClass( validClass );
			}
		},
		unhighlight: function( element, errorClass, validClass ) {
			if ( element.type === "radio" ) {
				this.findByName( element.name ).removeClass( errorClass ).addClass( validClass );
			} else {
				$( element ).removeClass( errorClass ).addClass( validClass );
			}
		}
	},

	// http://jqueryvalidation.org/jQuery.validator.setDefaults/
	setDefaults: function( settings ) {
		$.extend( $.validator.defaults, settings );
	},

	messages: {
		required: "This field is required.",
		remote: "Please fix this field.",
		email: "Please enter a valid email address.",
		url: "Please enter a valid URL.",
		date: "Please enter a valid date.",
		dateISO: "Please enter a valid date ( ISO ).",
		number: "Please enter a valid number.",
		digits: "Please enter only digits.",
		creditcard: "Please enter a valid credit card number.",
		equalTo: "Please enter the same value again.",
		maxlength: $.validator.format( "Please enter no more than {0} characters." ),
		minlength: $.validator.format( "Please enter at least {0} characters." ),
		rangelength: $.validator.format( "Please enter a value between {0} and {1} characters long." ),
		range: $.validator.format( "Please enter a value between {0} and {1}." ),
		max: $.validator.format( "Please enter a value less than or equal to {0}." ),
		min: $.validator.format( "Please enter a value greater than or equal to {0}." )
	},

	autoCreateRanges: false,

	prototype: {

		init: function() {
			this.labelContainer = $( this.settings.errorLabelContainer );
			this.errorContext = this.labelContainer.length && this.labelContainer || $( this.currentForm );
			this.containers = $( this.settings.errorContainer ).add( this.settings.errorLabelContainer );
			this.submitted = {};
			this.valueCache = {};
			this.pendingRequest = 0;
			this.pending = {};
			this.invalid = {};
			this.reset();

			var groups = ( this.groups = {} ),
				rules;
			$.each( this.settings.groups, function( key, value ) {
				if ( typeof value === "string" ) {
					value = value.split( /\s/ );
				}
				$.each( value, function( index, name ) {
					groups[ name ] = key;
				});
			});
			rules = this.settings.rules;
			$.each( rules, function( key, value ) {
				rules[ key ] = $.validator.normalizeRule( value );
			});

			function delegate( event ) {
				var validator = $.data( this[ 0 ].form, "validator" ),
					eventType = "on" + event.type.replace( /^validate/, "" ),
					settings = validator.settings;
				if ( settings[ eventType ] && !this.is( settings.ignore ) ) {
					settings[ eventType ].call( validator, this[ 0 ], event );
				}
			}
			$( this.currentForm )
				.validateDelegate( ":text, [type='password'], [type='file'], select, textarea, " +
					"[type='number'], [type='search'] ,[type='tel'], [type='url'], " +
					"[type='email'], [type='datetime'], [type='date'], [type='month'], " +
					"[type='week'], [type='time'], [type='datetime-local'], " +
					"[type='range'], [type='color'], [type='radio'], [type='checkbox']",
					"focusin focusout keyup", delegate)
				// Support: Chrome, oldIE
				// "select" is provided as event.target when clicking a option
				.validateDelegate("select, option, [type='radio'], [type='checkbox']", "click", delegate);

			if ( this.settings.invalidHandler ) {
				$( this.currentForm ).bind( "invalid-form.validate", this.settings.invalidHandler );
			}

			// Add aria-required to any Static/Data/Class required fields before first validation
			// Screen readers require this attribute to be present before the initial submission http://www.w3.org/TR/WCAG-TECHS/ARIA2.html
			$( this.currentForm ).find( "[required], [data-rule-required], .required" ).attr( "aria-required", "true" );
		},

		// http://jqueryvalidation.org/Validator.form/
		form: function() {
			this.checkForm();
			$.extend( this.submitted, this.errorMap );
			this.invalid = $.extend({}, this.errorMap );
			if ( !this.valid() ) {
				$( this.currentForm ).triggerHandler( "invalid-form", [ this ]);
			}
			this.showErrors();
			return this.valid();
		},

		checkForm: function() {
			this.prepareForm();
			for ( var i = 0, elements = ( this.currentElements = this.elements() ); elements[ i ]; i++ ) {
				this.check( elements[ i ] );
			}
			return this.valid();
		},

		// http://jqueryvalidation.org/Validator.element/
		element: function( element ) {
			var cleanElement = this.clean( element ),
				checkElement = this.validationTargetFor( cleanElement ),
				result = true;

			this.lastElement = checkElement;

			if ( checkElement === undefined ) {
				delete this.invalid[ cleanElement.name ];
			} else {
				this.prepareElement( checkElement );
				this.currentElements = $( checkElement );

				result = this.check( checkElement ) !== false;
				if ( result ) {
					delete this.invalid[ checkElement.name ];
				} else {
					this.invalid[ checkElement.name ] = true;
				}
			}
			// Add aria-invalid status for screen readers
			$( element ).attr( "aria-invalid", !result );

			if ( !this.numberOfInvalids() ) {
				// Hide error containers on last error
				this.toHide = this.toHide.add( this.containers );
			}
			this.showErrors();
			return result;
		},

		// http://jqueryvalidation.org/Validator.showErrors/
		showErrors: function( errors ) {
			if ( errors ) {
				// add items to error list and map
				$.extend( this.errorMap, errors );
				this.errorList = [];
				for ( var name in errors ) {
					this.errorList.push({
						message: errors[ name ],
						element: this.findByName( name )[ 0 ]
					});
				}
				// remove items from success list
				this.successList = $.grep( this.successList, function( element ) {
					return !( element.name in errors );
				});
			}
			if ( this.settings.showErrors ) {
				this.settings.showErrors.call( this, this.errorMap, this.errorList );
			} else {
				this.defaultShowErrors();
			}
		},

		// http://jqueryvalidation.org/Validator.resetForm/
		resetForm: function() {
			if ( $.fn.resetForm ) {
				$( this.currentForm ).resetForm();
			}
			this.submitted = {};
			this.lastElement = null;
			this.prepareForm();
			this.hideErrors();
			this.elements()
					.removeClass( this.settings.errorClass )
					.removeData( "previousValue" )
					.removeAttr( "aria-invalid" );
		},

		numberOfInvalids: function() {
			return this.objectLength( this.invalid );
		},

		objectLength: function( obj ) {
			/* jshint unused: false */
			var count = 0,
				i;
			for ( i in obj ) {
				count++;
			}
			return count;
		},

		hideErrors: function() {
			this.hideThese( this.toHide );
		},

		hideThese: function( errors ) {
			errors.not( this.containers ).text( "" );
			this.addWrapper( errors ).hide();
		},

		valid: function() {
			return this.size() === 0;
		},

		size: function() {
			return this.errorList.length;
		},

		focusInvalid: function() {
			if ( this.settings.focusInvalid ) {
				try {
					$( this.findLastActive() || this.errorList.length && this.errorList[ 0 ].element || [])
					.filter( ":visible" )
					.focus()
					// manually trigger focusin event; without it, focusin handler isn't called, findLastActive won't have anything to find
					.trigger( "focusin" );
				} catch ( e ) {
					// ignore IE throwing errors when focusing hidden elements
				}
			}
		},

		findLastActive: function() {
			var lastActive = this.lastActive;
			return lastActive && $.grep( this.errorList, function( n ) {
				return n.element.name === lastActive.name;
			}).length === 1 && lastActive;
		},

		elements: function() {
			var validator = this,
				rulesCache = {};

			// select all valid inputs inside the form (no submit or reset buttons)
			return $( this.currentForm )
			.find( "input, select, textarea" )
			.not( ":submit, :reset, :image, [disabled], [readonly]" )
			.not( this.settings.ignore )
			.filter( function() {
				if ( !this.name && validator.settings.debug && window.console ) {
					console.error( "%o has no name assigned", this );
				}

				// select only the first element for each name, and only those with rules specified
				if ( this.name in rulesCache || !validator.objectLength( $( this ).rules() ) ) {
					return false;
				}

				rulesCache[ this.name ] = true;
				return true;
			});
		},

		clean: function( selector ) {
			return $( selector )[ 0 ];
		},

		errors: function() {
			var errorClass = this.settings.errorClass.split( " " ).join( "." );
			return $( this.settings.errorElement + "." + errorClass, this.errorContext );
		},

		reset: function() {
			this.successList = [];
			this.errorList = [];
			this.errorMap = {};
			this.toShow = $( [] );
			this.toHide = $( [] );
			this.currentElements = $( [] );
		},

		prepareForm: function() {
			this.reset();
			this.toHide = this.errors().add( this.containers );
		},

		prepareElement: function( element ) {
			this.reset();
			this.toHide = this.errorsFor( element );
		},

		elementValue: function( element ) {
			var val,
				$element = $( element ),
				type = element.type;

			if ( type === "radio" || type === "checkbox" ) {
				return $( "input[name='" + element.name + "']:checked" ).val();
			} else if ( type === "number" && typeof element.validity !== "undefined" ) {
				return element.validity.badInput ? false : $element.val();
			}

			val = $element.val();
			if ( typeof val === "string" ) {
				return val.replace(/\r/g, "" );
			}
			return val;
		},

		check: function( element ) {
			element = this.validationTargetFor( this.clean( element ) );

			var rules = $( element ).rules(),
				rulesCount = $.map( rules, function( n, i ) {
					return i;
				}).length,
				dependencyMismatch = false,
				val = this.elementValue( element ),
				result, method, rule;

			for ( method in rules ) {
				rule = { method: method, parameters: rules[ method ] };
				try {

					result = $.validator.methods[ method ].call( this, val, element, rule.parameters );

					// if a method indicates that the field is optional and therefore valid,
					// don't mark it as valid when there are no other rules
					if ( result === "dependency-mismatch" && rulesCount === 1 ) {
						dependencyMismatch = true;
						continue;
					}
					dependencyMismatch = false;

					if ( result === "pending" ) {
						this.toHide = this.toHide.not( this.errorsFor( element ) );
						return;
					}

					if ( !result ) {
						this.formatAndAdd( element, rule );
						return false;
					}
				} catch ( e ) {
					if ( this.settings.debug && window.console ) {
						console.log( "Exception occurred when checking element " + element.id + ", check the '" + rule.method + "' method.", e );
					}
					throw e;
				}
			}
			if ( dependencyMismatch ) {
				return;
			}
			if ( this.objectLength( rules ) ) {
				this.successList.push( element );
			}
			return true;
		},

		// return the custom message for the given element and validation method
		// specified in the element's HTML5 data attribute
		// return the generic message if present and no method specific message is present
		customDataMessage: function( element, method ) {
			return $( element ).data( "msg" + method.charAt( 0 ).toUpperCase() +
				method.substring( 1 ).toLowerCase() ) || $( element ).data( "msg" );
		},

		// return the custom message for the given element name and validation method
		customMessage: function( name, method ) {
			var m = this.settings.messages[ name ];
			return m && ( m.constructor === String ? m : m[ method ]);
		},

		// return the first defined argument, allowing empty strings
		findDefined: function() {
			for ( var i = 0; i < arguments.length; i++) {
				if ( arguments[ i ] !== undefined ) {
					return arguments[ i ];
				}
			}
			return undefined;
		},

		defaultMessage: function( element, method ) {
			return this.findDefined(
				this.customMessage( element.name, method ),
				this.customDataMessage( element, method ),
				// title is never undefined, so handle empty string as undefined
				!this.settings.ignoreTitle && element.title || undefined,
				$.validator.messages[ method ],
				"<strong>Warning: No message defined for " + element.name + "</strong>"
			);
		},

		formatAndAdd: function( element, rule ) {
			var message = this.defaultMessage( element, rule.method ),
				theregex = /\$?\{(\d+)\}/g;
			if ( typeof message === "function" ) {
				message = message.call( this, rule.parameters, element );
			} else if ( theregex.test( message ) ) {
				message = $.validator.format( message.replace( theregex, "{$1}" ), rule.parameters );
			}
			this.errorList.push({
				message: message,
				element: element,
				method: rule.method
			});

			this.errorMap[ element.name ] = message;
			this.submitted[ element.name ] = message;
		},

		addWrapper: function( toToggle ) {
			if ( this.settings.wrapper ) {
				toToggle = toToggle.add( toToggle.parent( this.settings.wrapper ) );
			}
			return toToggle;
		},

		defaultShowErrors: function() {
			var i, elements, error;
			for ( i = 0; this.errorList[ i ]; i++ ) {
				error = this.errorList[ i ];
				if ( this.settings.highlight ) {
					this.settings.highlight.call( this, error.element, this.settings.errorClass, this.settings.validClass );
				}
				this.showLabel( error.element, error.message );
			}
			if ( this.errorList.length ) {
				this.toShow = this.toShow.add( this.containers );
			}
			if ( this.settings.success ) {
				for ( i = 0; this.successList[ i ]; i++ ) {
					this.showLabel( this.successList[ i ] );
				}
			}
			if ( this.settings.unhighlight ) {
				for ( i = 0, elements = this.validElements(); elements[ i ]; i++ ) {
					this.settings.unhighlight.call( this, elements[ i ], this.settings.errorClass, this.settings.validClass );
				}
			}
			this.toHide = this.toHide.not( this.toShow );
			this.hideErrors();
			this.addWrapper( this.toShow ).show();
		},

		validElements: function() {
			return this.currentElements.not( this.invalidElements() );
		},

		invalidElements: function() {
			return $( this.errorList ).map(function() {
				return this.element;
			});
		},

		showLabel: function( element, message ) {
			var place, group, errorID,
				error = this.errorsFor( element ),
				elementID = this.idOrName( element ),
				describedBy = $( element ).attr( "aria-describedby" );
			if ( error.length ) {
				// refresh error/success class
				error.removeClass( this.settings.validClass ).addClass( this.settings.errorClass );
				// replace message on existing label
				error.html( message );
			} else {
				// create error element
				error = $( "<" + this.settings.errorElement + ">" )
					.attr( "id", elementID + "-error" )
					.addClass( this.settings.errorClass )
					.html( message || "" );

				// Maintain reference to the element to be placed into the DOM
				place = error;
				if ( this.settings.wrapper ) {
					// make sure the element is visible, even in IE
					// actually showing the wrapped element is handled elsewhere
					place = error.hide().show().wrap( "<" + this.settings.wrapper + "/>" ).parent();
				}
				if ( this.labelContainer.length ) {
					this.labelContainer.append( place );
				} else if ( this.settings.errorPlacement ) {
					this.settings.errorPlacement( place, $( element ) );
				} else {
					place.insertAfter( element );
				}

				// Link error back to the element
				if ( error.is( "label" ) ) {
					// If the error is a label, then associate using 'for'
					error.attr( "for", elementID );
				} else if ( error.parents( "label[for='" + elementID + "']" ).length === 0 ) {
					// If the element is not a child of an associated label, then it's necessary
					// to explicitly apply aria-describedby

					errorID = error.attr( "id" ).replace( /(:|\.|\[|\])/g, "\\$1");
					// Respect existing non-error aria-describedby
					if ( !describedBy ) {
						describedBy = errorID;
					} else if ( !describedBy.match( new RegExp( "\\b" + errorID + "\\b" ) ) ) {
						// Add to end of list if not already present
						describedBy += " " + errorID;
					}
					$( element ).attr( "aria-describedby", describedBy );

					// If this element is grouped, then assign to all elements in the same group
					group = this.groups[ element.name ];
					if ( group ) {
						$.each( this.groups, function( name, testgroup ) {
							if ( testgroup === group ) {
								$( "[name='" + name + "']", this.currentForm )
									.attr( "aria-describedby", error.attr( "id" ) );
							}
						});
					}
				}
			}
			if ( !message && this.settings.success ) {
				error.text( "" );
				if ( typeof this.settings.success === "string" ) {
					error.addClass( this.settings.success );
				} else {
					this.settings.success( error, element );
				}
			}
			this.toShow = this.toShow.add( error );
		},

		errorsFor: function( element ) {
			var name = this.idOrName( element ),
				describer = $( element ).attr( "aria-describedby" ),
				selector = "label[for='" + name + "'], label[for='" + name + "'] *";

			// aria-describedby should directly reference the error element
			if ( describer ) {
				selector = selector + ", #" + describer.replace( /\s+/g, ", #" );
			}
			return this
				.errors()
				.filter( selector );
		},

		idOrName: function( element ) {
			return this.groups[ element.name ] || ( this.checkable( element ) ? element.name : element.id || element.name );
		},

		validationTargetFor: function( element ) {

			// If radio/checkbox, validate first element in group instead
			if ( this.checkable( element ) ) {
				element = this.findByName( element.name );
			}

			// Always apply ignore filter
			return $( element ).not( this.settings.ignore )[ 0 ];
		},

		checkable: function( element ) {
			return ( /radio|checkbox/i ).test( element.type );
		},

		findByName: function( name ) {
			return $( this.currentForm ).find( "[name='" + name + "']" );
		},

		getLength: function( value, element ) {
			switch ( element.nodeName.toLowerCase() ) {
			case "select":
				return $( "option:selected", element ).length;
			case "input":
				if ( this.checkable( element ) ) {
					return this.findByName( element.name ).filter( ":checked" ).length;
				}
			}
			return value.length;
		},

		depend: function( param, element ) {
			return this.dependTypes[typeof param] ? this.dependTypes[typeof param]( param, element ) : true;
		},

		dependTypes: {
			"boolean": function( param ) {
				return param;
			},
			"string": function( param, element ) {
				return !!$( param, element.form ).length;
			},
			"function": function( param, element ) {
				return param( element );
			}
		},

		optional: function( element ) {
			var val = this.elementValue( element );
			return !$.validator.methods.required.call( this, val, element ) && "dependency-mismatch";
		},

		startRequest: function( element ) {
			if ( !this.pending[ element.name ] ) {
				this.pendingRequest++;
				this.pending[ element.name ] = true;
			}
		},

		stopRequest: function( element, valid ) {
			this.pendingRequest--;
			// sometimes synchronization fails, make sure pendingRequest is never < 0
			if ( this.pendingRequest < 0 ) {
				this.pendingRequest = 0;
			}
			delete this.pending[ element.name ];
			if ( valid && this.pendingRequest === 0 && this.formSubmitted && this.form() ) {
				$( this.currentForm ).submit();
				this.formSubmitted = false;
			} else if (!valid && this.pendingRequest === 0 && this.formSubmitted ) {
				$( this.currentForm ).triggerHandler( "invalid-form", [ this ]);
				this.formSubmitted = false;
			}
		},

		previousValue: function( element ) {
			return $.data( element, "previousValue" ) || $.data( element, "previousValue", {
				old: null,
				valid: true,
				message: this.defaultMessage( element, "remote" )
			});
		}

	},

	classRuleSettings: {
		required: { required: true },
		email: { email: true },
		url: { url: true },
		date: { date: true },
		dateISO: { dateISO: true },
		number: { number: true },
		digits: { digits: true },
		creditcard: { creditcard: true }
	},

	addClassRules: function( className, rules ) {
		if ( className.constructor === String ) {
			this.classRuleSettings[ className ] = rules;
		} else {
			$.extend( this.classRuleSettings, className );
		}
	},

	classRules: function( element ) {
		var rules = {},
			classes = $( element ).attr( "class" );

		if ( classes ) {
			$.each( classes.split( " " ), function() {
				if ( this in $.validator.classRuleSettings ) {
					$.extend( rules, $.validator.classRuleSettings[ this ]);
				}
			});
		}
		return rules;
	},

	attributeRules: function( element ) {
		var rules = {},
			$element = $( element ),
			type = element.getAttribute( "type" ),
			method, value;

		for ( method in $.validator.methods ) {

			// support for <input required> in both html5 and older browsers
			if ( method === "required" ) {
				value = element.getAttribute( method );
				// Some browsers return an empty string for the required attribute
				// and non-HTML5 browsers might have required="" markup
				if ( value === "" ) {
					value = true;
				}
				// force non-HTML5 browsers to return bool
				value = !!value;
			} else {
				value = $element.attr( method );
			}

			// convert the value to a number for number inputs, and for text for backwards compability
			// allows type="date" and others to be compared as strings
			if ( /min|max/.test( method ) && ( type === null || /number|range|text/.test( type ) ) ) {
				value = Number( value );
			}

			if ( value || value === 0 ) {
				rules[ method ] = value;
			} else if ( type === method && type !== "range" ) {
				// exception: the jquery validate 'range' method
				// does not test for the html5 'range' type
				rules[ method ] = true;
			}
		}

		// maxlength may be returned as -1, 2147483647 ( IE ) and 524288 ( safari ) for text inputs
		if ( rules.maxlength && /-1|2147483647|524288/.test( rules.maxlength ) ) {
			delete rules.maxlength;
		}

		return rules;
	},

	dataRules: function( element ) {
		var method, value,
			rules = {}, $element = $( element );
		for ( method in $.validator.methods ) {
			value = $element.data( "rule" + method.charAt( 0 ).toUpperCase() + method.substring( 1 ).toLowerCase() );
			if ( value !== undefined ) {
				rules[ method ] = value;
			}
		}
		return rules;
	},

	staticRules: function( element ) {
		var rules = {},
			validator = $.data( element.form, "validator" );

		if ( validator.settings.rules ) {
			rules = $.validator.normalizeRule( validator.settings.rules[ element.name ] ) || {};
		}
		return rules;
	},

	normalizeRules: function( rules, element ) {
		// handle dependency check
		$.each( rules, function( prop, val ) {
			// ignore rule when param is explicitly false, eg. required:false
			if ( val === false ) {
				delete rules[ prop ];
				return;
			}
			if ( val.param || val.depends ) {
				var keepRule = true;
				switch ( typeof val.depends ) {
				case "string":
					keepRule = !!$( val.depends, element.form ).length;
					break;
				case "function":
					keepRule = val.depends.call( element, element );
					break;
				}
				if ( keepRule ) {
					rules[ prop ] = val.param !== undefined ? val.param : true;
				} else {
					delete rules[ prop ];
				}
			}
		});

		// evaluate parameters
		$.each( rules, function( rule, parameter ) {
			rules[ rule ] = $.isFunction( parameter ) ? parameter( element ) : parameter;
		});

		// clean number parameters
		$.each([ "minlength", "maxlength" ], function() {
			if ( rules[ this ] ) {
				rules[ this ] = Number( rules[ this ] );
			}
		});
		$.each([ "rangelength", "range" ], function() {
			var parts;
			if ( rules[ this ] ) {
				if ( $.isArray( rules[ this ] ) ) {
					rules[ this ] = [ Number( rules[ this ][ 0 ]), Number( rules[ this ][ 1 ] ) ];
				} else if ( typeof rules[ this ] === "string" ) {
					parts = rules[ this ].replace(/[\[\]]/g, "" ).split( /[\s,]+/ );
					rules[ this ] = [ Number( parts[ 0 ]), Number( parts[ 1 ] ) ];
				}
			}
		});

		if ( $.validator.autoCreateRanges ) {
			// auto-create ranges
			if ( rules.min != null && rules.max != null ) {
				rules.range = [ rules.min, rules.max ];
				delete rules.min;
				delete rules.max;
			}
			if ( rules.minlength != null && rules.maxlength != null ) {
				rules.rangelength = [ rules.minlength, rules.maxlength ];
				delete rules.minlength;
				delete rules.maxlength;
			}
		}

		return rules;
	},

	// Converts a simple string to a {string: true} rule, e.g., "required" to {required:true}
	normalizeRule: function( data ) {
		if ( typeof data === "string" ) {
			var transformed = {};
			$.each( data.split( /\s/ ), function() {
				transformed[ this ] = true;
			});
			data = transformed;
		}
		return data;
	},

	// http://jqueryvalidation.org/jQuery.validator.addMethod/
	addMethod: function( name, method, message ) {
		$.validator.methods[ name ] = method;
		$.validator.messages[ name ] = message !== undefined ? message : $.validator.messages[ name ];
		if ( method.length < 3 ) {
			$.validator.addClassRules( name, $.validator.normalizeRule( name ) );
		}
	},

	methods: {

		// http://jqueryvalidation.org/required-method/
		required: function( value, element, param ) {
			// check if dependency is met
			if ( !this.depend( param, element ) ) {
				return "dependency-mismatch";
			}
			if ( element.nodeName.toLowerCase() === "select" ) {
				// could be an array for select-multiple or a string, both are fine this way
				var val = $( element ).val();
				return val && val.length > 0;
			}
			if ( this.checkable( element ) ) {
				return this.getLength( value, element ) > 0;
			}
			return $.trim( value ).length > 0;
		},

		// http://jqueryvalidation.org/email-method/
		email: function( value, element ) {
			// From http://www.whatwg.org/specs/web-apps/current-work/multipage/states-of-the-type-attribute.html#e-mail-state-%28type=email%29
			// Retrieved 2014-01-14
			// If you have a problem with this implementation, report a bug against the above spec
			// Or use custom methods to implement your own email validation
			return this.optional( element ) || /^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/.test( value );
		},

		// http://jqueryvalidation.org/url-method/
		url: function( value, element ) {
			// contributed by Scott Gonzalez: http://projects.scottsplayground.com/iri/
			return this.optional( element ) || /^(https?|s?ftp):\/\/(((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:)*@)?(((\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5]))|((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?)(:\d*)?)(\/((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)+(\/(([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)*)*)?)?(\?((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|[\uE000-\uF8FF]|\/|\?)*)?(#((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|\/|\?)*)?$/i.test( value );
		},

		// http://jqueryvalidation.org/date-method/
		date: function( value, element ) {
			return this.optional( element ) || !/Invalid|NaN/.test( new Date( value ).toString() );
		},

		// http://jqueryvalidation.org/dateISO-method/
		dateISO: function( value, element ) {
			return this.optional( element ) || /^\d{4}[\/\-](0?[1-9]|1[012])[\/\-](0?[1-9]|[12][0-9]|3[01])$/.test( value );
		},

		// http://jqueryvalidation.org/number-method/
		number: function( value, element ) {
			return this.optional( element ) || /^-?(?:\d+|\d{1,3}(?:,\d{3})+)?(?:\.\d+)?$/.test( value );
		},

		// http://jqueryvalidation.org/digits-method/
		digits: function( value, element ) {
			return this.optional( element ) || /^\d+$/.test( value );
		},

		// http://jqueryvalidation.org/creditcard-method/
		// based on http://en.wikipedia.org/wiki/Luhn/
		creditcard: function( value, element ) {
			if ( this.optional( element ) ) {
				return "dependency-mismatch";
			}
			// accept only spaces, digits and dashes
			if ( /[^0-9 \-]+/.test( value ) ) {
				return false;
			}
			var nCheck = 0,
				nDigit = 0,
				bEven = false,
				n, cDigit;

			value = value.replace( /\D/g, "" );

			// Basing min and max length on
			// http://developer.ean.com/general_info/Valid_Credit_Card_Types
			if ( value.length < 13 || value.length > 19 ) {
				return false;
			}

			for ( n = value.length - 1; n >= 0; n--) {
				cDigit = value.charAt( n );
				nDigit = parseInt( cDigit, 10 );
				if ( bEven ) {
					if ( ( nDigit *= 2 ) > 9 ) {
						nDigit -= 9;
					}
				}
				nCheck += nDigit;
				bEven = !bEven;
			}

			return ( nCheck % 10 ) === 0;
		},

		// http://jqueryvalidation.org/minlength-method/
		minlength: function( value, element, param ) {
			var length = $.isArray( value ) ? value.length : this.getLength( value, element );
			return this.optional( element ) || length >= param;
		},

		// http://jqueryvalidation.org/maxlength-method/
		maxlength: function( value, element, param ) {
			var length = $.isArray( value ) ? value.length : this.getLength( value, element );
			return this.optional( element ) || length <= param;
		},

		// http://jqueryvalidation.org/rangelength-method/
		rangelength: function( value, element, param ) {
			var length = $.isArray( value ) ? value.length : this.getLength( value, element );
			return this.optional( element ) || ( length >= param[ 0 ] && length <= param[ 1 ] );
		},

		// http://jqueryvalidation.org/min-method/
		min: function( value, element, param ) {
			return this.optional( element ) || value >= param;
		},

		// http://jqueryvalidation.org/max-method/
		max: function( value, element, param ) {
			return this.optional( element ) || value <= param;
		},

		// http://jqueryvalidation.org/range-method/
		range: function( value, element, param ) {
			return this.optional( element ) || ( value >= param[ 0 ] && value <= param[ 1 ] );
		},

		// http://jqueryvalidation.org/equalTo-method/
		equalTo: function( value, element, param ) {
			// bind to the blur event of the target in order to revalidate whenever the target field is updated
			// TODO find a way to bind the event just once, avoiding the unbind-rebind overhead
			var target = $( param );
			if ( this.settings.onfocusout ) {
				target.unbind( ".validate-equalTo" ).bind( "blur.validate-equalTo", function() {
					$( element ).valid();
				});
			}
			return value === target.val();
		},

		// http://jqueryvalidation.org/remote-method/
		remote: function( value, element, param ) {
			if ( this.optional( element ) ) {
				return "dependency-mismatch";
			}

			var previous = this.previousValue( element ),
				validator, data;

			if (!this.settings.messages[ element.name ] ) {
				this.settings.messages[ element.name ] = {};
			}
			previous.originalMessage = this.settings.messages[ element.name ].remote;
			this.settings.messages[ element.name ].remote = previous.message;

			param = typeof param === "string" && { url: param } || param;

			if ( previous.old === value ) {
				return previous.valid;
			}

			previous.old = value;
			validator = this;
			this.startRequest( element );
			data = {};
			data[ element.name ] = value;
			$.ajax( $.extend( true, {
				url: param,
				mode: "abort",
				port: "validate" + element.name,
				dataType: "json",
				data: data,
				context: validator.currentForm,
				success: function( response ) {
					var valid = response === true || response === "true",
						errors, message, submitted;

					validator.settings.messages[ element.name ].remote = previous.originalMessage;
					if ( valid ) {
						submitted = validator.formSubmitted;
						validator.prepareElement( element );
						validator.formSubmitted = submitted;
						validator.successList.push( element );
						delete validator.invalid[ element.name ];
						validator.showErrors();
					} else {
						errors = {};
						message = response || validator.defaultMessage( element, "remote" );
						errors[ element.name ] = previous.message = $.isFunction( message ) ? message( value ) : message;
						validator.invalid[ element.name ] = true;
						validator.showErrors( errors );
					}
					previous.valid = valid;
					validator.stopRequest( element, valid );
				}
			}, param ) );
			return "pending";
		}

	}

});

$.format = function deprecated() {
	throw "$.format has been deprecated. Please use $.validator.format instead.";
};

// ajax mode: abort
// usage: $.ajax({ mode: "abort"[, port: "uniqueport"]});
// if mode:"abort" is used, the previous request on that port (port can be undefined) is aborted via XMLHttpRequest.abort()

var pendingRequests = {},
	ajax;
// Use a prefilter if available (1.5+)
if ( $.ajaxPrefilter ) {
	$.ajaxPrefilter(function( settings, _, xhr ) {
		var port = settings.port;
		if ( settings.mode === "abort" ) {
			if ( pendingRequests[port] ) {
				pendingRequests[port].abort();
			}
			pendingRequests[port] = xhr;
		}
	});
} else {
	// Proxy ajax
	ajax = $.ajax;
	$.ajax = function( settings ) {
		var mode = ( "mode" in settings ? settings : $.ajaxSettings ).mode,
			port = ( "port" in settings ? settings : $.ajaxSettings ).port;
		if ( mode === "abort" ) {
			if ( pendingRequests[port] ) {
				pendingRequests[port].abort();
			}
			pendingRequests[port] = ajax.apply(this, arguments);
			return pendingRequests[port];
		}
		return ajax.apply(this, arguments);
	};
}

// provides delegate(type: String, delegate: Selector, handler: Callback) plugin for easier event delegation
// handler is only called when $(event.target).is(delegate), in the scope of the jquery-object for event.target

$.extend($.fn, {
	validateDelegate: function( delegate, type, handler ) {
		return this.bind(type, function( event ) {
			var target = $(event.target);
			if ( target.is(delegate) ) {
				return handler.apply(target, arguments);
			}
		});
	}
});

}));
/*
 * jQuery throttle / debounce - v1.1 - 3/7/2010
 * http://benalman.com/projects/jquery-throttle-debounce-plugin/
 * 
 * Copyright (c) 2010 "Cowboy" Ben Alman
 * Dual licensed under the MIT and GPL licenses.
 * http://benalman.com/about/license/
 */
(function(b,c){var $=b.jQuery||b.Cowboy||(b.Cowboy={}),a;$.throttle=a=function(e,f,j,i){var h,d=0;if(typeof f!=="boolean"){i=j;j=f;f=c}function g(){var o=this,m=+new Date()-d,n=arguments;function l(){d=+new Date();j.apply(o,n)}function k(){h=c}if(i&&!h){l()}h&&clearTimeout(h);if(i===c&&m>e){l()}else{if(f!==true){h=setTimeout(i?k:l,i===c?e-m:e)}}}if($.guid){g.guid=j.guid=j.guid||$.guid++}return g};$.debounce=function(d,e,f){return f===c?a(d,e,false):a(d,f,e!==false)}})(this);
/*
 *	jQuery dotdotdot 1.7.2
 *
 *	Copyright (c) Fred Heusschen
 *	www.frebsite.nl
 *
 *	Plugin website:
 *	dotdotdot.frebsite.nl
 *
 *	Licensed under the MIT license.
 *	http://en.wikipedia.org/wiki/MIT_License
 */
!function(t,e){function n(t,e,n){var r=t.children(),o=!1;t.empty();for(var i=0,d=r.length;d>i;i++){var l=r.eq(i);if(t.append(l),n&&t.append(n),a(t,e)){l.remove(),o=!0;break}n&&n.detach()}return o}function r(e,n,i,d,l){var s=!1,c="a table, thead, tbody, tfoot, tr, col, colgroup, object, embed, param, ol, ul, dl, blockquote, select, optgroup, option, textarea, script, style",u="script, .dotdotdot-keep";return e.contents().detach().each(function(){var f=this,h=t(f);if("undefined"==typeof f||3==f.nodeType&&0==t.trim(f.data).length)return!0;if(h.is(u))e.append(h);else{if(s)return!0;e.append(h),!l||h.is(d.after)||h.find(d.after).length||e[e.is(c)?"after":"append"](l),a(i,d)&&(s=3==f.nodeType?o(h,n,i,d,l):r(h,n,i,d,l),s||(h.detach(),s=!0)),s||l&&l.detach()}}),s}function o(e,n,r,o,d){var c=e[0];if(!c)return!1;var f=s(c),h=-1!==f.indexOf(" ")?" ":"　",p="letter"==o.wrap?"":h,g=f.split(p),v=-1,w=-1,b=0,y=g.length-1;for(o.fallbackToLetter&&0==b&&0==y&&(p="",g=f.split(p),y=g.length-1);y>=b&&(0!=b||0!=y);){var m=Math.floor((b+y)/2);if(m==w)break;w=m,l(c,g.slice(0,w+1).join(p)+o.ellipsis),a(r,o)?(y=w,o.fallbackToLetter&&0==b&&0==y&&(p="",g=g[0].split(p),v=-1,w=-1,b=0,y=g.length-1)):(v=w,b=w)}if(-1==v||1==g.length&&0==g[0].length){var x=e.parent();e.detach();var T=d&&d.closest(x).length?d.length:0;x.contents().length>T?c=u(x.contents().eq(-1-T),n):(c=u(x,n,!0),T||x.detach()),c&&(f=i(s(c),o),l(c,f),T&&d&&t(c).parent().append(d))}else f=i(g.slice(0,v+1).join(p),o),l(c,f);return!0}function a(t,e){return t.innerHeight()>e.maxHeight}function i(e,n){for(;t.inArray(e.slice(-1),n.lastCharacter.remove)>-1;)e=e.slice(0,-1);return t.inArray(e.slice(-1),n.lastCharacter.noEllipsis)<0&&(e+=n.ellipsis),e}function d(t){return{width:t.innerWidth(),height:t.innerHeight()}}function l(t,e){t.innerText?t.innerText=e:t.nodeValue?t.nodeValue=e:t.textContent&&(t.textContent=e)}function s(t){return t.innerText?t.innerText:t.nodeValue?t.nodeValue:t.textContent?t.textContent:""}function c(t){do t=t.previousSibling;while(t&&1!==t.nodeType&&3!==t.nodeType);return t}function u(e,n,r){var o,a=e&&e[0];if(a){if(!r){if(3===a.nodeType)return a;if(t.trim(e.text()))return u(e.contents().last(),n)}for(o=c(a);!o;){if(e=e.parent(),e.is(n)||!e.length)return!1;o=c(e[0])}if(o)return u(t(o),n)}return!1}function f(e,n){return e?"string"==typeof e?(e=t(e,n),e.length?e:!1):e.jquery?e:!1:!1}function h(t){for(var e=t.parent().innerHeight()-t.position().top,n=["paddingTop","paddingBottom"],r=0,o=n.length;o>r;r++){var a=parseInt(t.css(n[r]),10);isNaN(a)&&(a=0),e-=a}return e}if(!t.fn.dotdotdot){t.fn.dotdotdot=function(e){if(0==this.length)return t.fn.dotdotdot.debug('No element found for "'+this.selector+'".'),this;if(this.length>1)return this.each(function(){t(this).dotdotdot(e)});var o=this;o.data("dotdotdot")&&o.trigger("destroy.dot"),o.data("dotdotdot-style",o.attr("style")||""),o.css("word-wrap","break-word"),"nowrap"===o.css("white-space")&&o.css("white-space","normal"),o.bind_events=function(){return o.bind("update.dot",function(e,d){e.preventDefault(),e.stopPropagation(),l.maxHeight="number"==typeof l.height?l.height:h(o),l.maxHeight+=l.tolerance,"undefined"!=typeof d&&(("string"==typeof d||d instanceof HTMLElement)&&(d=t("<div />").append(d).contents()),d instanceof t&&(i=d)),g=o.wrapInner('<div class="dotdotdot" />').children(),g.contents().detach().end().append(i.clone(!0)).find("br").replaceWith("  <br />  ").end().css({height:"auto",width:"auto",border:"none",padding:0,margin:0});var c=!1,u=!1;return s.afterElement&&(c=s.afterElement.clone(!0),c.show(),s.afterElement.detach()),a(g,l)&&(u="children"==l.wrap?n(g,l,c):r(g,o,g,l,c)),g.replaceWith(g.contents()),g=null,t.isFunction(l.callback)&&l.callback.call(o[0],u,i),s.isTruncated=u,u}).bind("isTruncated.dot",function(t,e){return t.preventDefault(),t.stopPropagation(),"function"==typeof e&&e.call(o[0],s.isTruncated),s.isTruncated}).bind("originalContent.dot",function(t,e){return t.preventDefault(),t.stopPropagation(),"function"==typeof e&&e.call(o[0],i),i}).bind("destroy.dot",function(t){t.preventDefault(),t.stopPropagation(),o.unwatch().unbind_events().contents().detach().end().append(i).attr("style",o.data("dotdotdot-style")||"").data("dotdotdot",!1)}),o},o.unbind_events=function(){return o.unbind(".dot"),o},o.watch=function(){if(o.unwatch(),"window"==l.watch){var e=t(window),n=e.width(),r=e.height();e.bind("resize.dot"+s.dotId,function(){n==e.width()&&r==e.height()&&l.windowResizeFix||(n=e.width(),r=e.height(),u&&clearInterval(u),u=setTimeout(function(){o.trigger("update.dot")},100))})}else c=d(o),u=setInterval(function(){if(o.is(":visible")){var t=d(o);(c.width!=t.width||c.height!=t.height)&&(o.trigger("update.dot"),c=t)}},500);return o},o.unwatch=function(){return t(window).unbind("resize.dot"+s.dotId),u&&clearInterval(u),o};var i=o.contents(),l=t.extend(!0,{},t.fn.dotdotdot.defaults,e),s={},c={},u=null,g=null;return l.lastCharacter.remove instanceof Array||(l.lastCharacter.remove=t.fn.dotdotdot.defaultArrays.lastCharacter.remove),l.lastCharacter.noEllipsis instanceof Array||(l.lastCharacter.noEllipsis=t.fn.dotdotdot.defaultArrays.lastCharacter.noEllipsis),s.afterElement=f(l.after,o),s.isTruncated=!1,s.dotId=p++,o.data("dotdotdot",!0).bind_events().trigger("update.dot"),l.watch&&o.watch(),o},t.fn.dotdotdot.defaults={ellipsis:"... ",wrap:"word",fallbackToLetter:!0,lastCharacter:{},tolerance:0,callback:null,after:null,height:null,watch:!1,windowResizeFix:!0},t.fn.dotdotdot.defaultArrays={lastCharacter:{remove:[" ","　",",",";",".","!","?"],noEllipsis:[]}},t.fn.dotdotdot.debug=function(){};var p=1,g=t.fn.html;t.fn.html=function(n){return n!=e&&!t.isFunction(n)&&this.data("dotdotdot")?this.trigger("update",[n]):g.apply(this,arguments)};var v=t.fn.text;t.fn.text=function(n){return n!=e&&!t.isFunction(n)&&this.data("dotdotdot")?(n=t("<div />").text(n).html(),this.trigger("update",[n])):v.apply(this,arguments)}}}(jQuery);
/*
 * jQuery Clipboard :: Fork of zClip :: Uses ZeroClipboard v1.3.2
 *
 * https://github.com/valeriansaliou/jquery.clipboard
 * http://www.steamdev.com/zclip/
 *
 * Copyright 2014, Valerian Saliou
 * Copyright 2011, SteamDev
 *
 * Released under the MIT license.
 * http://www.opensource.org/licenses/mit-license.php
 *
 * Version: v1.4
 * Date: Fri Oct 3, 2014
 */
/* Component: jQuery Clipboard */
(function ($) {
	var $clip = null;
	var $is_loaded = false;
	$.fn.clipboard = function (params) {
		if ((typeof params == 'object' && !params.length) || (typeof params == 'undefined')) {
			var settings = $.extend({
				path: 'jquery.clipboard.swf',
				copy: null,
				beforeCopy: null,
				afterCopy: null,
				clickAfter: true
			}, (params || {}));
			return this.each(function () {
				var o = $(this);
				if (o.is(':visible') && (typeof settings.copy == 'string' || $.isFunction(settings.copy))) {
					if ($.isFunction(settings.copy)) {
						o.bind('Clipboard_copy',settings.copy);
					}
					if ($.isFunction(settings.beforeCopy)) {
						o.bind('Clipboard_beforeCopy',settings.beforeCopy);
					}
					if ($.isFunction(settings.afterCopy)) {
						o.bind('Clipboard_afterCopy',settings.afterCopy);
					}
					if($clip === null) {
						ZeroClipboard.config({
							moviePath: settings.path,
							trustedDomains: '*',
							hoverClass: 'hover',
							activeClass: 'active'
						});
						$clip = new ZeroClipboard(null);
						$clip.on('load', function(client) {
							client.on('mouseover', function (client) {
								$(this).trigger('mouseenter');
							});
							client.on('mouseout', function (client) {
								$(this).trigger('mouseleave');
							});
							client.on('mousedown', function (client) {
								$(this).trigger('mousedown');
								if (!$.isFunction(settings.copy)) {
									client.setText(settings.copy);
								} else {
									client.setText($(this).triggerHandler('Clipboard_copy'));
								}
								if ($.isFunction(settings.beforeCopy)) {
									$(this).trigger('Clipboard_beforeCopy');
								}
							});
							client.on('complete', function (client, args) {
								if ($.isFunction(settings.afterCopy)) {
									$(this).trigger('Clipboard_afterCopy');
								} else {
									$(this).removeClass('hover');
								}
								if (settings.clickAfter) {
									$(this).trigger('click');
								}
							});
						});
					}
					$clip.clip([o[0]]);
				}
			});
		}
	};
})(jQuery);
/* Component: ZeroClipboard */
/*!
 * ZeroClipboard
 * The ZeroClipboard library provides an easy way to copy text to the clipboard using an invisible Adobe Flash movie and a JavaScript interface.
 * Copyright (c) 2014 Jon Rohan, James M. Greene
 * Licensed MIT
 * http://zeroclipboard.org/
 * v1.3.2
 */
(function() {
	"use strict";
	var currentElement;
	var flashState = {
		bridge: null,
		version: "0.0.0",
		disabled: null,
		outdated: null,
		ready: null
	};
	var _clipData = {};
	var clientIdCounter = 0;
	var _clientMeta = {};
	var elementIdCounter = 0;
	var _elementMeta = {};
	var _amdModuleId = null;
	var _cjsModuleId = null;
	var _swfPath = function() {
		var i, jsDir, tmpJsPath, jsPath, swfPath = "ZeroClipboard.swf";
		if (document.currentScript && (jsPath = document.currentScript.src)) {} else {
			var scripts = document.getElementsByTagName("script");
			if ("readyState" in scripts[0]) {
				for (i = scripts.length; i--; ) {
					if (scripts[i].readyState === "interactive" && (jsPath = scripts[i].src)) {
						break;
					}
				}
			} else if (document.readyState === "loading") {
				jsPath = scripts[scripts.length - 1].src;
			} else {
				for (i = scripts.length; i--; ) {
					tmpJsPath = scripts[i].src;
					if (!tmpJsPath) {
						jsDir = null;
						break;
					}
					tmpJsPath = tmpJsPath.split("#")[0].split("?")[0];
					tmpJsPath = tmpJsPath.slice(0, tmpJsPath.lastIndexOf("/") + 1);
					if (jsDir === null) {
						jsDir = tmpJsPath;
					} else if (jsDir !== tmpJsPath) {
						jsDir = null;
						break;
					}
				}
				if (jsDir !== null) {
					jsPath = jsDir;
				}
			}
		}
		if (jsPath) {
			jsPath = jsPath.split("#")[0].split("?")[0];
			swfPath = jsPath.slice(0, jsPath.lastIndexOf("/") + 1) + swfPath;
		}
		return swfPath;
	}();
	var _camelizeCssPropName = function() {
		var matcherRegex = /\-([a-z])/g, replacerFn = function(match, group) {
			return group.toUpperCase();
		};
		return function(prop) {
			return prop.replace(matcherRegex, replacerFn);
		};
	}();
	var _getStyle = function(el, prop) {
		var value, camelProp, tagName, possiblePointers, i, len;
		if (window.getComputedStyle) {
			value = window.getComputedStyle(el, null).getPropertyValue(prop);
		} else {
			camelProp = _camelizeCssPropName(prop);
			if (el.currentStyle) {
				value = el.currentStyle[camelProp];
			} else {
				value = el.style[camelProp];
			}
		}
		if (prop === "cursor") {
			if (!value || value === "auto") {
				tagName = el.tagName.toLowerCase();
				if (tagName === "a") {
					return "pointer";
				}
			}
		}
		return value;
	};
	var _elementMouseOver = function(event) {
		if (!event) {
			event = window.event;
		}
		var target;
		if (this !== window) {
			target = this;
		} else if (event.target) {
			target = event.target;
		} else if (event.srcElement) {
			target = event.srcElement;
		}
		ZeroClipboard.activate(target);
	};
	var _addEventHandler = function(element, method, func) {
		if (!element || element.nodeType !== 1) {
			return;
		}
		if (element.addEventListener) {
			element.addEventListener(method, func, false);
		} else if (element.attachEvent) {
			element.attachEvent("on" + method, func);
		}
	};
	var _removeEventHandler = function(element, method, func) {
		if (!element || element.nodeType !== 1) {
			return;
		}
		if (element.removeEventListener) {
			element.removeEventListener(method, func, false);
		} else if (element.detachEvent) {
			element.detachEvent("on" + method, func);
		}
	};
	var _addClass = function(element, value) {
		if (!element || element.nodeType !== 1) {
			return element;
		}
		if (element.classList) {
			if (!element.classList.contains(value)) {
				element.classList.add(value);
			}
			return element;
		}
		if (value && typeof value === "string") {
			var classNames = (value || "").split(/\s+/);
			if (element.nodeType === 1) {
				if (!element.className) {
					element.className = value;
				} else {
					var className = " " + element.className + " ", setClass = element.className;
					for (var c = 0, cl = classNames.length; c < cl; c++) {
						if (className.indexOf(" " + classNames[c] + " ") < 0) {
							setClass += " " + classNames[c];
						}
					}
					element.className = setClass.replace(/^\s+|\s+$/g, "");
				}
			}
		}
		return element;
	};
	var _removeClass = function(element, value) {
		if (!element || element.nodeType !== 1) {
			return element;
		}
		if (element.classList) {
			if (element.classList.contains(value)) {
				element.classList.remove(value);
			}
			return element;
		}
		if (value && typeof value === "string" || value === undefined) {
			var classNames = (value || "").split(/\s+/);
			if (element.nodeType === 1 && element.className) {
				if (value) {
					var className = (" " + element.className + " ").replace(/[\n\t]/g, " ");
					for (var c = 0, cl = classNames.length; c < cl; c++) {
						className = className.replace(" " + classNames[c] + " ", " ");
					}
					element.className = className.replace(/^\s+|\s+$/g, "");
				} else {
					element.className = "";
				}
			}
		}
		return element;
	};
	var _getZoomFactor = function() {
		var rect, physicalWidth, logicalWidth, zoomFactor = 1;
		if (typeof document.body.getBoundingClientRect === "function") {
			rect = document.body.getBoundingClientRect();
			physicalWidth = rect.right - rect.left;
			logicalWidth = document.body.offsetWidth;
			zoomFactor = Math.round(physicalWidth / logicalWidth * 100) / 100;
		}
		return zoomFactor;
	};
	var _getDOMObjectPosition = function(obj, defaultZIndex) {
		var info = {
			left: 0,
			top: 0,
			width: 0,
			height: 0,
			zIndex: _getSafeZIndex(defaultZIndex) - 1
		};
		if (obj.getBoundingClientRect) {
			var rect = obj.getBoundingClientRect();
			var pageXOffset, pageYOffset, zoomFactor;
			if ("pageXOffset" in window && "pageYOffset" in window) {
				pageXOffset = window.pageXOffset;
				pageYOffset = window.pageYOffset;
			} else {
				zoomFactor = _getZoomFactor();
				pageXOffset = Math.round(document.documentElement.scrollLeft / zoomFactor);
				pageYOffset = Math.round(document.documentElement.scrollTop / zoomFactor);
			}
			var leftBorderWidth = document.documentElement.clientLeft || 0;
			var topBorderWidth = document.documentElement.clientTop || 0;
			info.left = rect.left + pageXOffset - leftBorderWidth;
			info.top = rect.top + pageYOffset - topBorderWidth;
			info.width = "width" in rect ? rect.width : rect.right - rect.left;
			info.height = "height" in rect ? rect.height : rect.bottom - rect.top;
		}
		return info;
	};
	var _cacheBust = function(path, options) {
		var cacheBust = options === null || options && options.cacheBust === true && options.useNoCache === true;
		if (cacheBust) {
			return (path.indexOf("?") === -1 ? "?" : "&") + "noCache=" + new Date().getTime();
		} else {
			return "";
		}
	};
	var _vars = function(options) {
		var i, len, domain, str = [], domains = [], trustedOriginsExpanded = [];
		if (options.trustedOrigins) {
			if (typeof options.trustedOrigins === "string") {
				domains.push(options.trustedOrigins);
			} else if (typeof options.trustedOrigins === "object" && "length" in options.trustedOrigins) {
				domains = domains.concat(options.trustedOrigins);
			}
		}
		if (options.trustedDomains) {
			if (typeof options.trustedDomains === "string") {
				domains.push(options.trustedDomains);
			} else if (typeof options.trustedDomains === "object" && "length" in options.trustedDomains) {
				domains = domains.concat(options.trustedDomains);
			}
		}
		if (domains.length) {
			for (i = 0, len = domains.length; i < len; i++) {
				if (domains.hasOwnProperty(i) && domains[i] && typeof domains[i] === "string") {
					domain = _extractDomain(domains[i]);
					if (!domain) {
						continue;
					}
					if (domain === "*") {
						trustedOriginsExpanded = [ domain ];
						break;
					}
					trustedOriginsExpanded.push.apply(trustedOriginsExpanded, [ domain, "//" + domain, window.location.protocol + "//" + domain ]);
				}
			}
		}
		if (trustedOriginsExpanded.length) {
			str.push("trustedOrigins=" + encodeURIComponent(trustedOriginsExpanded.join(",")));
		}
		if (typeof options.jsModuleId === "string" && options.jsModuleId) {
			str.push("jsModuleId=" + encodeURIComponent(options.jsModuleId));
		}
		return str.join("&");
	};
	var _inArray = function(elem, array, fromIndex) {
		if (typeof array.indexOf === "function") {
			return array.indexOf(elem, fromIndex);
		}
		var i, len = array.length;
		if (typeof fromIndex === "undefined") {
			fromIndex = 0;
		} else if (fromIndex < 0) {
			fromIndex = len + fromIndex;
		}
		for (i = fromIndex; i < len; i++) {
			if (array.hasOwnProperty(i) && array[i] === elem) {
				return i;
			}
		}
		return -1;
	};
	var _prepClip = function(elements) {
		if (typeof elements === "string") throw new TypeError("ZeroClipboard doesn't accept query strings.");
		if (!elements.length) return [ elements ];
		return elements;
	};
	var _dispatchCallback = function(func, context, args, async) {
		if (async) {
			window.setTimeout(function() {
				func.apply(context, args);
			}, 0);
		} else {
			func.apply(context, args);
		}
	};
	var _getSafeZIndex = function(val) {
		var zIndex, tmp;
		if (val) {
			if (typeof val === "number" && val > 0) {
				zIndex = val;
			} else if (typeof val === "string" && (tmp = parseInt(val, 10)) && !isNaN(tmp) && tmp > 0) {
				zIndex = tmp;
			}
		}
		if (!zIndex) {
			if (typeof _globalConfig.zIndex === "number" && _globalConfig.zIndex > 0) {
				zIndex = _globalConfig.zIndex;
			} else if (typeof _globalConfig.zIndex === "string" && (tmp = parseInt(_globalConfig.zIndex, 10)) && !isNaN(tmp) && tmp > 0) {
				zIndex = tmp;
			}
		}
		return zIndex || 0;
	};
	var _deprecationWarning = function(deprecatedApiName, debugEnabled) {
		if (deprecatedApiName && debugEnabled !== false && typeof console !== "undefined" && console && (console.warn || console.log)) {
			var deprecationWarning = "`" + deprecatedApiName + "` is deprecated. See docs for more info:\n" + " https://github.com/zeroclipboard/zeroclipboard/blob/master/docs/instructions.md#deprecations";
			if (console.warn) {
				console.warn(deprecationWarning);
			} else {
				console.log(deprecationWarning);
			}
		}
	};
	var _extend = function() {
		var i, len, arg, prop, src, copy, target = arguments[0] || {};
		for (i = 1, len = arguments.length; i < len; i++) {
			if ((arg = arguments[i]) !== null) {
				for (prop in arg) {
					if (arg.hasOwnProperty(prop)) {
						src = target[prop];
						copy = arg[prop];
						if (target === copy) {
							continue;
						}
						if (copy !== undefined) {
							target[prop] = copy;
						}
					}
				}
			}
		}
		return target;
	};
	var _extractDomain = function(originOrUrl) {
		if (originOrUrl === null || originOrUrl === "") {
			return null;
		}
		originOrUrl = originOrUrl.replace(/^\s+|\s+$/g, "");
		if (originOrUrl === "") {
			return null;
		}
		var protocolIndex = originOrUrl.indexOf("//");
		originOrUrl = protocolIndex === -1 ? originOrUrl : originOrUrl.slice(protocolIndex + 2);
		var pathIndex = originOrUrl.indexOf("/");
		originOrUrl = pathIndex === -1 ? originOrUrl : protocolIndex === -1 || pathIndex === 0 ? null : originOrUrl.slice(0, pathIndex);
		if (originOrUrl && originOrUrl.slice(-4).toLowerCase() === ".swf") {
			return null;
		}
		return originOrUrl || null;
	};
	var _determineScriptAccess = function() {
		var _extractAllDomains = function(origins, resultsArray) {
			var i, len, tmp;
			if (origins !== null && resultsArray[0] !== "*") {
				if (typeof origins === "string") {
					origins = [ origins ];
				}
				if (typeof origins === "object" && "length" in origins) {
					for (i = 0, len = origins.length; i < len; i++) {
						if (origins.hasOwnProperty(i)) {
							tmp = _extractDomain(origins[i]);
							if (tmp) {
								if (tmp === "*") {
									resultsArray.length = 0;
									resultsArray.push("*");
									break;
								}
								if (_inArray(tmp, resultsArray) === -1) {
									resultsArray.push(tmp);
								}
							}
						}
					}
				}
			}
		};
		var _accessLevelLookup = {
			always: "always",
			samedomain: "sameDomain",
			never: "never"
		};
		return function(currentDomain, configOptions) {
			var asaLower, allowScriptAccess = configOptions.allowScriptAccess;
			if (typeof allowScriptAccess === "string" && (asaLower = allowScriptAccess.toLowerCase()) && /^always|samedomain|never$/.test(asaLower)) {
				return _accessLevelLookup[asaLower];
			}
			var swfDomain = _extractDomain(configOptions.moviePath);
			if (swfDomain === null) {
				swfDomain = currentDomain;
			}
			var trustedDomains = [];
			_extractAllDomains(configOptions.trustedOrigins, trustedDomains);
			_extractAllDomains(configOptions.trustedDomains, trustedDomains);
			var len = trustedDomains.length;
			if (len > 0) {
				if (len === 1 && trustedDomains[0] === "*") {
					return "always";
				}
				if (_inArray(currentDomain, trustedDomains) !== -1) {
					if (len === 1 && currentDomain === swfDomain) {
						return "sameDomain";
					}
					return "always";
				}
			}
			return "never";
		};
	}();
	var _objectKeys = function(obj) {
		if (obj === null) {
			return [];
		}
		if (Object.keys) {
			return Object.keys(obj);
		}
		var keys = [];
		for (var prop in obj) {
			if (obj.hasOwnProperty(prop)) {
				keys.push(prop);
			}
		}
		return keys;
	};
	var _deleteOwnProperties = function(obj) {
		if (obj) {
			for (var prop in obj) {
				if (obj.hasOwnProperty(prop)) {
					delete obj[prop];
				}
			}
		}
		return obj;
	};
	var _detectFlashSupport = function() {
		var hasFlash = false;
		if (typeof flashState.disabled === "boolean") {
			hasFlash = flashState.disabled === false;
		} else {
			if (typeof ActiveXObject === "function") {
				try {
					if (new ActiveXObject("ShockwaveFlash.ShockwaveFlash")) {
						hasFlash = true;
					}
				} catch (error) {}
			}
			if (!hasFlash && navigator.mimeTypes["application/x-shockwave-flash"]) {
				hasFlash = true;
			}
		}
		return hasFlash;
	};
	function _parseFlashVersion(flashVersion) {
		return flashVersion.replace(/,/g, ".").replace(/[^0-9\.]/g, "");
	}
	function _isFlashVersionSupported(flashVersion) {
		return parseFloat(_parseFlashVersion(flashVersion)) >= 10;
	}
	var ZeroClipboard = function(elements, options) {
		if (!(this instanceof ZeroClipboard)) {
			return new ZeroClipboard(elements, options);
		}
		this.id = "" + clientIdCounter++;
		_clientMeta[this.id] = {
			instance: this,
			elements: [],
			handlers: {}
		};
		if (elements) {
			this.clip(elements);
		}
		if (typeof options !== "undefined") {
			_deprecationWarning("new ZeroClipboard(elements, options)", _globalConfig.debug);
			ZeroClipboard.config(options);
		}
		this.options = ZeroClipboard.config();
		if (typeof flashState.disabled !== "boolean") {
			flashState.disabled = !_detectFlashSupport();
		}
		if (flashState.disabled === false && flashState.outdated !== true) {
			if (flashState.bridge === null) {
				flashState.outdated = false;
				flashState.ready = false;
				_bridge();
			}
		}
	};
	ZeroClipboard.prototype.setText = function(newText) {
		if (newText && newText !== "") {
			_clipData["text/plain"] = newText;
			if (flashState.ready === true && flashState.bridge) {
				flashState.bridge.setText(newText);
			} else {}
		}
		return this;
	};
	ZeroClipboard.prototype.setSize = function(width, height) {
		if (flashState.ready === true && flashState.bridge) {
			flashState.bridge.setSize(width, height);
		} else {}
		return this;
	};
	var _setHandCursor = function(enabled) {
		if (flashState.ready === true && flashState.bridge) {
			flashState.bridge.setHandCursor(enabled);
		} else {}
	};
	ZeroClipboard.prototype.destroy = function() {
		this.unclip();
		this.off();
		delete _clientMeta[this.id];
	};
	var _getAllClients = function() {
		var i, len, client, clients = [], clientIds = _objectKeys(_clientMeta);
		for (i = 0, len = clientIds.length; i < len; i++) {
			client = _clientMeta[clientIds[i]].instance;
			if (client && client instanceof ZeroClipboard) {
				clients.push(client);
			}
		}
		return clients;
	};
	ZeroClipboard.version = "1.3.2";
	var _globalConfig = {
		swfPath: _swfPath,
		trustedDomains: window.location.host ? [ window.location.host ] : [],
		cacheBust: true,
		forceHandCursor: false,
		zIndex: 999999999,
		debug: true,
		title: null,
		autoActivate: true
	};
	ZeroClipboard.config = function(options) {
		if (typeof options === "object" && options !== null) {
			_extend(_globalConfig, options);
		}
		if (typeof options === "string" && options) {
			if (_globalConfig.hasOwnProperty(options)) {
				return _globalConfig[options];
			}
			return;
		}
		var copy = {};
		for (var prop in _globalConfig) {
			if (_globalConfig.hasOwnProperty(prop)) {
				if (typeof _globalConfig[prop] === "object" && _globalConfig[prop] !== null) {
					if ("length" in _globalConfig[prop]) {
						copy[prop] = _globalConfig[prop].slice(0);
					} else {
						copy[prop] = _extend({}, _globalConfig[prop]);
					}
				} else {
					copy[prop] = _globalConfig[prop];
				}
			}
		}
		return copy;
	};
	ZeroClipboard.destroy = function() {
		ZeroClipboard.deactivate();
		for (var clientId in _clientMeta) {
			if (_clientMeta.hasOwnProperty(clientId) && _clientMeta[clientId]) {
				var client = _clientMeta[clientId].instance;
				if (client && typeof client.destroy === "function") {
					client.destroy();
				}
			}
		}
		var htmlBridge = _getHtmlBridge(flashState.bridge);
		if (htmlBridge && htmlBridge.parentNode) {
			htmlBridge.parentNode.removeChild(htmlBridge);
			flashState.ready = null;
			flashState.bridge = null;
		}
	};
	ZeroClipboard.activate = function(element) {
		if (currentElement) {
			_removeClass(currentElement, _globalConfig.hoverClass);
			_removeClass(currentElement, _globalConfig.activeClass);
		}
		currentElement = element;
		_addClass(element, _globalConfig.hoverClass);
		_reposition();
		var newTitle = _globalConfig.title || element.getAttribute("title");
		if (newTitle) {
			var htmlBridge = _getHtmlBridge(flashState.bridge);
			if (htmlBridge) {
				htmlBridge.setAttribute("title", newTitle);
			}
		}
		var useHandCursor = _globalConfig.forceHandCursor === true || _getStyle(element, "cursor") === "pointer";
		_setHandCursor(useHandCursor);
	};
	ZeroClipboard.deactivate = function() {
		var htmlBridge = _getHtmlBridge(flashState.bridge);
		if (htmlBridge) {
			htmlBridge.style.left = "0px";
			htmlBridge.style.top = "-9999px";
			htmlBridge.removeAttribute("title");
		}
		if (currentElement) {
			_removeClass(currentElement, _globalConfig.hoverClass);
			_removeClass(currentElement, _globalConfig.activeClass);
			currentElement = null;
		}
	};
	var _bridge = function() {
		var flashBridge, len;
		var container = document.getElementById("global-zeroclipboard-html-bridge");
		if (!container) {
			var opts = ZeroClipboard.config();
			opts.jsModuleId = typeof _amdModuleId === "string" && _amdModuleId || typeof _cjsModuleId === "string" && _cjsModuleId || null;
			var allowScriptAccess = _determineScriptAccess(window.location.host, _globalConfig);
			var flashvars = _vars(opts);
			var swfUrl = _globalConfig.moviePath + _cacheBust(_globalConfig.moviePath, _globalConfig);
			var html = ' <object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" id="global-zeroclipboard-flash-bridge" width="100%" height="100%"> <param name="movie" value="' + swfUrl + '"/> <param name="allowScriptAccess" value="' + allowScriptAccess + '"/> <param name="scale" value="exactfit"/> <param name="loop" value="false"/> <param name="menu" value="false"/> <param name="quality" value="best" /> <param name="bgcolor" value="#ffffff"/> <param name="wmode" value="transparent"/> <param name="flashvars" value="' + flashvars + '"/> <embed src="' + swfUrl + '" loop="false" menu="false" quality="best" bgcolor="#ffffff" width="100%" height="100%" name="global-zeroclipboard-flash-bridge" allowScriptAccess="' + allowScriptAccess + '" allowFullScreen="false" type="application/x-shockwave-flash" wmode="transparent" pluginspage="http://www.macromedia.com/go/getflashplayer" flashvars="' + flashvars + '" scale="exactfit"> </embed> </object>';
			container = document.createElement("div");
			container.id = "global-zeroclipboard-html-bridge";
			container.setAttribute("class", "global-zeroclipboard-container");
			container.style.position = "absolute";
			container.style.left = "0px";
			container.style.top = "-9999px";
			container.style.width = "15px";
			container.style.height = "15px";
			container.style.zIndex = "" + _getSafeZIndex(_globalConfig.zIndex);
			document.body.appendChild(container);
			container.innerHTML = html;
		}
		flashBridge = document["global-zeroclipboard-flash-bridge"];
		if (flashBridge && (len = flashBridge.length)) {
			flashBridge = flashBridge[len - 1];
		}
		flashState.bridge = flashBridge || container.children[0].lastElementChild;
	};
	var _getHtmlBridge = function(flashBridge) {
		var isFlashElement = /^OBJECT|EMBED$/;
		var htmlBridge = flashBridge && flashBridge.parentNode;
		while (htmlBridge && isFlashElement.test(htmlBridge.nodeName) && htmlBridge.parentNode) {
			htmlBridge = htmlBridge.parentNode;
		}
		return htmlBridge || null;
	};
	var _reposition = function() {
		if (currentElement) {
			var pos = _getDOMObjectPosition(currentElement, _globalConfig.zIndex);
			var htmlBridge = _getHtmlBridge(flashState.bridge);
			if (htmlBridge) {
				htmlBridge.style.top = pos.top + "px";
				htmlBridge.style.left = pos.left + "px";
				htmlBridge.style.width = pos.width + "px";
				htmlBridge.style.height = pos.height + "px";
				htmlBridge.style.zIndex = pos.zIndex + 1;
			}
			if (flashState.ready === true && flashState.bridge) {
				flashState.bridge.setSize(pos.width, pos.height);
			}
		}
		return this;
	};
	ZeroClipboard.prototype.on = function(eventName, func) {
		var i, len, events, added = {}, handlers = _clientMeta[this.id] && _clientMeta[this.id].handlers;
		if (typeof eventName === "string" && eventName) {
			events = eventName.toLowerCase().split(/\s+/);
		} else if (typeof eventName === "object" && eventName && typeof func === "undefined") {
			for (i in eventName) {
				if (eventName.hasOwnProperty(i) && typeof i === "string" && i && typeof eventName[i] === "function") {
					this.on(i, eventName[i]);
				}
			}
		}
		if (events && events.length) {
			for (i = 0, len = events.length; i < len; i++) {
				eventName = events[i].replace(/^on/, "");
				added[eventName] = true;
				if (!handlers[eventName]) {
					handlers[eventName] = [];
				}
				handlers[eventName].push(func);
			}
			if (added.noflash && flashState.disabled) {
				_receiveEvent.call(this, "noflash", {});
			}
			if (added.wrongflash && flashState.outdated) {
				_receiveEvent.call(this, "wrongflash", {
					flashVersion: flashState.version
				});
			}
			if (added.load && flashState.ready) {
				_receiveEvent.call(this, "load", {
					flashVersion: flashState.version
				});
			}
		}
		return this;
	};
	ZeroClipboard.prototype.off = function(eventName, func) {
		var i, len, foundIndex, events, perEventHandlers, handlers = _clientMeta[this.id] && _clientMeta[this.id].handlers;
		if (arguments.length === 0) {
			events = _objectKeys(handlers);
		} else if (typeof eventName === "string" && eventName) {
			events = eventName.split(/\s+/);
		} else if (typeof eventName === "object" && eventName && typeof func === "undefined") {
			for (i in eventName) {
				if (eventName.hasOwnProperty(i) && typeof i === "string" && i && typeof eventName[i] === "function") {
					this.off(i, eventName[i]);
				}
			}
		}
		if (events && events.length) {
			for (i = 0, len = events.length; i < len; i++) {
				eventName = events[i].toLowerCase().replace(/^on/, "");
				perEventHandlers = handlers[eventName];
				if (perEventHandlers && perEventHandlers.length) {
					if (func) {
						foundIndex = _inArray(func, perEventHandlers);
						while (foundIndex !== -1) {
							perEventHandlers.splice(foundIndex, 1);
							foundIndex = _inArray(func, perEventHandlers, foundIndex);
						}
					} else {
						handlers[eventName].length = 0;
					}
				}
			}
		}
		return this;
	};
	ZeroClipboard.prototype.handlers = function(eventName) {
		var prop, copy = null, handlers = _clientMeta[this.id] && _clientMeta[this.id].handlers;
		if (handlers) {
			if (typeof eventName === "string" && eventName) {
				return handlers[eventName] ? handlers[eventName].slice(0) : null;
			}
			copy = {};
			for (prop in handlers) {
				if (handlers.hasOwnProperty(prop) && handlers[prop]) {
					copy[prop] = handlers[prop].slice(0);
				}
			}
		}
		return copy;
	};
	var _dispatchClientCallbacks = function(eventName, context, args, async) {
		var handlers = _clientMeta[this.id] && _clientMeta[this.id].handlers[eventName];
		if (handlers && handlers.length) {
			var i, len, func, originalContext = context || this;
			for (i = 0, len = handlers.length; i < len; i++) {
				func = handlers[i];
				context = originalContext;
				if (typeof func === "string" && typeof window[func] === "function") {
					func = window[func];
				}
				if (typeof func === "object" && func && typeof func.handleEvent === "function") {
					context = func;
					func = func.handleEvent;
				}
				if (typeof func === "function") {
					_dispatchCallback(func, context, args, async);
				}
			}
		}
		return this;
	};
	ZeroClipboard.prototype.clip = function(elements) {
		elements = _prepClip(elements);
		for (var i = 0; i < elements.length; i++) {
			if (elements.hasOwnProperty(i) && elements[i] && elements[i].nodeType === 1) {
				if (!elements[i].zcClippingId) {
					elements[i].zcClippingId = "zcClippingId_" + elementIdCounter++;
					_elementMeta[elements[i].zcClippingId] = [ this.id ];
					if (_globalConfig.autoActivate === true) {
						_addEventHandler(elements[i], "mouseover", _elementMouseOver);
					}
				} else if (_inArray(this.id, _elementMeta[elements[i].zcClippingId]) === -1) {
					_elementMeta[elements[i].zcClippingId].push(this.id);
				}
				var clippedElements = _clientMeta[this.id].elements;
				if (_inArray(elements[i], clippedElements) === -1) {
					clippedElements.push(elements[i]);
				}
			}
		}
		return this;
	};
	ZeroClipboard.prototype.unclip = function(elements) {
		var meta = _clientMeta[this.id];
		if (meta) {
			var clippedElements = meta.elements;
			var arrayIndex;
			if (typeof elements === "undefined") {
				elements = clippedElements.slice(0);
			} else {
				elements = _prepClip(elements);
			}
			for (var i = elements.length; i--; ) {
				if (elements.hasOwnProperty(i) && elements[i] && elements[i].nodeType === 1) {
					arrayIndex = 0;
					while ((arrayIndex = _inArray(elements[i], clippedElements, arrayIndex)) !== -1) {
						clippedElements.splice(arrayIndex, 1);
					}
					var clientIds = _elementMeta[elements[i].zcClippingId];
					if (clientIds) {
						arrayIndex = 0;
						while ((arrayIndex = _inArray(this.id, clientIds, arrayIndex)) !== -1) {
							clientIds.splice(arrayIndex, 1);
						}
						if (clientIds.length === 0) {
							if (_globalConfig.autoActivate === true) {
								_removeEventHandler(elements[i], "mouseover", _elementMouseOver);
							}
							delete elements[i].zcClippingId;
						}
					}
				}
			}
		}
		return this;
	};
	ZeroClipboard.prototype.elements = function() {
		var meta = _clientMeta[this.id];
		return meta && meta.elements ? meta.elements.slice(0) : [];
	};
	var _getAllClientsClippedToElement = function(element) {
		var elementMetaId, clientIds, i, len, client, clients = [];
		if (element && element.nodeType === 1 && (elementMetaId = element.zcClippingId) && _elementMeta.hasOwnProperty(elementMetaId)) {
			clientIds = _elementMeta[elementMetaId];
			if (clientIds && clientIds.length) {
				for (i = 0, len = clientIds.length; i < len; i++) {
					client = _clientMeta[clientIds[i]].instance;
					if (client && client instanceof ZeroClipboard) {
						clients.push(client);
					}
				}
			}
		}
		return clients;
	};
	_globalConfig.hoverClass = "zeroclipboard-is-hover";
	_globalConfig.activeClass = "zeroclipboard-is-active";
	_globalConfig.trustedOrigins = null;
	_globalConfig.allowScriptAccess = null;
	_globalConfig.useNoCache = true;
	_globalConfig.moviePath = "ZeroClipboard.swf";
	ZeroClipboard.detectFlashSupport = function() {
		_deprecationWarning("ZeroClipboard.detectFlashSupport", _globalConfig.debug);
		return _detectFlashSupport();
	};
	ZeroClipboard.dispatch = function(eventName, args) {
		if (typeof eventName === "string" && eventName) {
			var cleanEventName = eventName.toLowerCase().replace(/^on/, "");
			if (cleanEventName) {
				var clients = currentElement ? _getAllClientsClippedToElement(currentElement) : _getAllClients();
				for (var i = 0, len = clients.length; i < len; i++) {
					_receiveEvent.call(clients[i], cleanEventName, args);
				}
			}
		}
	};
	ZeroClipboard.prototype.setHandCursor = function(enabled) {
		_deprecationWarning("ZeroClipboard.prototype.setHandCursor", _globalConfig.debug);
		enabled = typeof enabled === "boolean" ? enabled : !!enabled;
		_setHandCursor(enabled);
		_globalConfig.forceHandCursor = enabled;
		return this;
	};
	ZeroClipboard.prototype.reposition = function() {
		_deprecationWarning("ZeroClipboard.prototype.reposition", _globalConfig.debug);
		return _reposition();
	};
	ZeroClipboard.prototype.receiveEvent = function(eventName, args) {
		_deprecationWarning("ZeroClipboard.prototype.receiveEvent", _globalConfig.debug);
		if (typeof eventName === "string" && eventName) {
			var cleanEventName = eventName.toLowerCase().replace(/^on/, "");
			if (cleanEventName) {
				_receiveEvent.call(this, cleanEventName, args);
			}
		}
	};
	ZeroClipboard.prototype.setCurrent = function(element) {
		_deprecationWarning("ZeroClipboard.prototype.setCurrent", _globalConfig.debug);
		ZeroClipboard.activate(element);
		return this;
	};
	ZeroClipboard.prototype.resetBridge = function() {
		_deprecationWarning("ZeroClipboard.prototype.resetBridge", _globalConfig.debug);
		ZeroClipboard.deactivate();
		return this;
	};
	ZeroClipboard.prototype.setTitle = function(newTitle) {
		_deprecationWarning("ZeroClipboard.prototype.setTitle", _globalConfig.debug);
		newTitle = newTitle || _globalConfig.title || currentElement && currentElement.getAttribute("title");
		if (newTitle) {
			var htmlBridge = _getHtmlBridge(flashState.bridge);
			if (htmlBridge) {
				htmlBridge.setAttribute("title", newTitle);
			}
		}
		return this;
	};
	ZeroClipboard.setDefaults = function(options) {
		_deprecationWarning("ZeroClipboard.setDefaults", _globalConfig.debug);
		ZeroClipboard.config(options);
	};
	ZeroClipboard.prototype.addEventListener = function(eventName, func) {
		_deprecationWarning("ZeroClipboard.prototype.addEventListener", _globalConfig.debug);
		return this.on(eventName, func);
	};
	ZeroClipboard.prototype.removeEventListener = function(eventName, func) {
		_deprecationWarning("ZeroClipboard.prototype.removeEventListener", _globalConfig.debug);
		return this.off(eventName, func);
	};
	ZeroClipboard.prototype.ready = function() {
		_deprecationWarning("ZeroClipboard.prototype.ready", _globalConfig.debug);
		return flashState.ready === true;
	};
	var _receiveEvent = function(eventName, args) {
		eventName = eventName.toLowerCase().replace(/^on/, "");
		var cleanVersion = args && args.flashVersion && _parseFlashVersion(args.flashVersion) || null;
		var element = currentElement;
		var performCallbackAsync = true;
		switch (eventName) {
			case "load":
				if (cleanVersion) {
					if (!_isFlashVersionSupported(cleanVersion)) {
						_receiveEvent.call(this, "onWrongFlash", {
							flashVersion: cleanVersion
						});
						return;
					}
					flashState.outdated = false;
					flashState.ready = true;
					flashState.version = cleanVersion;
				}
				break;
			case "wrongflash":
				if (cleanVersion && !_isFlashVersionSupported(cleanVersion)) {
					flashState.outdated = true;
					flashState.ready = false;
					flashState.version = cleanVersion;
				}
				break;
			case "mouseover":
				_addClass(element, _globalConfig.hoverClass);
				break;
			case "mouseout":
				if (_globalConfig.autoActivate === true) {
					ZeroClipboard.deactivate();
				}
				break;
			case "mousedown":
				_addClass(element, _globalConfig.activeClass);
				break;
			case "mouseup":
				_removeClass(element, _globalConfig.activeClass);
				break;
			case "datarequested":
				var targetId = element.getAttribute("data-clipboard-target"), targetEl = !targetId ? null : document.getElementById(targetId);
				if (targetEl) {
					var textContent = targetEl.value || targetEl.textContent || targetEl.innerText;
					if (textContent) {
						this.setText(textContent);
					}
				} else {
					var defaultText = element.getAttribute("data-clipboard-text");
					if (defaultText) {
						this.setText(defaultText);
					}
				}
				performCallbackAsync = false;
				break;
			case "complete":
				_deleteOwnProperties(_clipData);
				break;
		}
		var context = element;
		var eventArgs = [ this, args ];
		return _dispatchClientCallbacks.call(this, eventName, context, eventArgs, performCallbackAsync);
	};
	if (typeof define === "function" && define.amd) {
		define([ "require", "exports", "module" ], function(require, exports, module) {
			_amdModuleId = module && module.id || null;
			return ZeroClipboard;
		});
	} else if (typeof module === "object" && module && typeof module.exports === "object" && module.exports) {
		_cjsModuleId = module.id || null;
		module.exports = ZeroClipboard;
	} else {
		window.ZeroClipboard = ZeroClipboard;
	}
})();
/**
 * Terrific JavaScript Framework v2.0.1
 * http://terrifically.org
 *
 * Copyright 2012, Remo Brunschwiler
 * MIT Licensed.
 *
 * Date: Mon, 10 Sep 2012 13:44:44 GMT
 *
 *
 * Includes:
 * Simple JavaScript Inheritance
 * By John Resig http://ejohn.org/
 * MIT Licensed.
 *
 * @module Tc
 *
 */
var Tc = Tc || {};

/*
 * The base library object.
 */
Tc.$ = $;
//Tc.$ = jQuery;// magnolia stk uses jQuery

/*
 * Simple JavaScript Inheritance
 * By John Resig http://ejohn.org/
 * MIT Licensed.
 */
(function(){
    var initializing = false, fnTest = /xyz/.test(function() { xyz; }) ? /\b_super\b/ : /.*/;
    
    // The base Class implementation (does nothing)
    this.Class = function(){
    };
    
    // Create a new Class that inherits from this class
    Class.extend = function(prop){
        var _super = this.prototype;
        
        // Instantiate a base class (but only create the instance,
        // don't run the init constructor)
        initializing = true;
        var prototype = new this();
        initializing = false;
        
        // Copy the properties over onto the new prototype
        for (var name in prop) {
            // Check if we're overwriting an existing function
            prototype[name] = typeof prop[name] == "function" &&
            typeof _super[name] == "function" &&
            fnTest.test(prop[name]) ? (function(name, fn){
                return function(){
                    var tmp = this._super;
                    
                    // Add a new ._super() method that is the same method
                    // but on the super-class
                    this._super = _super[name];
                    
                    // The method only need to be bound temporarily, so we
                    // remove it when we're done executing
                    var ret = fn.apply(this, arguments);
                    this._super = tmp;
                    
                    return ret;
                };
            })(name, prop[name]) : prop[name];
        }
        
        // The dummy class constructor
        function Class(){
            // All construction is actually done in the init method
            if (!initializing && this.init) {
				this.init.apply(this, arguments);
			}
        }
        
        // Populate our constructed prototype object
        Class.prototype = prototype;
        
        // Enforce the constructor to be what we expect
        Class.constructor = Class;
        
        // And make this class extendable
        Class.extend = arguments.callee;
        
        return Class;
    };
})();

/**
 * Contains the application base config.
 * The base config can be extended or overwritten either via
 * new Application ($ctx, config) during bootstrapping the application or via
 * overriding the Tc.Config object in your project.
 *
 * @author Remo Brunschwiler
 * @namespace Tc
 * @class Config
 * @static
 */
Tc.Config = {
    /** 
     * The paths for the different types of dependencies.
     *
     * @property dependencies
     * @type Object
     */
    dependencies: {
        css: '/css/dependencies',
        js: '/js/dependencies'
    }
};

(function($) {
    "use strict";

    /**
     * Responsible for application-wide issues such as the creation of modules and establishing connections between them.
     *
     * @author Remo Brunschwiler
     * @namespace Tc
     * @class Application
     */
    Tc.Application = Class.extend({

        /**
         * Initializes the application.
         *
         * @method init
         * @constructor
         * @param {jQuery} $ctx
         *      The jQuery context
         * @param {Object} config
         *      The configuration
         */
        init: function($ctx, config) {
            /**
             * The configuration.
             *
             * @property config
             * @type Object
             */
            this.config = $.extend(Tc.Config, config);

            /**
             * The jQuery context.
             *
             * @property $ctx
             * @type jQuery
             */
            this.$ctx = $ctx || $('body');

            /**
             * Contains references to all modules on the page. This can, for
             * example, be useful when there are interactions between Flash
             * objects and Javascript.
             *
             * @property modules
             * @type Array
             */
            this.modules = [];

            /**
             * Contains references to all connectors on the page.
             *
             * @property connectors
             * @type Object
             */
            this.connectors = {};

            /**
             * The sandbox to get the resources from
             * This sandbox is shared between all modules.
             *
             * @property sandbox
             * @type Sandbox
             */
            this.sandbox = new Tc.Sandbox(this, this.config);
        },

        /**
         * Register modules withing scope
         * Automatically registers all modules within the scope,
         * as long as the modules use the OOCSS naming conventions.
         *
         * @method registerModules
         * @param {jQuery} $ctx
         *      The jQuery context
         * @return {Array}
         *      A list containing the references of the registered modules
         */
        registerModules : function($ctx) {
            var self = this,
                modules = [],
                stringUtils = Tc.Utils.String;

            $ctx = $ctx || this.$ctx;

            $ctx.find('.mod:not([data-ignore="true"])').each(function() {
                var $this = $(this),
                    classes = $this.attr('class').split(' ');

                /*
                 * A module can have several different classes and data attributes.
                 * See below for possible values.
                 */

                /*
                 * @config .mod
                 *
                 * Indicates that it is a base module, this is the default and
                 * no JavaScript needs to be involved. It must occur excactly
                 * once.
                 */

                /*
                 * @config .mod{moduleName} || .mod-{module-name}
                 *
                 * Indicates that it is a module of type basic, which is
                 * derived from the base module. It can occur at most
                 * once. Example: .modBasic || .mod-basic
                 */

                /*
                 * @config .skin{moduleName}{skinName} || .skin-{module-name}-{skin-name}
                 *
                 * Indicates that the module basic has the submarine skin. It
                 * will be decorated by the skin JS (if it exists). It can occur
                 * arbitrarily. Example: .skinBasicSubmarine || .skin-basic-submarine
                 */

                /*
                 * @config data-connectors
                 *
                 * A module can have a comma-separated list of data connectors.
                 * The list contains the IDs of the connectors in the following
                 * schema: {connectorType}-{connectorId}
                 *
                 * {connectorType} is optional. If only the {connectorId} is given, the
                 * default connector is instantiated.
                 *
                 * The example MasterSlave-Navigation decodes to: type =
                 * MasterSlave, id = Navigation. This instantiates the MasterSlave
                 * connector (as mediator) with the connector id Navigation.
                 * The connector id is used to chain the appropriate (the ones with the same id)
                 * modules together and to improve the reusability of the connector.
                 * It can contain multiple connector ids (e.g. 1,2,MasterSlave-Navigation).
                 */

                if (classes.length > 1) {
                    var modName,
                        skins = [],
                        connectors = [],
                        dataConnectors;

                    for (var i = 0, len = classes.length; i < len; i++) {
                        var part = $.trim(classes[i]);

                        // do nothing for empty parts
                        if(part) {
                            // convert to camel if necessary
                            if (part.indexOf('-') > -1) {
                                part = stringUtils.toCamel(part);
                            }

                            if (part.indexOf('mod') === 0 && part.length > 3) {
                                modName = part.substr(3);
                            }
                            else if (part.indexOf('skin') === 0) {
                                // Remove the mod name part from the skin name
                                skins.push(part.substr(4).replace(modName, ''));
                            }
                        }
                    }

                    /*
                     * This needs to be done via attr() instead of data().
                     * As data() cast a single number-only connector to an integer, the split will fail.
                     */
                    dataConnectors = $this.attr('data-connectors');

                    if (dataConnectors) {
                        connectors = dataConnectors.split(',');
                        for (var i = 0, len = connectors.length; i < len; i++) {
                            var connector = $.trim(connectors[i]);
                            // do nothing for empty connectors
                            if(connector) {
                                connectors[i] = connector;
                            }
                        }
                    }

                    if (modName && Tc.Module[modName]) {
                        modules.push(self.registerModule($this, modName, skins, connectors));
                    }
                }
            });

            return modules;
        },

        /**
         * Unregisters the modules given by the module instances.
         *
         * @method unregisterModule
         * @param {Array} modules
         *      A list containting the module instances to unregister
         */
        unregisterModules : function(modules) {
            var connectors = this.connectors;

            modules = modules || this.modules;

            if (modules === this.modules) {
                // Clear everything if the arrays are equal
                this.connectors = [];
                this.modules = [];
            }
            else {
                // Unregister the given modules
                for (var i = 0, len = modules.length; i < len; i++) {
                    var module = modules[i],
                        index;

                    // Delete the references in the connectors
                    for (var connectorId in connectors) {
                        if (connectors.hasOwnProperty(connectorId)) {
                            connectors[connectorId].unregisterComponent(module);
                        }
                    }

                    // Delete the module instance itself
                    index = $.inArray(module, this.modules);
                    if(index > -1) {
                        delete this.modules[index];
                    }
                }
            }
        },

        /**
         * Starts (intializes) the registered modules.
         *
         * @method start
         * @param {Array} modules
         *      A list of the modules to start
         */
        start: function(modules) {
            modules = modules || this.modules;

            // Start the modules
            for (var i = 0, len = modules.length; i < len; i++) {
                modules[i].start();
            }
        },

        /**
         * Stops the registered modules.
         *
         * @method stop
         * @param {Array} modules
         *      A list containting the module instances to stop
         */
        stop: function(modules) {
            modules = modules || this.modules;

            // Stop the modules
            for (var i = 0, len = modules.length; i < len; i++) {
                modules[i].stop();
            }
        },

        /**
         * Registers a module.
         *
         * @method registerModule
         * @param {jQuery} $node
         *      The module node
         * @param {String} modName
         *      The module name. It must match the class name of the module
         * @param {Array} skins
         *      A list of skin names. Each entry must match a class name of a skin
         * @param {Array} connectors
         *      A list of connectors identifiers (e.g. MasterSlave-Navigation)
         *      Schema: {connectorName}-{connectorId}
         * @return {Module}
         *      The reference to the registered module
         */
        registerModule : function($node, modName, skins, connectors) {
            var modules = this.modules;

            modName = modName || undefined;
            skins = skins || [];
            connectors = connectors || [];

            if (modName && Tc.Module[modName]) {
                // Generate a unique ID for every module
                var id = modules.length;
                $node.data('id', id);

                // Instantiate module
                modules[id] = new Tc.Module[modName]($node, this.sandbox, id);

                // Decorate it
                for (var i = 0, len = skins.length; i < len; i++) {
                    var skinName = skins[i];

                    if (Tc.Module[modName][skinName]) {
                        modules[id] = modules[id].getDecoratedModule(modName, skinName);
                    }
                }

                // Register connections
                for (var i = 0, len = connectors.length; i < len; i++) {
                    this.registerConnection(connectors[i], modules[id]);
                }

                return modules[id];
            }

            return null;
        },

        /**
         * Registers a connection between a module and a connector.
         *
         * @method registerConnection
         * @param {String} connector
         *      The full connector name (e.g. MasterSlave-Navigation)
         * @param {Module} component
         *      The module instance
         */
        registerConnection : function(connector, component) {
            connector = $.trim(connector);

            var parts = connector.split('-'),
                connectorType,
                connectorId,
                identifier;

            if(parts.length === 1) {
                // default connector
                identifier = connectorId = parts[0];
            }
            else if(parts.length === 2) {
                // a specific connector type is given
                connectorType = parts[0];
                connectorId = parts[1];
                identifier = connectorType + connectorId;
            }

            if(identifier) {
                var connectors = this.connectors;

                if (!connectors[identifier]) {
                    // Instantiate the appropriate connector if it does not exist yet
                    if (!connectorType) {
                        connectors[identifier] = new Tc.Connector(connectorId);
                    }
                    else if (Tc.Connector[connectorType]) {
                        connectors[identifier] = new Tc.Connector[connectorType](connectorId);
                    }
                }

                if (connectors[identifier]) {
                    /*
                     * The connector observes the component and attaches it as
                     * an observer.
                     */
                    component.attachConnector(connectors[identifier]);

                    /*
                     * The component wants to be informed over state changes.
                     * It registers it as connector member.
                     */
                    connectors[identifier].registerComponent(component);
                }
            }
        },

        /**
         * Unregisters a module from a connector.
         *
         * @method unregisterConnection
         * @param {String} connectorId
         *      The connector channel id (e.g. 2)
         * @param {Module} component
         *      The module instance
         */
        unregisterConnection : function(connectorId, component) {
            var connector =  this.connectors[connectorId];

            // Delete the references in the connector and the module
            if (connector) {
                connector.unregisterComponent(component);
                component.detachConnector(connector);
            }
        }
    });
})(Tc.$);

(function($) {
    "use strict";

    /**
     * The sandbox is used as a central point to get resources from, grant
     * permissions, etc.  It is shared between all modules.
     *
     * @author Remo Brunschwiler
     * @namespace Tc
     * @class Sandbox
     */
    Tc.Sandbox = Class.extend({

        /**
         * Initializes the Sandbox.
         *
         * @method init
         * @constructor
         * @param {Applicaton} application 
         *      The application reference
         * @param {Object} config 
         *      The configuration
         */
        init : function(application, config) {

            /**
             * The application
             *
             * @property application
             * @type Application
             */
            this.application = application;

            /**
             * The configuration.
             *
             * @property config
             * @type Object
             */
            this.config = config;

            /**
             * Contains the 'after' hook module callbacks.
             *
             * @property afterCallbacks
             * @type Array
             */
            this.afterCallbacks = [];
        },

        /**
         * Adds (register and start) all modules in the given context scope.
         *
         * @method addModules
         * @param {jQuery} $ctx 
         *      The jQuery context
         * @return {Array} 
         *      A list containing the references of the registered modules
         */
        addModules: function($ctx) {
            var modules = [],
                application = this.application;

            if ($ctx) {
                // Register modules
                modules = application.registerModules($ctx);

                // Start modules
                application.start(modules);
            }

            return modules;
        },

        /**
         * Removes a module by module instances.
         * This stops and unregisters a module through a module instance.
         *
         * @method removeModules
         * @param {Array} modules 
         *      A list containting the module instances to remove
         */
        removeModules: function(modules) {
            var application = this.application;

            if (modules) {
                // Stop modules
                application.stop(modules);

                // Unregister modules
                application.unregisterModules(modules);
            }
        },

        /**
         * Subscribes a module to a connector.
         *
         * @method subscribe
         * @param {String} connector The full connector name (e.g. MasterSlave-Navigation)
         * @param {Module} module The module instance
         */
        subscribe: function(connector, module) {
            var application = this.application;

            if(module instanceof Tc.Module && connector) {
                // explicitly cast connector to string
                connector = connector + '';
                application.registerConnection(connector, module);
            }
        },

        /**
         * Unsubscribes a module from a connector.
         *
         * @method unsubscribe
         * @param {String} connectorId The connector channel id (e.g. 2 or Navigation)
         * @param {Module} module The module instance
         */
        unsubscribe: function(connectorId, module) {
            var application = this.application;

            if(module instanceof Tc.Module && connectorId) {
                // explicitly cast connector id to string
                connectorId = connectorId + '';
                application.unregisterConnection(connectorId, module);
            }
        },

        /**
         * Gets the appropriate module for the given ID.
         *
         * @method getModuleById
         * @param {int} id 
         *      The module ID
         * @return {Module} 
         *      The appropriate module
         */
        getModuleById: function(id) {
            var application = this.application;

            if (application.modules[id] !== undefined) {
                return application.modules[id];
            }
            else {
                throw new Error('the module with the id ' + id + 
                                ' does not exist');
            }
        },

        /**
         * Gets the application config.
         *
         * @method getConfig
         * @return {Object} 
         *      The configuration object
         */
        getConfig: function() {
            return this.config;
        },

        /**
         * Gets an application config param.
         *
         * @method getConfigParam
         * @param {String} name 
         *      The param name
         * @return {mixed} 
         *      The appropriate configuration param
         */
        getConfigParam: function(name) {
            var config = this.config;

            if (config[name] !== undefined) {
                return config[name];
            }
            else {
                throw new Error('the config param ' + name + ' does not exist');
            }
        },

        /**
         * Collects the module status messages and handles the callbacks.
         * This means that it is ready for the 'after' hook.
         *
         * @method ready
         * @param {Function} callback 
         *      The 'after' hook module callback
         */
        ready: function(callback) {
            var afterCallbacks = this.afterCallbacks;

            // Add the callback to the stack
            afterCallbacks.push(callback);

            // Check whether all modules are ready for the 'after' hook
            if (this.application.modules.length === afterCallbacks.length) {
                for (var i = 0; i < afterCallbacks.length; i++) {
                    var afterCallback = afterCallbacks[i];

                    if(typeof afterCallback === "function") {
                        // make sure the callback is only executed once (and is not called during addModules)
                        delete afterCallbacks[i];
                        afterCallback();
                    }
                }
            }
        }
    });
})(Tc.$);

(function($) {
    "use strict";

    /**
     * Base class for the different modules.
     *
     * @author Remo Brunschwiler
     * @namespace Tc
     * @class Module
     */
    Tc.Module = Class.extend({

        /**
         * Initializes the Module.
         *
         * @method init
         * @constructor
         * @param {jQuery} $ctx
         *      The jQuery context
         * @param {Sandbox} sandbox
         *      The sandbox to get the resources from
         * @param {String} id
         *      The Unique module ID
         */
        init: function($ctx, sandbox, id) {
            /**
             * Contains the module context.
             *
             * @property $ctx
             * @type jQuery
             */
            this.$ctx = $ctx;

            /**
             * Contains the unique module ID.
             *
             * @property id
             * @type String
             */
            this.id = id;

            /**
             * Contains the attached connectors.
             *
             * @property connectors
             * @type Object
             */
            this.connectors = {};

            /**
             * The sandbox to get the resources from.
             *
             * @property sandbox
             * @type Sandbox
             */
            this.sandbox = sandbox;
        },

        /**
         * Template method to start (i.e. init) the module.
         * This method provides hook functions which can be overridden
         * by the individual instance.
         *
         * @method start
         */
        start: function() {
            var self = this;

            // Call the hook method from the individual instance and provide the appropriate callback
            if (this.on) {
                this.on(function() {
                    self.initAfter();
                });
            }
        },

        /**
         * Template method to stop the module.
         *
         * @method stop
         */
        stop: function() {
            var $ctx = this.$ctx;

            // Remove all bound events and associated jQuery data
            $('*', $ctx).unbind().removeData();
            $ctx.unbind().removeData();
        },


        /**
         * Initialization callback.
         *
         * @method initAfter
         * @protected
         */
        initAfter: function() {
            var self = this;

            this.sandbox.ready(function() {
                /*
                 * Call the 'after' hook method from the individual instance
                 */
                if (self.after) {
                    self.after();
                }
            });
        },

        /**
         * Notifies all attached connectors about changes.
         *
         * @method fire
         * @param {String} state The new state
         * @param {Object} data The data to provide to your connected modules (optional)
         * @param {Array} channels  A list containting the channel ids to send the event to (optional)
         * @param {Function} defaultAction The default action to perform (optinal)
         */
        fire: function(state, data, channels, defaultAction) {
            var self = this,
                connectors = this.connectors,
                shouldBeCalled = true;  // indicates whether the default handler should be called

            // validate params
            if(channels == null && defaultAction == null) {
                // Max. 2 params
                if (typeof data === 'function') {
                    // (state, defaultAction)
                    defaultAction = data;
                    data = undefined;
                }
                else if ($.isArray(data)) {
                    // (state, channels)
                    channels = data;
                    data = undefined;
                }
            }
            else if(defaultAction == null) {
                // 2-3 params
                if (typeof channels === 'function') {
                    // (state, data, defaultAction)
                    defaultAction = channels;
                    channels = undefined;
                }

                if ($.isArray(data)) {
                    // (state, channels, defaultAction)
                    channels = data;
                    data = undefined;
                }
            }

            state = Tc.Utils.String.capitalize(state);
            data = data || {};
            channels = channels || Object.keys(connectors);

            for (var i = 0, len = channels.length; i < len; i++) {
                var connectorId = channels[i];
                if(connectors.hasOwnProperty(connectorId)) {
                    var connector = connectors[connectorId],
                        proceed = connector.notify(self, 'on' + state, data) || false;

                    if (!proceed) {
                        shouldBeCalled = false;
                    }

                } else {
                    throw new Error('the module #' + self.id + ' is not connected to connector ' + connectorId);
                }
            }

            // Execute default action unless a veto is provided
            if (shouldBeCalled) {
                if (typeof defaultAction === 'function') {
                    defaultAction();
                }
            }
        },

        /**
         * Attaches a connector (observer).
         *
         * @method attachConnector
         * @param {Connector} connector
         *      The connector to attach
         */
        attachConnector: function(connector) {
            this.connectors[connector.connectorId] = connector;
        },

        /**
         * Detaches a connector (observer).
         *
         * @method detachConnector
         * @param {Connector} connector The connector to detach
         */
        detachConnector: function(connector) {
            delete this.connectors[connector.connectorId];
        },

        /**
         * Decorates itself with the given skin.
         *
         * @method getDecoratedModule
         * @param {String} module The name of the module
         * @param {String} skin The name of the skin
         * @return {Module} The decorated module
         */
        getDecoratedModule: function(module, skin) {
            if (Tc.Module[module][skin]) {
                var Decorator = Tc.Module[module][skin];

                /*
                 * Sets the prototype object to the module.
                 * So the "non-decorated" functions will be called on the module
                 * without implementing the whole module interface.
                 */
                Decorator.prototype = this;
                Decorator.prototype.constructor = Tc.Module[module][skin];

                return new Decorator(this);
            }

            return null;
        }
    });
})(Tc.$);

(function($) {
    "use strict";

    /**
     * Base class for the different connectors.
     *
     * @author Remo Brunschwiler
     * @namespace Tc
     * @class Connector
     */
    Tc.Connector = Class.extend({

        /**
         * Initializes the Connector.
         *
         * @method init
         * @constructor
         * @param {String} connectorId
         *      The unique connector ID
         */
        init : function(connectorId) {
            this.connectorId = connectorId;
            this.components = {};
        },

        /**
         * Registers a component.
         *
         * @method registerComponent
         * @param {Module} component 
         *      The module to register
         */
        registerComponent: function(component) {
            this.components[component.id] = {
                'component': component
            };
        },

        /**
         * Unregisters a component.
         *
         * @method unregisterComponent
         * @param {Module} component 
         *      The module to unregister
         */
        unregisterComponent: function(component) {
            var components = this.components;

            if(components[component.id]) {
                delete components[component.id];
            }
        },

        /**
         * Notifies all registered components about a state change 
         * This can be be overriden in the specific connectors.
         *
         * @method notify
         * @param {Module} origin
         *      The module that sends the state change
         * @param {String} state 
         *      The component's state
         * @param {Object} data 
         *      Contains the state relevant data (if any)
         * @return {boolean}
         *      Indicates whether the default action should be excuted or not
         */
        notify: function(origin, state, data, callback) {
            /*
             * Gives the components the ability to prevent the default- and
             * after action from the events by returning false in the
             * on {Event}-Handler.
             */
            var proceed = true,
                components = this.components;

            for (var id in components) {
                if(components.hasOwnProperty(id)) {
                    var component = components[id].component;
                    if (component !== origin && component[state]) {
                        if (component[state](data) === false) {
                            proceed = false;
                        }
                    }
                }
            }

            return proceed;
        }
    });
})(Tc.$);

/*
 * Contains utility functions for several tasks.
 */
Tc.Utils = {};

// Helper
if (!Object.keys) {
    Object.keys = function (obj) {
        var keys = [], k;
        for (k in obj) {
            if (Object.prototype.hasOwnProperty.call(obj, k)) {
                keys.push(k);
            }
        }
        return keys;
    };
}
/**
 * Contains utility functions for string concerning tasks.
 *
 * @author Remo Brunschwiler
 * @namespace Tc
 * @class Utils.String
 * @static
 */
(function($) {
    "use strict";

    Tc.Utils.String = {
        /**
         * Capitalizes the first letter of the given string.
         *
         * @method capitalize
         * @param {String} str 
         *      The original string
         * @return {String} 
         *      The capitalized string
         */
        capitalize: function(str) {
            // Capitalize the first letter
            return str.substr(0, 1).toUpperCase().concat(str.substr(1));
        },

        /**
         * Camelizes the given string.
         *
         * @method toCamel
         * @param {String} str 
         *      The original string
         * @return {String} 
         *      The camelized string
         */
        toCamel: function(str){
            return str.replace(/(\-[A-Za-z])/g, function($1){return $1.toUpperCase().replace('-','');});
        }
    };
})(Tc.$);


/**
 * https://github.com/MarcDiethelm/terrificjs-extensions
 * Adds some sugar and enhancements to @brunschgi's excellent Terrificjs frontend framework.
 * @file terrificjs-extensions.js
 * @license MIT
 * @copyright 2014 Marc Diethelm
 */

(function ($) {

	'use strict';


	/**
	 * Select elements in the module context. Usage: this.$(selector)
	 * @author Marc Diethelm <marc.diethelm@namics.com>
	 * @param {String} selector
	 * @returns {Object} - jQuery collection
	 */
	Tc.Module.prototype.$ = function $$(selector) {
		return this.$ctx.find(selector);
	};


	/**
	 * Deprecated. Use Tc.Module.prototype.$
	 * Select elements in the module context. Usage: this.$$(selector)
	 * @deprecated Use Tc.Module.prototype.$
	 * @see Tc.Module.prototype.$
	 * @author Marc Diethelm <marc.diethelm@namics.com>
	 * @param {String} selector
	 * @returns {Object} - jQuery collection
	 */
	Tc.Module.prototype.$$ = Tc.Module.prototype.$;

	/**
	 * Bind methods to Terrific module context. Usage: this.bindAll(funcName [,funcName...])
	 * Inspired by Underscore's bindAll. http://underscorejs.org/#bindAll
	 * @author Marc Diethelm <marc.diethelm@namics.com>
	 * @author Simon Harte <simon.harte@namics.com>
	 * @param {...String} methods - Names of methods each as a param.
	 * @returns {Module} - Returns the module instance for chaining.
	 */
	Tc.Module.prototype.bindAll = function bindAll(methods) {
		var i = 0,
			args = arguments,
			argLen = args.length,
			methodName
		;

		for (i; i < argLen; i++) {
			methodName = args[i];
			if (typeof this[methodName] === 'function') {
				this[methodName] = $.proxy(this, methodName);
			} else if (typeof methodName === 'string') {
				throw new TypeError('bindAll: Tc.Module.' + this.getName() + '.' + methodName + ' is not a function');
			} else {
				throw new TypeError('Arguments to bindAll must be strings');
			}
		}

		return this;
	};

	/**
	 * Get the name of the Terrific module
	 * @author Remo Brunschwiler <remo.brunschwiler@namics.com>
	 * @author Mathias Hayoz <mathias.hayoz@namics.com>
	 * @returns {String} - Module name
	 */
	Tc.Module.prototype.getName = function getName() {
		var property;
		if (!this._modName) {
			for (property in Tc.Module) {
				if (Tc.Module.hasOwnProperty(property) && property !== 'constructor' && this instanceof Tc.Module[property]) {
					this._modName = property;
					break;
				}
			}
		}

		return this._modName;
	};

	/**
	 * Simplify connector channel subscription. Usage: this.subscribe(channelName [,channelName...])
	 *
	 * Because the second parameter to sandbox.subscribe (this) is often forgotten.
	 * Additionally this method allows connecting to multiple channels at once.
	 * @author Simon Harte <simon.harte@namics.com>
	 * @param {...String} channels - Connector channels to subscribe to
	 * @returns {Module} - Returns the module instance for chaining
	 */
	Tc.Module.prototype.subscribe = function subscribe(channels) {
		var i = 0,
			args = arguments,
			argLen = args.length,
			channelName
		;

		for (i; i < argLen; i++) {
			channelName = args[i];
			this.sandbox.subscribe(channelName, this);
		}

		return this;
	};

	var tplCache = {};
	/**
	 * Micro-templating for modules. Extrapolates {{= foo }} variables in strings from data.
	 * This function is a remix of
	 * - Simple JavaScript Templating – John Resig - http://ejohn.org/ - MIT Licensed
	 * - https://gist.github.com/topliceanu/1537847
	 * - http://weblog.west-wind.com/posts/2008/Oct/13/Client-Templating-with-jQuery
	 * This code incorporates a fix for single-quote usage.
	 * @author Marc Diethelm <marc.diethelm@namics.com>
	 * @param {String} str - Template
	 * @param {Object} [data] - Optional, renders template immediately if present. Data to use as the template context for variable extrapolation.
	 * @returns {Function|String} - Template function, to render template with data, or if data was supplied already the rendered template.
	 */
	Tc.Module.prototype.template = function template(str, data) {

		// Figure out if we're getting a template, or if we need to
		// load the template - and be sure to cache the result.
		var fn = !/\W/.test(str) ?
			tplCache[str] = tplCache[str] ||
				template(document.getElementById(str).innerHTML) :
			// Generate a reusable function that will serve as a template
			// generator (and which will be cached).
			/*jshint -W054, -W014 */
			new Function("obj",
					"var p=[],print=function(){p.push.apply(p,arguments);};" +
					// Introduce the data as local variables using with(){}
					"with(obj){p.push('" +
					// Convert the template into pure JavaScript
					str.replace(/[\r\t\n]/g, " ")
						.replace(/'(?=[^%]*\}\}>)/g, "\t")
						.split("'").join("\\'")
						.split("\t").join("'")
						.replace(/\{\{=(.+?)\}\}/g, "',$1,'")
						.split("{{").join("');")
						.split("}}").join("p.push('")
					+ "');}return p.join('');");
		/*jshint +W054, +W014 */
		// Provide some basic currying to the user
		return data ? fn(data) : fn;
	};

})(Tc.$);

(function($) {
	$(document).ready(function() {
		var application = new Tc.Application($('html'), {});
		application.registerModules();
		application.start();
	});
})(Tc.$);
var Utils = {
	TcSandbox: null
};

/* Called on click of submit button before validation starts */
function BIT_beforeValidateForm(form) {
	if (typeof BIT_ETRACKER !== "undefined"){
		BIT_ETRACKER.trackFormSubmit($(form));
	}
}

/* Called if validation was successful before form is submitted */
function BIT_beforeSubmitForm(form){
	localStorage.basket = window.location.href;
	if (typeof BIT_ETRACKER !== "undefined"){
		BIT_ETRACKER.trackFormSuccess($(form));
	}
}

/* Called if validation of form failed */
function BIT_validationFailed(form){
	if (typeof BIT_ETRACKER !== "undefined"){
		BIT_ETRACKER.trackFormError($(form));
	}
}
(function ($) {

	'use strict';
	/**
	 *
	 * @static
	 * @namespace Tc.Utils
	 * @class Lib
	 */
	Tc.Utils.Lib = {
		/**
		 * Initializes Datepicker
		 *
		 * @method initDatepicker
		 * @param {Object} $ctx   $context in which datepickers should be loaded
		 * @return {void}
		 */
		initDatepicker: function ($ctx) {
			$ctx.find('input[type=date]').each(function(index, element){
				var $el = $(element);
				var $clone;
				if($el.is(':not(.has-datepicker, .is-datepicker)')){
					$clone = $el.clone(false);
					$clone.removeAttr('name id value')
						.data('ref',$el.attr('id'))
						.addClass('is-datepicker')
						.datepicker({
							format: 'dd.mm.yyyy',
							autoclose: true,
							weekStart: 1,
							todayHighlight: true,
							language: $('html').attr('lang') || 'en'
						})
						.on('changeDate', function(ev){
							var $el = $(ev.currentTarget),
								$ref = $('#'+$el.data('ref')),
								date = Tc.Utils.Lib.convertSwissDatetoDate($el.val()),
								originalValue;
							/*
								tried to fix CNGIMPL-1979, does not work correctly yet, because it prevents ALL user inputs
								if(isNaN(date.valueOf())){
									originalValue = $ref[0].getAttribute('value');
									$ref.val(originalValue);
									$el.val(Tc.Utils.Lib.formatSwissDate(Tc.Utils.Lib.convertISOtoDate(originalValue)));
								}else{
									$ref.val(Tc.Utils.Lib.formatISODate(ev.date));
								}
							*/
							$ref.val(Tc.Utils.Lib.formatISODate(ev.date));
						})
						.datepicker('setDate',  Tc.Utils.Lib.convertISOtoDate($el.val()));
					$el.addClass('has-datepicker')
						.hide()
						.after($clone);
				}
			});
		},

		formatISODate: function(date){
			return date.getFullYear() + '-' + Tc.Utils.Lib.formatTwoDigit(date.getMonth()+1) + '-' +  Tc.Utils.Lib.formatTwoDigit(date.getDate());
		},

		formatSwissDate: function(date){
			return Tc.Utils.Lib.formatTwoDigit(date.getDate()) + '.' + Tc.Utils.Lib.formatTwoDigit(date.getMonth()+1) + '.' + date.getFullYear();
		},

		convertISOtoDate: function(iso){
			var arr = iso.split('-');
			return new Date(arr[0], arr[1]-1, arr[2]);
		},

		convertSwissDatetoDate: function(swissDate){
			var arr = swissDate.split('.');
			return new Date(arr[2], arr[1]-1, arr[0]);
		},

		formatTwoDigit: function(num) {
		    return num < 10 ? '0' + num : num;
		},

/* ******** */
/* Glossary */
/* ******** */
		initGlossary: function($ctx) {
			var dataUrl = $('body').data('glossary');
			if (dataUrl) {
				if ($ctx === undefined) {
					$ctx = $('.js-glossary-context').find('.mod-text p, .mod-teaser p, .mod-textimage p, .mod-table p');
				}
				$.getJSON(dataUrl, function (data) {
					Tc.Utils.Lib.parseGlossaryJson(data, $ctx)
				});
			}

		},
		parseGlossaryJson: function(data, $ctx) {
			Tc.Utils.Lib.glossaryData = data;
			$ctx.each(Tc.Utils.Lib.replaceGlossaryItems);
		},
		replaceGlossaryItems: function(index, element){
			var $element = $(element)
				,entry
				,textnodes = Tc.Utils.Lib.getTextNodesIn($element[0], false, ['abbr'])
				,curNode
				,curHtml
				,parentNode
				,resultNodes
				;

			function getPlaceholder(i) {
				entry = Tc.Utils.Lib.glossaryData[i];
				return '##' + entry.title.trim() + '##';
			}

			function preventDoubleReplacement() {
				for (var i = 0; i < Tc.Utils.Lib.glossaryData.length; i++) {
					var placeHolder = getPlaceholder(i);
					curHtml = curHtml.replace(new RegExp('\\b(' + entry.title.trim() + ')\\b', 'ig'), placeHolder);
				}
				return i;
			}

			function replacePlaceholderWithEntryTitle() {
				for (var i = 0; i < Tc.Utils.Lib.glossaryData.length; i++) {
					var placeHolder = getPlaceholder(i);
					var regExp = new RegExp(placeHolder,"g");
					curHtml = curHtml.replace(regExp, '<abbr title=\"' + entry.definition.trim().replace(/"/g,"&quot;") + '\">' + entry.title.trim() + '</abbr>');
				}
				return i;
			}

			for(var k = 0; k < textnodes.length; k++){
				curNode = textnodes[k];
				curHtml = textnodes[k].textContent;
				parentNode = curNode.parentNode;

				preventDoubleReplacement();
				replacePlaceholderWithEntryTitle();
				resultNodes = $('<span>' + curHtml + '</span>').contents(); //need to place this in some kind of element in order to have valid nodes
				for(var m=0; m<resultNodes.length; m++){
					parentNode.insertBefore(resultNodes[m],curNode);
				}
				parentNode.removeChild(curNode);
			}
		},
		/**
		 * Function to find all textnodes in given html-element, optionaly excluding given nodenames
		 *
		 * @method _getTextNodesIn
		 * @param {Object} node                     plain HTML-Object
		 * @param {Boolean} includeWhitespaceNodes  flag if whitespace nodes should be includes
		 * @param {Array} excludeNodes              Array of lowercase node names to exclude
		 * @return {Array} textnodes
		 */
		getTextNodesIn: function(node, includeWhitespaceNodes, excludeNodes) {
			var textNodes = [], nonWhitespaceMatcher = /\S/;
			if(excludeNodes === undefined)excludeNodes = [];

			function getTextNodes(node, excludeNodes) {
				if (node.nodeType == 3) {
					if (includeWhitespaceNodes || nonWhitespaceMatcher.test(node.nodeValue)) {
						textNodes.push(node);
					}
				} else {
					//only move on if tag is not listed in excludeNodes
					if(excludeNodes.indexOf(node.nodeName.toLocaleLowerCase()) === -1){
						for (var i = 0, len = node.childNodes.length; i < len; ++i) {
							getTextNodes(node.childNodes[i], excludeNodes);
						}
					}
				}
			}

			getTextNodes(node, excludeNodes);
			return textNodes;
		},



/* ********** */
/* Validation */
/* ********** */
		/**
		 * Initialises jQuery Validation Plugin with several custom validation methods.
		 * * .js-usepattern will trigger evaluation of pattern-attribute (class is set automatically if pattern-attribute is present)
		 * * .js-validgroup will check if all group members .js-group-element (wrapped in .js-group with data-group="NAME") are valid
		 *
		 * @method initValidation
		 * @param {Object}  jQuery-Object of form
		 * @return {Object} validator
		 */
		initValidation: function($form) {
			$.validator.addMethod('required', function(value, element){
				if(value === false){
					value = '';
				}
				var valid = value.length > 0;
				if(valid){
					$(element).closest('.form-group').removeClass('has-warning');
				}else{
					$(element).closest('.form-group').addClass('has-warning');
				}
				return valid;
			}, 'field is required');

			$.validator.addMethod('js-usepattern', function(value, element){
				if(value === false){
					value = '';
				}
				var valid = (value.search(new RegExp($(element).attr('pattern'), $(element).data('pattern-modifier') || 'i')) !== -1);
				if(valid){
					$(element).closest('.form-group').removeClass('has-warning');
				}else{
					$(element).closest('.form-group').addClass('has-warning');
				}
				return valid;
			}, 'pattern not valid');

			$.validator.addMethod('js-validgroup', function(value, element){
				var valid = true,
					filled = 0,
					$elements = $(element).closest('.js-group').find('.js-group-element');
				$elements.each(function(){
					var $curEl = $(this),
						pattern = $curEl.attr('pattern'),
						val = $curEl.val();
					if(val.length > 0){
						filled += 1;
					}
					if(pattern){
						if(val.search(new RegExp(pattern)) === -1){
							valid = false;
							return false;
						}
					}
				});
				if(valid){
					$elements.removeClass('error');
				}
				if(valid && filled > 0 && filled !== $elements.length){
					valid = false;
				}
				return valid;
			}, 'group invalid');

			/* groups */
			var config = {groups:{}};
			$form.find('.js-group').each(function(){
				var $curEl = $(this);
				$curEl.find('.js-group-element').each(function(){
					config.groups[$curEl.data('group')] += ' ' + $(this).attr('name');
				});
			});

			$form.find('input[pattern]').each(function(){
				$(this).addClass('js-usepattern');
			});

			return $form.validate($.extend(true, config, {
				ignore: ":hidden, .js-disable-validation",
				errorElement: 'span',
				errorClass: 'error',
				onfocusout: false,
				errorPlacement: function($error, $element) {
					$error.addClass('help-block');
					$element.parent().append($error);
				},
				showErrors: function(map, list){
					var i;
					for(i = 0; i < list.length; i+=1){
						list[i].message = $(list[i].element).data('validationtext') || list[i].message;
					}
					this.defaultShowErrors(list);
				},
				rules: {
				},
				groups: {
				}
			}));
		},

        getFileSize: function (uploadField) {
            var _this = this,
                $field = $(uploadField);

            if ($field.attr('type') != "file") {
                return -1;
            }


            if (uploadField.files) { // file api available
                if (uploadField.files.length > 0) { // file selected
                    return uploadField.files[0].size;
                }
                else {
                    return 0;
                }
            }
            else {
                return -1;
            }
        },

        validateUploadField: function (uploadField, maxSizeAll, maxSizeSingle, message) {
            var _this = this,
                $field = $(uploadField),
                $form = $field.parents('form'),
                formId = $form.attr('id'),
                $allUploads = $form.find("input[type='file']"),
                myFileSize,
                totalFileSize = 0;

            if ($field.attr('type') != "file") {
                return true;
            }

            myFileSize = _this.getFileSize(uploadField);
            $allUploads.each(function (index, element) {
                totalFileSize += _this.getFileSize(element);
            });

            if (myFileSize > maxSizeSingle || totalFileSize > maxSizeAll) {
                cq5forms_showMsg(formId, $field.attr('name'), message);
                return false;
            }

            return true;

        },

        /**
         * see https://www.creativejuiz.fr/blog/en/javascript-en/read-url-get-parameters-with-javascript
         * @param paramName the param to read from the url
         */
        getUrlParameter: function (paramName) {
            var vars = {};
            window.location.href.replace(location.hash, '').replace(
                /[?&]+([^=&]+)=?([^&]*)?/gi, // regexp
                function (m, key, value) { // callback
                    vars[key] = value !== undefined ? value : '';
                }
            );

            if (paramName) {
                return vars[paramName] ? vars[paramName] : null;
            }
            return vars;
        },

        /**
         * maximize body on load to fix issue of hidden page dialog
         */
        maximizeBodyInEditMode: function () {
            $(function () {
                var docHeight = $(document).height(),
                    $body = $('body.skin-layout-editmode');
                if ($body.length > 0 && $body.height() < docHeight) {
                    $body.css('min-height', docHeight);
                }
            });

        	$(window).on("resize", $.debounce(200, Tc.Utils.Lib.maximizeBodyInEditMode));
        },

        /**
         * String functions
         */


        stringIsEmpty: function (str) {
            return (!str || 0 === str.length);
        },

        stringIsBlank: function (str) {
            return (!str || /^\s*$/.test(str));
        }

    };

    Tc.Utils.Lib.maximizeBodyInEditMode();

})(Tc.$);

(function ($) {

	'use strict';
	/**
	 *
	 * @static
	 * @namespace Tc.Utils
	 * @class EqualHeight
	 */
	Tc.Utils.EqualHeight = {
		$equals: $(),
		/* public methods */
		addElements: function($elements) {
			Tc.Utils.EqualHeight.$equals = Tc.Utils.EqualHeight.$equals.add($elements);
		},

		set: function () {
			Tc.Utils.EqualHeight.$equals
				/*.filter(':not([data-equalheight-exclude*='+Tc.Utils.Responsive.getCurrentBPName()+'])')*/
				.each(Tc.Utils.EqualHeight.setHeights);
		},

		reset: function () {
			Tc.Utils.EqualHeight.$equals
				/*.filter('[data-equalheight-exclude*='+Tc.Utils.Responsive.getCurrentBPName()+']')*/
				.each(Tc.Utils.EqualHeight.resetHeights);
		},
		/* internal methods, only used by this utils */
		getMaxHeight: function ($items) {
			var i = 0,
				max = 0,
				currHeight;
			for (i; i < $items.length; i+=1) {
				currHeight = $items.eq(i).height();
				max = currHeight > max ? currHeight : max;
			}
			return max;
		},

		setHeights: function (index, item) {
			var $item = $(item),
				elements = Tc.Utils.EqualHeight.getEqualHeightElements($item),
				i,
				$curEl;
			$item.removeClass('equalheight-ready');
			for(i=0; i<elements.length;i+=1){
				$curEl = elements[i];
				$curEl.height('');
				$curEl.height(Tc.Utils.EqualHeight.getMaxHeight($curEl));
			}
			$item.addClass('equalheight-ready');
		},

		resetHeights: function (index, item) {
			var $item = $(item),
				elements = Tc.Utils.EqualHeight.getEqualHeightElements($item),
				i,
				$curEl;
			$item.removeClass('equalheight-ready');
			for(i=0; i<elements.length;i+=1){
				$curEl = elements[i];
				$curEl.height('');
			}
		},

		getElementsPerLine: function($container) {
			var $childs = $container.children(),
				lines = [],
				$el,
				curOffset,
				curLineIndex = 0;
			$childs.each(function(i, el){
				$el = $(el);
				if(i === 0){
					lines[curLineIndex] = $();
					curOffset = $el.offset().top;
				}else if($el.offset().top !== curOffset){
					curLineIndex += 1;
					lines[curLineIndex] = $();
					curOffset = $el.offset().top;
				}
				lines[curLineIndex] = lines[curLineIndex].add($el);
			});
			return lines;
		},

		getEqualHeightElements: function($container) {
			var group = $container.data('equalheight-group'),
				$elements;
			if(group){
				$elements = $container.find('.js-equalheight-element[data-equalheight-group='+group+']');
			}else if($container.is('[data-equal-height-elements="true"]')){
				$elements = $container.find('.js-equalheight-element');
			}else if($container.is('[data-equal-height-selector]')){
				$elements = $container.find($container.data('equal-height-selector'));
			}else{
				$elements = $container.children();
			}

			if($container.data('equalheight-line')){
				return this.getElementsPerLine($elements);
			}

			return [$elements];
		}
	};
})(Tc.$);

(function($) {
	'use strict';
	/**
	 *
	 * @static
	 * @namespace Tc.Utils
	 * @class Extensions
	 */
	Tc.Utils.Extensions = {
		isMobileDevice: function() {
			if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
				return true;
			}
			return false;
		}
	};
})(Tc.$);

(function ($) {

	'use strict';

    function AssertionError(sMessage) {
        this.name = "AssertionError";
        this.message = sMessage;
        this.stack = (new Error()).stack;
    }
    AssertionError.prototype = Object.create(Error.prototype);
    AssertionError.prototype.constructor = AssertionError;


    /**
	 *
	 * @static
	 * @namespace Tc.Utils
	 * @class Test
	 */
	Tc.Utils.Test = {

        /**
         *
         * @param expected
         * @param actual
         */
		assertEquals: function (expected, actual) {
			if (expected !== actual){
                throw new AssertionError("not equal! expected: " + expected + ", actual: " + actual);
			}
        }


	};

})(Tc.$);

(function ($) {

	'use strict';

    /**
	 *
	 * @static
	 * @namespace Tc.Utils
	 * @class WCM
	 */
	Tc.Utils.WCM = {

        /**
         * Returns the current content window.
		 * This is either the top browser window or the content frame if a page is viewed inside
		 * the content finder.
         */
		getCurrentWindow: function(){

			if(window.location.href.indexOf("cf#")>-1 && document.getElementById("cq-cf-frame")){
				return document.getElementById("cq-cf-frame").contentWindow;
			} else {
				return window;
			}

		},

		getParsedQueryString: function() {
			var that = this,
				queryString = Tc.Utils.WCM.getCurrentWindow().location.search.replace("?",""),
				params = {};

			var querystringKeyValueArray = queryString.split("&");
			for(var i=0; i < querystringKeyValueArray.length; i++){
				var pair = querystringKeyValueArray[i].split("=");
				if (pair && pair.length === 2) {
					params[pair[0]] = pair[1];
				}
			}

			return params;
		}

	};

})(Tc.$);

/* Modernizr 2.8.3 (Custom Build) | MIT & BSD
 * Build: http://modernizr.com/download/#-inputtypes-load
 */
;window.Modernizr=function(a,b,c){function u(a){i.cssText=a}function v(a,b){return u(prefixes.join(a+";")+(b||""))}function w(a,b){return typeof a===b}function x(a,b){return!!~(""+a).indexOf(b)}function y(a,b,d){for(var e in a){var f=b[a[e]];if(f!==c)return d===!1?a[e]:w(f,"function")?f.bind(d||b):f}return!1}function z(){e.inputtypes=function(a){for(var d=0,e,g,h,i=a.length;d<i;d++)j.setAttribute("type",g=a[d]),e=j.type!=="text",e&&(j.value=k,j.style.cssText="position:absolute;visibility:hidden;",/^range$/.test(g)&&j.style.WebkitAppearance!==c?(f.appendChild(j),h=b.defaultView,e=h.getComputedStyle&&h.getComputedStyle(j,null).WebkitAppearance!=="textfield"&&j.offsetHeight!==0,f.removeChild(j)):/^(search|tel)$/.test(g)||(/^(url|email)$/.test(g)?e=j.checkValidity&&j.checkValidity()===!1:e=j.value!=k)),n[a[d]]=!!e;return n}("search tel url email datetime date month week time datetime-local number range color".split(" "))}var d="2.8.3",e={},f=b.documentElement,g="modernizr",h=b.createElement(g),i=h.style,j=b.createElement("input"),k=":)",l={}.toString,m={},n={},o={},p=[],q=p.slice,r,s={}.hasOwnProperty,t;!w(s,"undefined")&&!w(s.call,"undefined")?t=function(a,b){return s.call(a,b)}:t=function(a,b){return b in a&&w(a.constructor.prototype[b],"undefined")},Function.prototype.bind||(Function.prototype.bind=function(b){var c=this;if(typeof c!="function")throw new TypeError;var d=q.call(arguments,1),e=function(){if(this instanceof e){var a=function(){};a.prototype=c.prototype;var f=new a,g=c.apply(f,d.concat(q.call(arguments)));return Object(g)===g?g:f}return c.apply(b,d.concat(q.call(arguments)))};return e});for(var A in m)t(m,A)&&(r=A.toLowerCase(),e[r]=m[A](),p.push((e[r]?"":"no-")+r));return e.input||z(),e.addTest=function(a,b){if(typeof a=="object")for(var d in a)t(a,d)&&e.addTest(d,a[d]);else{a=a.toLowerCase();if(e[a]!==c)return e;b=typeof b=="function"?b():b,typeof enableClasses!="undefined"&&enableClasses&&(f.className+=" "+(b?"":"no-")+a),e[a]=b}return e},u(""),h=j=null,e._version=d,e}(this,this.document),function(a,b,c){function d(a){return"[object Function]"==o.call(a)}function e(a){return"string"==typeof a}function f(){}function g(a){return!a||"loaded"==a||"complete"==a||"uninitialized"==a}function h(){var a=p.shift();q=1,a?a.t?m(function(){("c"==a.t?B.injectCss:B.injectJs)(a.s,0,a.a,a.x,a.e,1)},0):(a(),h()):q=0}function i(a,c,d,e,f,i,j){function k(b){if(!o&&g(l.readyState)&&(u.r=o=1,!q&&h(),l.onload=l.onreadystatechange=null,b)){"img"!=a&&m(function(){t.removeChild(l)},50);for(var d in y[c])y[c].hasOwnProperty(d)&&y[c][d].onload()}}var j=j||B.errorTimeout,l=b.createElement(a),o=0,r=0,u={t:d,s:c,e:f,a:i,x:j};1===y[c]&&(r=1,y[c]=[]),"object"==a?l.data=c:(l.src=c,l.type=a),l.width=l.height="0",l.onerror=l.onload=l.onreadystatechange=function(){k.call(this,r)},p.splice(e,0,u),"img"!=a&&(r||2===y[c]?(t.insertBefore(l,s?null:n),m(k,j)):y[c].push(l))}function j(a,b,c,d,f){return q=0,b=b||"j",e(a)?i("c"==b?v:u,a,b,this.i++,c,d,f):(p.splice(this.i++,0,a),1==p.length&&h()),this}function k(){var a=B;return a.loader={load:j,i:0},a}var l=b.documentElement,m=a.setTimeout,n=b.getElementsByTagName("script")[0],o={}.toString,p=[],q=0,r="MozAppearance"in l.style,s=r&&!!b.createRange().compareNode,t=s?l:n.parentNode,l=a.opera&&"[object Opera]"==o.call(a.opera),l=!!b.attachEvent&&!l,u=r?"object":l?"script":"img",v=l?"script":u,w=Array.isArray||function(a){return"[object Array]"==o.call(a)},x=[],y={},z={timeout:function(a,b){return b.length&&(a.timeout=b[0]),a}},A,B;B=function(a){function b(a){var a=a.split("!"),b=x.length,c=a.pop(),d=a.length,c={url:c,origUrl:c,prefixes:a},e,f,g;for(f=0;f<d;f++)g=a[f].split("="),(e=z[g.shift()])&&(c=e(c,g));for(f=0;f<b;f++)c=x[f](c);return c}function g(a,e,f,g,h){var i=b(a),j=i.autoCallback;i.url.split(".").pop().split("?").shift(),i.bypass||(e&&(e=d(e)?e:e[a]||e[g]||e[a.split("/").pop().split("?")[0]]),i.instead?i.instead(a,e,f,g,h):(y[i.url]?i.noexec=!0:y[i.url]=1,f.load(i.url,i.forceCSS||!i.forceJS&&"css"==i.url.split(".").pop().split("?").shift()?"c":c,i.noexec,i.attrs,i.timeout),(d(e)||d(j))&&f.load(function(){k(),e&&e(i.origUrl,h,g),j&&j(i.origUrl,h,g),y[i.url]=2})))}function h(a,b){function c(a,c){if(a){if(e(a))c||(j=function(){var a=[].slice.call(arguments);k.apply(this,a),l()}),g(a,j,b,0,h);else if(Object(a)===a)for(n in m=function(){var b=0,c;for(c in a)a.hasOwnProperty(c)&&b++;return b}(),a)a.hasOwnProperty(n)&&(!c&&!--m&&(d(j)?j=function(){var a=[].slice.call(arguments);k.apply(this,a),l()}:j[n]=function(a){return function(){var b=[].slice.call(arguments);a&&a.apply(this,b),l()}}(k[n])),g(a[n],j,b,n,h))}else!c&&l()}var h=!!a.test,i=a.load||a.both,j=a.callback||f,k=j,l=a.complete||f,m,n;c(h?a.yep:a.nope,!!i),i&&c(i)}var i,j,l=this.yepnope.loader;if(e(a))g(a,0,l,0);else if(w(a))for(i=0;i<a.length;i++)j=a[i],e(j)?g(j,0,l,0):w(j)?B(j):Object(j)===j&&h(j,l);else Object(a)===a&&h(a,l)},B.addPrefix=function(a,b){z[a]=b},B.addFilter=function(a){x.push(a)},B.errorTimeout=1e4,null==b.readyState&&b.addEventListener&&(b.readyState="loading",b.addEventListener("DOMContentLoaded",A=function(){b.removeEventListener("DOMContentLoaded",A,0),b.readyState="complete"},0)),a.yepnope=k(),a.yepnope.executeStack=h,a.yepnope.injectJs=function(a,c,d,e,i,j){var k=b.createElement("script"),l,o,e=e||B.errorTimeout;k.src=a;for(o in d)k.setAttribute(o,d[o]);c=j?h:c||f,k.onreadystatechange=k.onload=function(){!l&&g(k.readyState)&&(l=1,c(),k.onload=k.onreadystatechange=null)},m(function(){l||(l=1,c(1))},e),i?k.onload():n.parentNode.insertBefore(k,n)},a.yepnope.injectCss=function(a,c,d,e,g,i){var e=b.createElement("link"),j,c=i?h:c||f;e.href=a,e.rel="stylesheet",e.type="text/css";for(j in d)e.setAttribute(j,d[j]);g||(n.parentNode.insertBefore(e,n),m(c,0))}}(this,document),Modernizr.load=function(){yepnope.apply(window,[].slice.call(arguments,0))};
/*!
  hey, [be]Lazy.js - v1.8.2 - 2016.10.25
  A fast, small and dependency free lazy load script (https://github.com/dinbror/blazy)
  (c) Bjoern Klinggaard - @bklinggaard - http://dinbror.dk/blazy
*/
  (function(q,m){"function"===typeof define&&define.amd?define(m):"object"===typeof exports?module.exports=m():q.Blazy=m()})(this,function(){function q(b){var c=b._util;c.elements=E(b.options);c.count=c.elements.length;c.destroyed&&(c.destroyed=!1,b.options.container&&l(b.options.container,function(a){n(a,"scroll",c.validateT)}),n(window,"resize",c.saveViewportOffsetT),n(window,"resize",c.validateT),n(window,"scroll",c.validateT));m(b)}function m(b){for(var c=b._util,a=0;a<c.count;a++){var d=c.elements[a],e;a:{var g=d;e=b.options;var p=g.getBoundingClientRect();if(e.container&&y&&(g=g.closest(e.containerClass))){g=g.getBoundingClientRect();e=r(g,f)?r(p,{top:g.top-e.offset,right:g.right+e.offset,bottom:g.bottom+e.offset,left:g.left-e.offset}):!1;break a}e=r(p,f)}if(e||t(d,b.options.successClass))b.load(d),c.elements.splice(a,1),c.count--,a--}0===c.count&&b.destroy()}function r(b,c){return b.right>=c.left&&b.bottom>=c.top&&b.left<=c.right&&b.top<=c.bottom}function z(b,c,a){if(!t(b,a.successClass)&&(c||a.loadInvisible||0<b.offsetWidth&&0<b.offsetHeight))if(c=b.getAttribute(u)||b.getAttribute(a.src)){c=c.split(a.separator);var d=c[A&&1<c.length?1:0],e=b.getAttribute(a.srcset),g="img"===b.nodeName.toLowerCase(),p=(c=b.parentNode)&&"picture"===c.nodeName.toLowerCase();if(g||void 0===b.src){var h=new Image,w=function(){a.error&&a.error(b,"invalid");v(b,a.errorClass);k(h,"error",w);k(h,"load",f)},f=function(){g?p||B(b,d,e):b.style.backgroundImage='url("'+d+'")';x(b,a);k(h,"load",f);k(h,"error",w)};p&&(h=b,l(c.getElementsByTagName("source"),function(b){var c=a.srcset,e=b.getAttribute(c);e&&(b.setAttribute("srcset",e),b.removeAttribute(c))}));n(h,"error",w);n(h,"load",f);B(h,d,e)}else b.src=d,x(b,a)}else"video"===b.nodeName.toLowerCase()?(l(b.getElementsByTagName("source"),function(b){var c=a.src,e=b.getAttribute(c);e&&(b.setAttribute("src",e),b.removeAttribute(c))}),b.load(),x(b,a)):(a.error&&a.error(b,"missing"),v(b,a.errorClass))}function x(b,c){v(b,c.successClass);c.success&&c.success(b);b.removeAttribute(c.src);b.removeAttribute(c.srcset);l(c.breakpoints,function(a){b.removeAttribute(a.src)})}function B(b,c,a){a&&b.setAttribute("srcset",a);b.src=c}function t(b,c){return-1!==(" "+b.className+" ").indexOf(" "+c+" ")}function v(b,c){t(b,c)||(b.className+=" "+c)}function E(b){var c=[];b=b.root.querySelectorAll(b.selector);for(var a=b.length;a--;c.unshift(b[a]));return c}function C(b){f.bottom=(window.innerHeight||document.documentElement.clientHeight)+b;f.right=(window.innerWidth||document.documentElement.clientWidth)+b}function n(b,c,a){b.attachEvent?b.attachEvent&&b.attachEvent("on"+c,a):b.addEventListener(c,a,{capture:!1,passive:!0})}function k(b,c,a){b.detachEvent?b.detachEvent&&b.detachEvent("on"+c,a):b.removeEventListener(c,a,{capture:!1,passive:!0})}function l(b,c){if(b&&c)for(var a=b.length,d=0;d<a&&!1!==c(b[d],d);d++);}function D(b,c,a){var d=0;return function(){var e=+new Date;e-d<c||(d=e,b.apply(a,arguments))}}var u,f,A,y;return function(b){if(!document.querySelectorAll){var c=document.createStyleSheet();document.querySelectorAll=function(a,b,d,h,f){f=document.all;b=[];a=a.replace(/\[for\b/gi,"[htmlFor").split(",");for(d=a.length;d--;){c.addRule(a[d],"k:v");for(h=f.length;h--;)f[h].currentStyle.k&&b.push(f[h]);c.removeRule(0)}return b}}var a=this,d=a._util={};d.elements=[];d.destroyed=!0;a.options=b||{};a.options.error=a.options.error||!1;a.options.offset=a.options.offset||100;a.options.root=a.options.root||document;a.options.success=a.options.success||!1;a.options.selector=a.options.selector||".b-lazy";a.options.separator=a.options.separator||"|";a.options.containerClass=a.options.container;a.options.container=a.options.containerClass?document.querySelectorAll(a.options.containerClass):!1;a.options.errorClass=a.options.errorClass||"b-error";a.options.breakpoints=a.options.breakpoints||!1;a.options.loadInvisible=a.options.loadInvisible||!1;a.options.successClass=a.options.successClass||"b-loaded";a.options.validateDelay=a.options.validateDelay||25;a.options.saveViewportOffsetDelay=a.options.saveViewportOffsetDelay||50;a.options.srcset=a.options.srcset||"data-srcset";a.options.src=u=a.options.src||"data-src";y=Element.prototype.closest;A=1<window.devicePixelRatio;f={};f.top=0-a.options.offset;f.left=0-a.options.offset;a.revalidate=function(){q(a)};a.load=function(a,b){var c=this.options;void 0===a.length?z(a,b,c):l(a,function(a){z(a,b,c)})};a.destroy=function(){var a=this._util;this.options.container&&l(this.options.container,function(b){k(b,"scroll",a.validateT)});k(window,"scroll",a.validateT);k(window,"resize",a.validateT);k(window,"resize",a.saveViewportOffsetT);a.count=0;a.elements.length=0;a.destroyed=!0};d.validateT=D(function(){m(a)},a.options.validateDelay,a);d.saveViewportOffsetT=D(function(){C(a.options.offset)},a.options.saveViewportOffsetDelay,a);C(a.options.offset);l(a.options.breakpoints,function(a){if(a.width>=window.screen.width)return u=a.src,!1});setTimeout(function(){q(a)})}});
/*!
 * imagesLoaded PACKAGED v3.1.8
 * JavaScript is all like "You images are done yet or what?"
 * MIT License
 */

(function(){function e(){}function t(e,t){for(var n=e.length;n--;)if(e[n].listener===t)return n;return-1}function n(e){return function(){return this[e].apply(this,arguments)}}var i=e.prototype,r=this,o=r.EventEmitter;i.getListeners=function(e){var t,n,i=this._getEvents();if("object"==typeof e){t={};for(n in i)i.hasOwnProperty(n)&&e.test(n)&&(t[n]=i[n])}else t=i[e]||(i[e]=[]);return t},i.flattenListeners=function(e){var t,n=[];for(t=0;e.length>t;t+=1)n.push(e[t].listener);return n},i.getListenersAsObject=function(e){var t,n=this.getListeners(e);return n instanceof Array&&(t={},t[e]=n),t||n},i.addListener=function(e,n){var i,r=this.getListenersAsObject(e),o="object"==typeof n;for(i in r)r.hasOwnProperty(i)&&-1===t(r[i],n)&&r[i].push(o?n:{listener:n,once:!1});return this},i.on=n("addListener"),i.addOnceListener=function(e,t){return this.addListener(e,{listener:t,once:!0})},i.once=n("addOnceListener"),i.defineEvent=function(e){return this.getListeners(e),this},i.defineEvents=function(e){for(var t=0;e.length>t;t+=1)this.defineEvent(e[t]);return this},i.removeListener=function(e,n){var i,r,o=this.getListenersAsObject(e);for(r in o)o.hasOwnProperty(r)&&(i=t(o[r],n),-1!==i&&o[r].splice(i,1));return this},i.off=n("removeListener"),i.addListeners=function(e,t){return this.manipulateListeners(!1,e,t)},i.removeListeners=function(e,t){return this.manipulateListeners(!0,e,t)},i.manipulateListeners=function(e,t,n){var i,r,o=e?this.removeListener:this.addListener,s=e?this.removeListeners:this.addListeners;if("object"!=typeof t||t instanceof RegExp)for(i=n.length;i--;)o.call(this,t,n[i]);else for(i in t)t.hasOwnProperty(i)&&(r=t[i])&&("function"==typeof r?o.call(this,i,r):s.call(this,i,r));return this},i.removeEvent=function(e){var t,n=typeof e,i=this._getEvents();if("string"===n)delete i[e];else if("object"===n)for(t in i)i.hasOwnProperty(t)&&e.test(t)&&delete i[t];else delete this._events;return this},i.removeAllListeners=n("removeEvent"),i.emitEvent=function(e,t){var n,i,r,o,s=this.getListenersAsObject(e);for(r in s)if(s.hasOwnProperty(r))for(i=s[r].length;i--;)n=s[r][i],n.once===!0&&this.removeListener(e,n.listener),o=n.listener.apply(this,t||[]),o===this._getOnceReturnValue()&&this.removeListener(e,n.listener);return this},i.trigger=n("emitEvent"),i.emit=function(e){var t=Array.prototype.slice.call(arguments,1);return this.emitEvent(e,t)},i.setOnceReturnValue=function(e){return this._onceReturnValue=e,this},i._getOnceReturnValue=function(){return this.hasOwnProperty("_onceReturnValue")?this._onceReturnValue:!0},i._getEvents=function(){return this._events||(this._events={})},e.noConflict=function(){return r.EventEmitter=o,e},"function"==typeof define&&define.amd?define("eventEmitter/EventEmitter",[],function(){return e}):"object"==typeof module&&module.exports?module.exports=e:this.EventEmitter=e}).call(this),function(e){function t(t){var n=e.event;return n.target=n.target||n.srcElement||t,n}var n=document.documentElement,i=function(){};n.addEventListener?i=function(e,t,n){e.addEventListener(t,n,!1)}:n.attachEvent&&(i=function(e,n,i){e[n+i]=i.handleEvent?function(){var n=t(e);i.handleEvent.call(i,n)}:function(){var n=t(e);i.call(e,n)},e.attachEvent("on"+n,e[n+i])});var r=function(){};n.removeEventListener?r=function(e,t,n){e.removeEventListener(t,n,!1)}:n.detachEvent&&(r=function(e,t,n){e.detachEvent("on"+t,e[t+n]);try{delete e[t+n]}catch(i){e[t+n]=void 0}});var o={bind:i,unbind:r};"function"==typeof define&&define.amd?define("eventie/eventie",o):e.eventie=o}(this),function(e,t){"function"==typeof define&&define.amd?define(["eventEmitter/EventEmitter","eventie/eventie"],function(n,i){return t(e,n,i)}):"object"==typeof exports?module.exports=t(e,require("wolfy87-eventemitter"),require("eventie")):e.imagesLoaded=t(e,e.EventEmitter,e.eventie)}(window,function(e,t,n){function i(e,t){for(var n in t)e[n]=t[n];return e}function r(e){return"[object Array]"===d.call(e)}function o(e){var t=[];if(r(e))t=e;else if("number"==typeof e.length)for(var n=0,i=e.length;i>n;n++)t.push(e[n]);else t.push(e);return t}function s(e,t,n){if(!(this instanceof s))return new s(e,t);"string"==typeof e&&(e=document.querySelectorAll(e)),this.elements=o(e),this.options=i({},this.options),"function"==typeof t?n=t:i(this.options,t),n&&this.on("always",n),this.getImages(),a&&(this.jqDeferred=new a.Deferred);var r=this;setTimeout(function(){r.check()})}function f(e){this.img=e}function c(e){this.src=e,v[e]=this}var a=e.jQuery,u=e.console,h=u!==void 0,d=Object.prototype.toString;s.prototype=new t,s.prototype.options={},s.prototype.getImages=function(){this.images=[];for(var e=0,t=this.elements.length;t>e;e++){var n=this.elements[e];"IMG"===n.nodeName&&this.addImage(n);var i=n.nodeType;if(i&&(1===i||9===i||11===i))for(var r=n.querySelectorAll("img"),o=0,s=r.length;s>o;o++){var f=r[o];this.addImage(f)}}},s.prototype.addImage=function(e){var t=new f(e);this.images.push(t)},s.prototype.check=function(){function e(e,r){return t.options.debug&&h&&u.log("confirm",e,r),t.progress(e),n++,n===i&&t.complete(),!0}var t=this,n=0,i=this.images.length;if(this.hasAnyBroken=!1,!i)return this.complete(),void 0;for(var r=0;i>r;r++){var o=this.images[r];o.on("confirm",e),o.check()}},s.prototype.progress=function(e){this.hasAnyBroken=this.hasAnyBroken||!e.isLoaded;var t=this;setTimeout(function(){t.emit("progress",t,e),t.jqDeferred&&t.jqDeferred.notify&&t.jqDeferred.notify(t,e)})},s.prototype.complete=function(){var e=this.hasAnyBroken?"fail":"done";this.isComplete=!0;var t=this;setTimeout(function(){if(t.emit(e,t),t.emit("always",t),t.jqDeferred){var n=t.hasAnyBroken?"reject":"resolve";t.jqDeferred[n](t)}})},a&&(a.fn.imagesLoaded=function(e,t){var n=new s(this,e,t);return n.jqDeferred.promise(a(this))}),f.prototype=new t,f.prototype.check=function(){var e=v[this.img.src]||new c(this.img.src);if(e.isConfirmed)return this.confirm(e.isLoaded,"cached was confirmed"),void 0;if(this.img.complete&&void 0!==this.img.naturalWidth)return this.confirm(0!==this.img.naturalWidth,"naturalWidth"),void 0;var t=this;e.on("confirm",function(e,n){return t.confirm(e.isLoaded,n),!0}),e.check()},f.prototype.confirm=function(e,t){this.isLoaded=e,this.emit("confirm",this,t)};var v={};return c.prototype=new t,c.prototype.check=function(){if(!this.isChecked){var e=new Image;n.bind(e,"load",this),n.bind(e,"error",this),e.src=this.src,this.isChecked=!0}},c.prototype.handleEvent=function(e){var t="on"+e.type;this[t]&&this[t](e)},c.prototype.onload=function(e){this.confirm(!0,"onload"),this.unbindProxyEvents(e)},c.prototype.onerror=function(e){this.confirm(!1,"onerror"),this.unbindProxyEvents(e)},c.prototype.confirm=function(e,t){this.isConfirmed=!0,this.isLoaded=e,this.emit("confirm",this,t)},c.prototype.unbindProxyEvents=function(e){n.unbind(e.target,"load",this),n.unbind(e.target,"error",this)},s});
/*! matchMedia() polyfill - Test a CSS media type/query in JS. Authors & copyright (c) 2012: Scott Jehl, Paul Irish, Nicholas Zakas, David Knight. Dual MIT/BSD license */

window.matchMedia || (window.matchMedia = function() {
    "use strict";

    // For browsers that support matchMedium api such as IE 9 and webkit
    var styleMedia = (window.styleMedia || window.media);

    // For those that don't support matchMedium
    if (!styleMedia) {
        var style       = document.createElement('style'),
            script      = document.getElementsByTagName('script')[0],
            info        = null;

        style.type  = 'text/css';
        style.id    = 'matchmediajs-test';

        script.parentNode.insertBefore(style, script);

        // 'style.currentStyle' is used by IE <= 8 and 'window.getComputedStyle' for all other browsers
        info = ('getComputedStyle' in window) && window.getComputedStyle(style, null) || style.currentStyle;

        styleMedia = {
            matchMedium: function(media) {
                var text = '@media ' + media + '{ #matchmediajs-test { width: 1px; } }';

                // 'style.styleSheet' is used by IE <= 8 and 'style.textContent' for all other browsers
                if (style.styleSheet) {
                    style.styleSheet.cssText = text;
                } else {
                    style.textContent = text;
                }

                // Test if media query is true or false
                return info.width === '1px';
            }
        };
    }

    return function(media) {
        return {
            matches: styleMedia.matchMedium(media || 'all'),
            media: media || 'all'
        };
    };
}());

/*! matchMedia() polyfill addListener/removeListener extension. Author & copyright (c) 2012: Scott Jehl. Dual MIT/BSD license */
(function(){
    // Bail out for browsers that have addListener support
    if (window.matchMedia && window.matchMedia('all').addListener) {
        return false;
    }

    var localMatchMedia = window.matchMedia,
        hasMediaQueries = localMatchMedia('only all').matches,
        isListening     = false,
        timeoutID       = 0,    // setTimeout for debouncing 'handleChange'
        queries         = [],   // Contains each 'mql' and associated 'listeners' if 'addListener' is used
        handleChange    = function(evt) {
            // Debounce
            clearTimeout(timeoutID);

            timeoutID = setTimeout(function() {
                for (var i = 0, il = queries.length; i < il; i++) {
                    var mql         = queries[i].mql,
                        listeners   = queries[i].listeners || [],
                        matches     = localMatchMedia(mql.media).matches;

                    // Update mql.matches value and call listeners
                    // Fire listeners only if transitioning to or from matched state
                    if (matches !== mql.matches) {
                        mql.matches = matches;

                        for (var j = 0, jl = listeners.length; j < jl; j++) {
                            listeners[j].call(window, mql);
                        }
                    }
                }
            }, 30);
        };

    window.matchMedia = function(media) {
        var mql         = localMatchMedia(media),
            listeners   = [],
            index       = 0;

        mql.addListener = function(listener) {
            // Changes would not occur to css media type so return now (Affects IE <= 8)
            if (!hasMediaQueries) {
                return;
            }

            // Set up 'resize' listener for browsers that support CSS3 media queries (Not for IE <= 8)
            // There should only ever be 1 resize listener running for performance
            if (!isListening) {
                isListening = true;
                window.addEventListener('resize', handleChange, true);
            }

            // Push object only if it has not been pushed already
            if (index === 0) {
                index = queries.push({
                    mql         : mql,
                    listeners   : listeners
                });
            }

            listeners.push(listener);
        };

        mql.removeListener = function(listener) {
            for (var i = 0, il = listeners.length; i < il; i++){
                if (listeners[i] === listener){
                    listeners.splice(i, 1);
                }
            }
        };

        return mql;
    };
}());

"function" != typeof Object.create && (Object.create = function(t) {
	function o() {}
	return o.prototype = t, new o
}),
	function(t, o, i, s) {
		"use strict";
		var n = {
			_positionClasses: ["bottom-left", "bottom-right", "top-right", "top-left", "bottom-center", "top-center", "mid-center"],
			_defaultIcons: ["success", "error", "info", "warning"],
			init: function(o, i) {
				this.prepareOptions(o, t.toast.options), this.process()
			},
			prepareOptions: function(o, i) {
				var s = {};
				"string" == typeof o || o instanceof Array ? s.text = o : s = o, this.options = t.extend({}, i, s)
			},
			process: function() {
				this.setup(), this.addToDom(), this.position(), this.bindToast(), this.animate()
			},
			setup: function() {
				var o = "";
				if (this._toastEl = this._toastEl || t("<div></div>", {
					class: "jq-toast-single"
				}), o += '<span class="jq-toast-loader"></span>', this.options.allowToastClose && (o += '<span class="close-jq-toast-single">×</span>'), this.options.text instanceof Array) {
					this.options.heading && (o += '<h2 class="jq-toast-heading">' + this.options.heading + "</h2>"), o += '<ul class="jq-toast-ul">';
					for (var i = 0; i < this.options.text.length; i++) o += '<li class="jq-toast-li" id="jq-toast-item-' + i + '">' + this.options.text[i] + "</li>";
					o += "</ul>"
				} else this.options.heading && (o += '<h2 class="jq-toast-heading">' + this.options.heading + "</h2>"), o += this.options.text;
				this._toastEl.html(o), !1 !== this.options.bgColor && this._toastEl.css("background-color", this.options.bgColor), !1 !== this.options.textColor && this._toastEl.css("color", this.options.textColor), this.options.textAlign && this._toastEl.css("text-align", this.options.textAlign), !1 !== this.options.icon && (this._toastEl.addClass("jq-has-icon"), - 1 !== t.inArray(this.options.icon, this._defaultIcons) && this._toastEl.addClass("jq-icon-" + this.options.icon)), !1 !== this.options.class && this._toastEl.addClass(this.options.class)
			},
			position: function() {
				"string" == typeof this.options.position && -1 !== t.inArray(this.options.position, this._positionClasses) ? "bottom-center" === this.options.position ? this._container.css({
					left: t(o).outerWidth() / 2 - this._container.outerWidth() / 2,
					bottom: 20
				}) : "top-center" === this.options.position ? this._container.css({
					left: t(o).outerWidth() / 2 - this._container.outerWidth() / 2,
					top: 20
				}) : "mid-center" === this.options.position ? this._container.css({
					left: t(o).outerWidth() / 2 - this._container.outerWidth() / 2,
					top: t(o).outerHeight() / 2 - this._container.outerHeight() / 2
				}) : this._container.addClass(this.options.position) : "object" == typeof this.options.position ? this._container.css({
					top: this.options.position.top ? this.options.position.top : "auto",
					bottom: this.options.position.bottom ? this.options.position.bottom : "auto",
					left: this.options.position.left ? this.options.position.left : "auto",
					right: this.options.position.right ? this.options.position.right : "auto"
				}) : this._container.addClass("bottom-left")
			},
			bindToast: function() {
				var t = this;
				this._toastEl.on("afterShown", function() {
					t.processLoader()
				}), this._toastEl.find(".close-jq-toast-single").on("click", function(o) {
					o.preventDefault(), "fade" === t.options.showHideTransition ? (t._toastEl.trigger("beforeHide"), t._toastEl.fadeOut(function() {
						t._toastEl.trigger("afterHidden")
					})) : "slide" === t.options.showHideTransition ? (t._toastEl.trigger("beforeHide"), t._toastEl.slideUp(function() {
						t._toastEl.trigger("afterHidden")
					})) : (t._toastEl.trigger("beforeHide"), t._toastEl.hide(function() {
						t._toastEl.trigger("afterHidden")
					}))
				}), "function" == typeof this.options.beforeShow && this._toastEl.on("beforeShow", function() {
					t.options.beforeShow(t._toastEl)
				}), "function" == typeof this.options.afterShown && this._toastEl.on("afterShown", function() {
					t.options.afterShown(t._toastEl)
				}), "function" == typeof this.options.beforeHide && this._toastEl.on("beforeHide", function() {
					t.options.beforeHide(t._toastEl)
				}), "function" == typeof this.options.afterHidden && this._toastEl.on("afterHidden", function() {
					t.options.afterHidden(t._toastEl)
				}), "function" == typeof this.options.onClick && this._toastEl.on("click", function() {
					t.options.onClick(t._toastEl)
				})
			},
			addToDom: function() {
				var o = t(".jq-toast-wrap");
				if (0 === o.length ? (o = t("<div></div>", {
					class: "jq-toast-wrap",
					role: "alert",
					"aria-live": "polite"
				}), t("body").append(o)) : this.options.stack && !isNaN(parseInt(this.options.stack, 10)) || o.empty(), o.find(".jq-toast-single:hidden").remove(), o.append(this._toastEl), this.options.stack && !isNaN(parseInt(this.options.stack), 10)) {
					var i = o.find(".jq-toast-single").length - this.options.stack;
					i > 0 && t(".jq-toast-wrap").find(".jq-toast-single").slice(0, i).remove()
				}
				this._container = o
			},
			canAutoHide: function() {
				return !1 !== this.options.hideAfter && !isNaN(parseInt(this.options.hideAfter, 10))
			},
			processLoader: function() {
				if (!this.canAutoHide() || !1 === this.options.loader) return !1;
				var t = this._toastEl.find(".jq-toast-loader"),
					o = (this.options.hideAfter - 400) / 1e3 + "s",
					i = this.options.loaderBg,
					s = t.attr("style") || "";
				s = s.substring(0, s.indexOf("-webkit-transition")), s += "-webkit-transition: width " + o + " ease-in;                       -o-transition: width " + o + " ease-in;                       transition: width " + o + " ease-in;                       background-color: " + i + ";", t.attr("style", s).addClass("jq-toast-loaded")
			},
			animate: function() {
				t = this;
				if (this._toastEl.hide(), this._toastEl.trigger("beforeShow"), "fade" === this.options.showHideTransition.toLowerCase() ? this._toastEl.fadeIn(function() {
					t._toastEl.trigger("afterShown")
				}) : "slide" === this.options.showHideTransition.toLowerCase() ? this._toastEl.slideDown(function() {
					t._toastEl.trigger("afterShown")
				}) : this._toastEl.show(function() {
					t._toastEl.trigger("afterShown")
				}), this.canAutoHide()) {
					var t = this;
					o.setTimeout(function() {
						"fade" === t.options.showHideTransition.toLowerCase() ? (t._toastEl.trigger("beforeHide"), t._toastEl.fadeOut(function() {
							t._toastEl.trigger("afterHidden")
						})) : "slide" === t.options.showHideTransition.toLowerCase() ? (t._toastEl.trigger("beforeHide"), t._toastEl.slideUp(function() {
							t._toastEl.trigger("afterHidden")
						})) : (t._toastEl.trigger("beforeHide"), t._toastEl.hide(function() {
							t._toastEl.trigger("afterHidden")
						}))
					}, this.options.hideAfter)
				}
			},
			reset: function(o) {
				"all" === o ? t(".jq-toast-wrap").remove() : this._toastEl.remove()
			},
			update: function(t) {
				this.prepareOptions(t, this.options), this.setup(), this.bindToast()
			},
			close: function() {
				this._toastEl.find(".close-jq-toast-single").click()
			}
		};
		t.toast = function(t) {
			var o = Object.create(n);
			return o.init(t, this), {
				reset: function(t) {
					o.reset(t)
				},
				update: function(t) {
					o.update(t)
				},
				close: function() {
					o.close()
				}
			}
		}, t.toast.options = {
			text: "",
			heading: "",
			showHideTransition: "fade",
			allowToastClose: !0,
			hideAfter: 3e3,
			loader: !0,
			loaderBg: "#9EC600",
			stack: 5,
			position: "bottom-left",
			bgColor: !1,
			textColor: !1,
			textAlign: "left",
			icon: !1,
			beforeShow: function() {},
			afterShown: function() {},
			beforeHide: function() {},
			afterHidden: function() {},
			onClick: function() {}
		}
	}(jQuery, window, document);

/*!
 * Vue.js v2.6.10
 * (c) 2014-2019 Evan You
 * Released under the MIT License.
 */
!function(e,t){"object"==typeof exports&&"undefined"!=typeof module?module.exports=t():"function"==typeof define&&define.amd?define(t):(e=e||self).Vue=t()}(this,function(){"use strict";var e=Object.freeze({});function t(e){return null==e}function n(e){return null!=e}function r(e){return!0===e}function i(e){return"string"==typeof e||"number"==typeof e||"symbol"==typeof e||"boolean"==typeof e}function o(e){return null!==e&&"object"==typeof e}var a=Object.prototype.toString;function s(e){return"[object Object]"===a.call(e)}function c(e){var t=parseFloat(String(e));return t>=0&&Math.floor(t)===t&&isFinite(e)}function u(e){return n(e)&&"function"==typeof e.then&&"function"==typeof e.catch}function l(e){return null==e?"":Array.isArray(e)||s(e)&&e.toString===a?JSON.stringify(e,null,2):String(e)}function f(e){var t=parseFloat(e);return isNaN(t)?e:t}function p(e,t){for(var n=Object.create(null),r=e.split(","),i=0;i<r.length;i++)n[r[i]]=!0;return t?function(e){return n[e.toLowerCase()]}:function(e){return n[e]}}var d=p("slot,component",!0),v=p("key,ref,slot,slot-scope,is");function h(e,t){if(e.length){var n=e.indexOf(t);if(n>-1)return e.splice(n,1)}}var m=Object.prototype.hasOwnProperty;function y(e,t){return m.call(e,t)}function g(e){var t=Object.create(null);return function(n){return t[n]||(t[n]=e(n))}}var _=/-(\w)/g,b=g(function(e){return e.replace(_,function(e,t){return t?t.toUpperCase():""})}),$=g(function(e){return e.charAt(0).toUpperCase()+e.slice(1)}),w=/\B([A-Z])/g,C=g(function(e){return e.replace(w,"-$1").toLowerCase()});var x=Function.prototype.bind?function(e,t){return e.bind(t)}:function(e,t){function n(n){var r=arguments.length;return r?r>1?e.apply(t,arguments):e.call(t,n):e.call(t)}return n._length=e.length,n};function k(e,t){t=t||0;for(var n=e.length-t,r=new Array(n);n--;)r[n]=e[n+t];return r}function A(e,t){for(var n in t)e[n]=t[n];return e}function O(e){for(var t={},n=0;n<e.length;n++)e[n]&&A(t,e[n]);return t}function S(e,t,n){}var T=function(e,t,n){return!1},E=function(e){return e};function N(e,t){if(e===t)return!0;var n=o(e),r=o(t);if(!n||!r)return!n&&!r&&String(e)===String(t);try{var i=Array.isArray(e),a=Array.isArray(t);if(i&&a)return e.length===t.length&&e.every(function(e,n){return N(e,t[n])});if(e instanceof Date&&t instanceof Date)return e.getTime()===t.getTime();if(i||a)return!1;var s=Object.keys(e),c=Object.keys(t);return s.length===c.length&&s.every(function(n){return N(e[n],t[n])})}catch(e){return!1}}function j(e,t){for(var n=0;n<e.length;n++)if(N(e[n],t))return n;return-1}function D(e){var t=!1;return function(){t||(t=!0,e.apply(this,arguments))}}var L="data-server-rendered",M=["component","directive","filter"],I=["beforeCreate","created","beforeMount","mounted","beforeUpdate","updated","beforeDestroy","destroyed","activated","deactivated","errorCaptured","serverPrefetch"],F={optionMergeStrategies:Object.create(null),silent:!1,productionTip:!1,devtools:!1,performance:!1,errorHandler:null,warnHandler:null,ignoredElements:[],keyCodes:Object.create(null),isReservedTag:T,isReservedAttr:T,isUnknownElement:T,getTagNamespace:S,parsePlatformTagName:E,mustUseProp:T,async:!0,_lifecycleHooks:I},P=/a-zA-Z\u00B7\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u037D\u037F-\u1FFF\u200C-\u200D\u203F-\u2040\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD/;function R(e,t,n,r){Object.defineProperty(e,t,{value:n,enumerable:!!r,writable:!0,configurable:!0})}var H=new RegExp("[^"+P.source+".$_\\d]");var B,U="__proto__"in{},z="undefined"!=typeof window,V="undefined"!=typeof WXEnvironment&&!!WXEnvironment.platform,K=V&&WXEnvironment.platform.toLowerCase(),J=z&&window.navigator.userAgent.toLowerCase(),q=J&&/msie|trident/.test(J),W=J&&J.indexOf("msie 9.0")>0,Z=J&&J.indexOf("edge/")>0,G=(J&&J.indexOf("android"),J&&/iphone|ipad|ipod|ios/.test(J)||"ios"===K),X=(J&&/chrome\/\d+/.test(J),J&&/phantomjs/.test(J),J&&J.match(/firefox\/(\d+)/)),Y={}.watch,Q=!1;if(z)try{var ee={};Object.defineProperty(ee,"passive",{get:function(){Q=!0}}),window.addEventListener("test-passive",null,ee)}catch(e){}var te=function(){return void 0===B&&(B=!z&&!V&&"undefined"!=typeof global&&(global.process&&"server"===global.process.env.VUE_ENV)),B},ne=z&&window.__VUE_DEVTOOLS_GLOBAL_HOOK__;function re(e){return"function"==typeof e&&/native code/.test(e.toString())}var ie,oe="undefined"!=typeof Symbol&&re(Symbol)&&"undefined"!=typeof Reflect&&re(Reflect.ownKeys);ie="undefined"!=typeof Set&&re(Set)?Set:function(){function e(){this.set=Object.create(null)}return e.prototype.has=function(e){return!0===this.set[e]},e.prototype.add=function(e){this.set[e]=!0},e.prototype.clear=function(){this.set=Object.create(null)},e}();var ae=S,se=0,ce=function(){this.id=se++,this.subs=[]};ce.prototype.addSub=function(e){this.subs.push(e)},ce.prototype.removeSub=function(e){h(this.subs,e)},ce.prototype.depend=function(){ce.target&&ce.target.addDep(this)},ce.prototype.notify=function(){for(var e=this.subs.slice(),t=0,n=e.length;t<n;t++)e[t].update()},ce.target=null;var ue=[];function le(e){ue.push(e),ce.target=e}function fe(){ue.pop(),ce.target=ue[ue.length-1]}var pe=function(e,t,n,r,i,o,a,s){this.tag=e,this.data=t,this.children=n,this.text=r,this.elm=i,this.ns=void 0,this.context=o,this.fnContext=void 0,this.fnOptions=void 0,this.fnScopeId=void 0,this.key=t&&t.key,this.componentOptions=a,this.componentInstance=void 0,this.parent=void 0,this.raw=!1,this.isStatic=!1,this.isRootInsert=!0,this.isComment=!1,this.isCloned=!1,this.isOnce=!1,this.asyncFactory=s,this.asyncMeta=void 0,this.isAsyncPlaceholder=!1},de={child:{configurable:!0}};de.child.get=function(){return this.componentInstance},Object.defineProperties(pe.prototype,de);var ve=function(e){void 0===e&&(e="");var t=new pe;return t.text=e,t.isComment=!0,t};function he(e){return new pe(void 0,void 0,void 0,String(e))}function me(e){var t=new pe(e.tag,e.data,e.children&&e.children.slice(),e.text,e.elm,e.context,e.componentOptions,e.asyncFactory);return t.ns=e.ns,t.isStatic=e.isStatic,t.key=e.key,t.isComment=e.isComment,t.fnContext=e.fnContext,t.fnOptions=e.fnOptions,t.fnScopeId=e.fnScopeId,t.asyncMeta=e.asyncMeta,t.isCloned=!0,t}var ye=Array.prototype,ge=Object.create(ye);["push","pop","shift","unshift","splice","sort","reverse"].forEach(function(e){var t=ye[e];R(ge,e,function(){for(var n=[],r=arguments.length;r--;)n[r]=arguments[r];var i,o=t.apply(this,n),a=this.__ob__;switch(e){case"push":case"unshift":i=n;break;case"splice":i=n.slice(2)}return i&&a.observeArray(i),a.dep.notify(),o})});var _e=Object.getOwnPropertyNames(ge),be=!0;function $e(e){be=e}var we=function(e){var t;this.value=e,this.dep=new ce,this.vmCount=0,R(e,"__ob__",this),Array.isArray(e)?(U?(t=ge,e.__proto__=t):function(e,t,n){for(var r=0,i=n.length;r<i;r++){var o=n[r];R(e,o,t[o])}}(e,ge,_e),this.observeArray(e)):this.walk(e)};function Ce(e,t){var n;if(o(e)&&!(e instanceof pe))return y(e,"__ob__")&&e.__ob__ instanceof we?n=e.__ob__:be&&!te()&&(Array.isArray(e)||s(e))&&Object.isExtensible(e)&&!e._isVue&&(n=new we(e)),t&&n&&n.vmCount++,n}function xe(e,t,n,r,i){var o=new ce,a=Object.getOwnPropertyDescriptor(e,t);if(!a||!1!==a.configurable){var s=a&&a.get,c=a&&a.set;s&&!c||2!==arguments.length||(n=e[t]);var u=!i&&Ce(n);Object.defineProperty(e,t,{enumerable:!0,configurable:!0,get:function(){var t=s?s.call(e):n;return ce.target&&(o.depend(),u&&(u.dep.depend(),Array.isArray(t)&&function e(t){for(var n=void 0,r=0,i=t.length;r<i;r++)(n=t[r])&&n.__ob__&&n.__ob__.dep.depend(),Array.isArray(n)&&e(n)}(t))),t},set:function(t){var r=s?s.call(e):n;t===r||t!=t&&r!=r||s&&!c||(c?c.call(e,t):n=t,u=!i&&Ce(t),o.notify())}})}}function ke(e,t,n){if(Array.isArray(e)&&c(t))return e.length=Math.max(e.length,t),e.splice(t,1,n),n;if(t in e&&!(t in Object.prototype))return e[t]=n,n;var r=e.__ob__;return e._isVue||r&&r.vmCount?n:r?(xe(r.value,t,n),r.dep.notify(),n):(e[t]=n,n)}function Ae(e,t){if(Array.isArray(e)&&c(t))e.splice(t,1);else{var n=e.__ob__;e._isVue||n&&n.vmCount||y(e,t)&&(delete e[t],n&&n.dep.notify())}}we.prototype.walk=function(e){for(var t=Object.keys(e),n=0;n<t.length;n++)xe(e,t[n])},we.prototype.observeArray=function(e){for(var t=0,n=e.length;t<n;t++)Ce(e[t])};var Oe=F.optionMergeStrategies;function Se(e,t){if(!t)return e;for(var n,r,i,o=oe?Reflect.ownKeys(t):Object.keys(t),a=0;a<o.length;a++)"__ob__"!==(n=o[a])&&(r=e[n],i=t[n],y(e,n)?r!==i&&s(r)&&s(i)&&Se(r,i):ke(e,n,i));return e}function Te(e,t,n){return n?function(){var r="function"==typeof t?t.call(n,n):t,i="function"==typeof e?e.call(n,n):e;return r?Se(r,i):i}:t?e?function(){return Se("function"==typeof t?t.call(this,this):t,"function"==typeof e?e.call(this,this):e)}:t:e}function Ee(e,t){var n=t?e?e.concat(t):Array.isArray(t)?t:[t]:e;return n?function(e){for(var t=[],n=0;n<e.length;n++)-1===t.indexOf(e[n])&&t.push(e[n]);return t}(n):n}function Ne(e,t,n,r){var i=Object.create(e||null);return t?A(i,t):i}Oe.data=function(e,t,n){return n?Te(e,t,n):t&&"function"!=typeof t?e:Te(e,t)},I.forEach(function(e){Oe[e]=Ee}),M.forEach(function(e){Oe[e+"s"]=Ne}),Oe.watch=function(e,t,n,r){if(e===Y&&(e=void 0),t===Y&&(t=void 0),!t)return Object.create(e||null);if(!e)return t;var i={};for(var o in A(i,e),t){var a=i[o],s=t[o];a&&!Array.isArray(a)&&(a=[a]),i[o]=a?a.concat(s):Array.isArray(s)?s:[s]}return i},Oe.props=Oe.methods=Oe.inject=Oe.computed=function(e,t,n,r){if(!e)return t;var i=Object.create(null);return A(i,e),t&&A(i,t),i},Oe.provide=Te;var je=function(e,t){return void 0===t?e:t};function De(e,t,n){if("function"==typeof t&&(t=t.options),function(e,t){var n=e.props;if(n){var r,i,o={};if(Array.isArray(n))for(r=n.length;r--;)"string"==typeof(i=n[r])&&(o[b(i)]={type:null});else if(s(n))for(var a in n)i=n[a],o[b(a)]=s(i)?i:{type:i};e.props=o}}(t),function(e,t){var n=e.inject;if(n){var r=e.inject={};if(Array.isArray(n))for(var i=0;i<n.length;i++)r[n[i]]={from:n[i]};else if(s(n))for(var o in n){var a=n[o];r[o]=s(a)?A({from:o},a):{from:a}}}}(t),function(e){var t=e.directives;if(t)for(var n in t){var r=t[n];"function"==typeof r&&(t[n]={bind:r,update:r})}}(t),!t._base&&(t.extends&&(e=De(e,t.extends,n)),t.mixins))for(var r=0,i=t.mixins.length;r<i;r++)e=De(e,t.mixins[r],n);var o,a={};for(o in e)c(o);for(o in t)y(e,o)||c(o);function c(r){var i=Oe[r]||je;a[r]=i(e[r],t[r],n,r)}return a}function Le(e,t,n,r){if("string"==typeof n){var i=e[t];if(y(i,n))return i[n];var o=b(n);if(y(i,o))return i[o];var a=$(o);return y(i,a)?i[a]:i[n]||i[o]||i[a]}}function Me(e,t,n,r){var i=t[e],o=!y(n,e),a=n[e],s=Pe(Boolean,i.type);if(s>-1)if(o&&!y(i,"default"))a=!1;else if(""===a||a===C(e)){var c=Pe(String,i.type);(c<0||s<c)&&(a=!0)}if(void 0===a){a=function(e,t,n){if(!y(t,"default"))return;var r=t.default;if(e&&e.$options.propsData&&void 0===e.$options.propsData[n]&&void 0!==e._props[n])return e._props[n];return"function"==typeof r&&"Function"!==Ie(t.type)?r.call(e):r}(r,i,e);var u=be;$e(!0),Ce(a),$e(u)}return a}function Ie(e){var t=e&&e.toString().match(/^\s*function (\w+)/);return t?t[1]:""}function Fe(e,t){return Ie(e)===Ie(t)}function Pe(e,t){if(!Array.isArray(t))return Fe(t,e)?0:-1;for(var n=0,r=t.length;n<r;n++)if(Fe(t[n],e))return n;return-1}function Re(e,t,n){le();try{if(t)for(var r=t;r=r.$parent;){var i=r.$options.errorCaptured;if(i)for(var o=0;o<i.length;o++)try{if(!1===i[o].call(r,e,t,n))return}catch(e){Be(e,r,"errorCaptured hook")}}Be(e,t,n)}finally{fe()}}function He(e,t,n,r,i){var o;try{(o=n?e.apply(t,n):e.call(t))&&!o._isVue&&u(o)&&!o._handled&&(o.catch(function(e){return Re(e,r,i+" (Promise/async)")}),o._handled=!0)}catch(e){Re(e,r,i)}return o}function Be(e,t,n){if(F.errorHandler)try{return F.errorHandler.call(null,e,t,n)}catch(t){t!==e&&Ue(t,null,"config.errorHandler")}Ue(e,t,n)}function Ue(e,t,n){if(!z&&!V||"undefined"==typeof console)throw e;console.error(e)}var ze,Ve=!1,Ke=[],Je=!1;function qe(){Je=!1;var e=Ke.slice(0);Ke.length=0;for(var t=0;t<e.length;t++)e[t]()}if("undefined"!=typeof Promise&&re(Promise)){var We=Promise.resolve();ze=function(){We.then(qe),G&&setTimeout(S)},Ve=!0}else if(q||"undefined"==typeof MutationObserver||!re(MutationObserver)&&"[object MutationObserverConstructor]"!==MutationObserver.toString())ze="undefined"!=typeof setImmediate&&re(setImmediate)?function(){setImmediate(qe)}:function(){setTimeout(qe,0)};else{var Ze=1,Ge=new MutationObserver(qe),Xe=document.createTextNode(String(Ze));Ge.observe(Xe,{characterData:!0}),ze=function(){Ze=(Ze+1)%2,Xe.data=String(Ze)},Ve=!0}function Ye(e,t){var n;if(Ke.push(function(){if(e)try{e.call(t)}catch(e){Re(e,t,"nextTick")}else n&&n(t)}),Je||(Je=!0,ze()),!e&&"undefined"!=typeof Promise)return new Promise(function(e){n=e})}var Qe=new ie;function et(e){!function e(t,n){var r,i;var a=Array.isArray(t);if(!a&&!o(t)||Object.isFrozen(t)||t instanceof pe)return;if(t.__ob__){var s=t.__ob__.dep.id;if(n.has(s))return;n.add(s)}if(a)for(r=t.length;r--;)e(t[r],n);else for(i=Object.keys(t),r=i.length;r--;)e(t[i[r]],n)}(e,Qe),Qe.clear()}var tt=g(function(e){var t="&"===e.charAt(0),n="~"===(e=t?e.slice(1):e).charAt(0),r="!"===(e=n?e.slice(1):e).charAt(0);return{name:e=r?e.slice(1):e,once:n,capture:r,passive:t}});function nt(e,t){function n(){var e=arguments,r=n.fns;if(!Array.isArray(r))return He(r,null,arguments,t,"v-on handler");for(var i=r.slice(),o=0;o<i.length;o++)He(i[o],null,e,t,"v-on handler")}return n.fns=e,n}function rt(e,n,i,o,a,s){var c,u,l,f;for(c in e)u=e[c],l=n[c],f=tt(c),t(u)||(t(l)?(t(u.fns)&&(u=e[c]=nt(u,s)),r(f.once)&&(u=e[c]=a(f.name,u,f.capture)),i(f.name,u,f.capture,f.passive,f.params)):u!==l&&(l.fns=u,e[c]=l));for(c in n)t(e[c])&&o((f=tt(c)).name,n[c],f.capture)}function it(e,i,o){var a;e instanceof pe&&(e=e.data.hook||(e.data.hook={}));var s=e[i];function c(){o.apply(this,arguments),h(a.fns,c)}t(s)?a=nt([c]):n(s.fns)&&r(s.merged)?(a=s).fns.push(c):a=nt([s,c]),a.merged=!0,e[i]=a}function ot(e,t,r,i,o){if(n(t)){if(y(t,r))return e[r]=t[r],o||delete t[r],!0;if(y(t,i))return e[r]=t[i],o||delete t[i],!0}return!1}function at(e){return i(e)?[he(e)]:Array.isArray(e)?function e(o,a){var s=[];var c,u,l,f;for(c=0;c<o.length;c++)t(u=o[c])||"boolean"==typeof u||(l=s.length-1,f=s[l],Array.isArray(u)?u.length>0&&(st((u=e(u,(a||"")+"_"+c))[0])&&st(f)&&(s[l]=he(f.text+u[0].text),u.shift()),s.push.apply(s,u)):i(u)?st(f)?s[l]=he(f.text+u):""!==u&&s.push(he(u)):st(u)&&st(f)?s[l]=he(f.text+u.text):(r(o._isVList)&&n(u.tag)&&t(u.key)&&n(a)&&(u.key="__vlist"+a+"_"+c+"__"),s.push(u)));return s}(e):void 0}function st(e){return n(e)&&n(e.text)&&!1===e.isComment}function ct(e,t){if(e){for(var n=Object.create(null),r=oe?Reflect.ownKeys(e):Object.keys(e),i=0;i<r.length;i++){var o=r[i];if("__ob__"!==o){for(var a=e[o].from,s=t;s;){if(s._provided&&y(s._provided,a)){n[o]=s._provided[a];break}s=s.$parent}if(!s&&"default"in e[o]){var c=e[o].default;n[o]="function"==typeof c?c.call(t):c}}}return n}}function ut(e,t){if(!e||!e.length)return{};for(var n={},r=0,i=e.length;r<i;r++){var o=e[r],a=o.data;if(a&&a.attrs&&a.attrs.slot&&delete a.attrs.slot,o.context!==t&&o.fnContext!==t||!a||null==a.slot)(n.default||(n.default=[])).push(o);else{var s=a.slot,c=n[s]||(n[s]=[]);"template"===o.tag?c.push.apply(c,o.children||[]):c.push(o)}}for(var u in n)n[u].every(lt)&&delete n[u];return n}function lt(e){return e.isComment&&!e.asyncFactory||" "===e.text}function ft(t,n,r){var i,o=Object.keys(n).length>0,a=t?!!t.$stable:!o,s=t&&t.$key;if(t){if(t._normalized)return t._normalized;if(a&&r&&r!==e&&s===r.$key&&!o&&!r.$hasNormal)return r;for(var c in i={},t)t[c]&&"$"!==c[0]&&(i[c]=pt(n,c,t[c]))}else i={};for(var u in n)u in i||(i[u]=dt(n,u));return t&&Object.isExtensible(t)&&(t._normalized=i),R(i,"$stable",a),R(i,"$key",s),R(i,"$hasNormal",o),i}function pt(e,t,n){var r=function(){var e=arguments.length?n.apply(null,arguments):n({});return(e=e&&"object"==typeof e&&!Array.isArray(e)?[e]:at(e))&&(0===e.length||1===e.length&&e[0].isComment)?void 0:e};return n.proxy&&Object.defineProperty(e,t,{get:r,enumerable:!0,configurable:!0}),r}function dt(e,t){return function(){return e[t]}}function vt(e,t){var r,i,a,s,c;if(Array.isArray(e)||"string"==typeof e)for(r=new Array(e.length),i=0,a=e.length;i<a;i++)r[i]=t(e[i],i);else if("number"==typeof e)for(r=new Array(e),i=0;i<e;i++)r[i]=t(i+1,i);else if(o(e))if(oe&&e[Symbol.iterator]){r=[];for(var u=e[Symbol.iterator](),l=u.next();!l.done;)r.push(t(l.value,r.length)),l=u.next()}else for(s=Object.keys(e),r=new Array(s.length),i=0,a=s.length;i<a;i++)c=s[i],r[i]=t(e[c],c,i);return n(r)||(r=[]),r._isVList=!0,r}function ht(e,t,n,r){var i,o=this.$scopedSlots[e];o?(n=n||{},r&&(n=A(A({},r),n)),i=o(n)||t):i=this.$slots[e]||t;var a=n&&n.slot;return a?this.$createElement("template",{slot:a},i):i}function mt(e){return Le(this.$options,"filters",e)||E}function yt(e,t){return Array.isArray(e)?-1===e.indexOf(t):e!==t}function gt(e,t,n,r,i){var o=F.keyCodes[t]||n;return i&&r&&!F.keyCodes[t]?yt(i,r):o?yt(o,e):r?C(r)!==t:void 0}function _t(e,t,n,r,i){if(n)if(o(n)){var a;Array.isArray(n)&&(n=O(n));var s=function(o){if("class"===o||"style"===o||v(o))a=e;else{var s=e.attrs&&e.attrs.type;a=r||F.mustUseProp(t,s,o)?e.domProps||(e.domProps={}):e.attrs||(e.attrs={})}var c=b(o),u=C(o);c in a||u in a||(a[o]=n[o],i&&((e.on||(e.on={}))["update:"+o]=function(e){n[o]=e}))};for(var c in n)s(c)}else;return e}function bt(e,t){var n=this._staticTrees||(this._staticTrees=[]),r=n[e];return r&&!t?r:(wt(r=n[e]=this.$options.staticRenderFns[e].call(this._renderProxy,null,this),"__static__"+e,!1),r)}function $t(e,t,n){return wt(e,"__once__"+t+(n?"_"+n:""),!0),e}function wt(e,t,n){if(Array.isArray(e))for(var r=0;r<e.length;r++)e[r]&&"string"!=typeof e[r]&&Ct(e[r],t+"_"+r,n);else Ct(e,t,n)}function Ct(e,t,n){e.isStatic=!0,e.key=t,e.isOnce=n}function xt(e,t){if(t)if(s(t)){var n=e.on=e.on?A({},e.on):{};for(var r in t){var i=n[r],o=t[r];n[r]=i?[].concat(i,o):o}}else;return e}function kt(e,t,n,r){t=t||{$stable:!n};for(var i=0;i<e.length;i++){var o=e[i];Array.isArray(o)?kt(o,t,n):o&&(o.proxy&&(o.fn.proxy=!0),t[o.key]=o.fn)}return r&&(t.$key=r),t}function At(e,t){for(var n=0;n<t.length;n+=2){var r=t[n];"string"==typeof r&&r&&(e[t[n]]=t[n+1])}return e}function Ot(e,t){return"string"==typeof e?t+e:e}function St(e){e._o=$t,e._n=f,e._s=l,e._l=vt,e._t=ht,e._q=N,e._i=j,e._m=bt,e._f=mt,e._k=gt,e._b=_t,e._v=he,e._e=ve,e._u=kt,e._g=xt,e._d=At,e._p=Ot}function Tt(t,n,i,o,a){var s,c=this,u=a.options;y(o,"_uid")?(s=Object.create(o))._original=o:(s=o,o=o._original);var l=r(u._compiled),f=!l;this.data=t,this.props=n,this.children=i,this.parent=o,this.listeners=t.on||e,this.injections=ct(u.inject,o),this.slots=function(){return c.$slots||ft(t.scopedSlots,c.$slots=ut(i,o)),c.$slots},Object.defineProperty(this,"scopedSlots",{enumerable:!0,get:function(){return ft(t.scopedSlots,this.slots())}}),l&&(this.$options=u,this.$slots=this.slots(),this.$scopedSlots=ft(t.scopedSlots,this.$slots)),u._scopeId?this._c=function(e,t,n,r){var i=Pt(s,e,t,n,r,f);return i&&!Array.isArray(i)&&(i.fnScopeId=u._scopeId,i.fnContext=o),i}:this._c=function(e,t,n,r){return Pt(s,e,t,n,r,f)}}function Et(e,t,n,r,i){var o=me(e);return o.fnContext=n,o.fnOptions=r,t.slot&&((o.data||(o.data={})).slot=t.slot),o}function Nt(e,t){for(var n in t)e[b(n)]=t[n]}St(Tt.prototype);var jt={init:function(e,t){if(e.componentInstance&&!e.componentInstance._isDestroyed&&e.data.keepAlive){var r=e;jt.prepatch(r,r)}else{(e.componentInstance=function(e,t){var r={_isComponent:!0,_parentVnode:e,parent:t},i=e.data.inlineTemplate;n(i)&&(r.render=i.render,r.staticRenderFns=i.staticRenderFns);return new e.componentOptions.Ctor(r)}(e,Wt)).$mount(t?e.elm:void 0,t)}},prepatch:function(t,n){var r=n.componentOptions;!function(t,n,r,i,o){var a=i.data.scopedSlots,s=t.$scopedSlots,c=!!(a&&!a.$stable||s!==e&&!s.$stable||a&&t.$scopedSlots.$key!==a.$key),u=!!(o||t.$options._renderChildren||c);t.$options._parentVnode=i,t.$vnode=i,t._vnode&&(t._vnode.parent=i);if(t.$options._renderChildren=o,t.$attrs=i.data.attrs||e,t.$listeners=r||e,n&&t.$options.props){$e(!1);for(var l=t._props,f=t.$options._propKeys||[],p=0;p<f.length;p++){var d=f[p],v=t.$options.props;l[d]=Me(d,v,n,t)}$e(!0),t.$options.propsData=n}r=r||e;var h=t.$options._parentListeners;t.$options._parentListeners=r,qt(t,r,h),u&&(t.$slots=ut(o,i.context),t.$forceUpdate())}(n.componentInstance=t.componentInstance,r.propsData,r.listeners,n,r.children)},insert:function(e){var t,n=e.context,r=e.componentInstance;r._isMounted||(r._isMounted=!0,Yt(r,"mounted")),e.data.keepAlive&&(n._isMounted?((t=r)._inactive=!1,en.push(t)):Xt(r,!0))},destroy:function(e){var t=e.componentInstance;t._isDestroyed||(e.data.keepAlive?function e(t,n){if(n&&(t._directInactive=!0,Gt(t)))return;if(!t._inactive){t._inactive=!0;for(var r=0;r<t.$children.length;r++)e(t.$children[r]);Yt(t,"deactivated")}}(t,!0):t.$destroy())}},Dt=Object.keys(jt);function Lt(i,a,s,c,l){if(!t(i)){var f=s.$options._base;if(o(i)&&(i=f.extend(i)),"function"==typeof i){var p;if(t(i.cid)&&void 0===(i=function(e,i){if(r(e.error)&&n(e.errorComp))return e.errorComp;if(n(e.resolved))return e.resolved;var a=Ht;a&&n(e.owners)&&-1===e.owners.indexOf(a)&&e.owners.push(a);if(r(e.loading)&&n(e.loadingComp))return e.loadingComp;if(a&&!n(e.owners)){var s=e.owners=[a],c=!0,l=null,f=null;a.$on("hook:destroyed",function(){return h(s,a)});var p=function(e){for(var t=0,n=s.length;t<n;t++)s[t].$forceUpdate();e&&(s.length=0,null!==l&&(clearTimeout(l),l=null),null!==f&&(clearTimeout(f),f=null))},d=D(function(t){e.resolved=Bt(t,i),c?s.length=0:p(!0)}),v=D(function(t){n(e.errorComp)&&(e.error=!0,p(!0))}),m=e(d,v);return o(m)&&(u(m)?t(e.resolved)&&m.then(d,v):u(m.component)&&(m.component.then(d,v),n(m.error)&&(e.errorComp=Bt(m.error,i)),n(m.loading)&&(e.loadingComp=Bt(m.loading,i),0===m.delay?e.loading=!0:l=setTimeout(function(){l=null,t(e.resolved)&&t(e.error)&&(e.loading=!0,p(!1))},m.delay||200)),n(m.timeout)&&(f=setTimeout(function(){f=null,t(e.resolved)&&v(null)},m.timeout)))),c=!1,e.loading?e.loadingComp:e.resolved}}(p=i,f)))return function(e,t,n,r,i){var o=ve();return o.asyncFactory=e,o.asyncMeta={data:t,context:n,children:r,tag:i},o}(p,a,s,c,l);a=a||{},$n(i),n(a.model)&&function(e,t){var r=e.model&&e.model.prop||"value",i=e.model&&e.model.event||"input";(t.attrs||(t.attrs={}))[r]=t.model.value;var o=t.on||(t.on={}),a=o[i],s=t.model.callback;n(a)?(Array.isArray(a)?-1===a.indexOf(s):a!==s)&&(o[i]=[s].concat(a)):o[i]=s}(i.options,a);var d=function(e,r,i){var o=r.options.props;if(!t(o)){var a={},s=e.attrs,c=e.props;if(n(s)||n(c))for(var u in o){var l=C(u);ot(a,c,u,l,!0)||ot(a,s,u,l,!1)}return a}}(a,i);if(r(i.options.functional))return function(t,r,i,o,a){var s=t.options,c={},u=s.props;if(n(u))for(var l in u)c[l]=Me(l,u,r||e);else n(i.attrs)&&Nt(c,i.attrs),n(i.props)&&Nt(c,i.props);var f=new Tt(i,c,a,o,t),p=s.render.call(null,f._c,f);if(p instanceof pe)return Et(p,i,f.parent,s);if(Array.isArray(p)){for(var d=at(p)||[],v=new Array(d.length),h=0;h<d.length;h++)v[h]=Et(d[h],i,f.parent,s);return v}}(i,d,a,s,c);var v=a.on;if(a.on=a.nativeOn,r(i.options.abstract)){var m=a.slot;a={},m&&(a.slot=m)}!function(e){for(var t=e.hook||(e.hook={}),n=0;n<Dt.length;n++){var r=Dt[n],i=t[r],o=jt[r];i===o||i&&i._merged||(t[r]=i?Mt(o,i):o)}}(a);var y=i.options.name||l;return new pe("vue-component-"+i.cid+(y?"-"+y:""),a,void 0,void 0,void 0,s,{Ctor:i,propsData:d,listeners:v,tag:l,children:c},p)}}}function Mt(e,t){var n=function(n,r){e(n,r),t(n,r)};return n._merged=!0,n}var It=1,Ft=2;function Pt(e,a,s,c,u,l){return(Array.isArray(s)||i(s))&&(u=c,c=s,s=void 0),r(l)&&(u=Ft),function(e,i,a,s,c){if(n(a)&&n(a.__ob__))return ve();n(a)&&n(a.is)&&(i=a.is);if(!i)return ve();Array.isArray(s)&&"function"==typeof s[0]&&((a=a||{}).scopedSlots={default:s[0]},s.length=0);c===Ft?s=at(s):c===It&&(s=function(e){for(var t=0;t<e.length;t++)if(Array.isArray(e[t]))return Array.prototype.concat.apply([],e);return e}(s));var u,l;if("string"==typeof i){var f;l=e.$vnode&&e.$vnode.ns||F.getTagNamespace(i),u=F.isReservedTag(i)?new pe(F.parsePlatformTagName(i),a,s,void 0,void 0,e):a&&a.pre||!n(f=Le(e.$options,"components",i))?new pe(i,a,s,void 0,void 0,e):Lt(f,a,e,s,i)}else u=Lt(i,a,e,s);return Array.isArray(u)?u:n(u)?(n(l)&&function e(i,o,a){i.ns=o;"foreignObject"===i.tag&&(o=void 0,a=!0);if(n(i.children))for(var s=0,c=i.children.length;s<c;s++){var u=i.children[s];n(u.tag)&&(t(u.ns)||r(a)&&"svg"!==u.tag)&&e(u,o,a)}}(u,l),n(a)&&function(e){o(e.style)&&et(e.style);o(e.class)&&et(e.class)}(a),u):ve()}(e,a,s,c,u)}var Rt,Ht=null;function Bt(e,t){return(e.__esModule||oe&&"Module"===e[Symbol.toStringTag])&&(e=e.default),o(e)?t.extend(e):e}function Ut(e){return e.isComment&&e.asyncFactory}function zt(e){if(Array.isArray(e))for(var t=0;t<e.length;t++){var r=e[t];if(n(r)&&(n(r.componentOptions)||Ut(r)))return r}}function Vt(e,t){Rt.$on(e,t)}function Kt(e,t){Rt.$off(e,t)}function Jt(e,t){var n=Rt;return function r(){null!==t.apply(null,arguments)&&n.$off(e,r)}}function qt(e,t,n){Rt=e,rt(t,n||{},Vt,Kt,Jt,e),Rt=void 0}var Wt=null;function Zt(e){var t=Wt;return Wt=e,function(){Wt=t}}function Gt(e){for(;e&&(e=e.$parent);)if(e._inactive)return!0;return!1}function Xt(e,t){if(t){if(e._directInactive=!1,Gt(e))return}else if(e._directInactive)return;if(e._inactive||null===e._inactive){e._inactive=!1;for(var n=0;n<e.$children.length;n++)Xt(e.$children[n]);Yt(e,"activated")}}function Yt(e,t){le();var n=e.$options[t],r=t+" hook";if(n)for(var i=0,o=n.length;i<o;i++)He(n[i],e,null,e,r);e._hasHookEvent&&e.$emit("hook:"+t),fe()}var Qt=[],en=[],tn={},nn=!1,rn=!1,on=0;var an=0,sn=Date.now;if(z&&!q){var cn=window.performance;cn&&"function"==typeof cn.now&&sn()>document.createEvent("Event").timeStamp&&(sn=function(){return cn.now()})}function un(){var e,t;for(an=sn(),rn=!0,Qt.sort(function(e,t){return e.id-t.id}),on=0;on<Qt.length;on++)(e=Qt[on]).before&&e.before(),t=e.id,tn[t]=null,e.run();var n=en.slice(),r=Qt.slice();on=Qt.length=en.length=0,tn={},nn=rn=!1,function(e){for(var t=0;t<e.length;t++)e[t]._inactive=!0,Xt(e[t],!0)}(n),function(e){var t=e.length;for(;t--;){var n=e[t],r=n.vm;r._watcher===n&&r._isMounted&&!r._isDestroyed&&Yt(r,"updated")}}(r),ne&&F.devtools&&ne.emit("flush")}var ln=0,fn=function(e,t,n,r,i){this.vm=e,i&&(e._watcher=this),e._watchers.push(this),r?(this.deep=!!r.deep,this.user=!!r.user,this.lazy=!!r.lazy,this.sync=!!r.sync,this.before=r.before):this.deep=this.user=this.lazy=this.sync=!1,this.cb=n,this.id=++ln,this.active=!0,this.dirty=this.lazy,this.deps=[],this.newDeps=[],this.depIds=new ie,this.newDepIds=new ie,this.expression="","function"==typeof t?this.getter=t:(this.getter=function(e){if(!H.test(e)){var t=e.split(".");return function(e){for(var n=0;n<t.length;n++){if(!e)return;e=e[t[n]]}return e}}}(t),this.getter||(this.getter=S)),this.value=this.lazy?void 0:this.get()};fn.prototype.get=function(){var e;le(this);var t=this.vm;try{e=this.getter.call(t,t)}catch(e){if(!this.user)throw e;Re(e,t,'getter for watcher "'+this.expression+'"')}finally{this.deep&&et(e),fe(),this.cleanupDeps()}return e},fn.prototype.addDep=function(e){var t=e.id;this.newDepIds.has(t)||(this.newDepIds.add(t),this.newDeps.push(e),this.depIds.has(t)||e.addSub(this))},fn.prototype.cleanupDeps=function(){for(var e=this.deps.length;e--;){var t=this.deps[e];this.newDepIds.has(t.id)||t.removeSub(this)}var n=this.depIds;this.depIds=this.newDepIds,this.newDepIds=n,this.newDepIds.clear(),n=this.deps,this.deps=this.newDeps,this.newDeps=n,this.newDeps.length=0},fn.prototype.update=function(){this.lazy?this.dirty=!0:this.sync?this.run():function(e){var t=e.id;if(null==tn[t]){if(tn[t]=!0,rn){for(var n=Qt.length-1;n>on&&Qt[n].id>e.id;)n--;Qt.splice(n+1,0,e)}else Qt.push(e);nn||(nn=!0,Ye(un))}}(this)},fn.prototype.run=function(){if(this.active){var e=this.get();if(e!==this.value||o(e)||this.deep){var t=this.value;if(this.value=e,this.user)try{this.cb.call(this.vm,e,t)}catch(e){Re(e,this.vm,'callback for watcher "'+this.expression+'"')}else this.cb.call(this.vm,e,t)}}},fn.prototype.evaluate=function(){this.value=this.get(),this.dirty=!1},fn.prototype.depend=function(){for(var e=this.deps.length;e--;)this.deps[e].depend()},fn.prototype.teardown=function(){if(this.active){this.vm._isBeingDestroyed||h(this.vm._watchers,this);for(var e=this.deps.length;e--;)this.deps[e].removeSub(this);this.active=!1}};var pn={enumerable:!0,configurable:!0,get:S,set:S};function dn(e,t,n){pn.get=function(){return this[t][n]},pn.set=function(e){this[t][n]=e},Object.defineProperty(e,n,pn)}function vn(e){e._watchers=[];var t=e.$options;t.props&&function(e,t){var n=e.$options.propsData||{},r=e._props={},i=e.$options._propKeys=[];e.$parent&&$e(!1);var o=function(o){i.push(o);var a=Me(o,t,n,e);xe(r,o,a),o in e||dn(e,"_props",o)};for(var a in t)o(a);$e(!0)}(e,t.props),t.methods&&function(e,t){e.$options.props;for(var n in t)e[n]="function"!=typeof t[n]?S:x(t[n],e)}(e,t.methods),t.data?function(e){var t=e.$options.data;s(t=e._data="function"==typeof t?function(e,t){le();try{return e.call(t,t)}catch(e){return Re(e,t,"data()"),{}}finally{fe()}}(t,e):t||{})||(t={});var n=Object.keys(t),r=e.$options.props,i=(e.$options.methods,n.length);for(;i--;){var o=n[i];r&&y(r,o)||(a=void 0,36!==(a=(o+"").charCodeAt(0))&&95!==a&&dn(e,"_data",o))}var a;Ce(t,!0)}(e):Ce(e._data={},!0),t.computed&&function(e,t){var n=e._computedWatchers=Object.create(null),r=te();for(var i in t){var o=t[i],a="function"==typeof o?o:o.get;r||(n[i]=new fn(e,a||S,S,hn)),i in e||mn(e,i,o)}}(e,t.computed),t.watch&&t.watch!==Y&&function(e,t){for(var n in t){var r=t[n];if(Array.isArray(r))for(var i=0;i<r.length;i++)_n(e,n,r[i]);else _n(e,n,r)}}(e,t.watch)}var hn={lazy:!0};function mn(e,t,n){var r=!te();"function"==typeof n?(pn.get=r?yn(t):gn(n),pn.set=S):(pn.get=n.get?r&&!1!==n.cache?yn(t):gn(n.get):S,pn.set=n.set||S),Object.defineProperty(e,t,pn)}function yn(e){return function(){var t=this._computedWatchers&&this._computedWatchers[e];if(t)return t.dirty&&t.evaluate(),ce.target&&t.depend(),t.value}}function gn(e){return function(){return e.call(this,this)}}function _n(e,t,n,r){return s(n)&&(r=n,n=n.handler),"string"==typeof n&&(n=e[n]),e.$watch(t,n,r)}var bn=0;function $n(e){var t=e.options;if(e.super){var n=$n(e.super);if(n!==e.superOptions){e.superOptions=n;var r=function(e){var t,n=e.options,r=e.sealedOptions;for(var i in n)n[i]!==r[i]&&(t||(t={}),t[i]=n[i]);return t}(e);r&&A(e.extendOptions,r),(t=e.options=De(n,e.extendOptions)).name&&(t.components[t.name]=e)}}return t}function wn(e){this._init(e)}function Cn(e){e.cid=0;var t=1;e.extend=function(e){e=e||{};var n=this,r=n.cid,i=e._Ctor||(e._Ctor={});if(i[r])return i[r];var o=e.name||n.options.name,a=function(e){this._init(e)};return(a.prototype=Object.create(n.prototype)).constructor=a,a.cid=t++,a.options=De(n.options,e),a.super=n,a.options.props&&function(e){var t=e.options.props;for(var n in t)dn(e.prototype,"_props",n)}(a),a.options.computed&&function(e){var t=e.options.computed;for(var n in t)mn(e.prototype,n,t[n])}(a),a.extend=n.extend,a.mixin=n.mixin,a.use=n.use,M.forEach(function(e){a[e]=n[e]}),o&&(a.options.components[o]=a),a.superOptions=n.options,a.extendOptions=e,a.sealedOptions=A({},a.options),i[r]=a,a}}function xn(e){return e&&(e.Ctor.options.name||e.tag)}function kn(e,t){return Array.isArray(e)?e.indexOf(t)>-1:"string"==typeof e?e.split(",").indexOf(t)>-1:(n=e,"[object RegExp]"===a.call(n)&&e.test(t));var n}function An(e,t){var n=e.cache,r=e.keys,i=e._vnode;for(var o in n){var a=n[o];if(a){var s=xn(a.componentOptions);s&&!t(s)&&On(n,o,r,i)}}}function On(e,t,n,r){var i=e[t];!i||r&&i.tag===r.tag||i.componentInstance.$destroy(),e[t]=null,h(n,t)}!function(t){t.prototype._init=function(t){var n=this;n._uid=bn++,n._isVue=!0,t&&t._isComponent?function(e,t){var n=e.$options=Object.create(e.constructor.options),r=t._parentVnode;n.parent=t.parent,n._parentVnode=r;var i=r.componentOptions;n.propsData=i.propsData,n._parentListeners=i.listeners,n._renderChildren=i.children,n._componentTag=i.tag,t.render&&(n.render=t.render,n.staticRenderFns=t.staticRenderFns)}(n,t):n.$options=De($n(n.constructor),t||{},n),n._renderProxy=n,n._self=n,function(e){var t=e.$options,n=t.parent;if(n&&!t.abstract){for(;n.$options.abstract&&n.$parent;)n=n.$parent;n.$children.push(e)}e.$parent=n,e.$root=n?n.$root:e,e.$children=[],e.$refs={},e._watcher=null,e._inactive=null,e._directInactive=!1,e._isMounted=!1,e._isDestroyed=!1,e._isBeingDestroyed=!1}(n),function(e){e._events=Object.create(null),e._hasHookEvent=!1;var t=e.$options._parentListeners;t&&qt(e,t)}(n),function(t){t._vnode=null,t._staticTrees=null;var n=t.$options,r=t.$vnode=n._parentVnode,i=r&&r.context;t.$slots=ut(n._renderChildren,i),t.$scopedSlots=e,t._c=function(e,n,r,i){return Pt(t,e,n,r,i,!1)},t.$createElement=function(e,n,r,i){return Pt(t,e,n,r,i,!0)};var o=r&&r.data;xe(t,"$attrs",o&&o.attrs||e,null,!0),xe(t,"$listeners",n._parentListeners||e,null,!0)}(n),Yt(n,"beforeCreate"),function(e){var t=ct(e.$options.inject,e);t&&($e(!1),Object.keys(t).forEach(function(n){xe(e,n,t[n])}),$e(!0))}(n),vn(n),function(e){var t=e.$options.provide;t&&(e._provided="function"==typeof t?t.call(e):t)}(n),Yt(n,"created"),n.$options.el&&n.$mount(n.$options.el)}}(wn),function(e){var t={get:function(){return this._data}},n={get:function(){return this._props}};Object.defineProperty(e.prototype,"$data",t),Object.defineProperty(e.prototype,"$props",n),e.prototype.$set=ke,e.prototype.$delete=Ae,e.prototype.$watch=function(e,t,n){if(s(t))return _n(this,e,t,n);(n=n||{}).user=!0;var r=new fn(this,e,t,n);if(n.immediate)try{t.call(this,r.value)}catch(e){Re(e,this,'callback for immediate watcher "'+r.expression+'"')}return function(){r.teardown()}}}(wn),function(e){var t=/^hook:/;e.prototype.$on=function(e,n){var r=this;if(Array.isArray(e))for(var i=0,o=e.length;i<o;i++)r.$on(e[i],n);else(r._events[e]||(r._events[e]=[])).push(n),t.test(e)&&(r._hasHookEvent=!0);return r},e.prototype.$once=function(e,t){var n=this;function r(){n.$off(e,r),t.apply(n,arguments)}return r.fn=t,n.$on(e,r),n},e.prototype.$off=function(e,t){var n=this;if(!arguments.length)return n._events=Object.create(null),n;if(Array.isArray(e)){for(var r=0,i=e.length;r<i;r++)n.$off(e[r],t);return n}var o,a=n._events[e];if(!a)return n;if(!t)return n._events[e]=null,n;for(var s=a.length;s--;)if((o=a[s])===t||o.fn===t){a.splice(s,1);break}return n},e.prototype.$emit=function(e){var t=this._events[e];if(t){t=t.length>1?k(t):t;for(var n=k(arguments,1),r='event handler for "'+e+'"',i=0,o=t.length;i<o;i++)He(t[i],this,n,this,r)}return this}}(wn),function(e){e.prototype._update=function(e,t){var n=this,r=n.$el,i=n._vnode,o=Zt(n);n._vnode=e,n.$el=i?n.__patch__(i,e):n.__patch__(n.$el,e,t,!1),o(),r&&(r.__vue__=null),n.$el&&(n.$el.__vue__=n),n.$vnode&&n.$parent&&n.$vnode===n.$parent._vnode&&(n.$parent.$el=n.$el)},e.prototype.$forceUpdate=function(){this._watcher&&this._watcher.update()},e.prototype.$destroy=function(){var e=this;if(!e._isBeingDestroyed){Yt(e,"beforeDestroy"),e._isBeingDestroyed=!0;var t=e.$parent;!t||t._isBeingDestroyed||e.$options.abstract||h(t.$children,e),e._watcher&&e._watcher.teardown();for(var n=e._watchers.length;n--;)e._watchers[n].teardown();e._data.__ob__&&e._data.__ob__.vmCount--,e._isDestroyed=!0,e.__patch__(e._vnode,null),Yt(e,"destroyed"),e.$off(),e.$el&&(e.$el.__vue__=null),e.$vnode&&(e.$vnode.parent=null)}}}(wn),function(e){St(e.prototype),e.prototype.$nextTick=function(e){return Ye(e,this)},e.prototype._render=function(){var e,t=this,n=t.$options,r=n.render,i=n._parentVnode;i&&(t.$scopedSlots=ft(i.data.scopedSlots,t.$slots,t.$scopedSlots)),t.$vnode=i;try{Ht=t,e=r.call(t._renderProxy,t.$createElement)}catch(n){Re(n,t,"render"),e=t._vnode}finally{Ht=null}return Array.isArray(e)&&1===e.length&&(e=e[0]),e instanceof pe||(e=ve()),e.parent=i,e}}(wn);var Sn=[String,RegExp,Array],Tn={KeepAlive:{name:"keep-alive",abstract:!0,props:{include:Sn,exclude:Sn,max:[String,Number]},created:function(){this.cache=Object.create(null),this.keys=[]},destroyed:function(){for(var e in this.cache)On(this.cache,e,this.keys)},mounted:function(){var e=this;this.$watch("include",function(t){An(e,function(e){return kn(t,e)})}),this.$watch("exclude",function(t){An(e,function(e){return!kn(t,e)})})},render:function(){var e=this.$slots.default,t=zt(e),n=t&&t.componentOptions;if(n){var r=xn(n),i=this.include,o=this.exclude;if(i&&(!r||!kn(i,r))||o&&r&&kn(o,r))return t;var a=this.cache,s=this.keys,c=null==t.key?n.Ctor.cid+(n.tag?"::"+n.tag:""):t.key;a[c]?(t.componentInstance=a[c].componentInstance,h(s,c),s.push(c)):(a[c]=t,s.push(c),this.max&&s.length>parseInt(this.max)&&On(a,s[0],s,this._vnode)),t.data.keepAlive=!0}return t||e&&e[0]}}};!function(e){var t={get:function(){return F}};Object.defineProperty(e,"config",t),e.util={warn:ae,extend:A,mergeOptions:De,defineReactive:xe},e.set=ke,e.delete=Ae,e.nextTick=Ye,e.observable=function(e){return Ce(e),e},e.options=Object.create(null),M.forEach(function(t){e.options[t+"s"]=Object.create(null)}),e.options._base=e,A(e.options.components,Tn),function(e){e.use=function(e){var t=this._installedPlugins||(this._installedPlugins=[]);if(t.indexOf(e)>-1)return this;var n=k(arguments,1);return n.unshift(this),"function"==typeof e.install?e.install.apply(e,n):"function"==typeof e&&e.apply(null,n),t.push(e),this}}(e),function(e){e.mixin=function(e){return this.options=De(this.options,e),this}}(e),Cn(e),function(e){M.forEach(function(t){e[t]=function(e,n){return n?("component"===t&&s(n)&&(n.name=n.name||e,n=this.options._base.extend(n)),"directive"===t&&"function"==typeof n&&(n={bind:n,update:n}),this.options[t+"s"][e]=n,n):this.options[t+"s"][e]}})}(e)}(wn),Object.defineProperty(wn.prototype,"$isServer",{get:te}),Object.defineProperty(wn.prototype,"$ssrContext",{get:function(){return this.$vnode&&this.$vnode.ssrContext}}),Object.defineProperty(wn,"FunctionalRenderContext",{value:Tt}),wn.version="2.6.10";var En=p("style,class"),Nn=p("input,textarea,option,select,progress"),jn=function(e,t,n){return"value"===n&&Nn(e)&&"button"!==t||"selected"===n&&"option"===e||"checked"===n&&"input"===e||"muted"===n&&"video"===e},Dn=p("contenteditable,draggable,spellcheck"),Ln=p("events,caret,typing,plaintext-only"),Mn=function(e,t){return Hn(t)||"false"===t?"false":"contenteditable"===e&&Ln(t)?t:"true"},In=p("allowfullscreen,async,autofocus,autoplay,checked,compact,controls,declare,default,defaultchecked,defaultmuted,defaultselected,defer,disabled,enabled,formnovalidate,hidden,indeterminate,inert,ismap,itemscope,loop,multiple,muted,nohref,noresize,noshade,novalidate,nowrap,open,pauseonexit,readonly,required,reversed,scoped,seamless,selected,sortable,translate,truespeed,typemustmatch,visible"),Fn="http://www.w3.org/1999/xlink",Pn=function(e){return":"===e.charAt(5)&&"xlink"===e.slice(0,5)},Rn=function(e){return Pn(e)?e.slice(6,e.length):""},Hn=function(e){return null==e||!1===e};function Bn(e){for(var t=e.data,r=e,i=e;n(i.componentInstance);)(i=i.componentInstance._vnode)&&i.data&&(t=Un(i.data,t));for(;n(r=r.parent);)r&&r.data&&(t=Un(t,r.data));return function(e,t){if(n(e)||n(t))return zn(e,Vn(t));return""}(t.staticClass,t.class)}function Un(e,t){return{staticClass:zn(e.staticClass,t.staticClass),class:n(e.class)?[e.class,t.class]:t.class}}function zn(e,t){return e?t?e+" "+t:e:t||""}function Vn(e){return Array.isArray(e)?function(e){for(var t,r="",i=0,o=e.length;i<o;i++)n(t=Vn(e[i]))&&""!==t&&(r&&(r+=" "),r+=t);return r}(e):o(e)?function(e){var t="";for(var n in e)e[n]&&(t&&(t+=" "),t+=n);return t}(e):"string"==typeof e?e:""}var Kn={svg:"http://www.w3.org/2000/svg",math:"http://www.w3.org/1998/Math/MathML"},Jn=p("html,body,base,head,link,meta,style,title,address,article,aside,footer,header,h1,h2,h3,h4,h5,h6,hgroup,nav,section,div,dd,dl,dt,figcaption,figure,picture,hr,img,li,main,ol,p,pre,ul,a,b,abbr,bdi,bdo,br,cite,code,data,dfn,em,i,kbd,mark,q,rp,rt,rtc,ruby,s,samp,small,span,strong,sub,sup,time,u,var,wbr,area,audio,map,track,video,embed,object,param,source,canvas,script,noscript,del,ins,caption,col,colgroup,table,thead,tbody,td,th,tr,button,datalist,fieldset,form,input,label,legend,meter,optgroup,option,output,progress,select,textarea,details,dialog,menu,menuitem,summary,content,element,shadow,template,blockquote,iframe,tfoot"),qn=p("svg,animate,circle,clippath,cursor,defs,desc,ellipse,filter,font-face,foreignObject,g,glyph,image,line,marker,mask,missing-glyph,path,pattern,polygon,polyline,rect,switch,symbol,text,textpath,tspan,use,view",!0),Wn=function(e){return Jn(e)||qn(e)};function Zn(e){return qn(e)?"svg":"math"===e?"math":void 0}var Gn=Object.create(null);var Xn=p("text,number,password,search,email,tel,url");function Yn(e){if("string"==typeof e){var t=document.querySelector(e);return t||document.createElement("div")}return e}var Qn=Object.freeze({createElement:function(e,t){var n=document.createElement(e);return"select"!==e?n:(t.data&&t.data.attrs&&void 0!==t.data.attrs.multiple&&n.setAttribute("multiple","multiple"),n)},createElementNS:function(e,t){return document.createElementNS(Kn[e],t)},createTextNode:function(e){return document.createTextNode(e)},createComment:function(e){return document.createComment(e)},insertBefore:function(e,t,n){e.insertBefore(t,n)},removeChild:function(e,t){e.removeChild(t)},appendChild:function(e,t){e.appendChild(t)},parentNode:function(e){return e.parentNode},nextSibling:function(e){return e.nextSibling},tagName:function(e){return e.tagName},setTextContent:function(e,t){e.textContent=t},setStyleScope:function(e,t){e.setAttribute(t,"")}}),er={create:function(e,t){tr(t)},update:function(e,t){e.data.ref!==t.data.ref&&(tr(e,!0),tr(t))},destroy:function(e){tr(e,!0)}};function tr(e,t){var r=e.data.ref;if(n(r)){var i=e.context,o=e.componentInstance||e.elm,a=i.$refs;t?Array.isArray(a[r])?h(a[r],o):a[r]===o&&(a[r]=void 0):e.data.refInFor?Array.isArray(a[r])?a[r].indexOf(o)<0&&a[r].push(o):a[r]=[o]:a[r]=o}}var nr=new pe("",{},[]),rr=["create","activate","update","remove","destroy"];function ir(e,i){return e.key===i.key&&(e.tag===i.tag&&e.isComment===i.isComment&&n(e.data)===n(i.data)&&function(e,t){if("input"!==e.tag)return!0;var r,i=n(r=e.data)&&n(r=r.attrs)&&r.type,o=n(r=t.data)&&n(r=r.attrs)&&r.type;return i===o||Xn(i)&&Xn(o)}(e,i)||r(e.isAsyncPlaceholder)&&e.asyncFactory===i.asyncFactory&&t(i.asyncFactory.error))}function or(e,t,r){var i,o,a={};for(i=t;i<=r;++i)n(o=e[i].key)&&(a[o]=i);return a}var ar={create:sr,update:sr,destroy:function(e){sr(e,nr)}};function sr(e,t){(e.data.directives||t.data.directives)&&function(e,t){var n,r,i,o=e===nr,a=t===nr,s=ur(e.data.directives,e.context),c=ur(t.data.directives,t.context),u=[],l=[];for(n in c)r=s[n],i=c[n],r?(i.oldValue=r.value,i.oldArg=r.arg,fr(i,"update",t,e),i.def&&i.def.componentUpdated&&l.push(i)):(fr(i,"bind",t,e),i.def&&i.def.inserted&&u.push(i));if(u.length){var f=function(){for(var n=0;n<u.length;n++)fr(u[n],"inserted",t,e)};o?it(t,"insert",f):f()}l.length&&it(t,"postpatch",function(){for(var n=0;n<l.length;n++)fr(l[n],"componentUpdated",t,e)});if(!o)for(n in s)c[n]||fr(s[n],"unbind",e,e,a)}(e,t)}var cr=Object.create(null);function ur(e,t){var n,r,i=Object.create(null);if(!e)return i;for(n=0;n<e.length;n++)(r=e[n]).modifiers||(r.modifiers=cr),i[lr(r)]=r,r.def=Le(t.$options,"directives",r.name);return i}function lr(e){return e.rawName||e.name+"."+Object.keys(e.modifiers||{}).join(".")}function fr(e,t,n,r,i){var o=e.def&&e.def[t];if(o)try{o(n.elm,e,n,r,i)}catch(r){Re(r,n.context,"directive "+e.name+" "+t+" hook")}}var pr=[er,ar];function dr(e,r){var i=r.componentOptions;if(!(n(i)&&!1===i.Ctor.options.inheritAttrs||t(e.data.attrs)&&t(r.data.attrs))){var o,a,s=r.elm,c=e.data.attrs||{},u=r.data.attrs||{};for(o in n(u.__ob__)&&(u=r.data.attrs=A({},u)),u)a=u[o],c[o]!==a&&vr(s,o,a);for(o in(q||Z)&&u.value!==c.value&&vr(s,"value",u.value),c)t(u[o])&&(Pn(o)?s.removeAttributeNS(Fn,Rn(o)):Dn(o)||s.removeAttribute(o))}}function vr(e,t,n){e.tagName.indexOf("-")>-1?hr(e,t,n):In(t)?Hn(n)?e.removeAttribute(t):(n="allowfullscreen"===t&&"EMBED"===e.tagName?"true":t,e.setAttribute(t,n)):Dn(t)?e.setAttribute(t,Mn(t,n)):Pn(t)?Hn(n)?e.removeAttributeNS(Fn,Rn(t)):e.setAttributeNS(Fn,t,n):hr(e,t,n)}function hr(e,t,n){if(Hn(n))e.removeAttribute(t);else{if(q&&!W&&"TEXTAREA"===e.tagName&&"placeholder"===t&&""!==n&&!e.__ieph){var r=function(t){t.stopImmediatePropagation(),e.removeEventListener("input",r)};e.addEventListener("input",r),e.__ieph=!0}e.setAttribute(t,n)}}var mr={create:dr,update:dr};function yr(e,r){var i=r.elm,o=r.data,a=e.data;if(!(t(o.staticClass)&&t(o.class)&&(t(a)||t(a.staticClass)&&t(a.class)))){var s=Bn(r),c=i._transitionClasses;n(c)&&(s=zn(s,Vn(c))),s!==i._prevClass&&(i.setAttribute("class",s),i._prevClass=s)}}var gr,_r,br,$r,wr,Cr,xr={create:yr,update:yr},kr=/[\w).+\-_$\]]/;function Ar(e){var t,n,r,i,o,a=!1,s=!1,c=!1,u=!1,l=0,f=0,p=0,d=0;for(r=0;r<e.length;r++)if(n=t,t=e.charCodeAt(r),a)39===t&&92!==n&&(a=!1);else if(s)34===t&&92!==n&&(s=!1);else if(c)96===t&&92!==n&&(c=!1);else if(u)47===t&&92!==n&&(u=!1);else if(124!==t||124===e.charCodeAt(r+1)||124===e.charCodeAt(r-1)||l||f||p){switch(t){case 34:s=!0;break;case 39:a=!0;break;case 96:c=!0;break;case 40:p++;break;case 41:p--;break;case 91:f++;break;case 93:f--;break;case 123:l++;break;case 125:l--}if(47===t){for(var v=r-1,h=void 0;v>=0&&" "===(h=e.charAt(v));v--);h&&kr.test(h)||(u=!0)}}else void 0===i?(d=r+1,i=e.slice(0,r).trim()):m();function m(){(o||(o=[])).push(e.slice(d,r).trim()),d=r+1}if(void 0===i?i=e.slice(0,r).trim():0!==d&&m(),o)for(r=0;r<o.length;r++)i=Or(i,o[r]);return i}function Or(e,t){var n=t.indexOf("(");if(n<0)return'_f("'+t+'")('+e+")";var r=t.slice(0,n),i=t.slice(n+1);return'_f("'+r+'")('+e+(")"!==i?","+i:i)}function Sr(e,t){console.error("[Vue compiler]: "+e)}function Tr(e,t){return e?e.map(function(e){return e[t]}).filter(function(e){return e}):[]}function Er(e,t,n,r,i){(e.props||(e.props=[])).push(Rr({name:t,value:n,dynamic:i},r)),e.plain=!1}function Nr(e,t,n,r,i){(i?e.dynamicAttrs||(e.dynamicAttrs=[]):e.attrs||(e.attrs=[])).push(Rr({name:t,value:n,dynamic:i},r)),e.plain=!1}function jr(e,t,n,r){e.attrsMap[t]=n,e.attrsList.push(Rr({name:t,value:n},r))}function Dr(e,t,n,r,i,o,a,s){(e.directives||(e.directives=[])).push(Rr({name:t,rawName:n,value:r,arg:i,isDynamicArg:o,modifiers:a},s)),e.plain=!1}function Lr(e,t,n){return n?"_p("+t+',"'+e+'")':e+t}function Mr(t,n,r,i,o,a,s,c){var u;(i=i||e).right?c?n="("+n+")==='click'?'contextmenu':("+n+")":"click"===n&&(n="contextmenu",delete i.right):i.middle&&(c?n="("+n+")==='click'?'mouseup':("+n+")":"click"===n&&(n="mouseup")),i.capture&&(delete i.capture,n=Lr("!",n,c)),i.once&&(delete i.once,n=Lr("~",n,c)),i.passive&&(delete i.passive,n=Lr("&",n,c)),i.native?(delete i.native,u=t.nativeEvents||(t.nativeEvents={})):u=t.events||(t.events={});var l=Rr({value:r.trim(),dynamic:c},s);i!==e&&(l.modifiers=i);var f=u[n];Array.isArray(f)?o?f.unshift(l):f.push(l):u[n]=f?o?[l,f]:[f,l]:l,t.plain=!1}function Ir(e,t,n){var r=Fr(e,":"+t)||Fr(e,"v-bind:"+t);if(null!=r)return Ar(r);if(!1!==n){var i=Fr(e,t);if(null!=i)return JSON.stringify(i)}}function Fr(e,t,n){var r;if(null!=(r=e.attrsMap[t]))for(var i=e.attrsList,o=0,a=i.length;o<a;o++)if(i[o].name===t){i.splice(o,1);break}return n&&delete e.attrsMap[t],r}function Pr(e,t){for(var n=e.attrsList,r=0,i=n.length;r<i;r++){var o=n[r];if(t.test(o.name))return n.splice(r,1),o}}function Rr(e,t){return t&&(null!=t.start&&(e.start=t.start),null!=t.end&&(e.end=t.end)),e}function Hr(e,t,n){var r=n||{},i=r.number,o="$$v";r.trim&&(o="(typeof $$v === 'string'? $$v.trim(): $$v)"),i&&(o="_n("+o+")");var a=Br(t,o);e.model={value:"("+t+")",expression:JSON.stringify(t),callback:"function ($$v) {"+a+"}"}}function Br(e,t){var n=function(e){if(e=e.trim(),gr=e.length,e.indexOf("[")<0||e.lastIndexOf("]")<gr-1)return($r=e.lastIndexOf("."))>-1?{exp:e.slice(0,$r),key:'"'+e.slice($r+1)+'"'}:{exp:e,key:null};_r=e,$r=wr=Cr=0;for(;!zr();)Vr(br=Ur())?Jr(br):91===br&&Kr(br);return{exp:e.slice(0,wr),key:e.slice(wr+1,Cr)}}(e);return null===n.key?e+"="+t:"$set("+n.exp+", "+n.key+", "+t+")"}function Ur(){return _r.charCodeAt(++$r)}function zr(){return $r>=gr}function Vr(e){return 34===e||39===e}function Kr(e){var t=1;for(wr=$r;!zr();)if(Vr(e=Ur()))Jr(e);else if(91===e&&t++,93===e&&t--,0===t){Cr=$r;break}}function Jr(e){for(var t=e;!zr()&&(e=Ur())!==t;);}var qr,Wr="__r",Zr="__c";function Gr(e,t,n){var r=qr;return function i(){null!==t.apply(null,arguments)&&Qr(e,i,n,r)}}var Xr=Ve&&!(X&&Number(X[1])<=53);function Yr(e,t,n,r){if(Xr){var i=an,o=t;t=o._wrapper=function(e){if(e.target===e.currentTarget||e.timeStamp>=i||e.timeStamp<=0||e.target.ownerDocument!==document)return o.apply(this,arguments)}}qr.addEventListener(e,t,Q?{capture:n,passive:r}:n)}function Qr(e,t,n,r){(r||qr).removeEventListener(e,t._wrapper||t,n)}function ei(e,r){if(!t(e.data.on)||!t(r.data.on)){var i=r.data.on||{},o=e.data.on||{};qr=r.elm,function(e){if(n(e[Wr])){var t=q?"change":"input";e[t]=[].concat(e[Wr],e[t]||[]),delete e[Wr]}n(e[Zr])&&(e.change=[].concat(e[Zr],e.change||[]),delete e[Zr])}(i),rt(i,o,Yr,Qr,Gr,r.context),qr=void 0}}var ti,ni={create:ei,update:ei};function ri(e,r){if(!t(e.data.domProps)||!t(r.data.domProps)){var i,o,a=r.elm,s=e.data.domProps||{},c=r.data.domProps||{};for(i in n(c.__ob__)&&(c=r.data.domProps=A({},c)),s)i in c||(a[i]="");for(i in c){if(o=c[i],"textContent"===i||"innerHTML"===i){if(r.children&&(r.children.length=0),o===s[i])continue;1===a.childNodes.length&&a.removeChild(a.childNodes[0])}if("value"===i&&"PROGRESS"!==a.tagName){a._value=o;var u=t(o)?"":String(o);ii(a,u)&&(a.value=u)}else if("innerHTML"===i&&qn(a.tagName)&&t(a.innerHTML)){(ti=ti||document.createElement("div")).innerHTML="<svg>"+o+"</svg>";for(var l=ti.firstChild;a.firstChild;)a.removeChild(a.firstChild);for(;l.firstChild;)a.appendChild(l.firstChild)}else if(o!==s[i])try{a[i]=o}catch(e){}}}}function ii(e,t){return!e.composing&&("OPTION"===e.tagName||function(e,t){var n=!0;try{n=document.activeElement!==e}catch(e){}return n&&e.value!==t}(e,t)||function(e,t){var r=e.value,i=e._vModifiers;if(n(i)){if(i.number)return f(r)!==f(t);if(i.trim)return r.trim()!==t.trim()}return r!==t}(e,t))}var oi={create:ri,update:ri},ai=g(function(e){var t={},n=/:(.+)/;return e.split(/;(?![^(]*\))/g).forEach(function(e){if(e){var r=e.split(n);r.length>1&&(t[r[0].trim()]=r[1].trim())}}),t});function si(e){var t=ci(e.style);return e.staticStyle?A(e.staticStyle,t):t}function ci(e){return Array.isArray(e)?O(e):"string"==typeof e?ai(e):e}var ui,li=/^--/,fi=/\s*!important$/,pi=function(e,t,n){if(li.test(t))e.style.setProperty(t,n);else if(fi.test(n))e.style.setProperty(C(t),n.replace(fi,""),"important");else{var r=vi(t);if(Array.isArray(n))for(var i=0,o=n.length;i<o;i++)e.style[r]=n[i];else e.style[r]=n}},di=["Webkit","Moz","ms"],vi=g(function(e){if(ui=ui||document.createElement("div").style,"filter"!==(e=b(e))&&e in ui)return e;for(var t=e.charAt(0).toUpperCase()+e.slice(1),n=0;n<di.length;n++){var r=di[n]+t;if(r in ui)return r}});function hi(e,r){var i=r.data,o=e.data;if(!(t(i.staticStyle)&&t(i.style)&&t(o.staticStyle)&&t(o.style))){var a,s,c=r.elm,u=o.staticStyle,l=o.normalizedStyle||o.style||{},f=u||l,p=ci(r.data.style)||{};r.data.normalizedStyle=n(p.__ob__)?A({},p):p;var d=function(e,t){var n,r={};if(t)for(var i=e;i.componentInstance;)(i=i.componentInstance._vnode)&&i.data&&(n=si(i.data))&&A(r,n);(n=si(e.data))&&A(r,n);for(var o=e;o=o.parent;)o.data&&(n=si(o.data))&&A(r,n);return r}(r,!0);for(s in f)t(d[s])&&pi(c,s,"");for(s in d)(a=d[s])!==f[s]&&pi(c,s,null==a?"":a)}}var mi={create:hi,update:hi},yi=/\s+/;function gi(e,t){if(t&&(t=t.trim()))if(e.classList)t.indexOf(" ")>-1?t.split(yi).forEach(function(t){return e.classList.add(t)}):e.classList.add(t);else{var n=" "+(e.getAttribute("class")||"")+" ";n.indexOf(" "+t+" ")<0&&e.setAttribute("class",(n+t).trim())}}function _i(e,t){if(t&&(t=t.trim()))if(e.classList)t.indexOf(" ")>-1?t.split(yi).forEach(function(t){return e.classList.remove(t)}):e.classList.remove(t),e.classList.length||e.removeAttribute("class");else{for(var n=" "+(e.getAttribute("class")||"")+" ",r=" "+t+" ";n.indexOf(r)>=0;)n=n.replace(r," ");(n=n.trim())?e.setAttribute("class",n):e.removeAttribute("class")}}function bi(e){if(e){if("object"==typeof e){var t={};return!1!==e.css&&A(t,$i(e.name||"v")),A(t,e),t}return"string"==typeof e?$i(e):void 0}}var $i=g(function(e){return{enterClass:e+"-enter",enterToClass:e+"-enter-to",enterActiveClass:e+"-enter-active",leaveClass:e+"-leave",leaveToClass:e+"-leave-to",leaveActiveClass:e+"-leave-active"}}),wi=z&&!W,Ci="transition",xi="animation",ki="transition",Ai="transitionend",Oi="animation",Si="animationend";wi&&(void 0===window.ontransitionend&&void 0!==window.onwebkittransitionend&&(ki="WebkitTransition",Ai="webkitTransitionEnd"),void 0===window.onanimationend&&void 0!==window.onwebkitanimationend&&(Oi="WebkitAnimation",Si="webkitAnimationEnd"));var Ti=z?window.requestAnimationFrame?window.requestAnimationFrame.bind(window):setTimeout:function(e){return e()};function Ei(e){Ti(function(){Ti(e)})}function Ni(e,t){var n=e._transitionClasses||(e._transitionClasses=[]);n.indexOf(t)<0&&(n.push(t),gi(e,t))}function ji(e,t){e._transitionClasses&&h(e._transitionClasses,t),_i(e,t)}function Di(e,t,n){var r=Mi(e,t),i=r.type,o=r.timeout,a=r.propCount;if(!i)return n();var s=i===Ci?Ai:Si,c=0,u=function(){e.removeEventListener(s,l),n()},l=function(t){t.target===e&&++c>=a&&u()};setTimeout(function(){c<a&&u()},o+1),e.addEventListener(s,l)}var Li=/\b(transform|all)(,|$)/;function Mi(e,t){var n,r=window.getComputedStyle(e),i=(r[ki+"Delay"]||"").split(", "),o=(r[ki+"Duration"]||"").split(", "),a=Ii(i,o),s=(r[Oi+"Delay"]||"").split(", "),c=(r[Oi+"Duration"]||"").split(", "),u=Ii(s,c),l=0,f=0;return t===Ci?a>0&&(n=Ci,l=a,f=o.length):t===xi?u>0&&(n=xi,l=u,f=c.length):f=(n=(l=Math.max(a,u))>0?a>u?Ci:xi:null)?n===Ci?o.length:c.length:0,{type:n,timeout:l,propCount:f,hasTransform:n===Ci&&Li.test(r[ki+"Property"])}}function Ii(e,t){for(;e.length<t.length;)e=e.concat(e);return Math.max.apply(null,t.map(function(t,n){return Fi(t)+Fi(e[n])}))}function Fi(e){return 1e3*Number(e.slice(0,-1).replace(",","."))}function Pi(e,r){var i=e.elm;n(i._leaveCb)&&(i._leaveCb.cancelled=!0,i._leaveCb());var a=bi(e.data.transition);if(!t(a)&&!n(i._enterCb)&&1===i.nodeType){for(var s=a.css,c=a.type,u=a.enterClass,l=a.enterToClass,p=a.enterActiveClass,d=a.appearClass,v=a.appearToClass,h=a.appearActiveClass,m=a.beforeEnter,y=a.enter,g=a.afterEnter,_=a.enterCancelled,b=a.beforeAppear,$=a.appear,w=a.afterAppear,C=a.appearCancelled,x=a.duration,k=Wt,A=Wt.$vnode;A&&A.parent;)k=A.context,A=A.parent;var O=!k._isMounted||!e.isRootInsert;if(!O||$||""===$){var S=O&&d?d:u,T=O&&h?h:p,E=O&&v?v:l,N=O&&b||m,j=O&&"function"==typeof $?$:y,L=O&&w||g,M=O&&C||_,I=f(o(x)?x.enter:x),F=!1!==s&&!W,P=Bi(j),R=i._enterCb=D(function(){F&&(ji(i,E),ji(i,T)),R.cancelled?(F&&ji(i,S),M&&M(i)):L&&L(i),i._enterCb=null});e.data.show||it(e,"insert",function(){var t=i.parentNode,n=t&&t._pending&&t._pending[e.key];n&&n.tag===e.tag&&n.elm._leaveCb&&n.elm._leaveCb(),j&&j(i,R)}),N&&N(i),F&&(Ni(i,S),Ni(i,T),Ei(function(){ji(i,S),R.cancelled||(Ni(i,E),P||(Hi(I)?setTimeout(R,I):Di(i,c,R)))})),e.data.show&&(r&&r(),j&&j(i,R)),F||P||R()}}}function Ri(e,r){var i=e.elm;n(i._enterCb)&&(i._enterCb.cancelled=!0,i._enterCb());var a=bi(e.data.transition);if(t(a)||1!==i.nodeType)return r();if(!n(i._leaveCb)){var s=a.css,c=a.type,u=a.leaveClass,l=a.leaveToClass,p=a.leaveActiveClass,d=a.beforeLeave,v=a.leave,h=a.afterLeave,m=a.leaveCancelled,y=a.delayLeave,g=a.duration,_=!1!==s&&!W,b=Bi(v),$=f(o(g)?g.leave:g),w=i._leaveCb=D(function(){i.parentNode&&i.parentNode._pending&&(i.parentNode._pending[e.key]=null),_&&(ji(i,l),ji(i,p)),w.cancelled?(_&&ji(i,u),m&&m(i)):(r(),h&&h(i)),i._leaveCb=null});y?y(C):C()}function C(){w.cancelled||(!e.data.show&&i.parentNode&&((i.parentNode._pending||(i.parentNode._pending={}))[e.key]=e),d&&d(i),_&&(Ni(i,u),Ni(i,p),Ei(function(){ji(i,u),w.cancelled||(Ni(i,l),b||(Hi($)?setTimeout(w,$):Di(i,c,w)))})),v&&v(i,w),_||b||w())}}function Hi(e){return"number"==typeof e&&!isNaN(e)}function Bi(e){if(t(e))return!1;var r=e.fns;return n(r)?Bi(Array.isArray(r)?r[0]:r):(e._length||e.length)>1}function Ui(e,t){!0!==t.data.show&&Pi(t)}var zi=function(e){var o,a,s={},c=e.modules,u=e.nodeOps;for(o=0;o<rr.length;++o)for(s[rr[o]]=[],a=0;a<c.length;++a)n(c[a][rr[o]])&&s[rr[o]].push(c[a][rr[o]]);function l(e){var t=u.parentNode(e);n(t)&&u.removeChild(t,e)}function f(e,t,i,o,a,c,l){if(n(e.elm)&&n(c)&&(e=c[l]=me(e)),e.isRootInsert=!a,!function(e,t,i,o){var a=e.data;if(n(a)){var c=n(e.componentInstance)&&a.keepAlive;if(n(a=a.hook)&&n(a=a.init)&&a(e,!1),n(e.componentInstance))return d(e,t),v(i,e.elm,o),r(c)&&function(e,t,r,i){for(var o,a=e;a.componentInstance;)if(a=a.componentInstance._vnode,n(o=a.data)&&n(o=o.transition)){for(o=0;o<s.activate.length;++o)s.activate[o](nr,a);t.push(a);break}v(r,e.elm,i)}(e,t,i,o),!0}}(e,t,i,o)){var f=e.data,p=e.children,m=e.tag;n(m)?(e.elm=e.ns?u.createElementNS(e.ns,m):u.createElement(m,e),g(e),h(e,p,t),n(f)&&y(e,t),v(i,e.elm,o)):r(e.isComment)?(e.elm=u.createComment(e.text),v(i,e.elm,o)):(e.elm=u.createTextNode(e.text),v(i,e.elm,o))}}function d(e,t){n(e.data.pendingInsert)&&(t.push.apply(t,e.data.pendingInsert),e.data.pendingInsert=null),e.elm=e.componentInstance.$el,m(e)?(y(e,t),g(e)):(tr(e),t.push(e))}function v(e,t,r){n(e)&&(n(r)?u.parentNode(r)===e&&u.insertBefore(e,t,r):u.appendChild(e,t))}function h(e,t,n){if(Array.isArray(t))for(var r=0;r<t.length;++r)f(t[r],n,e.elm,null,!0,t,r);else i(e.text)&&u.appendChild(e.elm,u.createTextNode(String(e.text)))}function m(e){for(;e.componentInstance;)e=e.componentInstance._vnode;return n(e.tag)}function y(e,t){for(var r=0;r<s.create.length;++r)s.create[r](nr,e);n(o=e.data.hook)&&(n(o.create)&&o.create(nr,e),n(o.insert)&&t.push(e))}function g(e){var t;if(n(t=e.fnScopeId))u.setStyleScope(e.elm,t);else for(var r=e;r;)n(t=r.context)&&n(t=t.$options._scopeId)&&u.setStyleScope(e.elm,t),r=r.parent;n(t=Wt)&&t!==e.context&&t!==e.fnContext&&n(t=t.$options._scopeId)&&u.setStyleScope(e.elm,t)}function _(e,t,n,r,i,o){for(;r<=i;++r)f(n[r],o,e,t,!1,n,r)}function b(e){var t,r,i=e.data;if(n(i))for(n(t=i.hook)&&n(t=t.destroy)&&t(e),t=0;t<s.destroy.length;++t)s.destroy[t](e);if(n(t=e.children))for(r=0;r<e.children.length;++r)b(e.children[r])}function $(e,t,r,i){for(;r<=i;++r){var o=t[r];n(o)&&(n(o.tag)?(w(o),b(o)):l(o.elm))}}function w(e,t){if(n(t)||n(e.data)){var r,i=s.remove.length+1;for(n(t)?t.listeners+=i:t=function(e,t){function n(){0==--n.listeners&&l(e)}return n.listeners=t,n}(e.elm,i),n(r=e.componentInstance)&&n(r=r._vnode)&&n(r.data)&&w(r,t),r=0;r<s.remove.length;++r)s.remove[r](e,t);n(r=e.data.hook)&&n(r=r.remove)?r(e,t):t()}else l(e.elm)}function C(e,t,r,i){for(var o=r;o<i;o++){var a=t[o];if(n(a)&&ir(e,a))return o}}function x(e,i,o,a,c,l){if(e!==i){n(i.elm)&&n(a)&&(i=a[c]=me(i));var p=i.elm=e.elm;if(r(e.isAsyncPlaceholder))n(i.asyncFactory.resolved)?O(e.elm,i,o):i.isAsyncPlaceholder=!0;else if(r(i.isStatic)&&r(e.isStatic)&&i.key===e.key&&(r(i.isCloned)||r(i.isOnce)))i.componentInstance=e.componentInstance;else{var d,v=i.data;n(v)&&n(d=v.hook)&&n(d=d.prepatch)&&d(e,i);var h=e.children,y=i.children;if(n(v)&&m(i)){for(d=0;d<s.update.length;++d)s.update[d](e,i);n(d=v.hook)&&n(d=d.update)&&d(e,i)}t(i.text)?n(h)&&n(y)?h!==y&&function(e,r,i,o,a){for(var s,c,l,p=0,d=0,v=r.length-1,h=r[0],m=r[v],y=i.length-1,g=i[0],b=i[y],w=!a;p<=v&&d<=y;)t(h)?h=r[++p]:t(m)?m=r[--v]:ir(h,g)?(x(h,g,o,i,d),h=r[++p],g=i[++d]):ir(m,b)?(x(m,b,o,i,y),m=r[--v],b=i[--y]):ir(h,b)?(x(h,b,o,i,y),w&&u.insertBefore(e,h.elm,u.nextSibling(m.elm)),h=r[++p],b=i[--y]):ir(m,g)?(x(m,g,o,i,d),w&&u.insertBefore(e,m.elm,h.elm),m=r[--v],g=i[++d]):(t(s)&&(s=or(r,p,v)),t(c=n(g.key)?s[g.key]:C(g,r,p,v))?f(g,o,e,h.elm,!1,i,d):ir(l=r[c],g)?(x(l,g,o,i,d),r[c]=void 0,w&&u.insertBefore(e,l.elm,h.elm)):f(g,o,e,h.elm,!1,i,d),g=i[++d]);p>v?_(e,t(i[y+1])?null:i[y+1].elm,i,d,y,o):d>y&&$(0,r,p,v)}(p,h,y,o,l):n(y)?(n(e.text)&&u.setTextContent(p,""),_(p,null,y,0,y.length-1,o)):n(h)?$(0,h,0,h.length-1):n(e.text)&&u.setTextContent(p,""):e.text!==i.text&&u.setTextContent(p,i.text),n(v)&&n(d=v.hook)&&n(d=d.postpatch)&&d(e,i)}}}function k(e,t,i){if(r(i)&&n(e.parent))e.parent.data.pendingInsert=t;else for(var o=0;o<t.length;++o)t[o].data.hook.insert(t[o])}var A=p("attrs,class,staticClass,staticStyle,key");function O(e,t,i,o){var a,s=t.tag,c=t.data,u=t.children;if(o=o||c&&c.pre,t.elm=e,r(t.isComment)&&n(t.asyncFactory))return t.isAsyncPlaceholder=!0,!0;if(n(c)&&(n(a=c.hook)&&n(a=a.init)&&a(t,!0),n(a=t.componentInstance)))return d(t,i),!0;if(n(s)){if(n(u))if(e.hasChildNodes())if(n(a=c)&&n(a=a.domProps)&&n(a=a.innerHTML)){if(a!==e.innerHTML)return!1}else{for(var l=!0,f=e.firstChild,p=0;p<u.length;p++){if(!f||!O(f,u[p],i,o)){l=!1;break}f=f.nextSibling}if(!l||f)return!1}else h(t,u,i);if(n(c)){var v=!1;for(var m in c)if(!A(m)){v=!0,y(t,i);break}!v&&c.class&&et(c.class)}}else e.data!==t.text&&(e.data=t.text);return!0}return function(e,i,o,a){if(!t(i)){var c,l=!1,p=[];if(t(e))l=!0,f(i,p);else{var d=n(e.nodeType);if(!d&&ir(e,i))x(e,i,p,null,null,a);else{if(d){if(1===e.nodeType&&e.hasAttribute(L)&&(e.removeAttribute(L),o=!0),r(o)&&O(e,i,p))return k(i,p,!0),e;c=e,e=new pe(u.tagName(c).toLowerCase(),{},[],void 0,c)}var v=e.elm,h=u.parentNode(v);if(f(i,p,v._leaveCb?null:h,u.nextSibling(v)),n(i.parent))for(var y=i.parent,g=m(i);y;){for(var _=0;_<s.destroy.length;++_)s.destroy[_](y);if(y.elm=i.elm,g){for(var w=0;w<s.create.length;++w)s.create[w](nr,y);var C=y.data.hook.insert;if(C.merged)for(var A=1;A<C.fns.length;A++)C.fns[A]()}else tr(y);y=y.parent}n(h)?$(0,[e],0,0):n(e.tag)&&b(e)}}return k(i,p,l),i.elm}n(e)&&b(e)}}({nodeOps:Qn,modules:[mr,xr,ni,oi,mi,z?{create:Ui,activate:Ui,remove:function(e,t){!0!==e.data.show?Ri(e,t):t()}}:{}].concat(pr)});W&&document.addEventListener("selectionchange",function(){var e=document.activeElement;e&&e.vmodel&&Xi(e,"input")});var Vi={inserted:function(e,t,n,r){"select"===n.tag?(r.elm&&!r.elm._vOptions?it(n,"postpatch",function(){Vi.componentUpdated(e,t,n)}):Ki(e,t,n.context),e._vOptions=[].map.call(e.options,Wi)):("textarea"===n.tag||Xn(e.type))&&(e._vModifiers=t.modifiers,t.modifiers.lazy||(e.addEventListener("compositionstart",Zi),e.addEventListener("compositionend",Gi),e.addEventListener("change",Gi),W&&(e.vmodel=!0)))},componentUpdated:function(e,t,n){if("select"===n.tag){Ki(e,t,n.context);var r=e._vOptions,i=e._vOptions=[].map.call(e.options,Wi);if(i.some(function(e,t){return!N(e,r[t])}))(e.multiple?t.value.some(function(e){return qi(e,i)}):t.value!==t.oldValue&&qi(t.value,i))&&Xi(e,"change")}}};function Ki(e,t,n){Ji(e,t,n),(q||Z)&&setTimeout(function(){Ji(e,t,n)},0)}function Ji(e,t,n){var r=t.value,i=e.multiple;if(!i||Array.isArray(r)){for(var o,a,s=0,c=e.options.length;s<c;s++)if(a=e.options[s],i)o=j(r,Wi(a))>-1,a.selected!==o&&(a.selected=o);else if(N(Wi(a),r))return void(e.selectedIndex!==s&&(e.selectedIndex=s));i||(e.selectedIndex=-1)}}function qi(e,t){return t.every(function(t){return!N(t,e)})}function Wi(e){return"_value"in e?e._value:e.value}function Zi(e){e.target.composing=!0}function Gi(e){e.target.composing&&(e.target.composing=!1,Xi(e.target,"input"))}function Xi(e,t){var n=document.createEvent("HTMLEvents");n.initEvent(t,!0,!0),e.dispatchEvent(n)}function Yi(e){return!e.componentInstance||e.data&&e.data.transition?e:Yi(e.componentInstance._vnode)}var Qi={model:Vi,show:{bind:function(e,t,n){var r=t.value,i=(n=Yi(n)).data&&n.data.transition,o=e.__vOriginalDisplay="none"===e.style.display?"":e.style.display;r&&i?(n.data.show=!0,Pi(n,function(){e.style.display=o})):e.style.display=r?o:"none"},update:function(e,t,n){var r=t.value;!r!=!t.oldValue&&((n=Yi(n)).data&&n.data.transition?(n.data.show=!0,r?Pi(n,function(){e.style.display=e.__vOriginalDisplay}):Ri(n,function(){e.style.display="none"})):e.style.display=r?e.__vOriginalDisplay:"none")},unbind:function(e,t,n,r,i){i||(e.style.display=e.__vOriginalDisplay)}}},eo={name:String,appear:Boolean,css:Boolean,mode:String,type:String,enterClass:String,leaveClass:String,enterToClass:String,leaveToClass:String,enterActiveClass:String,leaveActiveClass:String,appearClass:String,appearActiveClass:String,appearToClass:String,duration:[Number,String,Object]};function to(e){var t=e&&e.componentOptions;return t&&t.Ctor.options.abstract?to(zt(t.children)):e}function no(e){var t={},n=e.$options;for(var r in n.propsData)t[r]=e[r];var i=n._parentListeners;for(var o in i)t[b(o)]=i[o];return t}function ro(e,t){if(/\d-keep-alive$/.test(t.tag))return e("keep-alive",{props:t.componentOptions.propsData})}var io=function(e){return e.tag||Ut(e)},oo=function(e){return"show"===e.name},ao={name:"transition",props:eo,abstract:!0,render:function(e){var t=this,n=this.$slots.default;if(n&&(n=n.filter(io)).length){var r=this.mode,o=n[0];if(function(e){for(;e=e.parent;)if(e.data.transition)return!0}(this.$vnode))return o;var a=to(o);if(!a)return o;if(this._leaving)return ro(e,o);var s="__transition-"+this._uid+"-";a.key=null==a.key?a.isComment?s+"comment":s+a.tag:i(a.key)?0===String(a.key).indexOf(s)?a.key:s+a.key:a.key;var c=(a.data||(a.data={})).transition=no(this),u=this._vnode,l=to(u);if(a.data.directives&&a.data.directives.some(oo)&&(a.data.show=!0),l&&l.data&&!function(e,t){return t.key===e.key&&t.tag===e.tag}(a,l)&&!Ut(l)&&(!l.componentInstance||!l.componentInstance._vnode.isComment)){var f=l.data.transition=A({},c);if("out-in"===r)return this._leaving=!0,it(f,"afterLeave",function(){t._leaving=!1,t.$forceUpdate()}),ro(e,o);if("in-out"===r){if(Ut(a))return u;var p,d=function(){p()};it(c,"afterEnter",d),it(c,"enterCancelled",d),it(f,"delayLeave",function(e){p=e})}}return o}}},so=A({tag:String,moveClass:String},eo);function co(e){e.elm._moveCb&&e.elm._moveCb(),e.elm._enterCb&&e.elm._enterCb()}function uo(e){e.data.newPos=e.elm.getBoundingClientRect()}function lo(e){var t=e.data.pos,n=e.data.newPos,r=t.left-n.left,i=t.top-n.top;if(r||i){e.data.moved=!0;var o=e.elm.style;o.transform=o.WebkitTransform="translate("+r+"px,"+i+"px)",o.transitionDuration="0s"}}delete so.mode;var fo={Transition:ao,TransitionGroup:{props:so,beforeMount:function(){var e=this,t=this._update;this._update=function(n,r){var i=Zt(e);e.__patch__(e._vnode,e.kept,!1,!0),e._vnode=e.kept,i(),t.call(e,n,r)}},render:function(e){for(var t=this.tag||this.$vnode.data.tag||"span",n=Object.create(null),r=this.prevChildren=this.children,i=this.$slots.default||[],o=this.children=[],a=no(this),s=0;s<i.length;s++){var c=i[s];c.tag&&null!=c.key&&0!==String(c.key).indexOf("__vlist")&&(o.push(c),n[c.key]=c,(c.data||(c.data={})).transition=a)}if(r){for(var u=[],l=[],f=0;f<r.length;f++){var p=r[f];p.data.transition=a,p.data.pos=p.elm.getBoundingClientRect(),n[p.key]?u.push(p):l.push(p)}this.kept=e(t,null,u),this.removed=l}return e(t,null,o)},updated:function(){var e=this.prevChildren,t=this.moveClass||(this.name||"v")+"-move";e.length&&this.hasMove(e[0].elm,t)&&(e.forEach(co),e.forEach(uo),e.forEach(lo),this._reflow=document.body.offsetHeight,e.forEach(function(e){if(e.data.moved){var n=e.elm,r=n.style;Ni(n,t),r.transform=r.WebkitTransform=r.transitionDuration="",n.addEventListener(Ai,n._moveCb=function e(r){r&&r.target!==n||r&&!/transform$/.test(r.propertyName)||(n.removeEventListener(Ai,e),n._moveCb=null,ji(n,t))})}}))},methods:{hasMove:function(e,t){if(!wi)return!1;if(this._hasMove)return this._hasMove;var n=e.cloneNode();e._transitionClasses&&e._transitionClasses.forEach(function(e){_i(n,e)}),gi(n,t),n.style.display="none",this.$el.appendChild(n);var r=Mi(n);return this.$el.removeChild(n),this._hasMove=r.hasTransform}}}};wn.config.mustUseProp=jn,wn.config.isReservedTag=Wn,wn.config.isReservedAttr=En,wn.config.getTagNamespace=Zn,wn.config.isUnknownElement=function(e){if(!z)return!0;if(Wn(e))return!1;if(e=e.toLowerCase(),null!=Gn[e])return Gn[e];var t=document.createElement(e);return e.indexOf("-")>-1?Gn[e]=t.constructor===window.HTMLUnknownElement||t.constructor===window.HTMLElement:Gn[e]=/HTMLUnknownElement/.test(t.toString())},A(wn.options.directives,Qi),A(wn.options.components,fo),wn.prototype.__patch__=z?zi:S,wn.prototype.$mount=function(e,t){return function(e,t,n){var r;return e.$el=t,e.$options.render||(e.$options.render=ve),Yt(e,"beforeMount"),r=function(){e._update(e._render(),n)},new fn(e,r,S,{before:function(){e._isMounted&&!e._isDestroyed&&Yt(e,"beforeUpdate")}},!0),n=!1,null==e.$vnode&&(e._isMounted=!0,Yt(e,"mounted")),e}(this,e=e&&z?Yn(e):void 0,t)},z&&setTimeout(function(){F.devtools&&ne&&ne.emit("init",wn)},0);var po=/\{\{((?:.|\r?\n)+?)\}\}/g,vo=/[-.*+?^${}()|[\]\/\\]/g,ho=g(function(e){var t=e[0].replace(vo,"\\$&"),n=e[1].replace(vo,"\\$&");return new RegExp(t+"((?:.|\\n)+?)"+n,"g")});var mo={staticKeys:["staticClass"],transformNode:function(e,t){t.warn;var n=Fr(e,"class");n&&(e.staticClass=JSON.stringify(n));var r=Ir(e,"class",!1);r&&(e.classBinding=r)},genData:function(e){var t="";return e.staticClass&&(t+="staticClass:"+e.staticClass+","),e.classBinding&&(t+="class:"+e.classBinding+","),t}};var yo,go={staticKeys:["staticStyle"],transformNode:function(e,t){t.warn;var n=Fr(e,"style");n&&(e.staticStyle=JSON.stringify(ai(n)));var r=Ir(e,"style",!1);r&&(e.styleBinding=r)},genData:function(e){var t="";return e.staticStyle&&(t+="staticStyle:"+e.staticStyle+","),e.styleBinding&&(t+="style:("+e.styleBinding+"),"),t}},_o=function(e){return(yo=yo||document.createElement("div")).innerHTML=e,yo.textContent},bo=p("area,base,br,col,embed,frame,hr,img,input,isindex,keygen,link,meta,param,source,track,wbr"),$o=p("colgroup,dd,dt,li,options,p,td,tfoot,th,thead,tr,source"),wo=p("address,article,aside,base,blockquote,body,caption,col,colgroup,dd,details,dialog,div,dl,dt,fieldset,figcaption,figure,footer,form,h1,h2,h3,h4,h5,h6,head,header,hgroup,hr,html,legend,li,menuitem,meta,optgroup,option,param,rp,rt,source,style,summary,tbody,td,tfoot,th,thead,title,tr,track"),Co=/^\s*([^\s"'<>\/=]+)(?:\s*(=)\s*(?:"([^"]*)"+|'([^']*)'+|([^\s"'=<>`]+)))?/,xo=/^\s*((?:v-[\w-]+:|@|:|#)\[[^=]+\][^\s"'<>\/=]*)(?:\s*(=)\s*(?:"([^"]*)"+|'([^']*)'+|([^\s"'=<>`]+)))?/,ko="[a-zA-Z_][\\-\\.0-9_a-zA-Z"+P.source+"]*",Ao="((?:"+ko+"\\:)?"+ko+")",Oo=new RegExp("^<"+Ao),So=/^\s*(\/?)>/,To=new RegExp("^<\\/"+Ao+"[^>]*>"),Eo=/^<!DOCTYPE [^>]+>/i,No=/^<!\--/,jo=/^<!\[/,Do=p("script,style,textarea",!0),Lo={},Mo={"&lt;":"<","&gt;":">","&quot;":'"',"&amp;":"&","&#10;":"\n","&#9;":"\t","&#39;":"'"},Io=/&(?:lt|gt|quot|amp|#39);/g,Fo=/&(?:lt|gt|quot|amp|#39|#10|#9);/g,Po=p("pre,textarea",!0),Ro=function(e,t){return e&&Po(e)&&"\n"===t[0]};function Ho(e,t){var n=t?Fo:Io;return e.replace(n,function(e){return Mo[e]})}var Bo,Uo,zo,Vo,Ko,Jo,qo,Wo,Zo=/^@|^v-on:/,Go=/^v-|^@|^:/,Xo=/([\s\S]*?)\s+(?:in|of)\s+([\s\S]*)/,Yo=/,([^,\}\]]*)(?:,([^,\}\]]*))?$/,Qo=/^\(|\)$/g,ea=/^\[.*\]$/,ta=/:(.*)$/,na=/^:|^\.|^v-bind:/,ra=/\.[^.\]]+(?=[^\]]*$)/g,ia=/^v-slot(:|$)|^#/,oa=/[\r\n]/,aa=/\s+/g,sa=g(_o),ca="_empty_";function ua(e,t,n){return{type:1,tag:e,attrsList:t,attrsMap:ma(t),rawAttrsMap:{},parent:n,children:[]}}function la(e,t){Bo=t.warn||Sr,Jo=t.isPreTag||T,qo=t.mustUseProp||T,Wo=t.getTagNamespace||T;t.isReservedTag;zo=Tr(t.modules,"transformNode"),Vo=Tr(t.modules,"preTransformNode"),Ko=Tr(t.modules,"postTransformNode"),Uo=t.delimiters;var n,r,i=[],o=!1!==t.preserveWhitespace,a=t.whitespace,s=!1,c=!1;function u(e){if(l(e),s||e.processed||(e=fa(e,t)),i.length||e===n||n.if&&(e.elseif||e.else)&&da(n,{exp:e.elseif,block:e}),r&&!e.forbidden)if(e.elseif||e.else)a=e,(u=function(e){var t=e.length;for(;t--;){if(1===e[t].type)return e[t];e.pop()}}(r.children))&&u.if&&da(u,{exp:a.elseif,block:a});else{if(e.slotScope){var o=e.slotTarget||'"default"';(r.scopedSlots||(r.scopedSlots={}))[o]=e}r.children.push(e),e.parent=r}var a,u;e.children=e.children.filter(function(e){return!e.slotScope}),l(e),e.pre&&(s=!1),Jo(e.tag)&&(c=!1);for(var f=0;f<Ko.length;f++)Ko[f](e,t)}function l(e){if(!c)for(var t;(t=e.children[e.children.length-1])&&3===t.type&&" "===t.text;)e.children.pop()}return function(e,t){for(var n,r,i=[],o=t.expectHTML,a=t.isUnaryTag||T,s=t.canBeLeftOpenTag||T,c=0;e;){if(n=e,r&&Do(r)){var u=0,l=r.toLowerCase(),f=Lo[l]||(Lo[l]=new RegExp("([\\s\\S]*?)(</"+l+"[^>]*>)","i")),p=e.replace(f,function(e,n,r){return u=r.length,Do(l)||"noscript"===l||(n=n.replace(/<!\--([\s\S]*?)-->/g,"$1").replace(/<!\[CDATA\[([\s\S]*?)]]>/g,"$1")),Ro(l,n)&&(n=n.slice(1)),t.chars&&t.chars(n),""});c+=e.length-p.length,e=p,A(l,c-u,c)}else{var d=e.indexOf("<");if(0===d){if(No.test(e)){var v=e.indexOf("--\x3e");if(v>=0){t.shouldKeepComment&&t.comment(e.substring(4,v),c,c+v+3),C(v+3);continue}}if(jo.test(e)){var h=e.indexOf("]>");if(h>=0){C(h+2);continue}}var m=e.match(Eo);if(m){C(m[0].length);continue}var y=e.match(To);if(y){var g=c;C(y[0].length),A(y[1],g,c);continue}var _=x();if(_){k(_),Ro(_.tagName,e)&&C(1);continue}}var b=void 0,$=void 0,w=void 0;if(d>=0){for($=e.slice(d);!(To.test($)||Oo.test($)||No.test($)||jo.test($)||(w=$.indexOf("<",1))<0);)d+=w,$=e.slice(d);b=e.substring(0,d)}d<0&&(b=e),b&&C(b.length),t.chars&&b&&t.chars(b,c-b.length,c)}if(e===n){t.chars&&t.chars(e);break}}function C(t){c+=t,e=e.substring(t)}function x(){var t=e.match(Oo);if(t){var n,r,i={tagName:t[1],attrs:[],start:c};for(C(t[0].length);!(n=e.match(So))&&(r=e.match(xo)||e.match(Co));)r.start=c,C(r[0].length),r.end=c,i.attrs.push(r);if(n)return i.unarySlash=n[1],C(n[0].length),i.end=c,i}}function k(e){var n=e.tagName,c=e.unarySlash;o&&("p"===r&&wo(n)&&A(r),s(n)&&r===n&&A(n));for(var u=a(n)||!!c,l=e.attrs.length,f=new Array(l),p=0;p<l;p++){var d=e.attrs[p],v=d[3]||d[4]||d[5]||"",h="a"===n&&"href"===d[1]?t.shouldDecodeNewlinesForHref:t.shouldDecodeNewlines;f[p]={name:d[1],value:Ho(v,h)}}u||(i.push({tag:n,lowerCasedTag:n.toLowerCase(),attrs:f,start:e.start,end:e.end}),r=n),t.start&&t.start(n,f,u,e.start,e.end)}function A(e,n,o){var a,s;if(null==n&&(n=c),null==o&&(o=c),e)for(s=e.toLowerCase(),a=i.length-1;a>=0&&i[a].lowerCasedTag!==s;a--);else a=0;if(a>=0){for(var u=i.length-1;u>=a;u--)t.end&&t.end(i[u].tag,n,o);i.length=a,r=a&&i[a-1].tag}else"br"===s?t.start&&t.start(e,[],!0,n,o):"p"===s&&(t.start&&t.start(e,[],!1,n,o),t.end&&t.end(e,n,o))}A()}(e,{warn:Bo,expectHTML:t.expectHTML,isUnaryTag:t.isUnaryTag,canBeLeftOpenTag:t.canBeLeftOpenTag,shouldDecodeNewlines:t.shouldDecodeNewlines,shouldDecodeNewlinesForHref:t.shouldDecodeNewlinesForHref,shouldKeepComment:t.comments,outputSourceRange:t.outputSourceRange,start:function(e,o,a,l,f){var p=r&&r.ns||Wo(e);q&&"svg"===p&&(o=function(e){for(var t=[],n=0;n<e.length;n++){var r=e[n];ya.test(r.name)||(r.name=r.name.replace(ga,""),t.push(r))}return t}(o));var d,v=ua(e,o,r);p&&(v.ns=p),"style"!==(d=v).tag&&("script"!==d.tag||d.attrsMap.type&&"text/javascript"!==d.attrsMap.type)||te()||(v.forbidden=!0);for(var h=0;h<Vo.length;h++)v=Vo[h](v,t)||v;s||(!function(e){null!=Fr(e,"v-pre")&&(e.pre=!0)}(v),v.pre&&(s=!0)),Jo(v.tag)&&(c=!0),s?function(e){var t=e.attrsList,n=t.length;if(n)for(var r=e.attrs=new Array(n),i=0;i<n;i++)r[i]={name:t[i].name,value:JSON.stringify(t[i].value)},null!=t[i].start&&(r[i].start=t[i].start,r[i].end=t[i].end);else e.pre||(e.plain=!0)}(v):v.processed||(pa(v),function(e){var t=Fr(e,"v-if");if(t)e.if=t,da(e,{exp:t,block:e});else{null!=Fr(e,"v-else")&&(e.else=!0);var n=Fr(e,"v-else-if");n&&(e.elseif=n)}}(v),function(e){null!=Fr(e,"v-once")&&(e.once=!0)}(v)),n||(n=v),a?u(v):(r=v,i.push(v))},end:function(e,t,n){var o=i[i.length-1];i.length-=1,r=i[i.length-1],u(o)},chars:function(e,t,n){if(r&&(!q||"textarea"!==r.tag||r.attrsMap.placeholder!==e)){var i,u,l,f=r.children;if(e=c||e.trim()?"script"===(i=r).tag||"style"===i.tag?e:sa(e):f.length?a?"condense"===a&&oa.test(e)?"":" ":o?" ":"":"")c||"condense"!==a||(e=e.replace(aa," ")),!s&&" "!==e&&(u=function(e,t){var n=t?ho(t):po;if(n.test(e)){for(var r,i,o,a=[],s=[],c=n.lastIndex=0;r=n.exec(e);){(i=r.index)>c&&(s.push(o=e.slice(c,i)),a.push(JSON.stringify(o)));var u=Ar(r[1].trim());a.push("_s("+u+")"),s.push({"@binding":u}),c=i+r[0].length}return c<e.length&&(s.push(o=e.slice(c)),a.push(JSON.stringify(o))),{expression:a.join("+"),tokens:s}}}(e,Uo))?l={type:2,expression:u.expression,tokens:u.tokens,text:e}:" "===e&&f.length&&" "===f[f.length-1].text||(l={type:3,text:e}),l&&f.push(l)}},comment:function(e,t,n){if(r){var i={type:3,text:e,isComment:!0};r.children.push(i)}}}),n}function fa(e,t){var n,r;(r=Ir(n=e,"key"))&&(n.key=r),e.plain=!e.key&&!e.scopedSlots&&!e.attrsList.length,function(e){var t=Ir(e,"ref");t&&(e.ref=t,e.refInFor=function(e){var t=e;for(;t;){if(void 0!==t.for)return!0;t=t.parent}return!1}(e))}(e),function(e){var t;"template"===e.tag?(t=Fr(e,"scope"),e.slotScope=t||Fr(e,"slot-scope")):(t=Fr(e,"slot-scope"))&&(e.slotScope=t);var n=Ir(e,"slot");n&&(e.slotTarget='""'===n?'"default"':n,e.slotTargetDynamic=!(!e.attrsMap[":slot"]&&!e.attrsMap["v-bind:slot"]),"template"===e.tag||e.slotScope||Nr(e,"slot",n,function(e,t){return e.rawAttrsMap[":"+t]||e.rawAttrsMap["v-bind:"+t]||e.rawAttrsMap[t]}(e,"slot")));if("template"===e.tag){var r=Pr(e,ia);if(r){var i=va(r),o=i.name,a=i.dynamic;e.slotTarget=o,e.slotTargetDynamic=a,e.slotScope=r.value||ca}}else{var s=Pr(e,ia);if(s){var c=e.scopedSlots||(e.scopedSlots={}),u=va(s),l=u.name,f=u.dynamic,p=c[l]=ua("template",[],e);p.slotTarget=l,p.slotTargetDynamic=f,p.children=e.children.filter(function(e){if(!e.slotScope)return e.parent=p,!0}),p.slotScope=s.value||ca,e.children=[],e.plain=!1}}}(e),function(e){"slot"===e.tag&&(e.slotName=Ir(e,"name"))}(e),function(e){var t;(t=Ir(e,"is"))&&(e.component=t);null!=Fr(e,"inline-template")&&(e.inlineTemplate=!0)}(e);for(var i=0;i<zo.length;i++)e=zo[i](e,t)||e;return function(e){var t,n,r,i,o,a,s,c,u=e.attrsList;for(t=0,n=u.length;t<n;t++)if(r=i=u[t].name,o=u[t].value,Go.test(r))if(e.hasBindings=!0,(a=ha(r.replace(Go,"")))&&(r=r.replace(ra,"")),na.test(r))r=r.replace(na,""),o=Ar(o),(c=ea.test(r))&&(r=r.slice(1,-1)),a&&(a.prop&&!c&&"innerHtml"===(r=b(r))&&(r="innerHTML"),a.camel&&!c&&(r=b(r)),a.sync&&(s=Br(o,"$event"),c?Mr(e,'"update:"+('+r+")",s,null,!1,0,u[t],!0):(Mr(e,"update:"+b(r),s,null,!1,0,u[t]),C(r)!==b(r)&&Mr(e,"update:"+C(r),s,null,!1,0,u[t])))),a&&a.prop||!e.component&&qo(e.tag,e.attrsMap.type,r)?Er(e,r,o,u[t],c):Nr(e,r,o,u[t],c);else if(Zo.test(r))r=r.replace(Zo,""),(c=ea.test(r))&&(r=r.slice(1,-1)),Mr(e,r,o,a,!1,0,u[t],c);else{var l=(r=r.replace(Go,"")).match(ta),f=l&&l[1];c=!1,f&&(r=r.slice(0,-(f.length+1)),ea.test(f)&&(f=f.slice(1,-1),c=!0)),Dr(e,r,i,o,f,c,a,u[t])}else Nr(e,r,JSON.stringify(o),u[t]),!e.component&&"muted"===r&&qo(e.tag,e.attrsMap.type,r)&&Er(e,r,"true",u[t])}(e),e}function pa(e){var t;if(t=Fr(e,"v-for")){var n=function(e){var t=e.match(Xo);if(!t)return;var n={};n.for=t[2].trim();var r=t[1].trim().replace(Qo,""),i=r.match(Yo);i?(n.alias=r.replace(Yo,"").trim(),n.iterator1=i[1].trim(),i[2]&&(n.iterator2=i[2].trim())):n.alias=r;return n}(t);n&&A(e,n)}}function da(e,t){e.ifConditions||(e.ifConditions=[]),e.ifConditions.push(t)}function va(e){var t=e.name.replace(ia,"");return t||"#"!==e.name[0]&&(t="default"),ea.test(t)?{name:t.slice(1,-1),dynamic:!0}:{name:'"'+t+'"',dynamic:!1}}function ha(e){var t=e.match(ra);if(t){var n={};return t.forEach(function(e){n[e.slice(1)]=!0}),n}}function ma(e){for(var t={},n=0,r=e.length;n<r;n++)t[e[n].name]=e[n].value;return t}var ya=/^xmlns:NS\d+/,ga=/^NS\d+:/;function _a(e){return ua(e.tag,e.attrsList.slice(),e.parent)}var ba=[mo,go,{preTransformNode:function(e,t){if("input"===e.tag){var n,r=e.attrsMap;if(!r["v-model"])return;if((r[":type"]||r["v-bind:type"])&&(n=Ir(e,"type")),r.type||n||!r["v-bind"]||(n="("+r["v-bind"]+").type"),n){var i=Fr(e,"v-if",!0),o=i?"&&("+i+")":"",a=null!=Fr(e,"v-else",!0),s=Fr(e,"v-else-if",!0),c=_a(e);pa(c),jr(c,"type","checkbox"),fa(c,t),c.processed=!0,c.if="("+n+")==='checkbox'"+o,da(c,{exp:c.if,block:c});var u=_a(e);Fr(u,"v-for",!0),jr(u,"type","radio"),fa(u,t),da(c,{exp:"("+n+")==='radio'"+o,block:u});var l=_a(e);return Fr(l,"v-for",!0),jr(l,":type",n),fa(l,t),da(c,{exp:i,block:l}),a?c.else=!0:s&&(c.elseif=s),c}}}}];var $a,wa,Ca={expectHTML:!0,modules:ba,directives:{model:function(e,t,n){var r=t.value,i=t.modifiers,o=e.tag,a=e.attrsMap.type;if(e.component)return Hr(e,r,i),!1;if("select"===o)!function(e,t,n){var r='var $$selectedVal = Array.prototype.filter.call($event.target.options,function(o){return o.selected}).map(function(o){var val = "_value" in o ? o._value : o.value;return '+(n&&n.number?"_n(val)":"val")+"});";r=r+" "+Br(t,"$event.target.multiple ? $$selectedVal : $$selectedVal[0]"),Mr(e,"change",r,null,!0)}(e,r,i);else if("input"===o&&"checkbox"===a)!function(e,t,n){var r=n&&n.number,i=Ir(e,"value")||"null",o=Ir(e,"true-value")||"true",a=Ir(e,"false-value")||"false";Er(e,"checked","Array.isArray("+t+")?_i("+t+","+i+")>-1"+("true"===o?":("+t+")":":_q("+t+","+o+")")),Mr(e,"change","var $$a="+t+",$$el=$event.target,$$c=$$el.checked?("+o+"):("+a+");if(Array.isArray($$a)){var $$v="+(r?"_n("+i+")":i)+",$$i=_i($$a,$$v);if($$el.checked){$$i<0&&("+Br(t,"$$a.concat([$$v])")+")}else{$$i>-1&&("+Br(t,"$$a.slice(0,$$i).concat($$a.slice($$i+1))")+")}}else{"+Br(t,"$$c")+"}",null,!0)}(e,r,i);else if("input"===o&&"radio"===a)!function(e,t,n){var r=n&&n.number,i=Ir(e,"value")||"null";Er(e,"checked","_q("+t+","+(i=r?"_n("+i+")":i)+")"),Mr(e,"change",Br(t,i),null,!0)}(e,r,i);else if("input"===o||"textarea"===o)!function(e,t,n){var r=e.attrsMap.type,i=n||{},o=i.lazy,a=i.number,s=i.trim,c=!o&&"range"!==r,u=o?"change":"range"===r?Wr:"input",l="$event.target.value";s&&(l="$event.target.value.trim()"),a&&(l="_n("+l+")");var f=Br(t,l);c&&(f="if($event.target.composing)return;"+f),Er(e,"value","("+t+")"),Mr(e,u,f,null,!0),(s||a)&&Mr(e,"blur","$forceUpdate()")}(e,r,i);else if(!F.isReservedTag(o))return Hr(e,r,i),!1;return!0},text:function(e,t){t.value&&Er(e,"textContent","_s("+t.value+")",t)},html:function(e,t){t.value&&Er(e,"innerHTML","_s("+t.value+")",t)}},isPreTag:function(e){return"pre"===e},isUnaryTag:bo,mustUseProp:jn,canBeLeftOpenTag:$o,isReservedTag:Wn,getTagNamespace:Zn,staticKeys:function(e){return e.reduce(function(e,t){return e.concat(t.staticKeys||[])},[]).join(",")}(ba)},xa=g(function(e){return p("type,tag,attrsList,attrsMap,plain,parent,children,attrs,start,end,rawAttrsMap"+(e?","+e:""))});function ka(e,t){e&&($a=xa(t.staticKeys||""),wa=t.isReservedTag||T,function e(t){t.static=function(e){if(2===e.type)return!1;if(3===e.type)return!0;return!(!e.pre&&(e.hasBindings||e.if||e.for||d(e.tag)||!wa(e.tag)||function(e){for(;e.parent;){if("template"!==(e=e.parent).tag)return!1;if(e.for)return!0}return!1}(e)||!Object.keys(e).every($a)))}(t);if(1===t.type){if(!wa(t.tag)&&"slot"!==t.tag&&null==t.attrsMap["inline-template"])return;for(var n=0,r=t.children.length;n<r;n++){var i=t.children[n];e(i),i.static||(t.static=!1)}if(t.ifConditions)for(var o=1,a=t.ifConditions.length;o<a;o++){var s=t.ifConditions[o].block;e(s),s.static||(t.static=!1)}}}(e),function e(t,n){if(1===t.type){if((t.static||t.once)&&(t.staticInFor=n),t.static&&t.children.length&&(1!==t.children.length||3!==t.children[0].type))return void(t.staticRoot=!0);if(t.staticRoot=!1,t.children)for(var r=0,i=t.children.length;r<i;r++)e(t.children[r],n||!!t.for);if(t.ifConditions)for(var o=1,a=t.ifConditions.length;o<a;o++)e(t.ifConditions[o].block,n)}}(e,!1))}var Aa=/^([\w$_]+|\([^)]*?\))\s*=>|^function\s*(?:[\w$]+)?\s*\(/,Oa=/\([^)]*?\);*$/,Sa=/^[A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*|\['[^']*?']|\["[^"]*?"]|\[\d+]|\[[A-Za-z_$][\w$]*])*$/,Ta={esc:27,tab:9,enter:13,space:32,up:38,left:37,right:39,down:40,delete:[8,46]},Ea={esc:["Esc","Escape"],tab:"Tab",enter:"Enter",space:[" ","Spacebar"],up:["Up","ArrowUp"],left:["Left","ArrowLeft"],right:["Right","ArrowRight"],down:["Down","ArrowDown"],delete:["Backspace","Delete","Del"]},Na=function(e){return"if("+e+")return null;"},ja={stop:"$event.stopPropagation();",prevent:"$event.preventDefault();",self:Na("$event.target !== $event.currentTarget"),ctrl:Na("!$event.ctrlKey"),shift:Na("!$event.shiftKey"),alt:Na("!$event.altKey"),meta:Na("!$event.metaKey"),left:Na("'button' in $event && $event.button !== 0"),middle:Na("'button' in $event && $event.button !== 1"),right:Na("'button' in $event && $event.button !== 2")};function Da(e,t){var n=t?"nativeOn:":"on:",r="",i="";for(var o in e){var a=La(e[o]);e[o]&&e[o].dynamic?i+=o+","+a+",":r+='"'+o+'":'+a+","}return r="{"+r.slice(0,-1)+"}",i?n+"_d("+r+",["+i.slice(0,-1)+"])":n+r}function La(e){if(!e)return"function(){}";if(Array.isArray(e))return"["+e.map(function(e){return La(e)}).join(",")+"]";var t=Sa.test(e.value),n=Aa.test(e.value),r=Sa.test(e.value.replace(Oa,""));if(e.modifiers){var i="",o="",a=[];for(var s in e.modifiers)if(ja[s])o+=ja[s],Ta[s]&&a.push(s);else if("exact"===s){var c=e.modifiers;o+=Na(["ctrl","shift","alt","meta"].filter(function(e){return!c[e]}).map(function(e){return"$event."+e+"Key"}).join("||"))}else a.push(s);return a.length&&(i+=function(e){return"if(!$event.type.indexOf('key')&&"+e.map(Ma).join("&&")+")return null;"}(a)),o&&(i+=o),"function($event){"+i+(t?"return "+e.value+"($event)":n?"return ("+e.value+")($event)":r?"return "+e.value:e.value)+"}"}return t||n?e.value:"function($event){"+(r?"return "+e.value:e.value)+"}"}function Ma(e){var t=parseInt(e,10);if(t)return"$event.keyCode!=="+t;var n=Ta[e],r=Ea[e];return"_k($event.keyCode,"+JSON.stringify(e)+","+JSON.stringify(n)+",$event.key,"+JSON.stringify(r)+")"}var Ia={on:function(e,t){e.wrapListeners=function(e){return"_g("+e+","+t.value+")"}},bind:function(e,t){e.wrapData=function(n){return"_b("+n+",'"+e.tag+"',"+t.value+","+(t.modifiers&&t.modifiers.prop?"true":"false")+(t.modifiers&&t.modifiers.sync?",true":"")+")"}},cloak:S},Fa=function(e){this.options=e,this.warn=e.warn||Sr,this.transforms=Tr(e.modules,"transformCode"),this.dataGenFns=Tr(e.modules,"genData"),this.directives=A(A({},Ia),e.directives);var t=e.isReservedTag||T;this.maybeComponent=function(e){return!!e.component||!t(e.tag)},this.onceId=0,this.staticRenderFns=[],this.pre=!1};function Pa(e,t){var n=new Fa(t);return{render:"with(this){return "+(e?Ra(e,n):'_c("div")')+"}",staticRenderFns:n.staticRenderFns}}function Ra(e,t){if(e.parent&&(e.pre=e.pre||e.parent.pre),e.staticRoot&&!e.staticProcessed)return Ha(e,t);if(e.once&&!e.onceProcessed)return Ba(e,t);if(e.for&&!e.forProcessed)return za(e,t);if(e.if&&!e.ifProcessed)return Ua(e,t);if("template"!==e.tag||e.slotTarget||t.pre){if("slot"===e.tag)return function(e,t){var n=e.slotName||'"default"',r=qa(e,t),i="_t("+n+(r?","+r:""),o=e.attrs||e.dynamicAttrs?Ga((e.attrs||[]).concat(e.dynamicAttrs||[]).map(function(e){return{name:b(e.name),value:e.value,dynamic:e.dynamic}})):null,a=e.attrsMap["v-bind"];!o&&!a||r||(i+=",null");o&&(i+=","+o);a&&(i+=(o?"":",null")+","+a);return i+")"}(e,t);var n;if(e.component)n=function(e,t,n){var r=t.inlineTemplate?null:qa(t,n,!0);return"_c("+e+","+Va(t,n)+(r?","+r:"")+")"}(e.component,e,t);else{var r;(!e.plain||e.pre&&t.maybeComponent(e))&&(r=Va(e,t));var i=e.inlineTemplate?null:qa(e,t,!0);n="_c('"+e.tag+"'"+(r?","+r:"")+(i?","+i:"")+")"}for(var o=0;o<t.transforms.length;o++)n=t.transforms[o](e,n);return n}return qa(e,t)||"void 0"}function Ha(e,t){e.staticProcessed=!0;var n=t.pre;return e.pre&&(t.pre=e.pre),t.staticRenderFns.push("with(this){return "+Ra(e,t)+"}"),t.pre=n,"_m("+(t.staticRenderFns.length-1)+(e.staticInFor?",true":"")+")"}function Ba(e,t){if(e.onceProcessed=!0,e.if&&!e.ifProcessed)return Ua(e,t);if(e.staticInFor){for(var n="",r=e.parent;r;){if(r.for){n=r.key;break}r=r.parent}return n?"_o("+Ra(e,t)+","+t.onceId+++","+n+")":Ra(e,t)}return Ha(e,t)}function Ua(e,t,n,r){return e.ifProcessed=!0,function e(t,n,r,i){if(!t.length)return i||"_e()";var o=t.shift();return o.exp?"("+o.exp+")?"+a(o.block)+":"+e(t,n,r,i):""+a(o.block);function a(e){return r?r(e,n):e.once?Ba(e,n):Ra(e,n)}}(e.ifConditions.slice(),t,n,r)}function za(e,t,n,r){var i=e.for,o=e.alias,a=e.iterator1?","+e.iterator1:"",s=e.iterator2?","+e.iterator2:"";return e.forProcessed=!0,(r||"_l")+"(("+i+"),function("+o+a+s+"){return "+(n||Ra)(e,t)+"})"}function Va(e,t){var n="{",r=function(e,t){var n=e.directives;if(!n)return;var r,i,o,a,s="directives:[",c=!1;for(r=0,i=n.length;r<i;r++){o=n[r],a=!0;var u=t.directives[o.name];u&&(a=!!u(e,o,t.warn)),a&&(c=!0,s+='{name:"'+o.name+'",rawName:"'+o.rawName+'"'+(o.value?",value:("+o.value+"),expression:"+JSON.stringify(o.value):"")+(o.arg?",arg:"+(o.isDynamicArg?o.arg:'"'+o.arg+'"'):"")+(o.modifiers?",modifiers:"+JSON.stringify(o.modifiers):"")+"},")}if(c)return s.slice(0,-1)+"]"}(e,t);r&&(n+=r+","),e.key&&(n+="key:"+e.key+","),e.ref&&(n+="ref:"+e.ref+","),e.refInFor&&(n+="refInFor:true,"),e.pre&&(n+="pre:true,"),e.component&&(n+='tag:"'+e.tag+'",');for(var i=0;i<t.dataGenFns.length;i++)n+=t.dataGenFns[i](e);if(e.attrs&&(n+="attrs:"+Ga(e.attrs)+","),e.props&&(n+="domProps:"+Ga(e.props)+","),e.events&&(n+=Da(e.events,!1)+","),e.nativeEvents&&(n+=Da(e.nativeEvents,!0)+","),e.slotTarget&&!e.slotScope&&(n+="slot:"+e.slotTarget+","),e.scopedSlots&&(n+=function(e,t,n){var r=e.for||Object.keys(t).some(function(e){var n=t[e];return n.slotTargetDynamic||n.if||n.for||Ka(n)}),i=!!e.if;if(!r)for(var o=e.parent;o;){if(o.slotScope&&o.slotScope!==ca||o.for){r=!0;break}o.if&&(i=!0),o=o.parent}var a=Object.keys(t).map(function(e){return Ja(t[e],n)}).join(",");return"scopedSlots:_u(["+a+"]"+(r?",null,true":"")+(!r&&i?",null,false,"+function(e){var t=5381,n=e.length;for(;n;)t=33*t^e.charCodeAt(--n);return t>>>0}(a):"")+")"}(e,e.scopedSlots,t)+","),e.model&&(n+="model:{value:"+e.model.value+",callback:"+e.model.callback+",expression:"+e.model.expression+"},"),e.inlineTemplate){var o=function(e,t){var n=e.children[0];if(n&&1===n.type){var r=Pa(n,t.options);return"inlineTemplate:{render:function(){"+r.render+"},staticRenderFns:["+r.staticRenderFns.map(function(e){return"function(){"+e+"}"}).join(",")+"]}"}}(e,t);o&&(n+=o+",")}return n=n.replace(/,$/,"")+"}",e.dynamicAttrs&&(n="_b("+n+',"'+e.tag+'",'+Ga(e.dynamicAttrs)+")"),e.wrapData&&(n=e.wrapData(n)),e.wrapListeners&&(n=e.wrapListeners(n)),n}function Ka(e){return 1===e.type&&("slot"===e.tag||e.children.some(Ka))}function Ja(e,t){var n=e.attrsMap["slot-scope"];if(e.if&&!e.ifProcessed&&!n)return Ua(e,t,Ja,"null");if(e.for&&!e.forProcessed)return za(e,t,Ja);var r=e.slotScope===ca?"":String(e.slotScope),i="function("+r+"){return "+("template"===e.tag?e.if&&n?"("+e.if+")?"+(qa(e,t)||"undefined")+":undefined":qa(e,t)||"undefined":Ra(e,t))+"}",o=r?"":",proxy:true";return"{key:"+(e.slotTarget||'"default"')+",fn:"+i+o+"}"}function qa(e,t,n,r,i){var o=e.children;if(o.length){var a=o[0];if(1===o.length&&a.for&&"template"!==a.tag&&"slot"!==a.tag){var s=n?t.maybeComponent(a)?",1":",0":"";return""+(r||Ra)(a,t)+s}var c=n?function(e,t){for(var n=0,r=0;r<e.length;r++){var i=e[r];if(1===i.type){if(Wa(i)||i.ifConditions&&i.ifConditions.some(function(e){return Wa(e.block)})){n=2;break}(t(i)||i.ifConditions&&i.ifConditions.some(function(e){return t(e.block)}))&&(n=1)}}return n}(o,t.maybeComponent):0,u=i||Za;return"["+o.map(function(e){return u(e,t)}).join(",")+"]"+(c?","+c:"")}}function Wa(e){return void 0!==e.for||"template"===e.tag||"slot"===e.tag}function Za(e,t){return 1===e.type?Ra(e,t):3===e.type&&e.isComment?(r=e,"_e("+JSON.stringify(r.text)+")"):"_v("+(2===(n=e).type?n.expression:Xa(JSON.stringify(n.text)))+")";var n,r}function Ga(e){for(var t="",n="",r=0;r<e.length;r++){var i=e[r],o=Xa(i.value);i.dynamic?n+=i.name+","+o+",":t+='"'+i.name+'":'+o+","}return t="{"+t.slice(0,-1)+"}",n?"_d("+t+",["+n.slice(0,-1)+"])":t}function Xa(e){return e.replace(/\u2028/g,"\\u2028").replace(/\u2029/g,"\\u2029")}new RegExp("\\b"+"do,if,for,let,new,try,var,case,else,with,await,break,catch,class,const,super,throw,while,yield,delete,export,import,return,switch,default,extends,finally,continue,debugger,function,arguments".split(",").join("\\b|\\b")+"\\b");function Ya(e,t){try{return new Function(e)}catch(n){return t.push({err:n,code:e}),S}}function Qa(e){var t=Object.create(null);return function(n,r,i){(r=A({},r)).warn;delete r.warn;var o=r.delimiters?String(r.delimiters)+n:n;if(t[o])return t[o];var a=e(n,r),s={},c=[];return s.render=Ya(a.render,c),s.staticRenderFns=a.staticRenderFns.map(function(e){return Ya(e,c)}),t[o]=s}}var es,ts,ns=(es=function(e,t){var n=la(e.trim(),t);!1!==t.optimize&&ka(n,t);var r=Pa(n,t);return{ast:n,render:r.render,staticRenderFns:r.staticRenderFns}},function(e){function t(t,n){var r=Object.create(e),i=[],o=[];if(n)for(var a in n.modules&&(r.modules=(e.modules||[]).concat(n.modules)),n.directives&&(r.directives=A(Object.create(e.directives||null),n.directives)),n)"modules"!==a&&"directives"!==a&&(r[a]=n[a]);r.warn=function(e,t,n){(n?o:i).push(e)};var s=es(t.trim(),r);return s.errors=i,s.tips=o,s}return{compile:t,compileToFunctions:Qa(t)}})(Ca),rs=(ns.compile,ns.compileToFunctions);function is(e){return(ts=ts||document.createElement("div")).innerHTML=e?'<a href="\n"/>':'<div a="\n"/>',ts.innerHTML.indexOf("&#10;")>0}var os=!!z&&is(!1),as=!!z&&is(!0),ss=g(function(e){var t=Yn(e);return t&&t.innerHTML}),cs=wn.prototype.$mount;return wn.prototype.$mount=function(e,t){if((e=e&&Yn(e))===document.body||e===document.documentElement)return this;var n=this.$options;if(!n.render){var r=n.template;if(r)if("string"==typeof r)"#"===r.charAt(0)&&(r=ss(r));else{if(!r.nodeType)return this;r=r.innerHTML}else e&&(r=function(e){if(e.outerHTML)return e.outerHTML;var t=document.createElement("div");return t.appendChild(e.cloneNode(!0)),t.innerHTML}(e));if(r){var i=rs(r,{outputSourceRange:!1,shouldDecodeNewlines:os,shouldDecodeNewlinesForHref:as,delimiters:n.delimiters,comments:n.comments},this),o=i.render,a=i.staticRenderFns;n.render=o,n.staticRenderFns=a}}return cs.call(this,e,t)},wn.compile=rs,wn});

(function($) {
	"use strict";
	/**
	 * Layout module implementation.
	 * https://gitlab.namics.com/snippets/2
	 *
	 * @author  <>
	 * @namespace Tc.Module
	 * @class Layout
	 * @extends Tc.Module
	 */
	Tc.Module.Layout = Tc.Module.extend({

		init: function($ctx, sandbox, modId) {
			this._super($ctx, sandbox, modId);
		},

		on: function(callback) {
			this.bindAll(
				"_onResizeDebounced"
			);
			this.$body = $("body");
			Utils.TcSandbox = this.sandbox;
			if(localStorage.basket && localStorage.basket !== window.location.href){
				if(localStorage.orderForm) {
					localStorage.removeItem("orderForm");
				}
				localStorage.removeItem("basket");
			}
			$('html').removeClass("no-js").addClass("js");
			$.fn.extend({
				scrollToMe: function () {
					var offset = $(this).offset().top;
					$('html, body').animate({scrollTop: offset}, 500);
				}
			});
			this._loadDatepicker();
			this._setResizeListener();
			callback(); // !do not remove
		},

		after: function() {
			Tc.Utils.Lib.initGlossary();
			Tc.Utils.EqualHeight.addElements(this.$$('.js-equalheight'));

			//Initializes LazyLoading of images
			this.bLazy = new Blazy();
		},

		_loadDatepicker: function(){
			var $ctx = this.$ctx;
			Modernizr.load({
				test: Modernizr.inputtypes.date,
				nope: [
					'/etc/designs/core/frontend/assets/js/dynamic/libraries/bootstrap-datepicker.js',
					'/etc/designs/core/frontend/assets/js/dynamic/libraries/bootstrap-datepicker.languages.js',
					'/etc/designs/core/frontend/assets/css/dynamic/libraries/datepicker.css'
				],
				complete: function(){
					if(!Modernizr.inputtypes.date) {
						Tc.Utils.Lib.initDatepicker($ctx);
					}
				}
			});
		},

		_setResizeListener: function() {
			var _this = this;
			$(window).on("resize viewportchange", $.debounce(200, _this._onResizeDebounced));
		},

		_onResizeDebounced: function() {
			if(!this.$body.hasClass('cq-wcm-edit')){
				Tc.Utils.EqualHeight.set();
			}
		}
	});
}(Tc.$));


(function ($) {
	"use strict";
	/**
	 * Accordion module implementation.
	 * https://gitlab.namics.com/snippets/2
	 *
	 * @author  <>
	 * @namespace Tc.Module
	 * @class Accordion
	 * @extends Tc.Module
	 */
	Tc.Module.Accordion = Tc.Module.extend({

		init: function ($ctx, sandbox, modId) {
			this._super($ctx, sandbox, modId);

		},

		on: function (callback) {
			var _this = this
				,autoCollapse = $('> div', _this.$ctx).data('auto-collapse')
				,firstElementOpen = $('> div', _this.$ctx).data('first-element-open')
				,$collapsedElmt = $("a.collapsed", _this.$ctx)
				;

			if (firstElementOpen) {
				$collapsedElmt.first().click();
			}

			if (autoCollapse) {
				$collapsedElmt.unbind('click').on('click', function (e) {
					var evt = $(e.target);

					if (!evt.hasClass('active')) {
						_this.$ctx.find('a.active').click();
					}
				});
			}

			callback(); // !do not remove
		},

		after: function () {
			var _this = this;

		}

	});
}(Tc.$));

(function($) {
	"use strict";
	/**
	 * Database module implementation.
	 * https://gitlab.namics.com/snippets/2
	 *
	 * @author ewessolek <elena.wessolek@namics.com>
	 * @author sbaur <stefan.baur@namics.com>
	 * @namespace Tc.Module
	 * @class Database
	 * @extends Tc.Module
	 */
	Tc.Module.Database = Tc.Module.extend({

		init: function($ctx, sandbox, modId) {
			this._super($ctx, sandbox, modId);
		},

		on: function(callback) {
			var _this = this;

			_this.initDatabaseFilter();

			callback(); // !do not remove
		},

		initDatabaseFilter: function() {
			var _this = this,
				$ctx = _this.$ctx;

			_this.$form = $ctx.find('.js-database-form');

			// form submit
			_this.$form.on('submit', function(e) {
				e.preventDefault();
				_this.submitForm();
			});
		},

		initDetails: function() {
			var _this = this,
				$ctx = _this.$ctx,
				$result = $ctx.find('.js-database-result'),
				$detailLink = $result.find('a.database-entry');

			// show details
			$detailLink.on('click', function(e) {
				e.preventDefault();
				var target = $(e.currentTarget),
					dataUrl = target.attr('href');

				_this.loadDetails(dataUrl, $result);
			});
		},

		loadDetails: function(dataUrl, $result) {
			var _this = this,
				$ctx = _this.$ctx;

			$result.addClass('loading');

			$.ajax({
				type: 'GET',
				url: dataUrl,
				success: function(data) {
					$result.html(data).removeClass('loading');

					// go back to database
					$ctx.on('click', '.js-database-link', function () {
						_this.submitForm();
					});
				}
			});
		},

		submitForm: function() {
			var _this = this,
				attributes = _this.$form.length !== null ? 'pageIndex=' + 0 + '&' + _this.$form.serialize() : 'pageIndex=' + 0;

			this.fire('loadContent', {attributes: attributes});
		},

		onContentDone: function() {
			var _this = this;

			_this.initDetails();
		}
	});
}(Tc.$));

(function ($) {
    "use strict";
    /**
     * Deleteresource module implementation.
     *
     * @author sbaur <stefan.baur@namics.com>
     * @namespace Tc.Module
     * @class Deleteresource
     * @extends Tc.Module
     */
    Tc.Module.Deleteresource = Tc.Module.extend({

        on: function (callback) {
            var $this = this,
                path = this.$ctx.data('delete-path');
            this.$resultContainer = this.$ctx.find('.result').find('.alert');

            $(window).load(function () {
                window.setTimeout(function () {
                    if (path) {
                        $this.askForDeletion(path);
                    } else {
                        $this.showResult('alert-danger', 'core.pages.deleteresource.message.notfound');
                    }
                }, 500);
            });
            callback(); // !do not remove
        },

        askForDeletion: function (path) {
            var $this = this;
            CQ.Ext.Msg.show({
                "title": CQ.I18n.getMessage("core.pages.deleteresource.title"),
                "msg": CQ.I18n.getMessage("core.pages.deleteresource.message.confirmdeletion"),
                "buttons": CQ.Ext.Msg.YESNO,
                "icon": CQ.Ext.MessageBox.QUESTION,
                "fn": function (btnId) {
                    if (btnId == "yes") {
                        $this.sendDeleteRequest(path)
                    } else if (btnId == "no") {
                        $this.showResult('alert-warning', 'core.pages.deleteresource.message.cancel');
                    }
                },
                "scope": this
            });
        },

        sendDeleteRequest: function (path) {
            var $this = this;
            var data = {
                "path": path,
                "_charset_": "utf-8",
                "cmd": "deletePage",
                "force": false
            };
            $.ajax({
                url: "/bin/wcmcommand",
                type: "POST",
                dataType: "html",
                data: data
            }).done(function (data, textStatus, jqXHR) {
                var message = $this.getMessage(data);
                if (message.indexOf('null') == 0) {
                    $this.showResult('alert-danger', 'core.pages.deleteresource.message.error', 'core.pages.deleteresource.message.notfound');
                    console.log(data);
                } else {
                    $this.showResult('alert-success', 'core.pages.deleteresource.message.success', message);
                }
            }).fail(function (jqXHR, textStatus, errorThrown) {
                var message = $this.getMessage(jqXHR.responseText);
                $this.showResult('alert-danger', 'core.pages.deleteresource.message.error', message);
                console.log(jqXHR.responseText);
            });
        },

        getMessage: function (result) {
            return $(result).find('#Message').html();
        },

        showResult: function (type, message, details) {
            var $this = this,
                i18nMessage = '<p><strong>' + CQ.I18n.getMessage(message) + '</strong></p>',
                detailsMessage = '';
            if (details) {
                detailsMessage = '<p>' + CQ.I18n.getMessage(details) + '</p>'
            }
            $this.$resultContainer.removeClass().addClass('alert').addClass(type).html(i18nMessage + detailsMessage);
        }
    });
}(Tc.$));

(function ($) {
	"use strict";
	/**
	 * Contactbox module implementation.
	 * https://gitlab.namics.com/snippets/2
	 *
	 * @author  <>
	 * @namespace Tc.Module
	 * @class Contactbox
	 * @extends Tc.Module
	 */
	Tc.Module.Contactbox = Tc.Module.extend({
		on: function (callback) {
			this.bindAll(
				'onClickPrint'
			);
			this.$$('.js-print-contact').on('click', this.onClickPrint);
			callback(); // !do not remove
		},

		onClickPrint: function (ev) {
			ev.preventDefault();

			function printMarkup(data) {
				var windowContent = '<html><head><title>Kontakt</title>'
					+ '<link rel="stylesheet" href="/etc/designs/core/frontend/guidelines.min.css" type="text/css" />'
					+ '</head><body class="container container-main" style="padding: 30px;">'
					+ data
					+ '</body></html>';

				return windowContent;
			}

			function Popup(data) {
				if (navigator.userAgent.search(/Windows/) > 0) {
					var printWin = window.open('', '', 'height=800,width=1000');
					printWin.document.open();
					printWin.document.write(printMarkup(data));
					printWin.document.close();
					printWin.focus();
					setTimeout(function () {
						printWin.print();
						printWin.close();
					}, 500);
				} else {
					var mywindow = window.open('', '', 'height=800,width=1000');
					mywindow.document.write('<html><head><title>Kontakt</title>');
					mywindow.document.write('<link rel="stylesheet" href="/etc/designs/core/frontend/guidelines.min.css" type="text/css" />');
					mywindow.document.write('</head><body class="container container-main" style="padding: 30px;">');
					mywindow.document.write(data);
					mywindow.document.write('</body></html>');
					setTimeout(function () {
						mywindow.print();
						mywindow.close();
					}, 500);
				}
				return true;
			}

			var printContent = this.$$('#contact').html();
			var $contactMap = this.$$("#map");
			if($contactMap.length) {
				var mapTitleHtml = $contactMap.find("h3").html() || "";
				var $mapImage = $contactMap.find("img").closest('p');
				var mapImageHtml = $mapImage.length ? $mapImage.get(0).outerHTML : "";
				printContent = printContent + mapTitleHtml + mapImageHtml;
			}

			new Popup(printContent);
		}
	});
}(Tc.$));

(function($) {
    "use strict";
    /**
     * Backtooverview
     * https://gitlab.namics.com/snippets/2
     *
     * @author  <>
     * @namespace Tc.Module
     * @class Backtooverview
     * @extends Tc.Module
     */
    Tc.Module.Backtooverview = Tc.Module.extend({

        init: function($ctx, sandbox, modId) {
            this._super($ctx, sandbox, modId);

        },

        on: function(callback) {
            var _this = this;

            _this.setReferrerToBackButton();

            callback(); // !do not remove
        },

        setReferrerToBackButton: function(){

            var _this = this,
                $ctx = _this.$ctx,
                backLink = $ctx.find('a'),
                hostPath = location.protocol+'//'+location.host,
                backLinkPath = backLink.eq(0).attr('href'),
                newBackPath = document.referrer.replace(hostPath,'');

            if(document.referrer.indexOf(backLinkPath)>-1){
                backLink.each(function(i,v){
                    var newHref = backLinkPath + newBackPath.replace(backLinkPath, '').replace('/content?', '?');
                    $(v).attr('href', newHref);
                });

            }
        },

        after: function() {
            var _this = this;
        }

    });
}(Tc.$));

(function($) {
	"use strict";
	/**
	 * Tabs module implementation.
	 * https://gitlab.namics.com/snippets/2
	 *
	 * @author  <>
	 * @namespace Tc.Module
	 * @class Tabs
	 * @extends Tc.Module
	 */
	Tc.Module.Tabs = Tc.Module.extend({

		init: function($ctx, sandbox, modId) {
			this._super($ctx, sandbox, modId);
		},

		on: function(callback) {
			var _this = this;

			callback(); // !do not remove
		},

		after: function() {
			var _this = this;

			//check if cq editmode class is available
			if($("body").hasClass("skin-layout-editmode")){
				//_this._initEditModeTabs();
			}

		},
		_initEditModeTabs: function() {
			var _this = this;
			$(".tabs-list a", _this.$ctx).first().addClass("current");
			$(".tabbody", _this.$ctx).first().addClass("current");
			$(".tabs-list a", _this.$ctx).click(function(event) {

				var contentId = $(this).attr("href");
				// remove all current classes from tabbody
				$(".tabbody", _this.$ctx).each(function() {
					$(this).removeClass("current");
				});
				// add current class toactive tab
				$(contentId, _this.$ctx).next(".tabbody").addClass("current");
			});
			//Trigger click on first tab navigation link
		}


	});
}(Tc.$));

(function($) {
    "use strict";
    /**
     * Tabs module implementation.
     * https://gitlab.namics.com/snippets/2
     *
     * @author  <>
     * @namespace Tc.Module
     * @class Tabs
     * @extends Tc.Module
     */
    Tc.Module.DynamicTabs = Tc.Module.extend({

        init: function($ctx, sandbox, modId) {
            this._super($ctx, sandbox, modId);
        },

        on: function(callback) {
            var _this = this;

            callback(); // !do not remove
        },

        after: function() {
        	this._init()
			if(this.$ctx.data("initialload") !== 0) {
				this._selectFirst();
			}

        },

		onLoadTabs: function() {
        	var _this = this;
        	_this._selectFirst();
		},

		_init: function() {
			var _this = this,
				tabParam = this._getTabParam(),
				selectedTabId = this._getTabId(tabParam);

			$(".nav-tabs a, .collapsify a", _this.$ctx).click(function(event) {

				var tabId = $(this).data("tabid"),
					dataStr = _this._getParamString(tabId);

				_this.fire("initialLoadContent", {attributes:dataStr}, [tabId]);
			});

		},

		_selectFirst: function() {
			this.fire('unloadContent');
			var _this = this,
				tabParam = this._getTabParam(),
				selectedTabId = this._getTabId(tabParam);

			//Trigger click on first tab navigation link
			setTimeout(function() {
				$(".nav-tabs a[data-tabid='"+selectedTabId+"']", _this.$ctx).click();
			}, 10);
			this.$ctx.removeClass('hidden');
		},

        _getParamString: function(tabParam) {
            var queryParams = Tc.Utils.WCM.getParsedQueryString(),
                params = [];

            tabParam = tabParam.replace("dynamictab", "") || "";
            queryParams.dyn_tab = tabParam;
            for (var p in queryParams) {
                params.push(p.replace("dyn_", "")+"="+queryParams[p]);
            }
            params = params.join("&") || "";
            return params;
        },

        _getTabId: function(tabParam) {
            if (tabParam && !isNaN(tabParam)) {
                return "dynamictab"+tabParam;
            } else {
                return "dynamictab0";
            }
        },

        _getTabParam: function() {
            var params = Tc.Utils.WCM.getParsedQueryString();
            return params.dyn_tab;
        }

    });
}(Tc.$));

(function($) {
	"use strict";
	/**
	 * Themes module implementation.
	 * https://gitlab.namics.com/snippets/2
	 *
	 * @author  <>
	 * @namespace Tc.Module
	 * @class Themes
	 * @extends Tc.Module
	 */
	Tc.Module.Themes = Tc.Module.extend({

		init: function($ctx, sandbox, modId) {
			this._super($ctx, sandbox, modId);

		},

		on: function(callback) {
			var _this = this;
			callback(); // !do not remove

			$(".tabs-list a", _this.$ctx ).click(function(event) {
				$('.enhanced_select_scroll.is_open').removeClass('is_open').hide().click();
			});

			// Trigger tab when themes select field open
			$(".yamm--select").on("show.bs.dropdown",function(){
				$('li:not(.disabled) a[data-toggle="tab"]:first', _this.$ctx).tab('show').trigger('show.bs.tab');
			});
			_this._initTabEvents();
			_this._initSelectEvents();

		},

		after: function() {
			var _this = this;
		},
		_initTabEvents: function() {
			var _this = this;

			$('a[data-toggle="tab"]', _this.$ctx).unbind('show.bs.tab').on('show.bs.tab', function (e) {
				var url = $(e.target).data("url")
					,tabId = $(e.target).attr("href");
				url = url || "";

				if($("body").hasClass("skin-layout-author")) {
					url += url.indexOf('?') == -1 ? "?wcmmode=disabled" : "&wcmmode=disabled";
				}

				//console.log("e.target: ", e.target); // newly activated tab
				//console.log("e.relatedTarget: ", e.relatedTarget); // previous active tab

				//check if content is already loaded
				if($(tabId).children().length === 0) {
					var modules = [];
					$(tabId).addClass("loading");
					$.ajax( url )
						.done(function(data) {
							//alert( "success" );
							$(tabId).html(data);
							modules = _this.sandbox.addModules($(tabId));
							_this._initTabEvents();
							_this._initSelectEvents();

							if(window.BIT_ETRACKER) {
								BIT_ETRACKER.addEvents(_this.$ctx);
							}
						})
						.fail(function() {
							//alert( "error" );
						})
						.always(function() {
							//alert( "complete" );
							$(tabId).removeClass("loading");
						});
				}
			});
		},
		_initSelectEvents: function () {
			var _this = this
				,$select = $("select:not(.no-chosen)", _this.$ctx);
			$select.chosen({
				disable_search_threshold: 10
			});
			$select.unbind('change').change(function() {
				var url = $("option:selected", this).val();
				url = url || "";
				if($("body").hasClass("skin-layout-author")) {
					url += url.indexOf('?') == -1 ? "?wcmmode=disabled" : "&wcmmode=disabled";
				}
				var modules = [];
				var $dContent = $(".tab-pane:visible", _this.$ctx).find(".dynamic-content");
				$dContent.addClass("loading");
				$.ajax( url )
					.done(function(data) {
						//alert( "success" );
						$dContent.html(data);
						modules = _this.sandbox.addModules($dContent);
					})
					.fail(function() {
						//alert( "error" );
					})
					.always(function() {
						//alert( "complete" );
						$dContent.removeClass("loading");
					});
			});

		}

	});
}(Tc.$));

(function($) {
	"use strict";
	/**
	 * Form module implementation.
	 * https://gitlab.namics.com/snippets/2
	 *
	 * @author  <>
	 * @namespace Tc.Module
	 * @class Form
	 * @extends Tc.Module
	 */
	Tc.Module.Form = Tc.Module.extend({

		init: function($ctx, sandbox, modId) {
			this._super($ctx, sandbox, modId);

			

		},

		on: function(callback) {
			var _this = this;
			_this.bindAll(
				"_formatErrors"
			);

			_this._checkForErrors();
			callback(); // !do not remove
		},

		after: function() {
			var _this = this;
		},

		_checkForErrors: function() {
			var _this = this,
				$errors = this.$$('.form_error');
			if($errors.length){
				$errors.each(_this._formatErrors);
			}
		},

		_formatErrors: function(i, el) {
			var _this = this;

			$(el).closest(".form-group").addClass("has-warning");
			if(i===0){
				_this._focusError(el)
			}
		},

		_focusError: function(el) {
			$(el).closest(".form-group").find('input,select').focus();
		}

	});
}(Tc.$));

(function ($) {
	'use strict';
	/**
	 * Teaserfocus module implementation.
	 * https://gitlab.namics.com/snippets/2
	 *
	 * @author Ilario Engler <ilario.engler@namics.com>
	 * @namespace Tc.Module
	 * @class Teaserfocus
	 * @extends Tc.Module
	 */
	Tc.Module.Teaserfocus = Tc.Module.extend({

		selectors: {
			tabPane: '.tab-pane.js-equalheight-element',
			tabContainer: '.tab-content'
		},

		on: function (callback) {
			this.$ctx.imagesLoaded(this.setHeight.bind(this));

			callback(); // !do not remove
		},

		setHeight: function () {
			var that = this;
			var max = 0;

			$(this.selectors.tabPane, this.$ctx).each(function (index, item) {
				var itemHeight = parseInt(getComputedStyle(item).getPropertyValue('height'), 10);

				if (max < itemHeight) {
					max = itemHeight;
				}
			});
			this.$ctx.find(that.selectors.tabContainer).height(max);
		}
	});
}(Tc.$));

(function ($) {
	"use strict";
	/**
	 * Mainnavigation module implementation.
	 * https://gitlab.namics.com/snippets/2
	 *
	 * @author  <>
	 * @namespace Tc.Module
	 * @class Mainnavigation
	 * @extends Tc.Module
	 */
	Tc.Module.Mainnavigation = Tc.Module.extend({

		init: function ($ctx, sandbox, modId) {
			this._super($ctx, sandbox, modId);


		},

		on: function (callback) {
			var _this = this;

			//load flyout content a bit after the page was loaded
			setTimeout(function () {
                _this.loadFlyoutContent();
            },100);

			callback(); // !do not remove
		},
		
		after: function () {

		},
		/**
		 * on page load, trigger ajax requests to fetch the flyout content and prepare the html structure
		 * on click, initialize the modules through the sandbox
		 */
		loadFlyoutContent: function () {
			var _this = this;
			$("li.dropdown", this.$ctx).each(function () {
				var $li = $(this),
					$a = $li.children("a.dropdown-toggle").first(),
					dataUrl = $a.data("url") || "",
					$container = $("ul.dropdown-menu > li > div.yamm-content > div.row > div.main-column", $li);

				if (dataUrl && $container.children().length === 0) {
                    var $fluidContainer = _this.$ctx.find('.container-fluid'),
                        loadingClass = 'loading',
                    	initializedClass = 'initialized';

                    if($("body").hasClass("skin-layout-author")) {
						dataUrl += dataUrl.indexOf('?') == -1 ? "?wcmmode=disabled" : "&wcmmode=disabled";
					}

					$fluidContainer.addClass(loadingClass);

					$.ajax({
						type: "GET",
						url: dataUrl,
						success: function (data) {
							//store ajax content into the correct position
                            $container.html(data);

                            //wait for click to trigger modules sandbox init
                            $li.on('click', function () {
                                if (!$container.hasClass(initializedClass)){
                                    $container.addClass(initializedClass);

									//wait for the menu to open, then init modules
									setTimeout(function () {
										$fluidContainer.removeClass(loadingClass);
										_this.sandbox.addModules($container);

                                        if(window.BIT_ETRACKER) {
                                            BIT_ETRACKER.addEvents(_this.$ctx);
                                        }

                                    }, 0);

								}
                            });

						},
						error: function () {
							$fluidContainer.removeClass(loadingClass);
						}
					});
				}
			});
		}
	});
}(Tc.$));

(function($) {
	"use strict";
	/**
	 * FormWebcode module implementation.
	 * https://gitlab.namics.com/snippets/2
	 *
	 * @author  <>
	 * @namespace Tc.Module
	 * @class FormWebcode
	 * @extends Tc.Module
	 */
	Tc.Module.FormWebcode = Tc.Module.extend({

		init: function($ctx, sandbox, modId) {
			this._super($ctx, sandbox, modId);
		},

		on: function(callback) {
			this.bindAll(
				"onFormSubmit"
			);
			this.$$("form").on("submit", this.onFormSubmit);
			callback(); // !do not remove
		},

		after: function() {

		},

		onFormSubmit: function(ev) {
			var _this = this,
				$body = $("body"),
				$form = $(ev.currentTarget),
				formData = $form.serialize(),
				formError = $form.data("error"),
				url = $form.attr("action") + "?" + formData;
			ev.preventDefault();
			_this.showError("", $form);
			$.ajax({
				url: url + ($body.is(".cq-wcm-edit") || $body.is(".cq-wcm-preview") ? "&wcmmode=disabled" : ""),
				type: 'GET',
				beforeSend: function (xhr) {
					xhr.overrideMimeType('text/plain; charset=UTF-8');
				},
				success: function () {
					$("p.error", _this.$ctx).remove();
					window.location = url;
				},
				error: function () {
					_this.showError(formError, $form);
				}
			});
		},

		 showError: function (formError, $form) {
			 var _this = this;

			 if ($("p.error", _this.$ctx).length !== 0) {
				 $("p.error", _this.$ctx).html(formError);
			 }
			 else {
				 $form.after("<p class='error'>" + formError + "</p>");
			 }
		 }



	});
}(Tc.$));

(function($) {
	"use strict";
	/**
	 * OneLineForm module implementation.
	 * https://gitlab.namics.com/snippets/2
	 *
	 * @author sbartels <sebastian.bartels@namics.com>
	 * @contributors tmay <thomas.may@namics.com>
	 * @namespace Tc.Module
	 * @class OneLineForm
	 * @extends Tc.Module
	 */
	Tc.Module.OneLineForm = Tc.Module.extend({
		init: function($ctx, sandbox, modId) {
			this._super($ctx, sandbox, modId);
		},

		on: function(callback) {
			this.bindAll(
				"onSubmitForm",
				"onChangeQuantity"
			);
			this.initForm();
			callback(); // !do not remove
		},
		initForm: function() {
			if ($("html").hasClass("no-localstorage")) {
				this.$$(".js-form-group").html(this.template(this.$$("#onelineform-error-template").html(), { "error": "no-cookie"}));
			} else {
				this.$quantity = this.$$(".js-quantity");
				this.sandbox.subscribe("Basket", this);
				this.$quantity.val(this.$quantity.attr("min"));
				this.$quantity.on("change", this.onChangeQuantity).trigger("change");
				this.$$(".js-one-line-form").on("submit", this.onSubmitForm);
			}
		},
		onSubmitForm: function(ev) {
			ev.preventDefault();
			this.amountValidation();
			if(!$(ev.currentTarget).is(":disabled")) {
				this.saveDataStorage();
				$.toast({
					text: this.getCartToastMessage() + this.amount + 'x ' + this.$$( "input[name='productTitle']").val(),
					showHideTransition: 'slide',
					hideAfter : 5000,
					position: 'bottom-right',
					textColor: '#3c763d',
					loaderBg: "#3c763d",
					loader: true,
					icon: 'success',
					class: 'alert alert-success'
				})
				this.fire("ShowDataStorage");
			}
		},
		getCartToastMessage: function() {
			var defaultMessage = 'The item has been added to the shopping cart:';
			var i18nMessage = Granite.I18n.get("core.components.content.wsdetails.cart.toast.message");
			if (i18nMessage) {
				return i18nMessage;
			} else {
				return defaultMessage;
			}
		},
		onChangeQuantity: function(ev) {
			this.amount = parseInt($(ev.currentTarget).val());
			this.amountValidation();
		},
		amountValidation: function() {
			var minAmount = parseInt(this.$quantity.attr("min"), 10)
				,maxAmount = parseInt(this.$quantity.attr("max"), 10)
				;

			if (this.amount < minAmount && this.amount < maxAmount) {
				this.$$(".js-error-container").html(this.template(this.$$("#onelineform-error-template").html(), { "error": "min" }));
				this.$$("#submit").prop("disabled", true);
			} else if (this.amount > maxAmount) {
				this.$$(".js-error-container").html(this.template(this.$$("#onelineform-error-template").html(), { "error": "max" }));
				this.$$("#submit").prop("disabled", true);
			} else {
				this.$$(".js-error-container").empty();
				this.$$("#submit").prop("disabled", false);
			}
		},
		saveDataStorage: function() {
			// Find Product Text for the Storage and add to a Array
			var product = this.$$( "input[name='productTitle']").val()
				,productIntern = this.$$( "input[name='productId']").val()
				,orderForm = JSON.parse(localStorage.getItem("orderForm")) || []
				,isProcuctInList = false
				,i
				;

			for (i = 0; i<orderForm.length; i++) {
				// Check if current product already is in order list
				if (orderForm[i].productId === productIntern) {
					orderForm[i].quantity = parseInt(orderForm[i].quantity) + parseInt(this.amount);
					isProcuctInList = true;
					break;
				}
			}
			// Add the product as new item if it is not in list
			if (!isProcuctInList) {
				orderForm.push({
					"id": (orderForm.length + 1),
					"productTitle": product,
					"productId": productIntern,
					quantity: this.amount
				});
			}

			// Read Localstorage with key orderForm
			localStorage.orderForm = JSON.stringify(orderForm);
		},
		after: function() {
		}
	});
}(Tc.$));

(function($) {
	"use strict";
	/**
	 * Basket module implementation.
	 * https://gitlab.namics.com/snippets/2
	 *
	 * @author sbartels <sebastian.bartels@namics.com>
	 * @namespace Tc.Module
	 * @class Basket
	 * @extends Tc.Module
	 */
	Tc.Module.Basket = Tc.Module.extend({

		init: function($ctx, sandbox, modId) {
			this._super($ctx, sandbox, modId);
		},

		on: function(callback) {
			// Trigger Connect
			this.sandbox.subscribe("Basket", this);
			this.isBasket();
			this.showDataStorage();
			this.deleteDataStorage();
			this.showBasketLink();
			callback(); // !do not remove
		},
		isBasket: function() {
			if($(".mod-orderform").length && !this.$ctx.parent().hasClass("mod-orderform")) {
				this.$ctx.hide();
			}
			if(this.$ctx.parent().hasClass("mod-orderform")) {
				this.$ctx.parent(".mod-orderform").parents("form").submit(function() {
					localStorage.basket = window.location.href;
				});
			}
		},
		onShowDataStorage: function() {
			this.showDataStorage();
			this.showBasketLink();
		},
		showDataStorage: function() {
			var dataStorage = localStorage.orderForm
				,data
				;
			if (dataStorage) {
				data = {
					"data": $.parseJSON(localStorage.getItem("orderForm"))
				};
				this.$ctx.find('.js-order-list').html(this.template(this.$ctx.find('#order-list-template').html(), data));
			}
			this.writeGenericField();
		},
		writeGenericField: function() {
			var mod = this
				,xallAttributes = ""
				,$el
				;
			if(mod.$ctx.parent().hasClass("mod-orderform")) {
				$(".order-list input[name^='order_']", mod.$ctx).each(function(i, el) {
					$el = $(el);
					xallAttributes += $el.attr("name") + "=" + $el.attr("value") + ",";
				});
				xallAttributes = xallAttributes.slice(0,-1);
				if($("input.orderform-input", mod.$ctx).length){
					$("input.orderform-input", mod.$ctx).val(xallAttributes);
				} else {
					mod.$ctx.append("<input name='orderform' class='orderform-input' type='hidden' value='"+xallAttributes+"'>");
				}
			}
			this.updateCartCount();
		},
		showBasketLink: function() {
			var mod = this
				,basketLink = $(".basket-link", mod.$ctx)
				,error = $(".error.empty", mod.$ctx)
				;
				if ($(".order-list", mod.$ctx).find("li").length) {
					if(mod.$ctx.parent().hasClass("mod-orderform")) {
						mod.$ctx.show();
					} else if(!$(".mod-orderform").length) {
						mod.$ctx.show();
					}
					basketLink.show();
					if(mod.$ctx.parent().hasClass("mod-orderform")) {
						error.hide();
					}
				} else {
					basketLink.hide();
					if(mod.$ctx.parent().hasClass("mod-orderform")) {
						error.show();
					} else {
						mod.$ctx.hide();
					}
				}
		},
		deleteDataStorage: function() {
			var mod = this
				,i
				,domId
				,json
				,$el
				;
			$(".order-list", mod.$ctx).on("click", ".storage-delete", function(e) {
				e.preventDefault();
				$el = $(this);
				domId = $el.closest("li").attr("id");
				json = JSON.parse(localStorage.orderForm);
				$el.closest("li").remove();

				for (i=0;i<json.length;i++) {
					if (json[i].id === parseInt(domId)) {
						json.splice(i,1);
					}
				}
				localStorage.orderForm = JSON.stringify(json);
				mod.showBasketLink();
				mod.writeGenericField();
			});

		},
		updateCartCount : function() {
			var orderForm = JSON.parse(localStorage.getItem("orderForm"));
			if (orderForm) {
				var cartCount = 0;
				for (var i = 0; i<orderForm.length; i++) {
					cartCount+=parseInt(orderForm[i].quantity);
				}
				if ($(".shopping-cart-count") && $(".shopping-cart-count").length) {
					$(".shopping-cart-count").text(cartCount);

					if (cartCount > 0) {
						$(".shopping-cart-count").show();
					} else {
						$(".shopping-cart-count").hide();
					}
				}
			}
		},
		after: function() {
		}
	});
}(Tc.$));

(function($) {
	"use strict";
	/**
	 * Externalcontent module implementation.
	 * https://gitlab.namics.com/snippets/2
	 *
	 * @author  <>
	 * @namespace Tc.Module
	 * @class Externalcontent
	 * @extends Tc.Module
	 */
	Tc.Module.Externalcontent = Tc.Module.extend({

		init: function($ctx, sandbox, modId) {
			this._super($ctx, sandbox, modId);

			

		},

		on: function(callback) {
			var _this = this,
				$ctx = _this.$ctx;



			callback(); // !do not remove
		},

		after: function() {
			var _this = this;
			_this.dataUrl = $(".content", _this.$ctx).data("url");
			_this.loadContent(_this.dataUrl);

		},
		loadContent: function(url, attributes, type) {
			url = url || "";
			var _this = this,
				aUrl = attributes !== undefined && attributes !== null ? url + attributes : url;

			type = type !== undefined ? type : "GET";

			if($("body").hasClass("skin-layout-author")) {
				aUrl += aUrl.indexOf('?') == -1 ? "?wcmmode=disabled" : "&wcmmode=disabled";
			}
			
			if(aUrl) {
				$.ajax({
					type: type,
					url: aUrl
				}).done(function(data) {
					$(".content", _this.$ctx).html(data);
					_this._bindClickEvents();
				});
			}

		},
		_bindClickEvents: function() {
			var _this = this;
			$("a", _this.$ctx).unbind("click").on( "click", function(event) {
				var url = $(this).attr("href");
				//only load normal links via ajax. let downloads through
				if (_this.isNormalLink(url) && !$(this).is('[download]')) {
					_this.loadContent(url);
					event.preventDefault();
				}
			});
			$("form", _this.$ctx).unbind("submit").on( "submit", function(event) {
				var method = $(this).attr("method");
				var url = $(this).attr("action")
					,parameter = $(this).serialize();
				_this.loadContent(url + "?" + parameter, null, method);
				event.preventDefault();
			});
		} ,
		stringContains: function (str, search) {
			return str.indexOf(search) !== -1;
		},
	    stringContainsAny: function (str, strArray) {
			for (var i=0; i < strArray.length; i++) {
				if (this.stringContains(str, strArray[i])){
					return true;
				}
			}
			return false;
		},
		stringEndsWith: function (str, suffix) {
			return str.indexOf(suffix, str.length - suffix.length) !== -1;
		},
	    isNormalLink: function (url) {
			return this.stringEndsWith(url, ".html");
		}
	});
}(Tc.$));

(function($) {
	"use strict";
	/**
	 * Search module implementation.
	 * https://gitlab.namics.com/snippets/2
	 *
	 * @author  <>
	 * @namespace Tc.Module
	 * @class Search
	 * @extends Tc.Module
	 */
	Tc.Module.Search = Tc.Module.extend({

		init: function($ctx, sandbox, modId) {
			var _this = this;
			this._super($ctx, sandbox, modId);

			this.$searchbox = $("form.search-box", _this.$ctx);
			this.dataUrl = this.$searchbox.data("url");
			this.content = this.$searchbox.data("content");
			this.documents = this.$searchbox.data("documents");
			this.validationMsg = "";
			this.minLength = 0;
            this.breakpointS = false;

			// add jquery rule for detecting double whitespaces
			// prevents user from using whitespaces to make an empty search
			jQuery.validator.addMethod("noDoubleSpace", function(value, element) {
				return value.indexOf("  ") < 0;
			});
		},

		on: function(callback) {
			var _this = this;
			_this._readHash();

			_this.$searchbox.submit(function( event ) {
				event.preventDefault();
			});

			callback(); // !do not remove
		},

		after: function() {
			var _this = this;
			_this._initValidation();
			_this._setCurrentDate();
			//$( ".form", _this.$ctx).submit();

		},

        buildQueryUrl: function (searchGetParam, content, dataUrl) {
			var dateFrom = $("#realmsearch_datefrom").val() || "";
			var dateTo = $("#realmsearch_dateto").val() || "";

            return dataUrl + "." + content + ".html?_charset_=UTF-8&search=" + encodeURIComponent(searchGetParam) + "&datefrom=" + dateFrom + "&dateto=" + dateTo;
        },

		startAjaxRequest: function(type) {
			var _this = this;
			var search = $("#inputSearch", _this.$ctx ).val();
			var hiddenResultContainer = '.search-results .collapsify + .tab-content';
			var countTabPane = $('.search-results .tab-pane').length;
			$(_this.$ctx).addClass("loading");
			$('#totalResults',_this.$ctx).html("0");
            _this.breakpointS = false;

            // mobile actions start
            if(window.innerWidth<769){
                _this.breakpointS = true;
            }
            // mobile actions end

            var contentPagePromise;
			var contentPagesDynamicContent = $("#contentPagesDynamicContent", _this.$ctx);
            if(contentPagesDynamicContent.length > 0){
                $( "#contentPagesDynamicContent", _this.$ctx ).addClass("loading");
				contentPagePromise = $.get(this.buildQueryUrl(search, _this.content, _this.dataUrl), function (data) {
					contentPagesDynamicContent.html(data).removeClass("loading");
				});
			} else {
                // if the element is not present in the dom, we just return a resolved deferred. "do nothing"
				contentPagePromise = $.Deferred().resolve();
            }

            var documentPromise;
			var documentsDynamicContent = $("#documentsDynamicContent", _this.$ctx);
            if(documentsDynamicContent.length > 0){
                $( "#documentsDynamicContent", _this.$ctx ).addClass("loading");
				documentPromise = $.get(this.buildQueryUrl(search, _this.documents, _this.dataUrl), function (data) {
					documentsDynamicContent.html(data).removeClass("loading");
				});
            } else {
            	// if the element is not present in the dom, we just return a resolved deferred. "do nothing"
            	documentPromise = $.Deferred().resolve();
			}

            $.when(
				contentPagePromise, documentPromise
			).then(function() {

				if(_this.breakpointS && countTabPane < 2) {
                    $(hiddenResultContainer).show().addClass('noTabLinkOnTop');
                }

				_this._resetFilter();
				_this._initPagination();
				_this._initFilter();
				_this._writeHash(search);
				_this._countTotalResults();
				$(_this.$ctx).removeClass("loading");
				$("#searchResults", _this.$ctx).show();
				if(window.BIT_ETRACKER && BIT_ETRACKER.trackSearch) {
					BIT_ETRACKER.trackSearch(_this.$ctx);
				}
			});
		},

		loadPage: function(page,type,attributes){
			var _this = this
				,search = $(".tab-pane.active .dynamic-content input[name='search']").val() || $("#inputSearch", _this.$ctx ).val()
				,nAttributes = attributes !== undefined ? "&" +  attributes : ""
				,bottomPaging = attributes.indexOf('pgbtm=1') > 0
				,offsetTop = _this.$ctx.offset().top - 100
			;

			var paginationPortion = "&page=" + page + nAttributes;

            if (type === 'contentPages'){
				$( "#contentPagesDynamicContent", _this.$ctx ).addClass("loading");
				$.get(this.buildQueryUrl(search, _this.content, _this.dataUrl) + paginationPortion, function(data ) {
					$( "#contentPagesDynamicContent", _this.$ctx ).html( data ).removeClass("loading");
					if(bottomPaging) {
						$('html, body').stop().animate({'scrollTop': offsetTop}, 200);
					}
					_this._initPagination();
					_this._initFilter();
					_this._countTotalResults();
				});
			}
			if (type === 'documentsPages'){
				$( "#documentsDynamicContent", _this.$ctx ).addClass("loading");
				$.get(this.buildQueryUrl(search,_this.documents,_this.dataUrl) + paginationPortion, function( data ) {
					$( "#documentsDynamicContent", _this.$ctx ).html( data ).removeClass("loading");
					if(bottomPaging) {
						$('html, body').stop().animate({'scrollTop': offsetTop}, 200);
					}
					_this._initPagination();
					_this._initFilter();
					_this._countTotalResults();
				});
			}
		},

		_initValidation: function(){

			var _this = this;
			var search = $( "form #inputSearch", _this.$ctx);
			_this.validationMsg = search.data("message");
			_this.minLength = search.data("minlength");

			$( "form", _this.$ctx ).validate({
				errorContainer: "#errorMessage",
				errorLabelContainer: "#errorMessage ul",
				wrapper: "li",
				submitHandler: function(form) {
					_this.startAjaxRequest(0,'');
				},
				rules: {
					searchField : {
						noDoubleSpace: true,
						required: true,
						minlength: _this.minLength
					}
				},
				messages: {
					searchField: {
						noDoubleSpace: _this.validationMsg,
						required: _this.validationMsg,
						minlength: _this.validationMsg
					}
				}
			});
		},
		_initFilter: function(){
			var _this = this;
			$(".search-filter-form button", _this.$ctx).unbind("click").on( "click", function(event) {
				var loadPage = 0
					,type = $(this).closest(".tab-pane").attr("id")
					,attributes = $(this).closest(".search-filter-form").serialize()
					;

				if(type === undefined) {
					var dynamicType = $(this).closest(".search-filter-form").attr("id");
					if(dynamicType === "pagesForm"){
						type = "contentPages";
					}
					if(dynamicType === "documentsForm"){
						type = "documentsPages";
					}
				}
				_this.loadPage(loadPage, type, attributes);
				event.preventDefault();
			});

		},
		_initPagination: function(){
			var _this = this;
			$(".pagination li:not(.active) a", _this.$ctx).unbind("click").on( "click", function(event) {
				var loadPage = $(this).data("loadpage")
					,type = $(this).closest(".tab-pane").attr("id");

				if(type === undefined) {
					var dynamicType = $(this).closest(".dynamic-content").attr("id");
					if(dynamicType === "contentPagesDynamicContent"){
						type = "contentPages";
					}
					if(dynamicType === "documentsDynamicContent"){
						type = "documentsPages";
					}
				}

				// if bottom-pagination is clicked, say this to the loadPage-method
				var pagingBottom = ($(event.currentTarget).closest('.pg-bottom').length==1) ? "&pgbtm=1":"";

				_this.hiddenAttributes = "";
				$(this).closest(".tab-pane").find("input[type=hidden]").each(function() {
					_this.hiddenAttributes += ($(this).attr("name") + "=" + $(this).attr("value") + "&");
				});
				$(this).closest(".collapse").find("input[type=hidden]").each(function() {
					_this.hiddenAttributes += ($(this).attr("name") + "=" + $(this).attr("value") + "&");
				});
				_this.hiddenAttributes = _this.hiddenAttributes.slice(0, - 1);
				var attributes =  _this.hiddenAttributes !== undefined || _this.hiddenAttributes !== "" ? _this.hiddenAttributes : undefined;
				_this.loadPage(loadPage, type, attributes+pagingBottom);
				event.preventDefault();
			});
		},
		_writeHash: function(searchString) {
			var encodeSearchString = encodeURIComponent(searchString);
			if(window.location.hash !== encodeSearchString){
				window.location.hash = encodeSearchString;
			}
		},
		_readHash: function() {
			var _this = this
				,searchString =  window.location.hash.replace("#","")
				,decodeSearchString =  decodeURIComponent(searchString)
				;

			if (decodeSearchString && decodeSearchString !== "contentPages" && decodeSearchString !== "documentsPages"){
				var url = _this.dataUrl + ".results.html?_charset_=UTF-8&search=" + decodeSearchString;
				$.get(url, function() {
					$( "#inputSearch", _this.$ctx ).val(decodeSearchString);
					_this.$searchbox.submit();
				});
			}
		},
		_setCurrentDate: function(){
			var _this = this
			,today = new Date()
			,dd = today.getDate()
			,mm = today.getMonth()+1 //January is 0!
			,yyyy = today.getFullYear();

			if(dd<10) {
				dd='0'+dd;
			}

			if(mm<10) {
				mm='0'+mm;
			}

			today = yyyy + "-" + mm + "-" + dd;
			$("#newsForm input[name=endDate]", _this.$ctx).val(today);
		},

		_countTotalResults: function() {
			var _this = this;
			var totalResults = 0;
			var pgBottomSelector = $('.dynamic-content .pg-bottom');
			var pgBottomSelectorA, pgBottomSelectorB = '';

			if(_this.breakpointS) { // mobile
                pgBottomSelectorA = $('.search-results .collapsify .pg-bottom', _this.$ctx);  // google search mobile
                pgBottomSelectorB = $('.search-results .collapsify + .tab-content .pg-bottom', _this.$ctx); // site search mobile
                pgBottomSelector = (pgBottomSelectorB.length > pgBottomSelectorA.length) ? pgBottomSelectorB : pgBottomSelectorA;
            }

            pgBottomSelector.each(function (i,v) {
				totalResults += $(v).data("results");
			});

			$("#totalResults", _this.$ctx).html(totalResults);
		},

		_resetFilter: function(){
			var _this = this
				,$startDate = $("#newsForm input[name=startDate]", _this.$ctx)
				,$datepicker = $("#newsForm input[name=startDate]", _this.$ctx).next(".is-datepicker");
			$(".search-filter-form", _this.$ctx).each(function() {
				$("input[type='radio']", this).first().trigger("click");
			});
			$startDate.val($startDate.data("initial-value"));
			//is datepicker plugin in use (firefox/internet explorer)
			if($datepicker.length !== 0){
				$datepicker.datepicker('setDates', new Date($startDate.data("initial-value")));
			}
			_this._setCurrentDate();
			$(".nav-tabs li:first a", _this.$ctx).trigger("click");
		}

	});
}(Tc.$));

(function($) {
	"use strict";
	/**
	 * Slideshow module implementation.
	 * https://gitlab.namics.com/snippets/2
	 *
	 * @author  tmay <thomas.may@namics.com>
	 * @namespace Tc.Module
	 * @class Slideshow
	 * @extends Tc.Module
	 */
	Tc.Module.Slideshow = Tc.Module.extend({

		init: function($ctx, sandbox, modId) {
			this._super($ctx, sandbox, modId);
		},

		on: function(callback) {
			this.setSlideshowOptions(this.$$(".carousel"));
			callback(); // !do not remove
		},

		after: function() {

		},

		setSlideshowOptions: function($el) {
			$el.carousel({
				interval: $el.data("time")
			});
		}

	});
}(Tc.$));
(function($) {
	"use strict";
	/**
	 * Gallery module implementation.
	 * https://gitlab.namics.com/snippets/2
	 *
	 * @author  <>
	 * @namespace Tc.Module
	 * @class Imagegallery
	 * @extends Tc.Module
	 */
	Tc.Module.Imagegallery = Tc.Module.extend({

		init: function($ctx, sandbox, modId) {
			this._super($ctx, sandbox, modId);

		},

		on: function(callback) {
			/*this.bindAll(
				"_positionMagnifier"
			);*/
			var _this = this;
			this.images = [];
			this.activeImage = -1;
			this.activeURL = null;
			this.prevImage = null;
			this.nextImage = null;

			this.preload  = {};

			//DOM ELEMENTS
			this.$singleContainer = $(".single-view", this.$ctx);
			this.$prevPager = $(".pager_prev a", _this.$singleContainer);
			this.$nextPager = $(".pager_next a", _this.$singleContainer);
			this.$image = $("img", _this.$singleContainer);
			this.$description = $(".description", _this.$singleContainer);
			this.$closer = $("a.close-sv", _this.$singleContainer);

			_this._initGallery();

			callback(); // !do not remove
		},

		after: function() {
			var _this = this;
			//$(window).on("resize", $.debounce(200, _this._positionMagnifier));
		},

		_initGallery: function() {
			var _this = this;
			_this._linkMapper();
			//_this._positionMagnifier();
			_this._lightboxNavigation();
			//_this.$ctx.imagesLoaded(_this._positionMagnifier);
		},
		_lightboxNavigation: function() {
			var _this = this;
			$(".pagination .disabled a", _this.$ctx).click(function(e) {
				e.preventDefault();
			});
			$(".modal .carousel-control", _this.$ctx).click(function(e) {
				var currentIndex = $(this).closest(".col-sm-3").index()
					,imagesCount =  $(this).closest(".row").children(".col-sm-3").length
					,isLeft = $(this).hasClass("left")
					,isRight = $(this).hasClass("right")
					,newIndex
					,$currentModal = $(this).closest(".modal")
					,parentWrapper
					;
				if(isLeft) {
					//current image = first image?
					if(currentIndex === 0) {
						newIndex = imagesCount - 1;
					} else {
						newIndex = currentIndex - 1;
					}

				} else if(isRight) {
					//current image last image?
					if(currentIndex + 1 === imagesCount) {
						newIndex = 0;
					} else {
						newIndex = currentIndex + 1;
					}
				}
				$currentModal.removeClass("fade").modal('hide').addClass("fade");
				parentWrapper = $(".gallery-view .col-sm-3", _this.$ctx).get(newIndex);
				$(parentWrapper).find(".modal").removeClass("fade").modal('show').addClass("fade");


				e.preventDefault();
			});

		},
		_positionMagnifier: function() {
			this.$$(".thumbnail").each(function(){
				var $img = $("img", this),
					$icon = $(".fa.fa-search", this),
					$figure = $("figure", this),
					bottom = $figure.height() - $img.height(),
					right = $figure.width() - $img.width();

				if($icon.length){
					if(bottom !== 0) {
						bottom = (bottom / 2) - 1;
					}
					if(right !== 0) {
						right = (right / 2) - 1;
					}
					$icon.css({
						bottom : bottom,
						right: right
					});
				}
			});
		},

		_linkMapper: function () {
			var _this = this
				,$galleryEl = $(".gallery-single", _this.$ctx)
				;

			$galleryEl.each(function() {
				var $modal = $(this).siblings(".modal")
					,description = $(".modal-body .lbContent", $modal).html()
					,link = $modal.find("img").attr("src")
					,title = $modal.find(".modal-title").html()
					,alt = $modal.find("img").attr("alt")
					;
				_this.images.push([link, title, description, alt]);
			});

			$galleryEl.unbind("click").click(function(e) {
				var elementIndex = $galleryEl.index(this);
				return _this.changeImage(elementIndex);
			});
		},
		changeImage: function (imageIndex) {
			var _this = this;
			if (imageIndex >= 0) {
				_this.activeImage = imageIndex;
				_this.activeURL = _this.images[_this.activeImage][0];
				_this.prevImage = (_this.activeImage || 0) - 1;
				_this.nextImage = ((_this.activeImage + 1) % _this.images.length) || -1;

				_this.preload = new Image();
				_this.preload.onload = _this._adjustMarkup();
				_this.preload.src = _this.activeURL;

			}

			return false;
		},
		next: function () {
			return this.changeImage(this.nextImage);
		},
		prev: function () {
			return this.changeImage(this.prevImage);
		},
		close: function () {
			var _this = this;
			if($(_this.$ctx).hasClass("detail-view")) {
				$(_this.$ctx).removeClass("detail-view");
//				_this.$ctx.height("auto");
			}
		},

		_adjustMarkup: function () {

//			this.$ctx.height("auto");

			var _this = this
				,el = _this.images[_this.activeImage]
				,singleViewHeight = _this.$singleContainer.height()
				,headline = el[1] !== undefined ? "<h3>" + el[1] + "</h3>" : ""
				;
//			_this.$ctx.height(singleViewHeight);
			_this.$image.attr("src", _this.activeURL).attr("alt", el[3]);
			_this.$description.html(headline).append(el[2]);

			if(_this.prevImage === -1) {
				_this.$prevPager.parent("li").hide();
			} else {
				_this.$prevPager.parent("li").show();
			}
			if(_this.nextImage === -1) {
				_this.$nextPager.parent("li").hide();
			} else {
				_this.$nextPager.parent("li").show();
			}
			_this.$prevPager.unbind("click").click(function() {
				return _this.prev();
			});
			_this.$nextPager.unbind("click").click(function() {
				return _this.next();
			});
			_this.$closer.unbind("click").click(function(event) {
				_this.close();
				event.preventDefault();
			});

			if(!$(_this.$ctx).hasClass("detail-view")) {
				$(_this.$ctx).addClass("detail-view");
			}

		}

	});
}(Tc.$));

(function ($) {
    "use strict";
    /**
     * Searchfield module implementation.
     * https://gitlab.namics.com/snippets/2
     *
     * @author  <>
     * @namespace Tc.Module
     * @class Searchfield
     * @extends Tc.Module
     */
    Tc.Module.Searchfield = Tc.Module.extend({

        init: function ($ctx, sandbox, modId) {
            this._super($ctx, sandbox, modId);

        },

        on: function (callback) {
            var _this = this;
            this.$$('.form-search .search-field').typeahead('destroy');
            $("form", _this.$ctx).submit(function (event) {
                var actionUrl = $("form", _this.$ctx).attr("action")
                    ,searchString = $("input[name='query']", _this.$ctx).val()
                    ,isAdminSearch = $("#admin-directory-search-field", _this.$ctx).length > 0
                    ,encodeSearchString = encodeURIComponent(searchString)
                    ,adminUrl = ''
                    ,$adminDirSearchStringInput = null
                    ,$adminDirSearchLanguageInput = null
                ;

                if (!isAdminSearch) {
                    if ($(".mod-search").length !== 0 && $(".realsmsearch-form").length === 0) { // go to search result page if the current page contains a realm search
                        $(".mod-search #inputSearch").val(searchString).focus();
                        $(".mod-search form").submit();
                        if ($(".nav-mobile").hasClass("nav-open")) {
                            $("#search-field-mobile").closest(".nav-mobile-menu.dropdown-toggle").click();
                        }

                    } else {
                        window.location = actionUrl + "#" + encodeSearchString;

                    }
                } else {
                    $adminDirSearchStringInput = $("input.js-admin-dir-search-field", _this.$ctx);
                    $adminDirSearchLanguageInput = $("input.js-admin-dir-language-field", _this.$ctx);
                    adminUrl = actionUrl + '?' + $adminDirSearchStringInput.attr('name') +'='+escape($adminDirSearchStringInput.val())+ '&' + $adminDirSearchLanguageInput.attr('name') +'='+escape($adminDirSearchLanguageInput.val())
                    window.open(adminUrl, "_blank");

                }
                event.preventDefault();
            });
            callback(); // !do not remove
        },

        after: function () {
            var _this = this;
        }

    });
}(Tc.$));


(function($) {
	"use strict";
	/**
	 * Dynamic module implementation.
	 * https://gitlab.namics.com/snippets/2
	 *
	 * @author  <>
	 * @namespace Tc.Module
	 * @class Dynamic
	 * @extends Tc.Module
	 */
	Tc.Module.Dynamic = Tc.Module.extend({

		isDynamicContentLoaded: false,
		freshPageLoad : false,
		$dynForm : $('#content form').eq(0),

		init: function($ctx, sandbox, modId) {
			this._super($ctx, sandbox, modId);

			this.bindAll(
				'contentLoaded',
				'onPaginationClick',
				'onAccordionClick'

			);


			this.currentWindow = Tc.Utils.WCM.getCurrentWindow();
			this.dataUrl = null;
			// offer helper
			this.initUrlParamHelper();
			this.getQueryVars();

		},

		getQueryVars : function(){

			var that = this,
				$ctx = that.$ctx,
				urlParamData = null,
				valueArray = new Array,
				formValueFromUrl = '';

			that.$dynForm.find('.form-group input[data-url-param][type=text], .form-group select[data-url-param]').each(function(i,v){
				valueArray.length = 0;
				urlParamData = $(v).data('urlParam');

				if (urlParamData !== undefined && $.urlParam(urlParamData) !== '') {
					formValueFromUrl = that._decodingValue($.urlParam(urlParamData));
                    if (v.nodeName === 'SELECT') {
                        if (v.multiple) {
                            $(v).val(formValueFromUrl.split(','));
                        } else {
                            $(v).val(formValueFromUrl);
                        }
                        $(v).trigger("chosen:updated");

                    } else {
                        // value to simple field
                        $(v).val(formValueFromUrl);
                    }

                }

			});


		},
		initUrlParamHelper: function(){

			var that = this;

			// offer url-param-return
			$.urlParam = function(name, url) {
				if (!url) {
					url = that.currentWindow.location.href;
				}
				var results = new RegExp('[\\?&]' + name + '=([^&#]*)').exec(url);
				if (!results) {
					return '';
				}
				return results[1] || undefined;
			}
		},

		on: function(callback) {
			var _this = this;
			callback(); // !do not remove
		},

		after: function() {
			this.dataUrl = this.$ctx.data("url");
			this.dataInterval = this.$ctx.data("interval");
			this.pageIndexParam = this.$ctx.data('pageindex-param') || 'pageIndex';

			if(this.$ctx.data("initialload") !== 0) {
				// page allready loaded, only call data-url
				this.loadContent(this.dataUrl,null,true);
				if(this.dataInterval) {
					var that = this;
					setInterval(function () { that.loadContent(that.dataUrl, null, true) }, this.dataInterval * 1000);
				}
			} else {
				// run initial methodes
				this._initEvents();
			}
			$(window).trigger("resize");
		},

		// replacestate of history , add url-variables without reloading the page
		// MODIMPL-114
		updateUrl: function(newHtml){
			var that = this,
				$addParams = $(newHtml).find('.add-param'),
				urlParamName = '',urlParamValue = '',
				authorModeString = 'wcmmode',
				arrQueryString = new Array();

			if($.urlParam(authorModeString)){
				arrQueryString.push('wcmmode=disabled')
			}

			$addParams.each(function(i,v){

				urlParamName = $(v).data('urlParam');
				urlParamValue = '';

				if(urlParamName){
					if($.urlParam(urlParamName) && that.freshPageLoad){
						urlParamValue = $.urlParam(urlParamName);
					}
					else {
						if($(v).val().length>0)
							urlParamValue = that._encodingValue($(v).val());
					}

					if(urlParamValue.length>0) {
						if(!(urlParamName == 'dyn_pageIndex' && urlParamValue == 0)) {
							arrQueryString.push(urlParamName + '=' + urlParamValue);
						}
					}

				}
			});

			that._replaceStateHelper(arrQueryString);

		},

		_decodingValue: function(decodeString){
			var decodedString = '';
			decodedString = decodeURIComponent(decodeString);
			return decodedString
		},

		_encodingValue: function(encodeString){
			var encodedString = '';
			encodedString = encodeURIComponent(encodeString);
			return encodedString
		},

		_replaceStateHelper: function(rsQueryArray){
			var _rsFilename = location.pathname.substring(location.pathname.lastIndexOf('/')+1),
				_rsQueryArray = rsQueryArray.join('&') || '';

			if(_rsQueryArray.length>0) {
				history.replaceState({}, '' , _rsFilename + '?' + _rsQueryArray);
			}
		},

		_initEvents: function() {
			this.$ctx.addClass("done");
			this._initPagination();
			this._initAccordion();
		},

		loadContent: function(originalUrl, attributes, pageload) {
			var that = this,
                url = originalUrl || "",
				qsAttributes = that.checkQueryStrings() || '',
				formAttributesCharset = '_charset_=UTF-8&';

			that.freshPageLoad = pageload;

			url = url.replace("{currentPath}", that.currentWindow.location.pathname + that.currentWindow.location.search);
			url = url.replace("{currentParams}", that.currentWindow.location.search.replace("?", "").replace(/(^|&)dyn_/g, "$1"));

			if($("body").hasClass("skin-layout-author")) {
				url += url.indexOf('?') == -1 ? "?wcmmode=disabled" : "&wcmmode=disabled";

				if(that.freshPageLoad && !Tc.Utils.Lib.stringIsBlank(qsAttributes)){
					url += '&' + formAttributesCharset + qsAttributes;
				}
			} else {
				if(that.freshPageLoad && !Tc.Utils.Lib.stringIsBlank(qsAttributes)){
					url += '?' + formAttributesCharset + qsAttributes;
				}
			}



			this.$ctx.removeClass("done").addClass("loading");
			$.ajax({
				type: "GET",
				url: url,
				data: attributes,
				success: this.contentLoaded
			});
		},

		onLoadContent: function(param){
			var that = this;

			if(param.url === undefined){
				param.url = this.dataUrl;
			}
			// form post
			this.loadContent(param.url, param.attributes, false);
		},

		onInitialLoadContent: function(param){
			if (!this.isDynamicContentLoaded) {
				this.onLoadContent(param);
			}
		},

		onUnloadContent: function() {
			this.isDynamicContentLoaded = false;
		},

		contentLoaded: function(data){
			this.isDynamicContentLoaded=true;
			this.$ctx.html(data);
			this._initEvents();
			this.fire('contentDone');
			this.updateUrl(data);
			this.$ctx.removeClass("loading");
			this.sandbox.addModules(this.$ctx);
		},

		_initPagination: function() {
			this.$$("ul.pagination li:not(.active) a").off("click.pagination").on("click.pagination", this.onPaginationClick);
		},

		onPaginationClick: function(ev){
			ev.preventDefault();
			var loadPage = $(ev.currentTarget).data("loadpage"), // 1
				$addParams = this.$$('.add-param[name!="'+this.pageIndexParam+'"]'), //
				// CNGIMPL-2943 - performance issue call paging without url-variable to enable caching
				attributes = ($addParams.length !== null && $addParams.length > 0) ? this.pageIndexParam+"=" + loadPage + "&" + $addParams.serialize() : "",
				replaceddataUrl = decodeURI(this.dataUrl).replace("{}", loadPage);

			this.loadContent(replaceddataUrl, attributes, false);
		},

		_initAccordion: function () {
			if(!this.isDynamicContentLoaded && this.$ctx.data("accordion") === 1) {
				this.$ctx.prev("a.collapsed").on("click.accordion", this.onAccordionClick);
			}
		},

		onAccordionClick: function () {
			this.loadContent(this.dataUrl, null, true);
			this.$ctx.prev("a.collapsed").off("click.accordion");
		},

		checkQueryStrings: function(){
			var that = this,
				docLocSearch = that.currentWindow.location.search,
				queryString = docLocSearch.replace('?',''),
				strKeyValue = null,
				formFieldName = '',
				returnString = '';

				var querystringKeyValueArray = queryString.split('&');
				for(var iq=0;iq<querystringKeyValueArray.length;iq++){
					strKeyValue = querystringKeyValueArray[iq];
					querystringKeyValueArray[iq] = strKeyValue.split('=');

					if(that.$dynForm.find("[data-url-param='"+querystringKeyValueArray[iq][0]+"']").length>0){

						formFieldName = that.$dynForm.find("[data-url-param='"+querystringKeyValueArray[iq][0]+"']").attr('name');
						returnString += '&' + formFieldName + '=' + querystringKeyValueArray[iq][1];
					}
				}

				return returnString.substring(1);

		}

	});
}(Tc.$));

(function ($) {
	"use strict";
	/**
	 * Nsbabonnement module implementation.
	 *
	 * @author  <>
	 * @namespace Tc.Module
	 * @class Nsbabonnement
	 * @extends Tc.Module
	 */
	Tc.Module.Nsbabonnement = Tc.Module.extend({

		init: function ($ctx, sandbox, modId) {
			this._super($ctx, sandbox, modId);
		},

		on: function (callback) {
			Tc.Utils.Lib.initValidation(this.$$('form'));
			callback(); // !do not remove
		},
		
		after: function () {

		}
	});
}(Tc.$));

(function ($) {
	"use strict";
	/**
	 * Newslist module implementation.
	 * https://gitlab.namics.com/snippets/2
	 *
	 * @author  <stefan.baur@namics.com>
	 * @namespace Tc.Module
	 * @class Newslist
	 * @extends Tc.Module
	 */
	Tc.Module.Newslist = Tc.Module.extend({
		on: function (callback) {
			var _this = this;

			//this causes those callbacks to be executed in the scope of the module, not the scope of the bound element
            _this.bindAll(
                "onSearchFormSubmit"
            );

            callback(); // !do not remove
		},

        after: function () {
            this.$$(".newslist-form").on('submit', this.onSearchFormSubmit);
        },

        onSearchFormSubmit: function(ev){
			ev.preventDefault();
			var $searchForm = $(ev.currentTarget),
				attributes = $searchForm.length !== null ? "pageIndex=" + 0 + "&" + $searchForm.serialize() : "pageIndex=" + 0;
			this.fire('loadContent', {attributes:attributes});
        }

	});
}(Tc.$));

(function ($) {
	"use strict";
	/**
	 * Nsbnewslist module implementation.
	 * https://gitlab.namics.com/snippets/2
	 *
	 * @author  <>
	 * @namespace Tc.Module
	 * @class Nsbnewslist
	 * @extends Tc.Module
	 */
	Tc.Module.Nsbnewslist = Tc.Module.extend({

		init: function ($ctx, sandbox, modId) {
			this._super($ctx, sandbox, modId);
		},

		on: function (callback) {
			var _this = this;
			_this.bindAll(
				"_onSubmit",
				"onNewsFilterSubmit"
			);
			callback(); // !do not remove
		},

		after: function () {
			var _this = this;
			_this._initNewsFilter();
			_this._setEnddate();
			_this.$$("form").on("submit", _this._onSubmit);
		},

		_setEnddate: function () {
			var _this = this,
				date = new Date(),
				enddate = date.getFullYear() + '-' + ('0' + (date.getMonth()+1)).slice(-2) + '-' + ('0' + date.getDate()).slice(-2);

			if ($("input[name='endDate']", _this.$ctx).attr("value") === '') {
				$("input[name='endDate']", _this.$ctx).attr("value", enddate);
			}
		},

		_initNewsFilter: function () {
			this.$$("#newsFilter").on('submit', this.onNewsFilterSubmit);
		},

		onNewsFilterSubmit: function(ev){
			ev.preventDefault();
			var $newsFilter = $(ev.currentTarget),
				attributes = $newsFilter.length !== null ? "pageIndex=" + 0 + "&" + $newsFilter.serialize() : "pageIndex=" + 0;
			this.fire('loadContent', {attributes:attributes});
		},


		_onSubmit: function() {
			var _this = this,
				submit = true,
				$datepicker = _this.$$(".is-datepicker"),
				$el;
			if($datepicker.length){
				$datepicker.each(function(i, el) {
					$el = $(el);
					if(!$el.val()){
						submit = false;
						$el.focus();
					}
					return false;
				});
			}
			return submit;
		}

	});
}(Tc.$));
(function ($) {
	"use strict";
	/**
	 * Teaserlist module implementation.
	 * https://gitlab.namics.com/snippets/2
	 *
	 * @author  <>
	 * @namespace Tc.Module
	 * @class Teaserlist
	 * @extends Tc.Module
	 */
	Tc.Module.Teaserlist = Tc.Module.extend({
		on: function (callback) {
			var _this = this;

            _this._loadDots();
            $(window).on("viewportchange", $.debounce(500, function (e) {
                _this._loadDots(true);
            }));


			//this causes those callbacks to be executed in the scope of the module, not the scope of the bound element
            _this.bindAll(
                "_onReset",
                "onSearchFormSubmit"
            );

            callback(); // !do not remove
		},

        after: function () {
            this.$$("#teaserlist-form").on('submit', this.onSearchFormSubmit);
            this.$$("button[type='reset']").on("click", this._onReset);
            this.$$('.chosen-container').width('100%');
        },

		_onReset: function (ev) {
			var _this = this;
            setTimeout(function () {
            	if (_this.$('.pagination').size() === 0) {
                    window.location.assign(window.location.pathname);
				} else {
            		_this.$('.tags').trigger('chosen:updated');
                    _this.$('.child-tags').trigger('chosen:updated');
				}
			}, 10);
		},

        onSearchFormSubmit: function(ev){
            var usePaging = this.$ctx.data('paging-enabled');
            if (usePaging){
				ev.preventDefault();
				var $searchForm = $(ev.currentTarget),
					attributes = $searchForm.length !== null ? "pageIndex=" + 0 + "&" + $searchForm.serialize() : "pageIndex=" + 0;
				this.fire('loadContent', {attributes:attributes});
            }
        },

		_loadDots: function (isInitialized) {
			// var to = null;
			var _this = this,
				$ctx = _this.$ctx,
				$wrapper = $ctx.find('.wrapper'),
				minHeight = 1000;

			// if function is called the first time and any teaser contains an
			// image wait until all images are fully loaded, then call function again
			// with flag isInitialized
			if(!isInitialized) {
				var $images = $ctx.find(".row").find("img");
				if($images.length) {
					$images.load(function() {
//						if(to != null) {
//							clearTimeout(to);
//							to = null;

							setTimeout(_this._loadDots(true), 100);
//							_this._loadDots(true);
//						}
					});

					// execute dotdotdot function after 1500 ms if image load event fails
//					to = setTimeout(function() {_this._loadDots(true);}, 1500);
					return;
				}
			}

			// skip dotdot if there are images with height 0
			$.each($ctx.find(".row").find("img"), function() {
				if($(this).height() === 0) {
					return;
				}
			});

			// reset timeout function
//			to = null;
			var execDot = false;

			// find all teaser within a row and set the height to lowest height
			$ctx.find(".row").each(function() {
				var $this = $(this);
				var $teaser = $this.find(".mod-teaser");
				var minimumHeight = 0;
				if($teaser.length) {
					$teaser.each(function() {
						var $this = $(this);
						minHeight = Math.min(minHeight, $this.height());
						minimumHeight = Math.max (minimumHeight, $this.find("img").height());
						var $img = $this.find("img");
						if($img.length && $img.height() == 0) {
							//minimumHeight = Math.max (minimumHeight, 71);
							return;
						}
						var $wrapper = $this.find(".wrapper");
						if($wrapper.length) {
							execDot = true;
							var textMinHeight = $wrapper.position().top + Math.min(71, $wrapper.height() + 5);
							minimumHeight = Math.max(minimumHeight, textMinHeight);
						}

						minHeight = Math.max(minHeight, minimumHeight);
					});
				}
				$this.find(".wrapper").each(function() {
					var $this = $(this);
					$this.css("height", minHeight - $this.position().top);
				});
			});

			// execute elipsis function
			if (execDot) {
				// AEM-282 Prevent text shortening when dialog checkbox is activated for it.
				$wrapper.find('p:not([data-prevent])').dotdotdot({
					elipsis: '...',
					wrap: 'word',
					fallbackToLetter: true,
					height: minHeight	// set height to fix bug on smallest viewport -> dotdotdot plugin removes <p> from DOM without a height
				});
			}

			if($ctx.parents("ul.dropdown-menu").length) {
				$ctx.find(".row").each(function() {
					var $this = $(this);
					var height = $this.height();
					$this.children().css("height", height);
				});
			}
		}
	});
}(Tc.$));

(function ($) {
	"use strict";
	/**
	 * Login module implementation.
	 *
	 * @author  <>
	 * @namespace Tc.Module
	 * @class Nsbabonnement
	 * @extends Tc.Module
	 */
	Tc.Module.Login = Tc.Module.extend({

		init: function ($ctx, sandbox, modId) {
			this._super($ctx, sandbox, modId);
		},

		on: function (callback) {
			Tc.Utils.Lib.initValidation(this.$$('form'));
			callback(); // !do not remove
		},
		
		after: function () {

		}
	});
}(Tc.$));

(function ($) {
	"use strict";
	/**
	 * Video module implementation.
	 *
	 * @author
	 * @namespace Tc.Module
	 * @class Video
	 * @extends Tc.Module
	 */
	Tc.Module.Video = Tc.Module.extend({

		init: function ($ctx, sandbox, modId) {
			this._super($ctx, sandbox, modId);

		},

		on: function (callback) {
			var $iframe = this.$ctx.find("iframe");
			$iframe.css("height", $iframe.width() * 9 / 16);
			
			$(window).on("resize viewportchange", function () {
				$iframe.css("height", $iframe.width() * 9 / 16);
			});
			
			callback(); // !do not remove
		},

		after: function () {
		}
	});
}(Tc.$));

(function($) {
	"use strict";
	/**
	 * Linklist module implementation.
	 *
	 * @author  <>
	 * @namespace Tc.Module
	 * @class Linklist
	 * @extends Tc.Module
	 */
	Tc.Module.Linklist = Tc.Module.extend({
		on: function(callback) {
			var _this = this,
				$ctx = _this.$ctx;

			$ctx.on('change', '.js-linklist-select', function() {
				var opt = $(this).find(':selected'),
					url = opt.data('url') || '',
					target = opt.data('target') || '_blank';

				if (url) {
					if (Tc.Utils.Extensions && Tc.Utils.Extensions.isMobileDevice()) {
						window.location.href = url; // fix for mobile devices
					}
					else {
						window.open(url, target);
					}
				}
			});

			callback(); // !do not remove
		}
	});
}(Tc.$));

(function($) {
	"use strict";
	/**
	 * Twitterstream module implementation.
	 * https://gitlab.namics.com/snippets/2
	 *
	 * @author  <>
	 * @namespace Tc.Module
	 * @class Twitterstream
	 * @extends Tc.Module
	 */
	Tc.Module.Twitterstream = Tc.Module.extend({
		on: function(callback) {
			var _this = this,
				$ctx = _this.$ctx;

			_this._loadTweets();
			_this._refreshTweets();

			callback(); // !do not remove
		},

		_loadTweets: function () {
			var _this = this,
				$ctx = _this.$ctx,
				$timeline = $('.js-twitter-timeline', $ctx),
				$url = $timeline.data('url');
			$url = $url || "";

			if($("body").hasClass("skin-layout-author")) {
				$url += $url.indexOf('?') == -1 ? "?wcmmode=disabled" : "&wcmmode=disabled";
			}
			
			// Load HTML of tweets
			$.ajax({
				type: 'GET',
				url: $url
			}).done(function (data) {
				if ($timeline.html() !== data) {
					$timeline.html(data);
					if(window.BIT_ETRACKER) {
						BIT_ETRACKER.addEvents($ctx);
					}
				}
			});
		},

		_refreshTweets: function () {
			var _this = this,
				$ctx = _this.$ctx,
				$interval = $('.js-twitter-timeline', $ctx).data('time-interval') || 300000;

			// Refresh tweets every 5 minutes
			setInterval(function () {
				_this._loadTweets();
			}, $interval);
		}

	});
}(Tc.$));
(function($) {
	"use strict";
	/**
	 * Iframe module implementation.
	 * https://gitlab.namics.com/snippets/2
	 *
	 * @author Elena Wessolek <elena.wessolek@namics.com>
	 * @contributors Thomas May <thomas.may@namics.com>
	 * @namespace Tc.Module
	 * @class Iframe
	 * @extends Tc.Module
	 */
	Tc.Module.Iframe = Tc.Module.extend({
		on: function(callback) {
			this.bindAll(
				"setCustomHeight"
			);

			$(window).on("load resize", $.debounce(200, this.setCustomHeight));

			callback(); // !do not remove
		},

		setCustomHeight: function (ev) {
			var $win = $(ev.currentTarget),
				$iframe = this.$$("iframe"),
				heightDesktop = $iframe.data("custom-height-desktop"),
				heightTablet = $iframe.data("custom-height-tablet"),
				heightPhone = $iframe.data("custom-height-phone");

			if (heightDesktop && $win.width() >= 992) {
				$iframe.height(heightDesktop);
			} else if (heightTablet && $win.width() >= 767 && $win.width() <= 991) {
				$iframe.height(heightTablet);
			} else if (heightPhone && $win.width() <= 767) {
				$iframe.height(heightPhone);
			}
		}

	});
}(Tc.$));
(function($) {
	"use strict";
	/**
	 * Eventlist module implementation.
	 * https://gitlab.namics.com/snippets/2
	 *
	 * @author Dino Ziermann <dino.ziermann@namics.com>
	 * @namespace Tc.Module
	 * @class Eventlist
	 * @extends Tc.Module
	 */
	Tc.Module.Eventlist = Tc.Module.extend({

		init: function($ctx, sandbox, modId) {
			this._super($ctx, sandbox, modId);
			this.bindAll(
				"onSubmit"
			);
		},

		on: function(callback) {
			this.$$("#eventsFilter").on("submit", this.onSubmit);
			callback(); // !do not remove
		},

		onSubmit: function(ev){
			ev.preventDefault();
			var $eventsFilter = $(ev.currentTarget),
				attributes = $eventsFilter.serialize();
			this.fire('loadContent', {attributes:attributes});
		},

		after: function() {
		}

	});
}(Tc.$));
(function ($) {
    "use strict";
    /**
     * Singlepageapplication module implementation copied from the Iframe module
     * https://gitlab.namics.com/snippets/2
     *
     * @author Raphael Hänni <raphael.haenni@bit.admin.ch>
     * @contributors Matthias Schwarz <matthias.schwarz@bit.admin.ch>
     * @contributors Elena Wessolek <elena.wessolek@namics.com>
     * @contributors Thomas May <thomas.may@namics.com>
     * @contributors Stefan Baur <sbaur@namics.com>
     * @namespace Tc.Module
     * @class Singlepageapplication
     * @extends Tc.Module
     */
    Tc.Module.Singlepageapplication = Tc.Module.extend(
        {

            DEBUG: Tc.Utils.Lib.getUrlParameter("debugSinglePageApplication") == "true",

            UNDEFINED_CUSTOM_HEIGHT: -1, // Pseudo Constant

            on: function (callback) {
                this.$window = $(window);
                this.$iframe = this.$("iframe");

                this.bindAll(
                    "updateIframeHeight"
                );

                callback(); // !do not remove
            },

            after: function () {
                //initially set iframe height to 0
                this.$iframe.height(0);
                this.updateIframeHeight();

                this.$window.on("resize", $.debounce(200, this.updateIframeHeight));
                this.$iframe.on("load", this.updateIframeHeight);
            },

            updateIframeHeight: function (event) {
                this.log("updateIframeHeight - event", event);

                var height = this.determineCustomHeight();

                this.log("updateIframeHeight - custom height", height);

                if (height == this.UNDEFINED_CUSTOM_HEIGHT) {
                    height = this.calculateIframeContentHeight();
                    this.log("updateIframeHeight - calculated height", height);
                }

                this.log("updateIframeHeight - final height", height);

                this.$iframe.height(height);
            },

            calculateIframeContentHeight: function () {
                var content = this.$iframe.contents(),
                    contentHeight = 0;

                try {
                    contentHeight = content.height();
                }
                catch(err) {
                    this.log("calculateIframeContentHeight - Could not calculate height due to error: ", err.message);
                }

                this.log("calculateIframeContentHeight - content", content);
                this.log("calculateIframeContentHeight - contentHeight", contentHeight);

                return contentHeight;
            },

            determineCustomHeight: function () {
                var windowWidth = this.$window.width(),
                    heightDesktop = parseInt(this.$iframe.data('custom-height-desktop'), 10),
                    heightTablet = parseInt(this.$iframe.data('custom-height-tablet'), 10),
                    heightPhone = parseInt(this.$iframe.data('custom-height-phone'), 10),
                    height = this.UNDEFINED_CUSTOM_HEIGHT;

                this.log("determineCustomHeight - windowWidth", windowWidth);
                this.log("determineCustomHeight - heightDesktop", heightDesktop);
                this.log("determineCustomHeight - heightTablet", heightTablet);
                this.log("determineCustomHeight - heightPhone", heightPhone);

                if (heightDesktop && windowWidth >= 992) {
                    height = heightDesktop;
                }
                else if (heightTablet && windowWidth >= 767 && windowWidth <= 991) {
                    height = heightTablet;
                }
                else if (heightPhone && windowWidth <= 767) {
                    height = heightPhone;
                }

                this.log("determineCustomHeight - height", height);

                return height;
            },

            log: function () {
                if (window.console) {
                    if (this.DEBUG) {
                        console.log.apply(console, arguments);
                    }
                }
            }

        });
}(Tc.$));

(function ($) {
	"use strict";
	/**
	 * The Joblist modules fetches a joblist page from jobs.admin.ch
	 *
	 * @author Matthias Schwarz <matthias.schwarz@bit.admin.ch>
	 * @namespace Tc.Module
	 * @class Joblist
	 * @extends Tc.Module
	 */
	Tc.Module.Joblist = Tc.Module.extend(
		{
			DEBUG: Tc.Utils.Lib.getUrlParameter("debugJoblistApplication") == "true",

			gotSizeFromFrame: false,
			lastFrameHeight: 0,

			init: function($ctx, sandbox, modId) {
				this._super($ctx, sandbox, modId);
			},

			on: function (callback) {

				var _this = this;
				var $ctx = _this.$ctx;

				this.$window = $(window);
				this.$div = this.$("div.jobListContent");
				this.$iframe;

				this.bindAll(
					"loadContentToDiv", "iframeFallback", "updateIframeHeight", "log"
				);
				this.authorMode =this.$div.hasClass("authorMode");
				this.gotSizeFromFrame = false;

				callback(); // !do not remove
			},

			after: function () {

				var dataUrl = this.$div.data('url');
				this.loadContentToDiv(dataUrl, this.$div[0]);

				this.log("at the end of after()");
			},

			loadContentToDiv: function(url, targetElement) {

				url = url || "";
				var _this = this;
				var _targetElement = targetElement; // we need a var for the closure

				if (url) {
					$.ajax({
						type: 'GET',
						url: url

					}).done(function (data) {

						var extractBody = /^[\s\S]*<body>([\s\S]+)<\/body>[\s\S]*$/;
						var match = extractBody.exec(data);

						// we skip documents with head but without resp. with an empty body
						if (match || data.indexOf('<head>') == -1) {
							var jobListDom = match ? $(match[1]) : $(data);
							jobListDom.find('script').remove();
							jobListDom.appendTo(_targetElement);
						}  else {
							_this.log("loadContentToDiv(): skipping response from "+url+" because we got a head without a body!");
						}

					}).error(function (request, status, errorThrown) {

						var errorTxt = "loadContentToDiv() could NOT load "+url+" Status:"+ status;
						_this.log(errorTxt);
						_this.iframeFallback(errorTxt);
					})
				}
			},

			iframeFallback: function(errorText) {

				if (this.authorMode) {

					this.log("iframeFallback() does work on author --> we display an error message");

					this.$div.text(errorText);

				} else { // we running on a publish instance

					this.log("use an iframe with document.domain='admin.ch' to display the joblist");

					var idNumber = this.$div[0].id.replace(/^.*[^0-9]([0-9]+)$/, '$1');
					try {
						var iframeId = "generated-iframe-"+idNumber;
						this.$iframe = this.$div.append("<iframe id='"+iframeId+"'/>");

						this.$iframe = $("#"+iframeId);
						this.$iframe.attr('height',10).attr('scrolling','no').attr('src',this.$div.data('url'));
						this.$iframe.css('width','100%').css('border',0).css('padding',0).css('margin',0);

						document.domain = 'admin.ch';
						this.$window.on("resize", $.debounce(200, this.updateIframeHeight));
						this.$iframe.on("load", this.updateIframeHeight);
						this.updateIframeHeight();

					} catch(err) { // we provide a link, if iframes are not supported by the browser

						var linkHref = this.$div.data('url');
						var linkText = $('#joblist-title-'+idNumber).text();
						linkText = linkText ? linkText : linkHref;
						this.$div.append("<a href='"+linkHref+"'>"+linkText+'</a>');
					}
				}
			},

			updateIframeHeight: function (event) {

				try {
					var height = this.$iframe.contents().height();
					this.log("updateIframeHeight - setting height "+ height);
					this.$iframe.height(height);
				}
				catch(err) {
					this.log("updateIframeHeight - Could not determine height due to error: "+err.message);
				}
			},

			log: function () {
				if (window.console) {
					if (this.DEBUG) {
						console.log.apply(console, arguments);
					}
				}
			}
		});
}(Tc.$));

